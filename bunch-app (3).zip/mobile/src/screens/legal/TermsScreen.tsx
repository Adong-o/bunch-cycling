import React from 'react';
import { LegalDocument, type LegalSection } from '@/components/legal/LegalDocument';
import { PREMIUM_MONTHLY_PRICE } from '@/lib/pricing';
import type { AuthScreenProps, ProfileScreenProps } from '@/navigation/types';

const SECTIONS: LegalSection[] = [
  {
    heading: '1. Agreement to these terms',
    body: [
      'These Terms of Service ("Terms") govern your use of Bunch, a cycling ride-tracking app operated by [Legal entity name] ("Bunch," "we," "us"). By creating an account or using the app, you agree to these Terms. If you don\'t agree, please don\'t use Bunch.',
    ],
  },
  {
    heading: '2. The service',
    body: [
      'Bunch lets you record rides using your phone\'s GPS, track distance, elevation, speed and streaks, follow other riders, tag who you rode with, create or join challenges, race segments, and keep a garage of your bikes. Some features are free; others require a Bunch Premium subscription, described below.',
    ],
  },
  {
    heading: '3. Your account',
    body: [
      '• You must provide accurate information when you register and keep your login credentials secure.',
      '• You\'re responsible for all activity under your account. Tell us right away at adongoabc@proton.me if you suspect unauthorized access.',
      '• You must be at least 13 years old (or the minimum age in your country) to use Bunch.',
      '• One account per person — don\'t create accounts to impersonate someone else or evade a suspension.',
    ],
  },
  {
    heading: '4. Bunch Premium',
    body: [
      `Bunch Premium is an optional paid subscription, currently priced at ${PREMIUM_MONTHLY_PRICE}/month (or the equivalent in your local currency), that removes the free plan's limits on bikes, saved routes, starred segments, recording devices, and self-created challenges.`,
      'Subscriptions renew automatically each billing period unless cancelled before the renewal date, through whichever payment method or app store account you subscribed with. Pricing and available plans may change with advance notice; changes apply from your next billing cycle.',
      'We don\'t generally offer refunds for partial subscription periods, except where required by law or by the app store you subscribed through. During early access, Premium may also be granted directly by Bunch administrators rather than through a paid subscription.',
    ],
  },
  {
    heading: '5. Your content',
    body: [
      'You keep ownership of the rides, photos, comments, routes, segments and everything else you create in Bunch ("your content"). By posting content with a visibility setting broader than private, you grant other riders who can see it the ability to view it within the app, and you grant Bunch the license needed to store, process and display it back to you and to those riders as part of operating the service.',
      'Tagging another rider on a ride shares that ride with them regardless of its visibility setting, so they can see it was recorded. Any rider you tag can remove the tag themselves at any time.',
      'You\'re responsible for what you post. Don\'t upload content you don\'t have the rights to, or content that is illegal, infringing, or violates someone else\'s privacy.',
    ],
  },
  {
    heading: '6. Rider conduct',
    body: [
      'Be decent to other riders. You agree not to:',
      '• Harass, threaten, or abuse other users.',
      '• Post false, misleading, or fraudulent ride data (for example, to win a challenge or segment leaderboard you didn\'t actually ride).',
      '• Tag another rider on a ride they weren\'t actually part of.',
      '• Upload content that is hateful, obscene, or infringes someone else\'s intellectual property.',
      '• Attempt to access another rider\'s account, scrape the service, or interfere with its normal operation.',
      '• Use Bunch for any unlawful purpose.',
      'We may remove content or suspend accounts that violate these Terms.',
    ],
  },
  {
    heading: '7. Ride safely — assumption of risk',
    body: [
      'Cycling carries inherent risks, including from traffic, road and trail conditions, weather, and equipment. Bunch\'s GPS tracking, maps, routes and segments are for recreational and informational purposes only — they are not a substitute for your own judgment, local traffic laws, or situational awareness, and GPS data can be inaccurate or incomplete.',
      'You are solely responsible for your own safety and the safety of others while riding, including obeying traffic laws and riding within your ability. Use Bunch at your own risk.',
    ],
  },
  {
    heading: '8. Disclaimers',
    body: [
      'Bunch is provided "as is" and "as available," without warranties of any kind, express or implied, including fitness for a particular purpose or non-infringement. We don\'t guarantee the service will be uninterrupted, error-free, or that ride statistics (distance, elevation, calories, etc.) will be perfectly accurate — they\'re estimates based on phone GPS and the information you provide.',
    ],
  },
  {
    heading: '9. Limitation of liability',
    body: [
      'To the fullest extent permitted by law, Bunch and its team won\'t be liable for any indirect, incidental, or consequential damages arising from your use of the app, including any injury sustained while cycling. Our total liability for any claim relating to the service is limited to the amount you paid us, if any, in the 12 months before the claim arose.',
    ],
  },
  {
    heading: '10. Termination',
    body: [
      'You can stop using Bunch and delete your account at any time. We may suspend or terminate your account if you violate these Terms, with notice where reasonably possible. Sections of these Terms that by their nature should survive termination (like content licenses already granted, disclaimers, and limitation of liability) will continue to apply.',
    ],
  },
  {
    heading: '11. Changes to these terms',
    body: [
      'We may update these Terms as Bunch evolves. We\'ll notify you of material changes in the app or by email before they take effect; continuing to use Bunch after that means you accept the updated Terms.',
    ],
  },
  {
    heading: '12. Governing law',
    body: [
      'These Terms are governed by the laws of [Governing jurisdiction], without regard to conflict-of-law principles, unless a different law is required by your local consumer protection rules.',
    ],
  },
  {
    heading: '13. Contact us',
    body: ['Questions about these Terms? Reach us at adongoabc@proton.me.'],
  },
];

const INTRO = 'Please read these Terms carefully — they cover your Bunch account, Bunch Premium billing, rider conduct, and the risks of cycling itself.';

export function TermsScreen({ navigation }: AuthScreenProps<'Terms'> | ProfileScreenProps<'Terms'>) {
  return <LegalDocument navigation={navigation} title="Terms of Service" lastUpdated="October 17, 2026" intro={INTRO} sections={SECTIONS} />;
}
