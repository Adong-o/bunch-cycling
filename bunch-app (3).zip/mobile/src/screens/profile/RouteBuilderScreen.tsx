import React, { useMemo, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Camera, CircleLayer, LineLayer, MapView, ShapeSource, UserLocation } from '@maplibre/maplibre-react-native';
import { Ionicons } from '@expo/vector-icons';
import { MapAttribution } from '@/components/map/MapAttribution';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/TextField';
import { useAuthStore } from '@/state/authStore';
import { createRoute } from '@/lib/api/routes';
import { getErrorMessage } from '@/lib/errors';
import { haversineDistanceM } from '@/lib/geo';
import { formatDistance } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { RoutesScreenProps } from '@/navigation/types';
import type { RouteGeoJSON, SurfaceType } from '@/lib/database.types';

// Same free, no-API-key tile source already proven in components/RideMap.tsx.
const STYLE_URL = 'https://tiles.openfreemap.org/styles/liberty';

const SURFACE_OPTIONS: Array<{ value: SurfaceType; label: string }> = [
  { value: 'paved', label: 'Paved' },
  { value: 'gravel', label: 'Gravel' },
  { value: 'mixed', label: 'Mixed' },
  { value: 'dirt', label: 'Dirt' },
];

interface Point {
  lat: number;
  lng: number;
}

export function RouteBuilderScreen({ navigation }: RoutesScreenProps<'RouteBuilder'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cameraRef = useRef<any>(null);

  // Two phases: "navigate" lets you pan/pinch-zoom freely to find where you
  // want to start (taps don't place anything, so exploring never leaves a
  // stray point behind); "drawing" is the original tap-to-extend behavior.
  // A double-tap in navigate mode jumps straight into drawing at that spot;
  // the "Start drawing" pill below is the reliable fallback for anyone whose
  // double-tap gets eaten by the map's own built-in double-tap-to-zoom.
  const [mode, setMode] = useState<'navigate' | 'drawing'>('navigate');
  const lastTapAtRef = useRef(0);

  const [points, setPoints] = useState<Point[]>([]);
  const [showSaveForm, setShowSaveForm] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [surfaceType, setSurfaceType] = useState<SurfaceType>('paved');
  const [isPublic, setIsPublic] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const totalDistanceM = useMemo(() => {
    let d = 0;
    for (let i = 1; i < points.length; i++) d += haversineDistanceM(points[i - 1], points[i]);
    return d;
  }, [points]);

  const lineGeoJSON = useMemo(
    () =>
      points.length > 1
        ? {
            type: 'Feature' as const,
            properties: {},
            geometry: { type: 'LineString' as const, coordinates: points.map((p) => [p.lng, p.lat]) },
          }
        : null,
    [points]
  );

  const pointsGeoJSON = useMemo(
    () =>
      points.length > 0
        ? {
            type: 'FeatureCollection' as const,
            features: points.map((p) => ({
              type: 'Feature' as const,
              properties: {},
              geometry: { type: 'Point' as const, coordinates: [p.lng, p.lat] },
            })),
          }
        : null,
    [points]
  );

  // Untyped on purpose, same reasoning as RideMap.tsx: this library's own TS
  // defs can't be verified against an installed copy in this sandbox.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function onMapPress(e: any) {
    const [lng, lat] = e.geometry.coordinates as [number, number];

    if (mode === 'navigate') {
      const now = Date.now();
      if (now - lastTapAtRef.current < 350) {
        lastTapAtRef.current = 0;
        startDrawingAt({ lat, lng });
      } else {
        lastTapAtRef.current = now;
      }
      return;
    }

    setPoints((prev) => [...prev, { lat, lng }]);
  }

  function startDrawingAt(point: Point) {
    setMode('drawing');
    setPoints([point]);
  }

  function onUndo() {
    setPoints((prev) => {
      const next = prev.slice(0, -1);
      // Undid the only point — drop back to free pan/zoom instead of sitting
      // in an empty "drawing" mode where the next tap would place a point.
      if (next.length === 0) setMode('navigate');
      return next;
    });
  }

  function onClose() {
    if (points.length === 0) {
      navigation.goBack();
      return;
    }
    Alert.alert('Discard this route?', "The points you've placed will be lost.", [
      { text: 'Keep drawing', style: 'cancel' },
      { text: 'Discard', style: 'destructive', onPress: () => navigation.goBack() },
    ]);
  }

  async function onSaveRoute() {
    if (!profile || points.length < 2) return;
    if (!name.trim()) {
      setFormError('Give your route a name.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const route_geojson: RouteGeoJSON = { type: 'LineString', coordinates: points.map((p) => [p.lng, p.lat]) };
      await createRoute({
        user_id: profile.id,
        name: name.trim(),
        description: description.trim(),
        distance_m: totalDistanceM,
        // Deliberately 0, not estimated — there's no terrain/elevation API in
        // this app, so a hand-drawn route can't honestly claim an elevation
        // figure. See the note shown in the save form below.
        elevation_gain_m: 0,
        route_geojson,
        surface_type: surfaceType,
        is_public: isPublic,
        created_from_ride_id: null,
      });
      navigation.goBack();
    } catch (e) {
      setFormError(getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  return (
    <View style={styles.root}>
      <MapView
        style={StyleSheet.absoluteFillObject}
        mapStyle={STYLE_URL}
        logoEnabled={false}
        attributionEnabled={false}
        onPress={onMapPress}
      >
        <Camera
          ref={cameraRef}
          followUserLocation={mode === 'navigate'}
          followUserMode="normal"
          followZoomLevel={14}
          animationMode="flyTo"
          animationDuration={600}
        />
        <UserLocation visible showsUserHeadingIndicator />
        {lineGeoJSON ? (
          <ShapeSource id="routeBuilderLine" shape={lineGeoJSON}>
            <LineLayer id="routeBuilderLineLayer" style={{ lineColor: colors.accent, lineWidth: 4, lineCap: 'round', lineJoin: 'round' }} />
          </ShapeSource>
        ) : null}
        {pointsGeoJSON ? (
          <ShapeSource id="routeBuilderPoints" shape={pointsGeoJSON}>
            <CircleLayer
              id="routeBuilderPointsLayer"
              style={{ circleColor: colors.accent, circleRadius: 5, circleStrokeColor: '#FFFFFF', circleStrokeWidth: 2 }}
            />
          </ShapeSource>
        ) : null}
      </MapView>

      <MapAttribution />

      <SafeAreaView edges={['top']} style={styles.topOverlay} pointerEvents="box-none">
        <Pressable onPress={onClose} hitSlop={10} style={styles.closeButton}>
          <Ionicons name="close" size={22} color={colors.textPrimary} />
        </Pressable>
        {!showSaveForm ? (
          <View style={styles.hintPill}>
            <Text style={styles.hintPillText}>
              {mode === 'navigate'
                ? 'Pan and zoom to where you want to start, then double-tap the map'
                : points.length === 1
                  ? 'Keep tapping to extend your route'
                  : 'Keep tapping to extend it'}
            </Text>
          </View>
        ) : null}
      </SafeAreaView>

      <SafeAreaView edges={['bottom']} style={styles.bottomOverlay} pointerEvents="box-none">
        {showSaveForm ? null : mode === 'navigate' ? (
          <Pressable onPress={() => setMode('drawing')} style={styles.startDrawingButton}>
            <Ionicons name="create-outline" size={18} color={colors.textOnAccent} />
            <Text style={styles.startDrawingLabel}>Start drawing</Text>
          </Pressable>
        ) : (
          <View style={styles.statsCard}>
            <View style={styles.statsRow}>
              <View>
                <Text style={styles.statValue}>{formatDistance(totalDistanceM, units)}</Text>
                <Text style={styles.statLabel}>DISTANCE</Text>
              </View>
              <View>
                <Text style={styles.statValue}>{points.length}</Text>
                <Text style={styles.statLabel}>POINTS</Text>
              </View>
            </View>
            <View style={styles.actionsRow}>
              <Button title="Undo" variant="secondary" onPress={onUndo} disabled={points.length === 0} fullWidth={false} style={styles.undoButton} />
              <Button title="Save route" onPress={() => setShowSaveForm(true)} disabled={points.length < 2} fullWidth={false} style={styles.saveTriggerButton} />
            </View>
          </View>
        )}
        {showSaveForm && (
          <View style={styles.formCard}>
            <Text style={styles.formTitle}>Save route</Text>
            <TextField label="Name" value={name} onChangeText={setName} placeholder="e.g. Riverside loop" />
            <TextField label="Description (optional)" value={description} onChangeText={setDescription} placeholder="Notes about this route" />
            <View>
              <Text style={styles.label}>Surface</Text>
              <View style={styles.chipRow}>
                {SURFACE_OPTIONS.map((opt) => (
                  <Pressable
                    key={opt.value}
                    onPress={() => setSurfaceType(opt.value)}
                    style={[styles.chip, surfaceType === opt.value && styles.chipActive]}
                  >
                    <Text style={[styles.chipLabel, surfaceType === opt.value && styles.chipLabelActive]}>{opt.label}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
            <View>
              <Text style={styles.label}>Visibility</Text>
              <View style={styles.chipRow}>
                <Pressable onPress={() => setIsPublic(false)} style={[styles.chip, !isPublic && styles.chipActive]}>
                  <Ionicons name="lock-closed-outline" size={13} color={!isPublic ? colors.accent : colors.textSecondary} />
                  <Text style={[styles.chipLabel, !isPublic && styles.chipLabelActive]}>Private</Text>
                </Pressable>
                <Pressable onPress={() => setIsPublic(true)} style={[styles.chip, isPublic && styles.chipActive]}>
                  <Ionicons name="earth-outline" size={13} color={isPublic ? colors.accent : colors.textSecondary} />
                  <Text style={[styles.chipLabel, isPublic && styles.chipLabelActive]}>Public</Text>
                </Pressable>
              </View>
              <Text style={styles.visibilityHint}>
                {isPublic ? 'Anyone can find and ride this route.' : 'Only you can see this route.'}
              </Text>
            </View>
            <Text style={styles.elevationNote}>
              Elevation isn't available for hand-drawn routes — it's calculated automatically for routes saved from a recorded
              ride.
            </Text>
            {formError ? <Text style={styles.error}>{formError}</Text> : null}
            <View style={styles.formActions}>
              <Button title="Back" variant="ghost" onPress={() => setShowSaveForm(false)} fullWidth={false} />
              <Button title="Save" onPress={onSaveRoute} loading={saving} fullWidth={false} style={styles.saveButton} />
            </View>
          </View>
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },

  topOverlay: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.md, paddingTop: spacing.sm, gap: spacing.sm },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.overlay,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hintPill: { flex: 1, backgroundColor: colors.overlay, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 10 },
  hintPillText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textPrimary, textAlign: 'center' },

  bottomOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, paddingHorizontal: spacing.md, paddingBottom: spacing.md, gap: spacing.sm },

  startDrawingButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.accent,
    borderRadius: radius.pill,
    paddingVertical: 15,
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  startDrawingLabel: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textOnAccent },

  statsCard: {
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    padding: spacing.md,
    gap: spacing.sm,
  },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around' },
  statValue: { ...typeTokens.statMedium, color: colors.textPrimary, textAlign: 'center' },
  statLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary, textAlign: 'center', marginTop: 2, letterSpacing: 0.3 },
  actionsRow: { flexDirection: 'row', gap: spacing.sm },
  undoButton: { flex: 1 },
  saveTriggerButton: { flex: 2 },

  formCard: {
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    padding: spacing.md,
    gap: spacing.sm,
  },
  formTitle: { ...typeTokens.h3, color: colors.textPrimary },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.2 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  chipLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  chipLabelActive: { color: colors.accent },
  visibilityHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 6 },
  elevationNote: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, lineHeight: 17 },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 13 },
  formActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: spacing.sm },
  saveButton: { paddingHorizontal: spacing.xl },
});
