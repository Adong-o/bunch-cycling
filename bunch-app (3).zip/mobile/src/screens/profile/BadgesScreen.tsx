import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { LoadingView } from '@/components/ui/LoadingView';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { listAllBadges, listMyBadges } from '@/lib/api/badges';
import { colors, fonts, radius, shadow, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Badge } from '@/lib/database.types';

export function BadgesScreen({ navigation }: ProfileScreenProps<'Badges'>) {
  const profile = useAuthStore((s) => s.profile);
  const { width } = useWindowDimensions();
  // Two columns, sized in whole pixels — a '48%' width plus a gap can add up to a hair over 100% and wrap to one column.
  const cardWidth = Math.floor((width - spacing.md * 2 - spacing.sm) / 2);
  const [allBadges, setAllBadges] = useState<Badge[]>([]);
  const [awarded, setAwarded] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!profile) return;
    Promise.all([listAllBadges(), listMyBadges(profile.id)])
      .then(([badges, mine]) => {
        setAllBadges(badges);
        const map: Record<string, string> = {};
        for (const m of mine) map[m.badge_id] = m.awarded_at;
        setAwarded(map);
      })
      .catch(() => setFailed(true))
      .finally(() => setLoading(false));
  }, [profile]);

  if (loading) return <LoadingView />;

  const earnedCount = allBadges.filter((b) => awarded[b.id]).length;
  // Earned first (newest first), then the ones still to win in their catalogue order.
  const sorted = [...allBadges].sort((a, b) => {
    const ea = awarded[a.id];
    const eb = awarded[b.id];
    if (ea && eb) return eb.localeCompare(ea);
    if (ea) return -1;
    if (eb) return 1;
    return 0;
  });

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Back">
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Badges</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {failed || allBadges.length === 0 ? (
          <EmptyState icon={<Ionicons name="ribbon-outline" size={32} color={colors.textTertiary} />} title="Couldn't load badges" description="Check your connection and open this screen again." />
        ) : (
          <>
            <View style={styles.progressCard}>
              <View style={styles.progressTop}>
                <Text style={styles.progressTitle}>
                  <Text style={styles.progressCount}>{earnedCount}</Text> of {allBadges.length} earned
                </Text>
                <Text style={styles.progressHint}>{earnedCount === allBadges.length ? 'All collected' : `${allBadges.length - earnedCount} to go`}</Text>
              </View>
              <ProgressBar progress={allBadges.length ? earnedCount / allBadges.length : 0} color={colors.gold} trackColor={colors.goldMuted} height={8} />
            </View>

            <View style={styles.grid}>
              {sorted.map((badge) => {
                const earnedAt = awarded[badge.id];
                const isEarned = !!earnedAt;
                return (
                  <View
                    key={badge.id}
                    style={[styles.badgeCard, { width: cardWidth }, isEarned ? styles.badgeCardEarned : styles.badgeCardLocked]}
                    accessible
                    accessibilityLabel={`${badge.name}. ${isEarned ? 'Earned' : 'Not earned yet'}. ${badge.description}`}
                  >
                    <View style={[styles.badgeIcon, isEarned && styles.badgeIconEarned]}>
                      <Text style={[styles.badgeEmoji, !isEarned && styles.badgeEmojiLocked]}>{badge.icon}</Text>
                      {!isEarned ? (
                        <View style={styles.lock}>
                          <Ionicons name="lock-closed" size={10} color={colors.textSecondary} />
                        </View>
                      ) : null}
                    </View>
                    <Text style={[styles.badgeName, !isEarned && styles.badgeNameLocked]} numberOfLines={2}>
                      {badge.name}
                    </Text>
                    <Text style={styles.badgeDescription}>{badge.description}</Text>
                    {isEarned ? <Text style={styles.badgeDate}>Earned {format(new Date(earnedAt), 'MMM d, yyyy')}</Text> : <Text style={styles.badgeToGo}>Not yet</Text>}
                  </View>
                );
              })}
            </View>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { paddingBottom: spacing.xxl },
  progressCard: {
    marginHorizontal: spacing.md,
    marginTop: spacing.xs,
    padding: spacing.md,
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadow.card,
  },
  progressTop: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' },
  progressTitle: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textSecondary },
  progressCount: { fontFamily: fonts.extraBold, fontSize: 24, color: colors.textPrimary },
  progressHint: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.gold },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: spacing.md, paddingTop: spacing.md, gap: spacing.sm },
  badgeCard: { alignItems: 'center', gap: 4, paddingVertical: spacing.md, paddingHorizontal: spacing.sm, borderRadius: radius.lg, borderWidth: 1 },
  badgeCardEarned: { backgroundColor: colors.surface, borderColor: colors.border, ...shadow.card },
  // Locked badges stay fully legible — dimming the whole card made the names and
  // descriptions unreadable. Only the emblem is muted; a small padlock says "not yet".
  badgeCardLocked: { backgroundColor: colors.surfaceHigh, borderColor: colors.border },
  badgeIcon: { width: 56, height: 56, borderRadius: radius.pill, backgroundColor: colors.surfaceHighest, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  badgeIconEarned: { backgroundColor: colors.goldMuted },
  // Each badge's own icon is a real emoji (badges.icon in the DB), not an Ionicons glyph.
  badgeEmoji: { fontSize: 28 },
  badgeEmojiLocked: { opacity: 0.4 },
  lock: { position: 'absolute', right: -2, bottom: -2, width: 20, height: 20, borderRadius: 10, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.borderStrong, alignItems: 'center', justifyContent: 'center' },
  badgeName: { fontFamily: fonts.bold, fontSize: 14, color: colors.textPrimary, textAlign: 'center' },
  badgeNameLocked: { color: colors.textSecondary },
  badgeDescription: { fontFamily: fonts.regular, fontSize: 12, color: colors.textSecondary, textAlign: 'center', lineHeight: 17 },
  badgeDate: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.gold, marginTop: 4 },
  badgeToGo: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.textTertiary, marginTop: 4 },
});
