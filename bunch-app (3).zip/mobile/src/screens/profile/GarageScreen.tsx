import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Pill } from '@/components/ui/Pill';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { listBikes, createBike, updateBike, deleteBike, FREE_BIKE_LIMIT } from '@/lib/api/bikes';
import { getErrorMessage } from '@/lib/errors';
import { formatDistance } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Bike, BikeType } from '@/lib/database.types';

const BIKE_TYPES: Array<{ value: BikeType; label: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { value: 'road', label: 'Road', icon: 'bicycle-outline' },
  { value: 'gravel', label: 'Gravel', icon: 'bicycle-outline' },
  { value: 'mountain', label: 'Mountain', icon: 'bicycle-outline' },
  { value: 'commuter', label: 'Commuter', icon: 'bicycle-outline' },
  { value: 'ebike', label: 'E-Bike', icon: 'flash-outline' },
  { value: 'other', label: 'Other', icon: 'ellipsis-horizontal-outline' },
];

export function GarageScreen({ navigation }: ProfileScreenProps<'Garage'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [bikes, setBikes] = useState<Bike[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<BikeType>('gravel');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    if (!profile) return;
    try {
      setBikes(await listBikes(profile.id));
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const activeBikes = bikes.filter((b) => !b.is_retired);
  const atCap = !profile?.is_premium && activeBikes.length >= FREE_BIKE_LIMIT;

  async function onAddBike() {
    if (!profile || !newName.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const bike = await createBike({
        user_id: profile.id,
        name: newName.trim(),
        type: newType,
        is_default: bikes.length === 0,
      });
      setBikes((prev) => [...prev, bike]);
      setNewName('');
      setNewType('gravel');
      setAdding(false);
    } catch (e) {
      // The DB's own free-plan-limit message already reads as a friendly,
      // complete sentence ("Free plan is limited to 2 bikes. Upgrade to
      // Bunch Premium to add more."), so it needs no special-casing here.
      setError(getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  async function onSetDefault(bike: Bike) {
    const previousDefault = bikes.find((b) => b.is_default && b.id !== bike.id);
    setBikes((prev) => prev.map((b) => ({ ...b, is_default: b.id === bike.id })));
    try {
      if (previousDefault) await updateBike(previousDefault.id, { is_default: false });
      await updateBike(bike.id, { is_default: true });
    } catch (e) {
      await load();
      Alert.alert('Could not set default bike', getErrorMessage(e));
    }
  }

  async function onToggleRetired(bike: Bike) {
    const next = !bike.is_retired;
    setBikes((prev) => prev.map((b) => (b.id === bike.id ? { ...b, is_retired: next } : b)));
    try {
      await updateBike(bike.id, { is_retired: next });
    } catch (e) {
      await load();
      Alert.alert('Could not update bike', getErrorMessage(e));
    }
  }

  function onDelete(bike: Bike) {
    Alert.alert('Remove this bike?', `"${bike.name}" will be removed from your garage. Past rides keep their stats.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          const previous = bikes;
          setBikes((prev) => prev.filter((b) => b.id !== bike.id));
          try {
            await deleteBike(bike.id);
          } catch (e) {
            setBikes(previous);
            Alert.alert('Could not remove bike', getErrorMessage(e));
          }
        },
      },
    ]);
  }

  if (loading) return <LoadingView />;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Garage</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        {bikes.length === 0 ? (
          <EmptyState icon={<Ionicons name="bicycle-outline" size={32} color={colors.textTertiary} />} title="No bikes yet" description="Add a bike to track distance per bike and pick it when you save a ride." />
        ) : (
          <View style={styles.list}>
            {bikes.map((bike) => (
              <Card key={bike.id} style={[styles.bikeCard, bike.is_retired && styles.bikeCardRetired]}>
                <View style={styles.bikeRow}>
                  <View style={styles.bikeIcon}>
                    <Ionicons name={BIKE_TYPES.find((t) => t.value === bike.type)?.icon ?? 'bicycle-outline'} size={20} color={colors.accent} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={styles.bikeNameRow}>
                      <Text style={styles.bikeName}>{bike.name}</Text>
                      {bike.is_default ? <Pill label="Default" tone="accent" /> : null}
                      {bike.is_retired ? <Pill label="Retired" tone="neutral" /> : null}
                    </View>
                    <Text style={styles.bikeMeta}>
                      {formatDistance(bike.total_distance_m, units)} · {bike.total_rides} ride{bike.total_rides === 1 ? '' : 's'}
                    </Text>
                  </View>
                </View>
                <View style={styles.bikeActions}>
                  {!bike.is_default && !bike.is_retired ? (
                    <Pressable onPress={() => onSetDefault(bike)} style={styles.bikeActionButton}>
                      <Text style={styles.bikeActionLabel}>Set default</Text>
                    </Pressable>
                  ) : null}
                  <Pressable onPress={() => onToggleRetired(bike)} style={styles.bikeActionButton}>
                    <Text style={styles.bikeActionLabel}>{bike.is_retired ? 'Reactivate' : 'Retire'}</Text>
                  </Pressable>
                  <Pressable onPress={() => onDelete(bike)} style={styles.bikeActionButton}>
                    <Text style={[styles.bikeActionLabel, { color: colors.danger }]}>Remove</Text>
                  </Pressable>
                </View>
              </Card>
            ))}
          </View>
        )}

        {adding ? (
          <Card style={styles.addCard}>
            <TextField label="Bike name" value={newName} onChangeText={setNewName} placeholder="e.g. The Gravel Grinder" />
            <View style={styles.typeRow}>
              {BIKE_TYPES.map((t) => (
                <Pressable key={t.value} onPress={() => setNewType(t.value)} style={[styles.typeChip, newType === t.value && styles.typeChipActive]}>
                  <Text style={[styles.typeChipLabel, newType === t.value && styles.typeChipLabelActive]}>{t.label}</Text>
                </Pressable>
              ))}
            </View>
            {error ? <Text style={styles.error}>{error}</Text> : null}
            <View style={styles.addActions}>
              <Button title="Cancel" variant="ghost" fullWidth={false} onPress={() => setAdding(false)} />
              <Button title="Add bike" onPress={onAddBike} loading={saving} fullWidth={false} style={{ paddingHorizontal: spacing.xl }} />
            </View>
          </Card>
        ) : (
          <Button
            title={atCap ? 'Free plan: 2/2 bikes' : 'Add a bike'}
            variant="secondary"
            onPress={() => (atCap ? null : setAdding(true))}
            disabled={atCap}
            style={styles.addButton}
          />
        )}
        {atCap ? <Text style={styles.capHint}>Bunch Premium unlocks unlimited bikes.</Text> : null}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { padding: spacing.md, paddingBottom: spacing.xxl, gap: spacing.md },
  list: { gap: spacing.sm },
  bikeCard: { gap: spacing.sm },
  bikeCardRetired: { opacity: 0.6 },
  bikeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  bikeIcon: {
    width: 42,
    height: 42,
    borderRadius: radius.sm,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bikeNameRow: { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' },
  bikeName: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  bikeMeta: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  bikeActions: { flexDirection: 'row', gap: spacing.md, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm },
  bikeActionButton: {},
  bikeActionLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  addCard: { gap: spacing.sm },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  typeChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceHigh },
  typeChipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  typeChipLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  typeChipLabelActive: { color: colors.accent, fontFamily: fonts.semiBold },
  addActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: spacing.sm },
  addButton: {},
  capHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center' },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 13 },
});
