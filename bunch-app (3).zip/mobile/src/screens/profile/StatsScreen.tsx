import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { Easing, FadeInUp, useAnimatedStyle, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { SpeedometerIcon } from '@/components/icons/HeroIcons';
import { useAuthStore } from '@/state/authStore';
import { supabase } from '@/lib/supabase';
import { formatDistance, formatDuration, formatElevation } from '@/lib/units';
import { colors, fonts, radius, shadow, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';

interface RideStatRow {
  distance_m: number;
  moving_time_s: number;
  elevation_gain_m: number;
  started_at: string;
  bike_id: string | null;
}

interface WeekBucket {
  label: string;
  distanceM: number;
}

/** Monday-start week bucket, in UTC so a rider's local timezone can't shift a ride into the wrong week near midnight. */
function isoWeekStart(d: Date): Date {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = date.getUTCDay(); // 0 = Sunday
  const diff = (day === 0 ? -6 : 1) - day;
  date.setUTCDate(date.getUTCDate() + diff);
  return date;
}

export function StatsScreen({ navigation }: ProfileScreenProps<'Stats'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [rides, setRides] = useState<RideStatRow[] | null>(null);
  const [ebikeBikeIds, setEbikeBikeIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    let cancelled = false;
    (async () => {
      try {
        const [{ data: rideRows, error: rideErr }, { data: bikeRows, error: bikeErr }] = await Promise.all([
          supabase
            .from('rides')
            .select('distance_m, moving_time_s, elevation_gain_m, started_at, bike_id')
            .eq('user_id', profile.id),
          supabase.from('bikes').select('id, type').eq('user_id', profile.id),
        ]);
        if (rideErr) throw rideErr;
        if (bikeErr) throw bikeErr;
        if (cancelled) return;
        setRides(rideRows ?? []);
        setEbikeBikeIds(new Set((bikeRows ?? []).filter((b) => b.type === 'ebike').map((b) => b.id)));
      } catch {
        if (!cancelled) setError('Could not load your stats.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [profile]);

  const stats = useMemo(() => {
    if (!rides) return null;

    let totalDistanceM = 0;
    let totalMovingS = 0;
    let totalElevationM = 0;
    let ebikeDistanceM = 0;
    let ebikeMovingS = 0;
    let acousticDistanceM = 0;
    let acousticMovingS = 0;
    let longestRideM = 0;
    let biggestClimbM = 0;

    const weekMap = new Map<string, number>();

    for (const r of rides) {
      totalDistanceM += r.distance_m;
      totalMovingS += r.moving_time_s;
      totalElevationM += r.elevation_gain_m;
      if (r.distance_m > longestRideM) longestRideM = r.distance_m;
      if (r.elevation_gain_m > biggestClimbM) biggestClimbM = r.elevation_gain_m;

      const isEbike = r.bike_id != null && ebikeBikeIds.has(r.bike_id);
      if (isEbike) {
        ebikeDistanceM += r.distance_m;
        ebikeMovingS += r.moving_time_s;
      } else {
        acousticDistanceM += r.distance_m;
        acousticMovingS += r.moving_time_s;
      }

      const weekKey = isoWeekStart(new Date(r.started_at)).toISOString().slice(0, 10);
      weekMap.set(weekKey, (weekMap.get(weekKey) ?? 0) + r.distance_m);
    }

    // Last 8 ISO weeks including the current one, oldest first, zero-filled.
    const weeks: WeekBucket[] = [];
    const currentWeekStart = isoWeekStart(new Date());
    for (let i = 7; i >= 0; i--) {
      const ws = new Date(currentWeekStart);
      ws.setUTCDate(ws.getUTCDate() - i * 7);
      const key = ws.toISOString().slice(0, 10);
      weeks.push({ label: `${ws.getUTCMonth() + 1}/${ws.getUTCDate()}`, distanceM: weekMap.get(key) ?? 0 });
    }

    const thisWeekM = weeks[weeks.length - 1]?.distanceM ?? 0;
    const lastWeekM = weeks[weeks.length - 2]?.distanceM ?? 0;
    const weekDeltaPct = lastWeekM > 0 ? Math.round(((thisWeekM - lastWeekM) / lastWeekM) * 100) : null;

    return {
      rideCount: rides.length,
      totalDistanceM,
      totalMovingS,
      totalElevationM,
      hasEbike: ebikeDistanceM > 0,
      ebikeDistanceM,
      ebikeMovingS,
      acousticDistanceM,
      acousticMovingS,
      longestRideM,
      biggestClimbM,
      thisWeekM,
      weekDeltaPct,
      weeks,
    };
  }, [rides, ebikeBikeIds]);

  if (loading) return <LoadingView label="Crunching your numbers…" />;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Stats</Text>
        <View style={{ width: 26 }} />
      </View>

      {error ? (
        <EmptyState icon={<Ionicons name="cloud-offline-outline" size={32} color={colors.textTertiary} />} title="Couldn't load your stats" description={error} />
      ) : !stats || stats.rideCount === 0 ? (
        <EmptyState
          icon={<Ionicons name="stats-chart-outline" size={32} color={colors.textTertiary} />}
          title="No rides yet"
          description="Record your first ride from the Record tab and your stats will show up here."
        />
      ) : (
        <ScrollView contentContainerStyle={styles.scroll}>
          <Animated.View entering={FadeInUp.duration(420)} style={styles.hero}>
            <View style={styles.heroIconBadge}>
              <SpeedometerIcon size={24} color={colors.accent} />
            </View>
            <Text style={styles.heroLabel}>ALL-TIME DISTANCE</Text>
            <Text style={styles.heroValue}>{formatDistance(stats.totalDistanceM, units)}</Text>
            <Text style={styles.heroSub}>
              {stats.rideCount} {stats.rideCount === 1 ? 'ride' : 'rides'} · {formatDuration(stats.totalMovingS, 'long')} ·{' '}
              {formatElevation(stats.totalElevationM, units)} climbed
            </Text>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(90).duration(420)} style={styles.weekCard}>
            <View>
              <Text style={styles.weekCardLabel}>THIS WEEK</Text>
              <Text style={styles.weekCardValue}>{formatDistance(stats.thisWeekM, units)}</Text>
            </View>
            {stats.weekDeltaPct != null && stats.thisWeekM > 0 ? (
              <View style={[styles.trendPill, stats.weekDeltaPct >= 0 ? styles.trendPillUp : styles.trendPillFlat]}>
                <Ionicons
                  name={stats.weekDeltaPct >= 0 ? 'arrow-up' : 'arrow-down'}
                  size={12}
                  color={stats.weekDeltaPct >= 0 ? colors.success : colors.textSecondary}
                />
                <Text style={[styles.trendPillText, stats.weekDeltaPct >= 0 && styles.trendPillTextUp]}>{Math.abs(stats.weekDeltaPct)}% vs last week</Text>
              </View>
            ) : null}
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(150).duration(420)} style={styles.bestsRow}>
            <View style={styles.bestTile}>
              <Ionicons name="trending-up-outline" size={16} color={colors.accent} />
              <Text style={styles.bestValue}>{formatDistance(stats.longestRideM, units)}</Text>
              <Text style={styles.bestLabel}>Longest ride</Text>
            </View>
            <View style={styles.bestTile}>
              <Ionicons name="triangle-outline" size={16} color={colors.accent} />
              <Text style={styles.bestValue}>{formatElevation(stats.biggestClimbM, units)}</Text>
              <Text style={styles.bestLabel}>Biggest climb</Text>
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(210).duration(420)} style={styles.card}>
            <Text style={styles.cardLabel}>LAST 8 WEEKS</Text>
            <WeekChart weeks={stats.weeks} />
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(stats.hasEbike ? 330 : 270).duration(420)}>
            <Pressable onPress={() => navigation.navigate('RideHeatmap')} style={styles.heatmapCard}>
              <View style={styles.heatmapIconBadge}>
                <Ionicons name="flame" size={18} color="#FF6A3D" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardLabel}>RIDE HEATMAP</Text>
                <Text style={styles.cardHint}>See every road you've ridden, brightest where you ride most.</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
            </Pressable>
          </Animated.View>

          {stats.hasEbike ? (
            <Animated.View entering={FadeInUp.delay(270).duration(420)} style={styles.card}>
              <Text style={styles.cardLabel}>ACOUSTIC VS E-BIKE</Text>
              <Text style={styles.cardHint}>Motor-assisted miles are kept separate so they don't inflate your acoustic totals.</Text>
              <View style={styles.statsRow}>
                <View style={styles.splitGroup}>
                  <View style={styles.splitIconBadge}>
                    <Ionicons name="bicycle-outline" size={16} color={colors.accent} />
                  </View>
                  <Text style={styles.splitValue}>{formatDistance(stats.acousticDistanceM, units)}</Text>
                  <Text style={styles.splitLabel}>Acoustic</Text>
                  <Text style={styles.splitSub}>{formatDuration(stats.acousticMovingS, 'long')}</Text>
                </View>
                <View style={styles.splitGroup}>
                  <View style={[styles.splitIconBadge, styles.splitIconBadgeGold]}>
                    <Ionicons name="flash-outline" size={16} color={colors.gold} />
                  </View>
                  <Text style={styles.splitValue}>{formatDistance(stats.ebikeDistanceM, units)}</Text>
                  <Text style={styles.splitLabel}>E-bike</Text>
                  <Text style={styles.splitSub}>{formatDuration(stats.ebikeMovingS, 'long')}</Text>
                </View>
              </View>
            </Animated.View>
          ) : null}
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

function WeekChart({ weeks }: { weeks: WeekBucket[] }) {
  const max = Math.max(1, ...weeks.map((w) => w.distanceM));
  return (
    <View style={styles.chart}>
      <View style={styles.chartBars}>
        {weeks.map((w, i) => (
          <ChartBar key={i} heightPct={Math.max(4, Math.round((w.distanceM / max) * 100))} isCurrent={i === weeks.length - 1} delay={i * 50} />
        ))}
      </View>
      <View style={styles.chartAxis}>
        <Text style={styles.chartAxisLabel}>{weeks[0]?.label}</Text>
        <Text style={styles.chartAxisLabel}>Now</Text>
      </View>
    </View>
  );
}

function ChartBar({ heightPct, isCurrent, delay }: { heightPct: number; isCurrent: boolean; delay: number }) {
  const height = useSharedValue(0);

  useEffect(() => {
    height.value = withDelay(delay, withTiming(heightPct, { duration: 480, easing: Easing.out(Easing.cubic) }));
    // Only re-run when the target height actually changes, not on every parent re-render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [heightPct]);

  const fillStyle = useAnimatedStyle(() => ({ height: `${height.value}%` as const }));

  return (
    <View style={styles.chartBarTrack}>
      <Animated.View style={[styles.chartBarFill, fillStyle, { opacity: isCurrent ? 1 : 0.35 }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { padding: spacing.md, paddingBottom: spacing.xxl, gap: spacing.sm },

  hero: {
    alignItems: 'center',
    backgroundColor: colors.accentMuted,
    borderRadius: radius.xl,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.md,
    gap: 4,
    marginBottom: spacing.xs,
  },
  heroIconBadge: {
    width: 44,
    height: 44,
    borderRadius: radius.lg,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
    ...shadow.card,
  },
  heroLabel: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.accent, letterSpacing: 0.6 },
  heroValue: { fontFamily: fonts.monoBold, fontSize: 44, color: colors.textPrimary, marginTop: 2 },
  heroSub: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary, textAlign: 'center', marginTop: 2 },

  weekCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  weekCardLabel: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.textSecondary, letterSpacing: 0.4 },
  weekCardValue: { fontFamily: fonts.monoBold, fontSize: 22, color: colors.textPrimary, marginTop: 2 },
  trendPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
  },
  trendPillUp: { backgroundColor: colors.successMuted },
  trendPillFlat: { backgroundColor: colors.surfaceHigh },
  trendPillText: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.textSecondary },
  trendPillTextUp: { color: colors.success },

  bestsRow: { flexDirection: 'row', gap: spacing.sm },
  bestTile: {
    flex: 1,
    alignItems: 'center',
    gap: 3,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: spacing.sm,
  },
  bestValue: { fontFamily: fonts.monoBold, fontSize: 17, color: colors.textPrimary, marginTop: 2 },
  bestLabel: { fontFamily: fonts.medium, fontSize: 11, color: colors.textTertiary },

  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  cardLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary, letterSpacing: 0.4 },
  cardHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, lineHeight: 16, marginTop: -4 },
  heatmapCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  heatmapIconBadge: { width: 40, height: 40, borderRadius: radius.md, backgroundColor: 'rgba(255,106,61,0.14)', alignItems: 'center', justifyContent: 'center' },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around' },

  splitGroup: { flex: 1, alignItems: 'center', gap: 2 },
  splitIconBadge: {
    width: 32,
    height: 32,
    borderRadius: radius.md,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  splitIconBadgeGold: { backgroundColor: colors.goldMuted },
  splitLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary },
  splitValue: { fontFamily: fonts.monoBold, fontSize: 20, color: colors.textPrimary },
  splitSub: { fontFamily: fonts.medium, fontSize: 12, color: colors.textTertiary },

  chart: { gap: 6 },
  chartBars: { flexDirection: 'row', alignItems: 'flex-end', height: 90, gap: 6 },
  chartBarTrack: {
    flex: 1,
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: colors.surfaceHigh,
    borderRadius: 4,
    overflow: 'hidden',
  },
  chartBarFill: { backgroundColor: colors.accent, borderRadius: 4 },
  chartAxis: { flexDirection: 'row', justifyContent: 'space-between' },
  chartAxisLabel: { fontFamily: fonts.medium, fontSize: 10, color: colors.textTertiary },
});
