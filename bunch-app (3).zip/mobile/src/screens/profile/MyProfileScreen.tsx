import React, { useEffect, useMemo, useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Avatar } from '@/components/ui/Avatar';
import { StatBlock } from '@/components/ui/StatBlock';
import { Pill } from '@/components/ui/Pill';
import { EmptyState } from '@/components/ui/EmptyState';
import { BadgeStrip } from '@/components/profile/BadgeStrip';
import { ridingStyleLabel } from '@/components/profile/RidingStylePicker';
import { useAuthStore } from '@/state/authStore';
import { getRiderTotals, listMyRides, syncStreak, type RiderTotals } from '@/lib/api/rides';
import { getFollowCounts } from '@/lib/api/social';
import { countMyHighlights } from '@/lib/api/highlights';
import { countMyRoutes } from '@/lib/api/routes';
import { countStarredSegments } from '@/lib/api/segments';
import { listAllBadges, listMyBadges } from '@/lib/api/badges';
import { supabase } from '@/lib/supabase';
import { formatRideTimestamp } from '@/lib/dateFormat';
import { formatDistance, formatDuration, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Badge, Ride, UserBadge } from '@/lib/database.types';

type IoniconName = keyof typeof Ionicons.glyphMap;
type TabKey = 'overview' | 'timeline' | 'photos';

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: 'overview', label: 'Overview' },
  { key: 'timeline', label: 'Timeline' },
  { key: 'photos', label: 'Photos' },
];

export function MyProfileScreen({ navigation }: ProfileScreenProps<'MyProfile'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';
  const { width } = useWindowDimensions();

  // Tab-to-tab jumps (Routes, Ride detail) live in sibling navigators whose
  // param lists aren't part of ProfileStackParamList, so go through the
  // parent tab navigator by name.
  const jump = (tab: string, screen: string, params?: object) =>
    (navigation as unknown as { navigate: (name: string, p?: object) => void }).navigate(tab, { screen, params });

  const [tab, setTab] = useState<TabKey>('overview');
  const [totals, setTotals] = useState<RiderTotals | null>(null);
  const [earnedBadges, setEarnedBadges] = useState<Array<UserBadge & { badge: Badge }>>([]);
  const [totalBadgeCount, setTotalBadgeCount] = useState(0);
  const [follows, setFollows] = useState<{ followers: number; following: number } | null>(null);
  const [highlightCount, setHighlightCount] = useState<number | null>(null);
  const [routeCount, setRouteCount] = useState<number | null>(null);
  const [starredCount, setStarredCount] = useState<number | null>(null);
  const [rides, setRides] = useState<Ride[] | null>(null);
  const [highlightPhotos, setHighlightPhotos] = useState<string[]>([]);

  useEffect(() => {
    if (!profile) return;
    getRiderTotals(profile.id).then(setTotals).catch(() => {});
    syncStreak(profile).catch(() => {});
    getFollowCounts(profile.id).then(setFollows).catch(() => {});
    countMyHighlights(profile.id).then(setHighlightCount).catch(() => {});
    countMyRoutes(profile.id).then(setRouteCount).catch(() => {});
    countStarredSegments(profile.id).then(setStarredCount).catch(() => {});
    listMyRides(profile.id, 60).then(setRides).catch(() => setRides([]));
    supabase
      .from('ride_highlights')
      .select('photo_url')
      .eq('user_id', profile.id)
      .not('photo_url', 'is', null)
      .order('created_at', { ascending: false })
      .limit(60)
      .then(({ data }) => setHighlightPhotos((data ?? []).map((r) => r.photo_url).filter((u): u is string => !!u)));
    Promise.all([listMyBadges(profile.id), listAllBadges()])
      .then(([mine, all]) => {
        setEarnedBadges(mine);
        setTotalBadgeCount(all.length);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const photos = useMemo(() => {
    const fromRides = (rides ?? []).flatMap((r) => r.photo_urls);
    return Array.from(new Set([...highlightPhotos, ...fromRides]));
  }, [rides, highlightPhotos]);

  if (!profile) return null;

  const tileSize = (width - spacing.md * 2 - spacing.sm) / 2;
  const photoSize = (width - spacing.md * 2 - spacing.xxs * 2) / 3;

  const tiles: Array<{ key: string; label: string; value: string; icon: IoniconName; onPress: () => void }> = [
    { key: 'routes', label: 'Saved routes', value: routeCount != null ? `${routeCount}` : '–', icon: 'bookmark-outline', onPress: () => jump('RoutesTab', 'SavedRoutes') },
    { key: 'segments', label: 'Starred segments', value: starredCount != null ? `${starredCount}` : '–', icon: 'trending-up-outline', onPress: () => navigation.navigate('Segments') },
    { key: 'activities', label: 'Completed activities', value: totals ? `${totals.totalRides}` : '–', icon: 'checkmark-done-outline', onPress: () => setTab('timeline') },
    { key: 'highlights', label: 'Highlights', value: highlightCount != null ? `${highlightCount}` : '–', icon: 'sparkles-outline', onPress: () => setTab('photos') },
  ];

  return (
    <ScreenContainer padded={false}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.topBar}>
          <Text style={styles.topTitle}>Profile</Text>
          <Pressable onPress={() => navigation.navigate('Settings')} hitSlop={10} style={styles.topButton} accessibilityLabel="Settings">
            <Ionicons name="settings-outline" size={20} color={colors.textPrimary} />
          </Pressable>
        </View>

        <View style={styles.header}>
          <Pressable onPress={() => navigation.navigate('EditProfile')} style={styles.avatarWrap}>
            <Avatar uri={profile.avatar_url} name={profile.display_name} size={92} />
            <View style={styles.editBadge}>
              <Ionicons name="pencil" size={12} color={colors.textOnAccent} />
            </View>
          </Pressable>
          <Text style={styles.name}>{profile.display_name}</Text>
          <Text style={styles.username}>@{profile.username}</Text>
          {profile.riding_styles.length > 0 ? (
            <View style={styles.chipRow}>
              {profile.riding_styles.map((style) => (
                <Pill key={style} label={ridingStyleLabel(style)} tone="accent" />
              ))}
            </View>
          ) : (
            <Pressable onPress={() => navigation.navigate('EditProfile')}>
              <Text style={styles.addStyles}>+ Add your riding styles</Text>
            </Pressable>
          )}
          {profile.bio ? <Text style={styles.bio}>{profile.bio}</Text> : null}
          <View style={styles.followRow}>
            <View style={styles.followItem}>
              <Text style={styles.followValue}>{follows?.followers ?? '–'}</Text>
              <Text style={styles.followLabel}>Followers</Text>
            </View>
            <View style={styles.followDivider} />
            <View style={styles.followItem}>
              <Text style={styles.followValue}>{follows?.following ?? '–'}</Text>
              <Text style={styles.followLabel}>Following</Text>
            </View>
          </View>
        </View>

        <View style={styles.tabs}>
          {TABS.map((t) => (
            <Pressable key={t.key} onPress={() => setTab(t.key)} style={styles.tab}>
              <Text style={[styles.tabLabel, tab === t.key && styles.tabLabelActive]}>{t.label}</Text>
              <View style={[styles.tabUnderline, tab === t.key && styles.tabUnderlineActive]} />
            </Pressable>
          ))}
        </View>

        {tab === 'overview' ? (
          <View>
            <View style={styles.tileGrid}>
              {tiles.map((t) => (
                <Pressable key={t.key} onPress={t.onPress} style={[styles.tile, { width: tileSize }]}>
                  <View style={styles.tileIcon}>
                    <Ionicons name={t.icon} size={20} color={colors.accent} />
                  </View>
                  <Text style={styles.tileValue}>{t.value}</Text>
                  <Text style={styles.tileLabel}>{t.label}</Text>
                </Pressable>
              ))}
            </View>

            <Text style={styles.sectionTitle}>Statistics</Text>
            <View style={styles.card}>
              <View style={styles.statsRow}>
                <StatBlock label="ACTIVITIES" value={totals ? `${totals.totalRides}` : '–'} align="center" size="md" style={{ flex: 1 }} />
                <StatBlock label="DISTANCE" value={totals ? formatDistance(totals.totalDistanceM, units) : '–'} align="center" size="md" style={{ flex: 1 }} />
                <StatBlock label="TIME" value={totals ? formatDuration(totals.totalMovingTimeS, 'long') : '–'} align="center" size="md" style={{ flex: 1 }} />
              </View>
              {totals ? <Text style={styles.cardCaption}>{formatElevation(totals.totalElevationM, units)} climbed in total</Text> : null}
              <View style={styles.cardDivider} />
              <View style={styles.cardLinks}>
                <Pressable onPress={() => navigation.navigate('Stats')} style={styles.cardLink}>
                  <Ionicons name="stats-chart-outline" size={16} color={colors.accent} />
                  <Text style={styles.cardLinkText}>Stats over time</Text>
                </Pressable>
                <Pressable onPress={() => navigation.navigate('RideHeatmap')} style={styles.cardLink}>
                  <Ionicons name="flame-outline" size={16} color={colors.accent} />
                  <Text style={styles.cardLinkText}>Heatmap</Text>
                </Pressable>
              </View>
            </View>

            <Text style={styles.sectionTitle}>Streak</Text>
            <View style={styles.card}>
              <View style={styles.streakRow}>
                <View style={styles.streakFlame}>
                  <Ionicons name="flame" size={22} color={colors.gold} />
                </View>
                <StatBlock label="CURRENT" value={`${profile.current_streak}`} style={{ flex: 1 }} />
                <StatBlock label="LONGEST" value={`${profile.longest_streak}`} style={{ flex: 1 }} />
              </View>
              <Text style={styles.cardCaption}>
                Target: {formatDistance(profile.target_distance_m, units)} / {profile.target_period === 'daily' ? 'day' : 'week'}
              </Text>
            </View>

            <View style={{ marginTop: spacing.md }}>
              <BadgeStrip earned={earnedBadges} totalCount={totalBadgeCount} onPress={() => navigation.navigate('Badges')} />
            </View>

            {!profile.is_premium ? (
              <Pressable onPress={() => navigation.navigate('Premium')} style={styles.premiumNudge}>
                <View style={styles.premiumNudgeIcon}>
                  <Ionicons name="star" size={16} color={colors.gold} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.premiumNudgeTitle}>Unlock Bunch Premium</Text>
                  <Text style={styles.premiumNudgeBody}>Unlimited bikes, routes & segments</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
              </Pressable>
            ) : null}

            <Text style={styles.sectionTitle}>More</Text>
            <View style={styles.linksList}>
              {MORE_LINKS.concat(profile.is_admin ? [{ label: 'Admin', icon: 'shield-checkmark-outline', route: 'Admin' }] : []).map((link) => (
                <Pressable key={link.route} onPress={() => navigation.navigate(link.route)} style={styles.linkRow}>
                  <Ionicons name={link.icon} size={20} color={colors.accent} />
                  <Text style={styles.linkLabel}>{link.label}</Text>
                  <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}

        {tab === 'timeline' ? (
          <View style={styles.timeline}>
            {rides == null ? null : rides.length === 0 ? (
              <EmptyState icon={<Ionicons name="bicycle-outline" size={36} color={colors.textTertiary} />} title="No rides yet" description="Record your first ride and it will show up here." />
            ) : (
              rides.map((ride) => (
                <Pressable key={ride.id} onPress={() => jump('HomeTab', 'RideDetail', { rideId: ride.id })} style={styles.timelineRow}>
                  <View style={styles.timelineDot} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.timelineTitle} numberOfLines={1}>{ride.title || 'Ride'}</Text>
                    <Text style={styles.timelineMeta}>{[formatRideTimestamp(ride.started_at), ride.start_location_name].filter(Boolean).join(' · ')}</Text>
                    <Text style={styles.timelineStats}>
                      {formatDistance(ride.distance_m, units)} · {formatDuration(ride.moving_time_s, 'long')} · {formatElevation(ride.elevation_gain_m, units)}
                    </Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
                </Pressable>
              ))
            )}
          </View>
        ) : null}

        {tab === 'photos' ? (
          photos.length === 0 ? (
            <EmptyState icon={<Ionicons name="images-outline" size={36} color={colors.textTertiary} />} title="No photos yet" description="Photos from your rides and highlights will collect here." />
          ) : (
            <View style={styles.photoGrid}>
              {photos.map((uri) => (
                <Image key={uri} source={{ uri }} style={{ width: photoSize, height: photoSize, backgroundColor: colors.surfaceHigh }} />
              ))}
            </View>
          )
        ) : null}
      </ScrollView>
    </ScreenContainer>
  );
}

const MORE_LINKS: Array<{ label: string; icon: IoniconName; route: 'Garage' | 'Devices' | 'ImportRides' | 'Admin' }> = [
  { label: 'Garage', icon: 'bicycle-outline', route: 'Garage' },
  { label: 'Devices', icon: 'bluetooth-outline', route: 'Devices' },
  { label: 'Import rides', icon: 'cloud-upload-outline', route: 'ImportRides' },
];

const styles = StyleSheet.create({
  scroll: { paddingBottom: spacing.xxl },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  topTitle: { ...typeTokens.h2, color: colors.textPrimary },
  topButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  header: { alignItems: 'center', paddingHorizontal: spacing.lg, paddingTop: spacing.md, gap: 4 },
  avatarWrap: { marginBottom: spacing.xs },
  editBadge: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.bg,
  },
  name: { ...typeTokens.h2, color: colors.textPrimary },
  username: { fontFamily: fonts.medium, fontSize: 14, color: colors.textSecondary },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 6, marginTop: spacing.xs },
  addStyles: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent, marginTop: spacing.xs },
  bio: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xs },
  followRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, marginTop: spacing.md },
  followItem: { alignItems: 'center', minWidth: 80 },
  followValue: { fontFamily: fonts.bold, fontSize: 20, color: colors.textPrimary },
  followLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary, marginTop: 2 },
  followDivider: { width: 1, height: 28, backgroundColor: colors.border },

  tabs: { flexDirection: 'row', marginTop: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border, marginHorizontal: spacing.md },
  tab: { flex: 1, alignItems: 'center', paddingTop: spacing.sm },
  tabLabel: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textTertiary, paddingBottom: spacing.sm },
  tabLabelActive: { color: colors.textPrimary },
  tabUnderline: { height: 3, alignSelf: 'stretch', borderTopLeftRadius: 3, borderTopRightRadius: 3, backgroundColor: 'transparent' },
  tabUnderlineActive: { backgroundColor: colors.accent },

  tileGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, paddingHorizontal: spacing.md, marginTop: spacing.md },
  tile: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: 2 },
  tileIcon: { width: 38, height: 38, borderRadius: radius.sm, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.xs },
  tileValue: { fontFamily: fonts.bold, fontSize: 20, color: colors.textPrimary },
  tileLabel: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary },

  sectionTitle: { ...typeTokens.h3, color: colors.textPrimary, marginHorizontal: spacing.md, marginTop: spacing.lg, marginBottom: spacing.sm },
  card: { marginHorizontal: spacing.md, backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: spacing.sm },
  statsRow: { flexDirection: 'row' },
  cardCaption: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  cardDivider: { height: 1, backgroundColor: colors.border },
  cardLinks: { flexDirection: 'row', gap: spacing.lg },
  cardLink: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  cardLinkText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  streakRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  streakFlame: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.goldMuted, alignItems: 'center', justifyContent: 'center' },

  premiumNudge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    backgroundColor: colors.goldMuted,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  premiumNudgeIcon: { width: 34, height: 34, borderRadius: radius.sm, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  premiumNudgeTitle: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
  premiumNudgeBody: { fontFamily: fonts.regular, fontSize: 12, color: colors.textSecondary, marginTop: 1 },

  linksList: { marginHorizontal: spacing.md, gap: spacing.xs },
  linkRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md, backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border },
  linkLabel: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary, flex: 1 },

  timeline: { paddingHorizontal: spacing.md, paddingTop: spacing.sm, gap: spacing.xs },
  timelineRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md, backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border },
  timelineDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.accent },
  timelineTitle: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  timelineMeta: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 1 },
  timelineStats: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary, marginTop: 4 },

  photoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xxs, paddingHorizontal: spacing.md, paddingTop: spacing.md },
});
