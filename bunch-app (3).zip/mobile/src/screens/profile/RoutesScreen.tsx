import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, TextInput, View, type LayoutChangeEvent } from 'react-native';
import Animated, { FadeInDown, FadeOutDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { ExploreMap, type ExploreMapHandle, type ExploreRoute } from '@/components/routes/ExploreMap';
import { RouteCard } from '@/components/routes/RouteCard';
import { ROUTE_PREVIEW_HEIGHT, RoutePreviewCard } from '@/components/routes/RoutePreviewCard';
import { COLLAPSED_VISIBLE, RoutesSheet, type SheetSnap } from '@/components/routes/RoutesSheet';
import { DISTANCE_BUCKETS, type DistanceBucket } from '@/components/routes/routeMeta';
import { MapRoundButton, MapZoomPill } from '@/components/map/MapControls';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/state/authStore';
import { getRouteRideCounts, listVisibleRoutes } from '@/lib/api/routes';
import { getErrorMessage } from '@/lib/errors';
import { geoJSONToCoordinates } from '@/lib/geo';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import type { RoutesScreenProps } from '@/navigation/types';
import type { RouteRow, SurfaceType } from '@/lib/database.types';

const SURFACES: SurfaceType[] = ['paved', 'gravel', 'mixed', 'dirt'];

/** Height of the search row + filter chips (46 + 8 + 34) plus the gap under the status bar. */
const TOP_OVERLAY_CONTENT = 46 + spacing.xs + 34 + spacing.xs;
/** Breathing room between the floating controls and whatever sits under them. */
const CONTROL_GAP = 14;

/** Routes tab: map-first explore screen. The map draws every route the rider can
 * see (their own plus other riders' public ones) — pinch, drag, double-tap and the
 * +/− buttons all zoom it, tapping a line previews that route and opens it. The
 * draggable sheet lists the same routes. Saved/owned management lives in SavedRoutes. */
export function RoutesScreen({ navigation }: RoutesScreenProps<'RoutesList'>) {
  const insets = useSafeAreaInsets();
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';
  const mapRef = useRef<ExploreMapHandle>(null);
  const listRef = useRef<FlatList<RouteRow>>(null);

  const [routes, setRoutes] = useState<RouteRow[]>([]);
  const [counts, setCounts] = useState<Record<string, { rides: number; riders: number }>>({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [containerHeight, setContainerHeight] = useState(0);
  const [snap, setSnap] = useState<SheetSnap>('half');

  const [query, setQuery] = useState('');
  const [bucket, setBucket] = useState<DistanceBucket>('any');
  const [surface, setSurface] = useState<SurfaceType | null>(null);
  const [onlyMine, setOnlyMine] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      let cancelled = false;
      listVisibleRoutes()
        .then(async (rows) => {
          if (cancelled) return;
          setRoutes(rows);
          setLoadError(null);
          const c = await getRouteRideCounts(rows.map((r) => r.id)).catch(() => ({}));
          if (!cancelled) setCounts(c);
        })
        .catch((e) => !cancelled && setLoadError(getErrorMessage(e)))
        .finally(() => !cancelled && setLoading(false));
      return () => {
        cancelled = true;
      };
    }, []),
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const range = DISTANCE_BUCKETS.find((b) => b.key === bucket);
    return routes.filter((r) => {
      if (q && !r.name.toLowerCase().includes(q)) return false;
      if (range && (r.distance_m < range.min || r.distance_m >= range.max)) return false;
      if (surface && r.surface_type !== surface) return false;
      if (onlyMine && r.user_id !== profile?.id) return false;
      return true;
    });
  }, [routes, query, bucket, surface, onlyMine, profile?.id]);

  // A filter can hide the route that was selected — then there is nothing to preview.
  const selected = useMemo(() => filtered.find((r) => r.id === selectedId) ?? null, [filtered, selectedId]);

  const mapRoutes = useMemo<ExploreRoute[]>(
    () =>
      filtered
        .map((r) => ({ id: r.id, coordinates: geoJSONToCoordinates(r.route_geojson), mine: r.user_id === profile?.id }))
        .filter((r) => r.coordinates.length >= 2),
    [filtered, profile?.id],
  );

  // Nothing to fit? Start where the rider is (only if location was already allowed — never prompt just for a map).
  const centredRef = useRef(false);
  useEffect(() => {
    if (loading || routes.length > 0 || centredRef.current) return;
    centredRef.current = true;
    (async () => {
      try {
        const perm = await Location.getForegroundPermissionsAsync();
        if (!perm.granted) return;
        const pos = (await Location.getLastKnownPositionAsync()) ?? (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }));
        if (pos) mapRef.current?.flyTo(pos.coords.longitude, pos.coords.latitude, 12);
      } catch {
        // The map just stays on its default view.
      }
    })();
  }, [loading, routes.length]);

  const sheetVisible = snap === 'full' ? containerHeight * 0.9 : snap === 'half' ? containerHeight * 0.46 : COLLAPSED_VISIBLE;
  // The preview card floats just above the sheet; the map controls and attribution ride above both.
  const previewLift = selected ? ROUTE_PREVIEW_HEIGHT + 12 : 0;
  const controlsBottom = sheetVisible + previewLift + CONTROL_GAP;

  function openRoute(id: string) {
    navigation.navigate('RouteDetail', { routeId: id });
  }

  function onMapSelect(id: string | null) {
    setSelectedId(id);
    if (!id) return;
    // Make room: the sheet folds down so the framed route is not hidden behind it…
    setSnap('collapsed');
    // …and the list is parked on that route, so it is the first card you see when you pull the sheet up.
    const index = filtered.findIndex((r) => r.id === id);
    if (index >= 0) requestAnimationFrame(() => listRef.current?.scrollToIndex({ index, animated: true, viewPosition: 0 }));
  }

  async function onLocate() {
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Location is off', 'Allow location access in Settings to centre the map on you.');
        return;
      }
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      mapRef.current?.flyTo(pos.coords.longitude, pos.coords.latitude, 13);
    } catch (e) {
      Alert.alert('Could not find you', getErrorMessage(e));
    }
  }

  const filtersActive = bucket !== 'any' || surface !== null || onlyMine || query.trim().length > 0;

  function clearFilters() {
    setQuery('');
    setBucket('any');
    setSurface(null);
    setOnlyMine(false);
  }

  const title = loading
    ? 'Loading routes…'
    : filtered.length === 0 && !filtersActive
      ? 'Routes'
      : `${filtered.length} ${filtered.length === 1 ? 'route' : 'routes'}`;

  const header = (
    <View style={styles.sheetHeader}>
      <Text style={styles.sheetTitle}>{title}</Text>
      {filtersActive ? (
        <Pressable onPress={clearFilters} hitSlop={8} accessibilityRole="button">
          <Text style={styles.clearText}>Clear filters</Text>
        </Pressable>
      ) : null}
    </View>
  );

  return (
    <View style={styles.root} onLayout={(e: LayoutChangeEvent) => setContainerHeight(e.nativeEvent.layout.height)}>
      <ExploreMap
        ref={mapRef}
        routes={mapRoutes}
        selectedId={selected?.id ?? null}
        onSelect={onMapSelect}
        topPadding={insets.top + TOP_OVERLAY_CONTENT + 20}
        bottomPadding={sheetVisible + previewLift + 28}
        attributionBottom={controlsBottom - CONTROL_GAP + 8}
      />

      <View style={[styles.topOverlay, { paddingTop: insets.top + spacing.xs }]} pointerEvents="box-none">
        <View style={styles.searchRow}>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={18} color={colors.textTertiary} />
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Search routes"
              placeholderTextColor={colors.textTertiary}
              style={styles.searchInput}
              returnKeyType="search"
              autoCorrect={false}
            />
            {query.length > 0 ? (
              <Pressable onPress={() => setQuery('')} hitSlop={8} accessibilityLabel="Clear search">
                <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
              </Pressable>
            ) : null}
          </View>
          <Pressable onPress={() => navigation.navigate('RouteBuilder')} style={styles.planButton} accessibilityRole="button" accessibilityLabel="Plan a new route">
            <Ionicons name="add" size={18} color={colors.textOnAccent} />
            <Text style={styles.planText}>Plan</Text>
          </Pressable>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow} keyboardShouldPersistTaps="handled">
          <FilterChip label="Mine" active={onlyMine} onPress={() => setOnlyMine((v) => !v)} />
          {DISTANCE_BUCKETS.map((b) => (
            <FilterChip key={b.key} label={b.label} active={bucket === b.key} onPress={() => setBucket(bucket === b.key ? 'any' : b.key)} />
          ))}
          {SURFACES.map((s) => (
            <FilterChip key={s} label={s[0].toUpperCase() + s.slice(1)} active={surface === s} onPress={() => setSurface(surface === s ? null : s)} />
          ))}
        </ScrollView>

        <View style={styles.topRight} pointerEvents="box-none">
          <MapRoundButton icon="bookmark-outline" label="Saved routes" onPress={() => navigation.navigate('SavedRoutes')} />
        </View>
      </View>

      {snap !== 'full' ? (
        <View style={[styles.controls, { bottom: controlsBottom }]} pointerEvents="box-none">
          {mapRoutes.length > 1 || selected ? (
            <MapRoundButton icon="scan-outline" label={selected ? 'Fit this route' : 'Show all routes'} onPress={() => mapRef.current?.fitRoutes()} />
          ) : null}
          <MapRoundButton icon="locate" label="Centre on me" onPress={onLocate} />
          <MapZoomPill onZoomIn={() => mapRef.current?.zoomIn()} onZoomOut={() => mapRef.current?.zoomOut()} />
        </View>
      ) : null}

      {containerHeight > 0 ? (
        <RoutesSheet containerHeight={containerHeight} snap={snap} onSnapChange={setSnap} header={header}>
          {loading ? (
            <View style={styles.centered}>
              <ActivityIndicator color={colors.accent} />
            </View>
          ) : loadError ? (
            <View style={styles.empty}>
              <View style={[styles.emptyIcon, { backgroundColor: colors.dangerMuted }]}>
                <Ionicons name="cloud-offline-outline" size={26} color={colors.danger} />
              </View>
              <Text style={styles.emptyTitle}>Couldn't load routes</Text>
              <Text style={styles.emptyBody}>{loadError}</Text>
            </View>
          ) : (
            <FlatList
              ref={listRef}
              data={filtered}
              onScrollToIndexFailed={(info) => listRef.current?.scrollToOffset({ offset: info.averageItemLength * info.index, animated: true })}
              extraData={selected?.id}
              keyExtractor={(r) => r.id}
              contentContainerStyle={styles.listContent}
              ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
              renderItem={({ item }) => (
                <RouteCard
                  route={item}
                  units={units}
                  riders={counts[item.id]?.riders ?? 0}
                  selected={item.id === selected?.id}
                  isMine={item.user_id === profile?.id}
                  onPress={() => openRoute(item.id)}
                />
              )}
              ListEmptyComponent={
                filtersActive ? (
                  <View style={styles.empty}>
                    <View style={styles.emptyIcon}>
                      <Ionicons name="search-outline" size={26} color={colors.accent} />
                    </View>
                    <Text style={styles.emptyTitle}>No routes match</Text>
                    <Text style={styles.emptyBody}>Nothing fits those filters. Loosen one, or clear them all to see every route.</Text>
                    <Button title="Clear filters" variant="secondary" size="md" fullWidth={false} onPress={clearFilters} style={styles.emptyButton} />
                  </View>
                ) : (
                  <View style={styles.empty}>
                    <View style={styles.emptyIcon}>
                      <Ionicons name="map-outline" size={26} color={colors.accent} />
                    </View>
                    <Text style={styles.emptyTitle}>Your first route starts here</Text>
                    <Text style={styles.emptyBody}>
                      Draw a route on the map, or save a ride you’ve recorded as a route. Public routes from other riders will show up here too.
                    </Text>
                    <Button
                      title="Plan a route"
                      size="md"
                      fullWidth={false}
                      onPress={() => navigation.navigate('RouteBuilder')}
                      icon={<Ionicons name="add" size={18} color={colors.textOnAccent} />}
                      style={styles.emptyButton}
                    />
                  </View>
                )
              }
            />
          )}
        </RoutesSheet>
      ) : null}

      {selected ? (
        <Animated.View
          key={selected.id}
          entering={FadeInDown.duration(220)}
          exiting={FadeOutDown.duration(150)}
          style={[styles.preview, { bottom: sheetVisible + 12 }]}
        >
          <RoutePreviewCard
            route={selected}
            units={units}
            riders={counts[selected.id]?.riders ?? 0}
            isMine={selected.user_id === profile?.id}
            onOpen={() => openRoute(selected.id)}
            onDismiss={() => setSelectedId(null)}
          />
        </Animated.View>
      ) : null}
    </View>
  );
}

function FilterChip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && styles.chipActive]} accessibilityRole="button" accessibilityState={{ selected: active }}>
      <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  topOverlay: { position: 'absolute', top: 0, left: 0, right: 0, gap: spacing.xs },
  searchRow: { flexDirection: 'row', gap: spacing.xs, paddingHorizontal: spacing.md },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.surface,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm,
    height: 46,
    ...shadow.card,
  },
  searchInput: { flex: 1, fontFamily: fonts.medium, fontSize: 15, color: colors.textPrimary, padding: 0 },
  planButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.accent,
    borderRadius: radius.pill,
    paddingLeft: spacing.sm,
    paddingRight: spacing.md,
    height: 46,
    ...shadow.card,
  },
  planText: { fontFamily: fonts.bold, fontSize: 14, color: colors.textOnAccent },
  chipRow: { paddingHorizontal: spacing.md, gap: spacing.xs },
  chip: {
    backgroundColor: colors.surface,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm,
    height: 34,
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  chipActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  chipText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textPrimary },
  chipTextActive: { color: colors.textOnAccent },
  topRight: { alignSelf: 'flex-end', paddingRight: spacing.md },
  controls: { position: 'absolute', right: spacing.md, gap: 10, alignItems: 'center' },
  preview: { position: 'absolute', left: spacing.md, right: spacing.md },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
  sheetTitle: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary },
  clearText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  listContent: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  centered: { alignItems: 'center', justifyContent: 'center', gap: spacing.xs, padding: spacing.lg },
  empty: { alignItems: 'center', justifyContent: 'center', gap: 6, paddingTop: spacing.md, paddingHorizontal: spacing.md },
  emptyIcon: { width: 56, height: 56, borderRadius: 20, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  emptyTitle: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary, textAlign: 'center' },
  emptyBody: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center', lineHeight: 20 },
  emptyButton: { marginTop: spacing.sm },
});
