import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Card } from '@/components/ui/Card';
import { useAuthStore } from '@/state/authStore';
import { PREMIUM_MONTHLY_PRICE, PREMIUM_YEARLY_PRICE, PREMIUM_YEARLY_DISCOUNT } from '@/lib/pricing';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';

interface FeatureRow {
  label: string;
  free: string;
  premium: string;
}

// Every row here is a real, enforced gate (see enforce_bike_cap /
// enforce_route_cap / enforce_segment_star_cap / enforce_recording_device_cap
// triggers in schema.sql) or an already-shipped visual (the gold "Bunch
// Premium" pill shown on MyProfileScreen/UserProfileScreen/SettingsScreen) —
// nothing on this screen is aspirational.
const FEATURES: FeatureRow[] = [
  { label: 'Bikes in your garage', free: '2', premium: 'Unlimited' },
  { label: 'Saved routes', free: '3', premium: 'Unlimited' },
  { label: 'Starred segments', free: '5', premium: 'Unlimited' },
  { label: 'Recording devices', free: '1', premium: 'Unlimited' },
  { label: 'Profile badge', free: '—', premium: 'Gold badge' },
];

export function PremiumScreen({ navigation }: ProfileScreenProps<'Premium'>) {
  const profile = useAuthStore((s) => s.profile);
  const isPremium = profile?.is_premium ?? false;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Premium</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.hero}>
          <View style={styles.heroBadge}>
            <Ionicons name="star" size={28} color={colors.gold} />
          </View>
          <Text style={styles.heroTitle}>Bunch Premium</Text>

          {isPremium ? (
            <Text style={styles.heroSubtitle}>
              You're a Premium rider
              {profile?.premium_since ? ` since ${new Date(profile.premium_since).toLocaleDateString()}` : ''}. Thanks for
              backing the app.
            </Text>
          ) : (
            <>
              <View style={styles.priceRow}>
                <Text style={styles.price}>{PREMIUM_MONTHLY_PRICE}</Text>
                <Text style={styles.pricePeriod}>/ month</Text>
              </View>
              <Text style={styles.heroSubtitle}>
                or {PREMIUM_YEARLY_PRICE} billed yearly — about {PREMIUM_YEARLY_DISCOUNT} off
              </Text>
            </>
          )}
        </View>

        <Card>
          <View style={styles.tableHeaderRow}>
            <View style={{ flex: 1.4 }} />
            <Text style={styles.tableHeaderLabel}>Free</Text>
            <Text style={[styles.tableHeaderLabel, styles.tableHeaderPremium]}>Premium</Text>
          </View>
          {FEATURES.map((row, i) => (
            <View key={row.label} style={[styles.tableRow, i === FEATURES.length - 1 && styles.tableRowLast]}>
              <Text style={styles.rowLabel}>{row.label}</Text>
              <Text style={styles.rowFree}>{row.free}</Text>
              <Text style={styles.rowPremium}>{row.premium}</Text>
            </View>
          ))}
        </Card>

        <View style={styles.noteBox}>
          <Ionicons name="information-circle-outline" size={16} color={colors.textTertiary} />
          <Text style={styles.noteText}>
            Bunch is in early access, so Premium isn't sold in-app yet — it's granted directly by the Bunch team. Open
            Settings to see your current plan, or reach out to request an upgrade.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
  },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingTop: spacing.xs, paddingBottom: spacing.xxl, gap: spacing.lg },
  hero: { alignItems: 'center', paddingTop: spacing.sm, paddingBottom: spacing.xs, gap: 6 },
  heroBadge: {
    width: 64,
    height: 64,
    borderRadius: radius.xl,
    backgroundColor: colors.goldMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  heroTitle: { ...typeTokens.h1, color: colors.textPrimary },
  heroSubtitle: {
    fontFamily: fonts.regular,
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.lg,
    lineHeight: 20,
  },
  priceRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 4, marginTop: 4 },
  price: { ...typeTokens.display, color: colors.textPrimary },
  pricePeriod: { fontFamily: fonts.medium, fontSize: 16, color: colors.textSecondary, marginBottom: 6 },
  tableHeaderRow: { flexDirection: 'row', alignItems: 'center', paddingBottom: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
  tableHeaderLabel: { flex: 1, fontFamily: fonts.semiBold, fontSize: 12, color: colors.textTertiary, textAlign: 'center', letterSpacing: 0.3 },
  tableHeaderPremium: { color: colors.gold },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tableRowLast: { borderBottomWidth: 0 },
  rowLabel: { flex: 1.4, fontFamily: fonts.medium, fontSize: 13, color: colors.textPrimary },
  rowFree: { flex: 1, fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, textAlign: 'center' },
  rowPremium: { flex: 1, fontFamily: fonts.semiBold, fontSize: 13, color: colors.gold, textAlign: 'center' },
  noteBox: {
    flexDirection: 'row',
    gap: spacing.xs,
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.md,
    padding: spacing.sm,
  },
  noteText: { flex: 1, fontFamily: fonts.regular, fontSize: 12, color: colors.textSecondary, lineHeight: 17 },
});
