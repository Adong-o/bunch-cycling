import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { RideMap } from '@/components/RideMap';
import { Avatar } from '@/components/ui/Avatar';
import { StatBlock } from '@/components/ui/StatBlock';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import {
  getSegment,
  getSegmentLeaderboard,
  deleteSegment,
  starSegment,
  unstarSegment,
  listStarredSegments,
  FREE_STARRED_SEGMENT_LIMIT,
} from '@/lib/api/segments';
import { getErrorMessage } from '@/lib/errors';
import { boundingBox, geoJSONToCoordinates } from '@/lib/geo';
import { formatDistance, formatDuration, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Segment, SegmentLeaderboardRow } from '@/lib/database.types';

export function SegmentDetailScreen({ navigation, route }: ProfileScreenProps<'SegmentDetail'>) {
  const { segmentId } = route.params;
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [segment, setSegment] = useState<Segment | null>(null);
  const [leaderboard, setLeaderboard] = useState<SegmentLeaderboardRow[]>([]);
  // null = no explicit choice yet, so the view can default to whichever
  // board actually has entries instead of always opening on an empty one.
  const [boardTab, setBoardTab] = useState<'acoustic' | 'ebike' | null>(null);
  const [starred, setStarred] = useState(false);
  const [atCap, setAtCap] = useState(false);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [starBusy, setStarBusy] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const s = await getSegment(segmentId);
      if (!s) {
        setNotFound(true);
        return;
      }
      const [board, mine] = await Promise.all([getSegmentLeaderboard(segmentId), listStarredSegments(profile.id)]);
      setSegment(s);
      setLeaderboard(board);
      setStarred(mine.some((m) => m.id === segmentId));
      setAtCap(!profile.is_premium && mine.length >= FREE_STARRED_SEGMENT_LIMIT);
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, [segmentId, profile]);

  useEffect(() => {
    load();
  }, [load]);

  async function onToggleStar() {
    if (!profile || !segment || starBusy) return;
    if (!starred && atCap) return;
    setStarBusy(true);
    const previous = starred;
    setStarred(!previous);
    try {
      if (previous) await unstarSegment(profile.id, segment.id);
      else await starSegment(profile.id, segment.id);
    } catch (e) {
      setStarred(previous);
      Alert.alert(previous ? 'Could not unstar segment' : 'Could not star segment', getErrorMessage(e));
    } finally {
      setStarBusy(false);
    }
  }

  function onDelete() {
    if (!segment) return;
    Alert.alert('Delete this segment?', `"${segment.name}" will be removed for everyone, including its leaderboard. This cannot be undone.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setDeleting(true);
          try {
            await deleteSegment(segment.id);
            navigation.goBack();
          } catch (e) {
            setDeleting(false);
            Alert.alert('Could not delete segment', getErrorMessage(e));
          }
        },
      },
    ]);
  }

  if (loading) return <LoadingView />;

  if (notFound || !segment) {
    return (
      <ScreenContainer>
        <View style={styles.backRow}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
        </View>
        <EmptyState
          icon={<Ionicons name="help-circle-outline" size={32} color={colors.textTertiary} />}
          title="Segment not found"
          description="This segment may have been deleted."
        />
      </ScreenContainer>
    );
  }

  const canDelete = profile?.id === segment.created_by || profile?.is_admin;
  const bounds = boundingBox(segment.route_geojson);
  const coords = geoJSONToCoordinates(segment.route_geojson);
  const starDisabled = starBusy || (!starred && atCap);

  // Acoustic and e-bike riders are ranked separately (schema partitions
  // rank() by is_ebike) so an e-bike's motor assist never bumps a rider off
  // the board they're actually competing on.
  const acousticBoard = useMemo(() => leaderboard.filter((r) => !r.is_ebike), [leaderboard]);
  const ebikeBoard = useMemo(() => leaderboard.filter((r) => r.is_ebike), [leaderboard]);
  const hasEbikeBoard = ebikeBoard.length > 0;
  const activeTab = boardTab ?? (acousticBoard.length === 0 && hasEbikeBoard ? 'ebike' : 'acoustic');
  const activeBoard = activeTab === 'ebike' ? ebikeBoard : acousticBoard;
  const myRank = activeBoard.find((r) => r.user_id === profile?.id);

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.headerActions}>
          <Pressable onPress={onToggleStar} hitSlop={10} disabled={starDisabled} style={styles.headerIcon}>
            <Ionicons name={starred ? 'star' : 'star-outline'} size={22} color={starred ? colors.gold : starDisabled ? colors.textTertiary : colors.textSecondary} />
          </Pressable>
          {canDelete ? (
            <Pressable onPress={onDelete} hitSlop={10} disabled={deleting} style={styles.headerIcon}>
              <Ionicons name="trash-outline" size={20} color={colors.danger} />
            </Pressable>
          ) : null}
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        {coords.length > 1 ? <RideMap routeCoordinates={coords} bounds={bounds} expandable expandTitle="Segment" style={styles.map} /> : null}

        <View style={styles.body}>
          <Text style={styles.title}>{segment.name}</Text>

          <View style={styles.statsCard}>
            <View style={styles.statsRow}>
              <StatBlock label="DISTANCE" value={formatDistance(segment.distance_m, units)} size="lg" />
              <StatBlock label="ELEVATION" value={formatElevation(segment.elevation_gain_m, units)} size="lg" />
            </View>
            <View style={styles.statsDivider} />
            <View style={styles.statsRow}>
              <StatBlock label="AVG GRADE" value={segment.avg_grade_pct != null ? `${segment.avg_grade_pct.toFixed(1)}%` : '—'} />
              <StatBlock label="SURFACE" value={segment.surface_type} />
            </View>
          </View>

          {!starred && atCap ? (
            <Text style={styles.capHint}>
              You've starred {FREE_STARRED_SEGMENT_LIMIT} segments on the free plan. Upgrade to Bunch Premium to star more.
            </Text>
          ) : null}

          <View style={styles.leaderboardSection}>
            <View style={styles.leaderboardHeader}>
              <Text style={styles.sectionLabel}>LEADERBOARD</Text>
              {hasEbikeBoard ? (
                <View style={styles.boardSwitch}>
                  <Pressable
                    onPress={() => setBoardTab('acoustic')}
                    style={[styles.boardSwitchItem, activeTab === 'acoustic' && styles.boardSwitchItemActive]}
                    hitSlop={6}
                  >
                    <Text style={[styles.boardSwitchText, activeTab === 'acoustic' && styles.boardSwitchTextActive]}>Acoustic</Text>
                  </Pressable>
                  <Pressable
                    onPress={() => setBoardTab('ebike')}
                    style={[styles.boardSwitchItem, activeTab === 'ebike' && styles.boardSwitchItemActive]}
                    hitSlop={6}
                  >
                    <Ionicons
                      name="flash"
                      size={12}
                      color={activeTab === 'ebike' ? colors.textOnAccent : colors.textSecondary}
                      style={styles.boardSwitchIcon}
                    />
                    <Text style={[styles.boardSwitchText, activeTab === 'ebike' && styles.boardSwitchTextActive]}>E-bike</Text>
                  </Pressable>
                </View>
              ) : null}
            </View>

            {myRank ? (
              <View style={styles.myEffortCard}>
                <Ionicons name="trophy-outline" size={16} color={colors.gold} />
                <Text style={styles.myEffortText}>
                  Your best: {formatDuration(myRank.best_elapsed_s)} · Rank #{myRank.rank} of {activeBoard.length}
                </Text>
              </View>
            ) : null}

            {activeBoard.length === 0 ? (
              <Text style={styles.noEfforts}>
                {activeTab === 'ebike'
                  ? 'No e-bike efforts on this segment yet. Be the first.'
                  : 'No one has ridden this segment yet. Star it and be the first on the board.'}
              </Text>
            ) : (
              <View style={styles.leaderboardList}>
                {activeBoard.map((row) => (
                  <View key={row.user_id} style={[styles.leaderboardRow, row.user_id === profile?.id && styles.leaderboardRowMe]}>
                    <Text style={styles.rank}>{row.rank}</Text>
                    <Avatar uri={row.avatar_url} name={row.display_name} size={32} />
                    <Text style={styles.leaderboardName} numberOfLines={1}>
                      {row.display_name}
                      {row.user_id === profile?.id ? ' (you)' : ''}
                    </Text>
                    <Text style={styles.leaderboardTime}>{formatDuration(row.best_elapsed_s)}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  backRow: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  headerActions: { flexDirection: 'row', gap: spacing.md },
  headerIcon: { padding: 2 },
  scroll: { paddingBottom: spacing.xxl },
  map: { height: 220, marginHorizontal: spacing.md, marginTop: spacing.xs },
  body: { paddingHorizontal: spacing.md, gap: spacing.md, marginTop: spacing.sm },
  title: { ...typeTokens.h2, color: colors.textPrimary },
  statsCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around' },
  statsDivider: { height: 1, backgroundColor: colors.border },
  capHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center' },
  leaderboardSection: { gap: spacing.sm },
  leaderboardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary, letterSpacing: 0.4 },
  boardSwitch: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.pill,
    padding: 2,
  },
  boardSwitchItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radius.pill,
  },
  boardSwitchItemActive: { backgroundColor: colors.accent },
  boardSwitchIcon: { marginRight: 3 },
  boardSwitchText: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary },
  boardSwitchTextActive: { color: colors.textOnAccent },
  myEffortCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.goldMuted,
    borderRadius: radius.md,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.sm,
  },
  myEffortText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textPrimary },
  noEfforts: { fontFamily: fonts.regular, fontSize: 14, color: colors.textTertiary, lineHeight: 20 },
  leaderboardList: { gap: 2 },
  leaderboardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.xs,
    borderRadius: radius.sm,
  },
  leaderboardRowMe: { backgroundColor: colors.accentMuted },
  rank: { fontFamily: fonts.bold, fontSize: 14, color: colors.textTertiary, width: 22, textAlign: 'center' },
  leaderboardName: { flex: 1, fontFamily: fonts.medium, fontSize: 14, color: colors.textPrimary },
  leaderboardTime: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
});
