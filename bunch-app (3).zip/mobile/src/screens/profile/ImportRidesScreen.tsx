import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/TextField';
import { StatBlock } from '@/components/ui/StatBlock';
import { useAuthStore } from '@/state/authStore';
import { pickImportFile, saveImportedRide, type ParsedImportedRide } from '@/lib/gpxImport';
import { listRecordingDevices, recordingDeviceBrandLabel } from '@/lib/api/recordingDevices';
import { getErrorMessage } from '@/lib/errors';
import { formatDistance, formatDuration, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { RecordingDevice, RideVisibility } from '@/lib/database.types';

const VISIBILITY_OPTIONS = [
  { value: 'public', label: 'Everyone', icon: 'earth-outline' },
  { value: 'followers', label: 'Followers', icon: 'people-outline' },
  { value: 'private', label: 'Only me', icon: 'lock-closed-outline' },
] as const;

export function ImportRidesScreen({ navigation }: ProfileScreenProps<'ImportRides'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [picking, setPicking] = useState(false);
  const [parsed, setParsed] = useState<ParsedImportedRide | null>(null);
  const [title, setTitle] = useState('');
  const [visibility, setVisibility] = useState<RideVisibility>('public');
  const [saving, setSaving] = useState(false);

  const [recordingDevices, setRecordingDevices] = useState<RecordingDevice[]>([]);
  const [recordingDeviceId, setRecordingDeviceId] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    listRecordingDevices(profile.id)
      .then(setRecordingDevices)
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  async function onChooseFile() {
    setPicking(true);
    try {
      const result = await pickImportFile();
      if (!result) return; // user canceled the picker
      setParsed(result.parsed);
      setTitle(result.parsed.title);
      setVisibility('public');
    } catch (e) {
      Alert.alert('Could not import ride', getErrorMessage(e));
    } finally {
      setPicking(false);
    }
  }

  function onStartOver() {
    setParsed(null);
    setTitle('');
    setRecordingDeviceId(null);
  }

  async function onSave() {
    if (!profile || !parsed) return;
    setSaving(true);
    try {
      const ride = await saveImportedRide(profile.id, parsed, { title, visibility, recordingDeviceId });
      Alert.alert('Ride imported', `"${ride.title}" was added to your rides.`, [{ text: 'OK', onPress: onStartOver }]);
    } catch (e) {
      Alert.alert('Could not save ride', getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Import rides</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {!parsed ? (
          <View style={styles.introCard}>
            <View style={styles.introIcon}>
              <Ionicons name="cloud-upload-outline" size={28} color={colors.accent} />
            </View>
            <Text style={styles.introTitle}>Bring in a past ride</Text>
            <Text style={styles.introBody}>
              Import a ride from Strava, Garmin, or any app that can export a GPX or TCX file.
            </Text>
            <Button title={picking ? 'Reading file…' : 'Choose file'} onPress={onChooseFile} loading={picking} />
          </View>
        ) : (
          <>
            <View style={styles.statsCard}>
              <View style={styles.statsRow}>
                <StatBlock label="DISTANCE" value={formatDistance(parsed.distanceM, units)} size="lg" />
                <StatBlock label="MOVING TIME" value={formatDuration(parsed.movingTimeS, 'long')} size="lg" />
              </View>
              <View style={styles.statsDivider} />
              <View style={styles.statsRow}>
                <StatBlock label="ELEVATION" value={formatElevation(parsed.elevationGainM, units)} />
                <StatBlock label="DATE" value={new Date(parsed.startedAt).toLocaleDateString()} />
              </View>
            </View>

            <View style={styles.form}>
              <TextField label="Title" value={title} onChangeText={setTitle} placeholder={parsed.title} />

              <View>
                <Text style={styles.label}>Who can see this</Text>
                <View style={styles.visibilityRow}>
                  {VISIBILITY_OPTIONS.map((opt) => (
                    <Pressable
                      key={opt.value}
                      onPress={() => setVisibility(opt.value)}
                      style={[styles.visibilityOption, visibility === opt.value && styles.visibilityOptionActive]}
                    >
                      <Ionicons name={opt.icon} size={16} color={visibility === opt.value ? colors.accent : colors.textSecondary} />
                      <Text style={[styles.visibilityLabel, visibility === opt.value && styles.visibilityLabelActive]}>{opt.label}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>

              {recordingDevices.length > 0 ? (
                <View>
                  <Text style={styles.label}>Recorded with</Text>
                  <View style={styles.deviceRow}>
                    <Pressable
                      onPress={() => setRecordingDeviceId(null)}
                      style={[styles.deviceChip, recordingDeviceId === null && styles.deviceChipActive]}
                    >
                      <Text style={[styles.deviceChipLabel, recordingDeviceId === null && styles.deviceChipLabelActive]}>None</Text>
                    </Pressable>
                    {recordingDevices.map((d) => (
                      <Pressable
                        key={d.id}
                        onPress={() => setRecordingDeviceId(d.id)}
                        style={[styles.deviceChip, recordingDeviceId === d.id && styles.deviceChipActive]}
                      >
                        <Text style={[styles.deviceChipLabel, recordingDeviceId === d.id && styles.deviceChipLabelActive]}>{d.name}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
              ) : (
                <Pressable onPress={() => navigation.navigate('Devices')} hitSlop={6}>
                  <Text style={styles.deviceLinkHint}>Tag which device recorded this ride — add one under Devices.</Text>
                </Pressable>
              )}

              <Button title="Save ride" onPress={onSave} loading={saving} />
              <Button title="Choose a different file" variant="ghost" onPress={onChooseFile} disabled={saving || picking} />
            </View>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { padding: spacing.md, paddingBottom: spacing.xxl, gap: spacing.md },

  introCard: {
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    marginTop: spacing.md,
  },
  introIcon: {
    width: 56,
    height: 56,
    borderRadius: radius.xl,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  introTitle: { ...typeTokens.h3, color: colors.textPrimary },
  introBody: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center', lineHeight: 20, marginBottom: spacing.sm },

  statsCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around' },
  statsDivider: { height: 1, backgroundColor: colors.border },

  form: { gap: spacing.md },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.2 },
  visibilityRow: { flexDirection: 'row', gap: spacing.xs },
  visibilityOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  visibilityOptionActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  visibilityLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  visibilityLabelActive: { color: colors.accent, fontFamily: fonts.semiBold },

  deviceRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  deviceChip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  deviceChipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  deviceChipLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  deviceChipLabelActive: { color: colors.accent, fontFamily: fonts.semiBold },
  deviceLinkHint: { fontFamily: fonts.medium, fontSize: 12, color: colors.accent },
});
