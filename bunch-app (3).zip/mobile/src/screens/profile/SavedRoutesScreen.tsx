import React, { useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Card } from '@/components/ui/Card';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { RideMap } from '@/components/RideMap';
import { useAuthStore } from '@/state/authStore';
import { listMyRoutes, deleteRoute, setRouteVisibility, FREE_ROUTE_LIMIT } from '@/lib/api/routes';
import { getErrorMessage } from '@/lib/errors';
import { boundingBox, geoJSONToCoordinates } from '@/lib/geo';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { RoutesScreenProps } from '@/navigation/types';
import type { RouteRow } from '@/lib/database.types';

export function SavedRoutesScreen({ navigation }: RoutesScreenProps<'SavedRoutes'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [routes, setRoutes] = useState<RouteRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    listMyRoutes(profile.id)
      .then(setRoutes)
      .finally(() => setLoading(false));
  }, [profile]);

  function onToggleVisibility(route: RouteRow) {
    const next = !route.is_public;
    setRoutes((prev) => prev.map((r) => (r.id === route.id ? { ...r, is_public: next } : r)));
    setRouteVisibility(route.id, next).catch((e) => {
      setRoutes((prev) => prev.map((r) => (r.id === route.id ? { ...r, is_public: route.is_public } : r)));
      Alert.alert('Could not update visibility', getErrorMessage(e));
    });
  }

  function onDelete(route: RouteRow) {
    Alert.alert('Delete this route?', `"${route.name}" will be removed from your saved routes.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          const previous = routes;
          setRoutes((prev) => prev.filter((r) => r.id !== route.id));
          try {
            await deleteRoute(route.id);
          } catch (e) {
            setRoutes(previous);
            Alert.alert('Could not delete route', getErrorMessage(e));
          }
        },
      },
    ]);
  }

  if (loading) return <LoadingView />;

  const atCap = !profile?.is_premium && routes.length >= FREE_ROUTE_LIMIT;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10} style={styles.backButton}>
          <Ionicons name="chevron-back" size={22} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Saved routes</Text>
        <Pressable onPress={() => navigation.navigate('RouteBuilder')} hitSlop={10} style={styles.addButton}>
          <Ionicons name="add" size={24} color={colors.textOnAccent} />
        </Pressable>
      </View>

      <FlatList
        data={routes}
        keyExtractor={(r) => r.id}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        ListHeaderComponent={
          routes.length > 0 ? (
            <Text style={styles.hint}>
              Save a route from any ride's detail screen to reuse it later. {atCap ? 'Bunch Premium unlocks unlimited saved routes.' : `Free plan: ${routes.length}/${FREE_ROUTE_LIMIT} saved.`}
            </Text>
          ) : null
        }
        renderItem={({ item }) => {
          const bounds = boundingBox(item.route_geojson);
          const coords = geoJSONToCoordinates(item.route_geojson);
          return (
            <Card padded={false} style={styles.routeCard}>
              {coords.length > 1 ? <RideMap routeCoordinates={coords} bounds={bounds} interactive={false} style={styles.routeMap} /> : null}
              <View style={styles.routeBody}>
                <Text style={styles.routeName}>{item.name}</Text>
                <View style={styles.routeStatsRow}>
                  <Text style={styles.routeStat}>{formatDistance(item.distance_m, units)}</Text>
                  <Text style={styles.routeStatDivider}>·</Text>
                  <Text style={styles.routeStat}>{formatElevation(item.elevation_gain_m, units)} elevation</Text>
                  <Text style={styles.routeStatDivider}>·</Text>
                  <Text style={styles.routeStat}>{item.surface_type}</Text>
                </View>
                <View style={styles.cardActionsRow}>
                  <Pressable onPress={() => onToggleVisibility(item)} style={styles.visibilityButton}>
                    <Ionicons
                      name={item.is_public ? 'earth-outline' : 'lock-closed-outline'}
                      size={13}
                      color={colors.textSecondary}
                    />
                    <Text style={styles.visibilityLabel}>{item.is_public ? 'Public' : 'Private'}</Text>
                  </Pressable>
                  <Pressable onPress={() => onDelete(item)} style={styles.deleteButton}>
                    <Ionicons name="trash-outline" size={14} color={colors.danger} />
                    <Text style={styles.deleteLabel}>Delete</Text>
                  </Pressable>
                </View>
              </View>
            </Card>
          );
        }}
        ListEmptyComponent={
          <EmptyState
            icon={<Ionicons name="map-outline" size={32} color={colors.textTertiary} />}
            title="No saved routes yet"
            description="Open a ride you've recorded and save it as a route to plan the same ride again later."
          />
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.sm },
  headerTitle: { ...typeTokens.h2, color: colors.textPrimary, flex: 1, marginLeft: spacing.sm },
  backButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceHigh, alignItems: 'center', justifyContent: 'center' },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  hint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginBottom: spacing.sm, lineHeight: 17 },
  routeCard: { overflow: 'hidden' },
  routeMap: { height: 140, borderRadius: 0 },
  routeBody: { padding: spacing.md, gap: 4 },
  routeName: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  routeStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' },
  routeStat: { fontFamily: fonts.regular, fontSize: 12, color: colors.textSecondary },
  routeStatDivider: { color: colors.textTertiary },
  cardActionsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: spacing.xs },
  visibilityButton: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  visibilityLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary },
  deleteButton: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' },
  deleteLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.danger },
});
