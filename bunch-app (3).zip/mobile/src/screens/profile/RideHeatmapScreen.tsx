import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Camera, LineLayer, MapView, ShapeSource } from '@maplibre/maplibre-react-native';
import { Ionicons } from '@expo/vector-icons';
import { MapAttribution } from '@/components/map/MapAttribution';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { listMyRideTracks } from '@/lib/api/rides';
import { geoJSONToCoordinates, boundingBox } from '@/lib/geo';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';

const STYLE_URL = 'https://tiles.openfreemap.org/styles/liberty';

/**
 * "Where have I ridden the most" — every recorded ride's track, overlaid on
 * one map. There's no dedicated heatmap layer for line data in MapLibre (its
 * HeatmapLayer is for point density), so this uses the same technique real
 * GPS-track heatmaps use: draw every track into ONE source at low, constant
 * opacity and let ordinary alpha blending do the accumulation — a road
 * ridden 20 times ends up visibly brighter than one ridden once, because
 * each pass's faint line stacks on the last. One ShapeSource/LineLayer pair
 * for all tracks (not one per ride) so this stays one native layer even for
 * a rider with hundreds of rides.
 */
export function RideHeatmapScreen({ navigation }: ProfileScreenProps<'RideHeatmap'>) {
  const profile = useAuthStore((s) => s.profile);
  const [loading, setLoading] = useState(true);
  const [rideCount, setRideCount] = useState(0);
  const [lines, setLines] = useState<GeoJSON.FeatureCollection | null>(null);
  const [bounds, setBounds] = useState<[number, number, number, number] | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const cameraRef = React.useRef<any>(null); // eslint-disable-line @typescript-eslint/no-explicit-any

  useEffect(() => {
    if (!profile) return;
    listMyRideTracks(profile.id)
      .then((tracks) => {
        const withCoords = tracks.map((t) => geoJSONToCoordinates(t.route_geojson)).filter((c) => c.length > 1);
        setRideCount(withCoords.length);

        if (withCoords.length > 0) {
          setLines({
            type: 'FeatureCollection',
            features: withCoords.map((coords) => ({
              type: 'Feature',
              properties: {},
              geometry: { type: 'LineString', coordinates: coords },
            })),
          });

          let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity;
          for (const coords of withCoords) {
            const b = boundingBox({ type: 'LineString', coordinates: coords });
            if (!b) continue;
            if (b[0] < minLng) minLng = b[0];
            if (b[1] < minLat) minLat = b[1];
            if (b[2] > maxLng) maxLng = b[2];
            if (b[3] > maxLat) maxLat = b[3];
          }
          if (minLng !== Infinity) setBounds([minLng, minLat, maxLng, maxLat]);
        }
      })
      .finally(() => setLoading(false));
  }, [profile]);

  useEffect(() => {
    if (!bounds || !mapReady) return;
    const [minLng, minLat, maxLng, maxLat] = bounds;
    if (minLng === maxLng && minLat === maxLat) {
      cameraRef.current?.setCamera({ centerCoordinate: [minLng, minLat], zoomLevel: 12, animationDuration: 400 });
    } else {
      cameraRef.current?.fitBounds([maxLng, maxLat], [minLng, minLat], 48, 600);
    }
  }, [bounds, mapReady]);

  return (
    <View style={styles.root}>
      {loading ? (
        <LoadingView label="Building your heatmap…" />
      ) : !lines ? (
        <SafeAreaView edges={['top']} style={styles.emptyWrap}>
          <View style={styles.header}>
            <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
              <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
            </Pressable>
            <Text style={styles.headerTitle}>Heatmap</Text>
            <View style={{ width: 26 }} />
          </View>
          <EmptyState
            icon={<Ionicons name="flame-outline" size={32} color={colors.textTertiary} />}
            title="No tracks yet"
            description="Record a few rides with GPS and the roads you ride most will start glowing brighter here."
          />
        </SafeAreaView>
      ) : (
        <>
          <MapView style={StyleSheet.absoluteFillObject} mapStyle={STYLE_URL} logoEnabled={false} attributionEnabled={false} onDidFinishLoadingMap={() => setMapReady(true)}>
            <Camera ref={cameraRef} animationMode="flyTo" animationDuration={600} />
            <ShapeSource id="heatmapTracks" shape={lines}>
              <LineLayer
                id="heatmapTracksLayer"
                style={{ lineColor: '#FF6A3D', lineWidth: 2.5, lineOpacity: 0.16, lineCap: 'round', lineJoin: 'round' }}
              />
            </ShapeSource>
          </MapView>

          <SafeAreaView edges={['top']} style={styles.overlayHeader} pointerEvents="box-none">
            <Pressable onPress={() => navigation.goBack()} hitSlop={10} style={styles.backButton}>
              <Ionicons name="chevron-back" size={22} color={colors.textPrimary} />
            </Pressable>
            <View style={styles.titlePill}>
              <Ionicons name="flame" size={13} color="#FF6A3D" />
              <Text style={styles.titlePillText}>
                {rideCount} ride{rideCount === 1 ? '' : 's'} mapped
              </Text>
            </View>
          </SafeAreaView>

          <MapAttribution />
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  emptyWrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  overlayHeader: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  backButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.overlay, alignItems: 'center', justifyContent: 'center' },
  titlePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.overlay,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  titlePillText: { fontFamily: fonts.semiBold, fontSize: 12.5, color: colors.textPrimary },
});
