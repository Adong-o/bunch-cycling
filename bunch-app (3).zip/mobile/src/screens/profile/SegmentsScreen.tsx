import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Card } from '@/components/ui/Card';
import { LoadingView } from '@/components/ui/LoadingView';
import { useAuthStore } from '@/state/authStore';
import { listStarredSegments, listNearbySegments, starSegment, unstarSegment, FREE_STARRED_SEGMENT_LIMIT } from '@/lib/api/segments';
import { getErrorMessage } from '@/lib/errors';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Segment, UnitSystem } from '@/lib/database.types';

export function SegmentsScreen({ navigation }: ProfileScreenProps<'Segments'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [starred, setStarred] = useState<Segment[]>([]);
  const [nearby, setNearby] = useState<Segment[]>([]);
  const [loading, setLoading] = useState(true);
  const [nearbyLoading, setNearbyLoading] = useState(true);
  const [nearbyAvailable, setNearbyAvailable] = useState(true);
  const [pendingId, setPendingId] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;

    listStarredSegments(profile.id)
      .then(setStarred)
      .finally(() => setLoading(false));

    // Nearby discovery is best-effort: if location permission was never
    // granted, or a fix can't be found, we simply hide the section rather
    // than surfacing an error — starring from a ride stays the primary flow.
    (async () => {
      try {
        const { granted } = await Location.getForegroundPermissionsAsync();
        if (!granted) {
          setNearbyAvailable(false);
          return;
        }
        const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const found = await listNearbySegments(pos.coords.latitude, pos.coords.longitude);
        setNearby(found);
      } catch {
        setNearbyAvailable(false);
      } finally {
        setNearbyLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const starredIds = new Set(starred.map((s) => s.id));
  const atCap = !profile?.is_premium && starred.length >= FREE_STARRED_SEGMENT_LIMIT;
  const nearbyOnly = nearby.filter((s) => !starredIds.has(s.id));

  async function onToggleStar(segment: Segment) {
    if (!profile || pendingId) return;
    const isStarred = starredIds.has(segment.id);
    if (!isStarred && atCap) return;

    setPendingId(segment.id);
    if (isStarred) {
      setStarred((prev) => prev.filter((s) => s.id !== segment.id));
      try {
        await unstarSegment(profile.id, segment.id);
      } catch (e) {
        setStarred((prev) => [...prev, segment]);
        Alert.alert('Could not unstar segment', getErrorMessage(e));
      }
    } else {
      setStarred((prev) => [...prev, segment]);
      try {
        await starSegment(profile.id, segment.id);
      } catch (e) {
        setStarred((prev) => prev.filter((s) => s.id !== segment.id));
        Alert.alert('Could not star segment', getErrorMessage(e));
      }
    }
    setPendingId(null);
  }

  if (loading) return <LoadingView />;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Segments</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.sectionLabel}>
          STARRED{!profile?.is_premium ? `  ${starred.length}/${FREE_STARRED_SEGMENT_LIMIT}` : ''}
        </Text>
        {starred.length === 0 ? (
          <Text style={styles.hint}>
            Star a segment to automatically track your effort on it next time you ride it. Create one from any ride's detail screen.
          </Text>
        ) : (
          <View style={styles.list}>
            {starred.map((segment) => (
              <SegmentRow
                key={segment.id}
                segment={segment}
                units={units}
                starred
                busy={pendingId === segment.id}
                onPress={() => navigation.navigate('SegmentDetail', { segmentId: segment.id })}
                onToggleStar={() => onToggleStar(segment)}
              />
            ))}
          </View>
        )}
        {atCap ? <Text style={styles.capHint}>Bunch Premium unlocks unlimited starred segments.</Text> : null}

        {!nearbyLoading && nearbyAvailable ? (
          <>
            <Text style={[styles.sectionLabel, styles.sectionSpaced]}>NEARBY</Text>
            {nearbyOnly.length === 0 ? (
              <Text style={styles.hint}>No segments found near your current location yet.</Text>
            ) : (
              <View style={styles.list}>
                {nearbyOnly.map((segment) => (
                  <SegmentRow
                    key={segment.id}
                    segment={segment}
                    units={units}
                    starred={false}
                    busy={pendingId === segment.id}
                    disabledStar={atCap}
                    onPress={() => navigation.navigate('SegmentDetail', { segmentId: segment.id })}
                    onToggleStar={() => onToggleStar(segment)}
                  />
                ))}
              </View>
            )}
          </>
        ) : null}
      </ScrollView>
    </ScreenContainer>
  );
}

function SegmentRow({
  segment,
  units,
  starred,
  busy,
  disabledStar,
  onPress,
  onToggleStar,
}: {
  segment: Segment;
  units: UnitSystem;
  starred: boolean;
  busy: boolean;
  disabledStar?: boolean;
  onPress: () => void;
  onToggleStar: () => void;
}) {
  const starDisabled = busy || (!starred && !!disabledStar);
  return (
    <Card padded={false} style={styles.row}>
      <Pressable onPress={onPress} style={styles.rowMain}>
        <View style={styles.rowIcon}>
          <Ionicons name="flag-outline" size={18} color={colors.accent} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.rowName} numberOfLines={1}>
            {segment.name}
          </Text>
          <View style={styles.rowStatsRow}>
            <Text style={styles.rowStat}>{formatDistance(segment.distance_m, units)}</Text>
            <Text style={styles.rowStatDivider}>·</Text>
            <Text style={styles.rowStat}>{formatElevation(segment.elevation_gain_m, units)}</Text>
            {segment.avg_grade_pct != null ? (
              <>
                <Text style={styles.rowStatDivider}>·</Text>
                <Text style={styles.rowStat}>{segment.avg_grade_pct.toFixed(1)}%</Text>
              </>
            ) : null}
          </View>
        </View>
      </Pressable>
      <Pressable onPress={onToggleStar} hitSlop={10} disabled={starDisabled} style={styles.starButton}>
        <Ionicons name={starred ? 'star' : 'star-outline'} size={20} color={starred ? colors.gold : starDisabled ? colors.textTertiary : colors.textSecondary} />
      </Pressable>
    </Card>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  sectionLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textTertiary, letterSpacing: 0.4, marginBottom: spacing.sm },
  sectionSpaced: { marginTop: spacing.lg },
  hint: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, lineHeight: 19, marginBottom: spacing.xs },
  capHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: spacing.xs, textAlign: 'center' },
  list: { gap: spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center' },
  rowMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.sm, paddingLeft: spacing.md },
  rowIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowName: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
  rowStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2, flexWrap: 'wrap' },
  rowStat: { fontFamily: fonts.regular, fontSize: 12, color: colors.textSecondary },
  rowStatDivider: { color: colors.textTertiary, fontSize: 12 },
  starButton: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm, alignItems: 'center', justifyContent: 'center' },
});
