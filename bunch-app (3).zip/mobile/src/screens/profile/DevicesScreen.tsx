import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Modal, PermissionsAndroid, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { listDevices, addDevice, removeDevice } from '@/lib/api/devices';
import {
  listRecordingDevices,
  createRecordingDevice,
  deleteRecordingDevice,
  recordingDeviceBrandLabel,
  RECORDING_DEVICE_BRANDS,
  FREE_RECORDING_DEVICE_LIMIT,
} from '@/lib/api/recordingDevices';
import { getErrorMessage } from '@/lib/errors';
import { destroyBleManager, disconnectPeripheral, scanForSensors, subscribeToSensor, type ScannedPeripheral, type SensorKind } from '@/lib/ble';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Device, DeviceType, RecordingDevice, RecordingDeviceBrand } from '@/lib/database.types';

const DEVICE_TYPES: Array<{ value: DeviceType; label: string; icon: keyof typeof Ionicons.glyphMap; sensorKind: SensorKind | null }> = [
  { value: 'heart_rate', label: 'Heart rate', icon: 'heart-outline', sensorKind: 'heart_rate' },
  { value: 'speed_cadence', label: 'Speed/cadence', icon: 'speedometer-outline', sensorKind: 'speed_cadence' },
  { value: 'power', label: 'Power meter', icon: 'flash-outline', sensorKind: 'power' },
  { value: 'combo', label: 'Combo sensor', icon: 'hardware-chip-outline', sensorKind: null },
  { value: 'other', label: 'Other', icon: 'bluetooth-outline', sensorKind: null },
];

const PAIRABLE_TYPES = DEVICE_TYPES.filter((t) => t.sensorKind != null);

const READING_UNIT: Record<SensorKind, string> = { heart_rate: 'bpm', speed_cadence: 'rpm', power: 'W' };

/** Android 12+ requires a runtime grant for BLE scan/connect on top of the manifest entries; older Android covers BLE scanning under the location permission already requested during onboarding. */
async function ensureAndroidBlePermission(): Promise<boolean> {
  if (Platform.OS !== 'android' || Platform.Version < 31) return true;
  const results = await PermissionsAndroid.requestMultiple([
    PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
    PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
  ]);
  return (
    results[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN] === PermissionsAndroid.RESULTS.GRANTED &&
    results[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] === PermissionsAndroid.RESULTS.GRANTED
  );
}

export function DevicesScreen({ navigation }: ProfileScreenProps<'Devices'>) {
  const profile = useAuthStore((s) => s.profile);

  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);

  // Manual add — for 'combo' / 'other', which have no single standard GATT profile to pair against.
  const [manualAdd, setManualAdd] = useState(false);
  const [manualName, setManualName] = useState('');
  const [manualType, setManualType] = useState<DeviceType>('combo');
  const [manualSaving, setManualSaving] = useState(false);
  const [manualError, setManualError] = useState<string | null>(null);

  // Recording devices registry — a saved record of what GPS watch/computer
  // recorded a ride, not a live BLE connection (see recordingDevices.ts).
  const [recordingDevices, setRecordingDevices] = useState<RecordingDevice[]>([]);
  const [addingRecordingDevice, setAddingRecordingDevice] = useState(false);
  const [newRecordingDeviceBrand, setNewRecordingDeviceBrand] = useState<RecordingDeviceBrand>('garmin');
  const [newRecordingDeviceName, setNewRecordingDeviceName] = useState('');
  const [recordingDeviceSaving, setRecordingDeviceSaving] = useState(false);
  const [recordingDeviceError, setRecordingDeviceError] = useState<string | null>(null);

  // Scan sheet
  const [scanOpen, setScanOpen] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [found, setFound] = useState<ScannedPeripheral[]>([]);
  const [scanError, setScanError] = useState<string | null>(null);
  const stopScanRef = useRef<(() => void) | null>(null);
  const scanStopTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Pairing a found peripheral
  const [pairing, setPairing] = useState<ScannedPeripheral | null>(null);
  const [pairType, setPairType] = useState<DeviceType>('heart_rate');
  const [pairStatus, setPairStatus] = useState<'idle' | 'connecting' | 'waiting' | 'reading' | 'error'>('idle');
  const [pairReading, setPairReading] = useState<number | null>(null);
  const [pairError, setPairError] = useState<string | null>(null);
  const unsubscribePairRef = useRef<(() => void) | null>(null);
  const pairWaitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Live view for an already-paired device
  const [liveDevice, setLiveDevice] = useState<Device | null>(null);
  const [liveReading, setLiveReading] = useState<number | null>(null);
  const [liveStatus, setLiveStatus] = useState<'connecting' | 'live' | 'error'>('connecting');
  const [liveError, setLiveError] = useState<string | null>(null);
  const unsubscribeLiveRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!profile) return;
    listDevices(profile.id)
      .then(setDevices)
      .finally(() => setLoading(false));
    listRecordingDevices(profile.id)
      .then(setRecordingDevices)
      .catch(() => {});
  }, [profile]);

  // Belt-and-braces: release any open scan/connection and the native
  // manager itself if the screen unmounts mid-flow.
  useEffect(() => {
    return () => {
      stopScanRef.current?.();
      unsubscribePairRef.current?.();
      unsubscribeLiveRef.current?.();
      if (scanStopTimerRef.current) clearTimeout(scanStopTimerRef.current);
      if (pairWaitTimerRef.current) clearTimeout(pairWaitTimerRef.current);
      destroyBleManager();
    };
  }, []);

  function closeScan() {
    stopScanRef.current?.();
    stopScanRef.current = null;
    unsubscribePairRef.current?.();
    unsubscribePairRef.current = null;
    if (scanStopTimerRef.current) {
      clearTimeout(scanStopTimerRef.current);
      scanStopTimerRef.current = null;
    }
    if (pairWaitTimerRef.current) {
      clearTimeout(pairWaitTimerRef.current);
      pairWaitTimerRef.current = null;
    }
    setScanning(false);
    setScanOpen(false);
    setFound([]);
    setScanError(null);
    setPairing(null);
  }

  async function onOpenScan() {
    setScanOpen(true);
    setScanError(null);
    setFound([]);
    const granted = await ensureAndroidBlePermission();
    if (!granted) {
      setScanError("Bluetooth permission wasn't granted, so Bunch can't scan for sensors.");
      return;
    }
    setScanning(true);
    stopScanRef.current = scanForSensors(
      (peripheral) => setFound((prev) => (prev.some((p) => p.id === peripheral.id) ? prev : [...prev, peripheral])),
      (message) => {
        setScanError(message);
        setScanning(false);
      },
      12000
    );
    scanStopTimerRef.current = setTimeout(() => setScanning(false), 12000);
  }

  function onRescan() {
    setFound([]);
    setScanError(null);
    onOpenScan();
  }

  function onPickFound(peripheral: ScannedPeripheral) {
    stopScanRef.current?.();
    setPairing(peripheral);
    setPairType('heart_rate');
    setPairStatus('idle');
    setPairReading(null);
    setPairError(null);
  }

  async function onConfirmPair() {
    if (!pairing) return;
    const sensorKind = DEVICE_TYPES.find((t) => t.value === pairType)?.sensorKind;
    if (!sensorKind) return;

    setPairStatus('connecting');
    setPairError(null);
    let gotReading = false;

    unsubscribePairRef.current = await subscribeToSensor(
      pairing.id,
      sensorKind,
      (value) => {
        gotReading = true;
        setPairReading(value);
        setPairStatus('reading');
      },
      (message) => {
        setPairStatus('error');
        setPairError(message);
      }
    );

    setPairStatus((s) => (s === 'connecting' ? 'waiting' : s));
    // A sensor that isn't actively broadcasting yet (a heart rate strap not
    // being worn, for instance) may not send a first notification right
    // away — don't block saving on that forever.
    pairWaitTimerRef.current = setTimeout(() => {
      if (!gotReading) {
        setPairStatus((s) => (s === 'waiting' ? 'reading' : s));
      }
    }, 6000);
  }

  async function onSavePairing() {
    if (!pairing || !profile) return;
    try {
      const device = await addDevice({
        user_id: profile.id,
        name: pairing.name,
        type: pairType,
        ble_identifier: pairing.id,
        last_connected_at: new Date().toISOString(),
      });
      setDevices((prev) => [...prev, device]);
      closeScan();
    } catch (e) {
      setPairError(getErrorMessage(e));
    }
  }

  function onCancelPairing() {
    unsubscribePairRef.current?.();
    unsubscribePairRef.current = null;
    if (pairWaitTimerRef.current) {
      clearTimeout(pairWaitTimerRef.current);
      pairWaitTimerRef.current = null;
    }
    setPairing(null);
  }

  async function onManualAdd() {
    if (!profile || !manualName.trim()) return;
    setManualSaving(true);
    setManualError(null);
    try {
      const device = await addDevice({ user_id: profile.id, name: manualName.trim(), type: manualType });
      setDevices((prev) => [...prev, device]);
      setManualName('');
      setManualType('combo');
      setManualAdd(false);
    } catch (e) {
      setManualError(getErrorMessage(e));
    } finally {
      setManualSaving(false);
    }
  }

  function onRemove(device: Device) {
    Alert.alert('Remove this device?', `"${device.name}" will be removed from your paired devices.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          const previous = devices;
          setDevices((prev) => prev.filter((d) => d.id !== device.id));
          try {
            await removeDevice(device.id);
          } catch (e) {
            setDevices(previous);
            Alert.alert('Could not remove device', getErrorMessage(e));
          }
        },
      },
    ]);
  }

  async function onAddRecordingDevice() {
    if (!profile || !newRecordingDeviceName.trim()) return;
    setRecordingDeviceSaving(true);
    setRecordingDeviceError(null);
    try {
      const device = await createRecordingDevice({
        user_id: profile.id,
        name: newRecordingDeviceName.trim(),
        brand: newRecordingDeviceBrand,
      });
      setRecordingDevices((prev) => [...prev, device]);
      setNewRecordingDeviceName('');
      setNewRecordingDeviceBrand('garmin');
      setAddingRecordingDevice(false);
    } catch (e) {
      // The DB's own free-plan-limit message already reads as a complete,
      // friendly sentence, same as the Garage/Routes screens' pattern.
      setRecordingDeviceError(getErrorMessage(e));
    } finally {
      setRecordingDeviceSaving(false);
    }
  }

  function onRemoveRecordingDevice(device: RecordingDevice) {
    Alert.alert('Remove this device?', `"${device.name}" will be removed. Any past rides tagged with it will no longer show it.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          const previous = recordingDevices;
          setRecordingDevices((prev) => prev.filter((d) => d.id !== device.id));
          try {
            await deleteRecordingDevice(device.id);
          } catch (e) {
            setRecordingDevices(previous);
            Alert.alert('Could not remove device', getErrorMessage(e));
          }
        },
      },
    ]);
  }

  async function onOpenLive(device: Device) {
    const sensorKind = DEVICE_TYPES.find((t) => t.value === device.type)?.sensorKind;
    if (!sensorKind || !device.ble_identifier) return;

    setLiveDevice(device);
    setLiveStatus('connecting');
    setLiveReading(null);
    setLiveError(null);

    unsubscribeLiveRef.current = await subscribeToSensor(
      device.ble_identifier,
      sensorKind,
      (value) => {
        setLiveReading(value);
        setLiveStatus('live');
      },
      (message) => {
        setLiveStatus('error');
        setLiveError(message);
      }
    );
  }

  function onCloseLive() {
    unsubscribeLiveRef.current?.();
    unsubscribeLiveRef.current = null;
    if (liveDevice?.ble_identifier) disconnectPeripheral(liveDevice.ble_identifier);
    setLiveDevice(null);
  }

  const recordingDeviceAtCap = !profile?.is_premium && recordingDevices.length >= FREE_RECORDING_DEVICE_LIMIT;

  if (loading) return <LoadingView />;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Devices</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.hint}>
          Pair a heart rate strap, speed/cadence sensor or power meter over Bluetooth to read live data from it here.
          Other sensor types can be kept as a record of your setup without a live connection.
        </Text>

        {devices.length === 0 ? (
          <EmptyState
            icon={<Ionicons name="bluetooth-outline" size={32} color={colors.textTertiary} />}
            title="No devices yet"
            description="Pair a sensor over Bluetooth, or add one manually to keep a record of your setup."
          />
        ) : (
          <View style={styles.list}>
            {devices.map((device) => {
              const meta = DEVICE_TYPES.find((t) => t.value === device.type) ?? DEVICE_TYPES[DEVICE_TYPES.length - 1];
              const canGoLive = !!meta.sensorKind && !!device.ble_identifier;
              return (
                <Card key={device.id} style={styles.deviceCard}>
                  <View style={styles.deviceRow}>
                    <View style={styles.deviceIcon}>
                      <Ionicons name={meta.icon} size={20} color={colors.accent} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.deviceName}>{device.name}</Text>
                      <Text style={styles.deviceMeta}>
                        {meta.label}
                        {canGoLive ? ' · Paired' : ''}
                      </Text>
                    </View>
                    {canGoLive ? (
                      <Pressable onPress={() => onOpenLive(device)} hitSlop={8} style={styles.liveButton}>
                        <Ionicons name="pulse-outline" size={13} color={colors.accent} />
                        <Text style={styles.liveButtonLabel}>Live</Text>
                      </Pressable>
                    ) : null}
                    <Pressable onPress={() => onRemove(device)} hitSlop={10}>
                      <Ionicons name="trash-outline" size={18} color={colors.danger} />
                    </Pressable>
                  </View>
                </Card>
              );
            })}
          </View>
        )}

        <Button title="Pair a sensor over Bluetooth" onPress={onOpenScan} />

        {manualAdd ? (
          <Card style={styles.addCard}>
            <Text style={styles.addCardLabel}>Add without pairing</Text>
            <TextField label="Device name" value={manualName} onChangeText={setManualName} placeholder="e.g. Wahoo TICKR" />
            <View style={styles.typeRow}>
              {DEVICE_TYPES.map((t) => (
                <Pressable key={t.value} onPress={() => setManualType(t.value)} style={[styles.typeChip, manualType === t.value && styles.typeChipActive]}>
                  <Ionicons name={t.icon} size={13} color={manualType === t.value ? colors.accent : colors.textSecondary} />
                  <Text style={[styles.typeChipLabel, manualType === t.value && styles.typeChipLabelActive]}>{t.label}</Text>
                </Pressable>
              ))}
            </View>
            {manualError ? <Text style={styles.error}>{manualError}</Text> : null}
            <View style={styles.addActions}>
              <Button title="Cancel" variant="ghost" fullWidth={false} onPress={() => setManualAdd(false)} />
              <Button title="Add" onPress={onManualAdd} loading={manualSaving} fullWidth={false} style={{ paddingHorizontal: spacing.xl }} />
            </View>
          </Card>
        ) : (
          <Button title="Add a device without pairing" variant="ghost" onPress={() => setManualAdd(true)} />
        )}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recording devices</Text>
          <Text style={styles.hint}>
            Tag which GPS watch or bike computer recorded a ride, so it can show on your rides — a saved record, not
            a live sync. Bunch doesn't connect to Garmin, Coros, Wahoo or similar accounts directly.
          </Text>
        </View>

        {recordingDevices.length === 0 && !addingRecordingDevice ? (
          <EmptyState
            icon={<Ionicons name="watch-outline" size={32} color={colors.textTertiary} />}
            title="No recording devices yet"
            description="Add your Garmin, Coros, Wahoo or other device so your rides can show what recorded them."
          />
        ) : (
          <View style={styles.list}>
            {recordingDevices.map((device) => (
              <Card key={device.id} style={styles.deviceCard}>
                <View style={styles.deviceRow}>
                  <View style={styles.deviceIcon}>
                    <Ionicons name="watch-outline" size={20} color={colors.accent} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.deviceName}>{device.name}</Text>
                    <Text style={styles.deviceMeta}>{recordingDeviceBrandLabel(device.brand)}</Text>
                  </View>
                  <Pressable onPress={() => onRemoveRecordingDevice(device)} hitSlop={10}>
                    <Ionicons name="trash-outline" size={18} color={colors.danger} />
                  </Pressable>
                </View>
              </Card>
            ))}
          </View>
        )}

        {addingRecordingDevice ? (
          <Card style={styles.addCard}>
            <Text style={styles.addCardLabel}>Add a recording device</Text>
            <View style={styles.typeRow}>
              {RECORDING_DEVICE_BRANDS.map((b) => (
                <Pressable
                  key={b.value}
                  onPress={() => setNewRecordingDeviceBrand(b.value)}
                  style={[styles.typeChip, newRecordingDeviceBrand === b.value && styles.typeChipActive]}
                >
                  <Text style={[styles.typeChipLabel, newRecordingDeviceBrand === b.value && styles.typeChipLabelActive]}>{b.label}</Text>
                </Pressable>
              ))}
            </View>
            <TextField
              label="Name"
              value={newRecordingDeviceName}
              onChangeText={setNewRecordingDeviceName}
              placeholder={`e.g. My ${recordingDeviceBrandLabel(newRecordingDeviceBrand)}`}
            />
            {recordingDeviceError ? <Text style={styles.error}>{recordingDeviceError}</Text> : null}
            <View style={styles.addActions}>
              <Button title="Cancel" variant="ghost" fullWidth={false} onPress={() => setAddingRecordingDevice(false)} />
              <Button
                title="Add"
                onPress={onAddRecordingDevice}
                loading={recordingDeviceSaving}
                fullWidth={false}
                style={{ paddingHorizontal: spacing.xl }}
              />
            </View>
          </Card>
        ) : (
          <Button
            title={recordingDeviceAtCap ? `Free plan: ${recordingDevices.length}/${FREE_RECORDING_DEVICE_LIMIT} device` : 'Add a recording device'}
            variant="secondary"
            onPress={() => (recordingDeviceAtCap ? null : setAddingRecordingDevice(true))}
            disabled={recordingDeviceAtCap}
          />
        )}
        {recordingDeviceAtCap ? <Text style={styles.capHint}>Bunch Premium unlocks unlimited recording devices.</Text> : null}
      </ScrollView>

      {/* Scan + pair sheet */}
      <Modal visible={scanOpen} animationType="slide" transparent onRequestClose={closeScan}>
        <View style={styles.sheetScrim}>
          <View style={styles.sheet}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>{pairing ? 'Pair sensor' : 'Nearby sensors'}</Text>
              <Pressable onPress={closeScan} hitSlop={10}>
                <Ionicons name="close" size={22} color={colors.textSecondary} />
              </Pressable>
            </View>

            {!pairing ? (
              <>
                {scanError ? (
                  <View style={styles.sheetState}>
                    <Ionicons name="alert-circle-outline" size={28} color={colors.danger} />
                    <Text style={styles.sheetStateText}>{scanError}</Text>
                    <Button title="Try again" variant="secondary" fullWidth={false} onPress={onRescan} />
                  </View>
                ) : (
                  <ScrollView style={styles.sheetList} contentContainerStyle={{ gap: spacing.xs }}>
                    {found.map((peripheral) => (
                      <Pressable key={peripheral.id} onPress={() => onPickFound(peripheral)} style={styles.foundRow}>
                        <View style={styles.foundIcon}>
                          <Ionicons name="bluetooth-outline" size={18} color={colors.accent} />
                        </View>
                        <Text style={styles.foundName}>{peripheral.name}</Text>
                        <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
                      </Pressable>
                    ))}
                    {scanning ? (
                      <View style={styles.scanningRow}>
                        <ActivityIndicator color={colors.accent} />
                        <Text style={styles.scanningText}>Scanning for nearby sensors…</Text>
                      </View>
                    ) : found.length === 0 ? (
                      <View style={styles.sheetState}>
                        <Text style={styles.sheetStateText}>
                          No sensors found. Make sure it's powered on and awake — most sensors only advertise for a short
                          window after that.
                        </Text>
                        <Button title="Scan again" variant="secondary" fullWidth={false} onPress={onRescan} />
                      </View>
                    ) : null}
                  </ScrollView>
                )}
              </>
            ) : (
              <View style={styles.pairPanel}>
                <Text style={styles.pairDeviceName}>{pairing.name}</Text>
                <Text style={styles.pairHint}>What kind of sensor is this?</Text>
                <View style={styles.typeRow}>
                  {PAIRABLE_TYPES.map((t) => (
                    <Pressable
                      key={t.value}
                      onPress={() => setPairType(t.value)}
                      disabled={pairStatus !== 'idle'}
                      style={[styles.typeChip, pairType === t.value && styles.typeChipActive]}
                    >
                      <Ionicons name={t.icon} size={13} color={pairType === t.value ? colors.accent : colors.textSecondary} />
                      <Text style={[styles.typeChipLabel, pairType === t.value && styles.typeChipLabelActive]}>{t.label}</Text>
                    </Pressable>
                  ))}
                </View>

                {pairStatus === 'idle' ? (
                  <View style={styles.pairActions}>
                    <Button title="Cancel" variant="ghost" fullWidth={false} onPress={onCancelPairing} />
                    <Button title="Connect" onPress={onConfirmPair} fullWidth={false} style={{ paddingHorizontal: spacing.xl }} />
                  </View>
                ) : pairStatus === 'error' ? (
                  <View style={styles.sheetState}>
                    <Ionicons name="alert-circle-outline" size={26} color={colors.danger} />
                    <Text style={styles.sheetStateText}>{pairError}</Text>
                    <View style={styles.pairActions}>
                      <Button title="Back" variant="ghost" fullWidth={false} onPress={onCancelPairing} />
                      <Button title="Try again" onPress={onConfirmPair} fullWidth={false} style={{ paddingHorizontal: spacing.xl }} />
                    </View>
                  </View>
                ) : (
                  <View style={styles.readingBox}>
                    {pairStatus === 'connecting' ? (
                      <>
                        <ActivityIndicator color={colors.accent} />
                        <Text style={styles.readingLabel}>Connecting…</Text>
                      </>
                    ) : pairReading != null ? (
                      <>
                        <Text style={styles.readingValue}>
                          {pairReading} <Text style={styles.readingUnit}>{READING_UNIT[PAIRABLE_TYPES.find((t) => t.value === pairType)!.sensorKind!]}</Text>
                        </Text>
                        <Text style={styles.readingLabel}>Connected and reading live</Text>
                      </>
                    ) : (
                      <>
                        <Ionicons name="checkmark-circle-outline" size={26} color={colors.success} />
                        <Text style={styles.readingLabel}>
                          Connected — no reading yet. That's normal if the sensor isn't active right now; Bunch will read
                          from it once it's broadcasting.
                        </Text>
                      </>
                    )}
                    <View style={styles.pairActions}>
                      <Button title="Cancel" variant="ghost" fullWidth={false} onPress={onCancelPairing} />
                      <Button title="Save device" onPress={onSavePairing} fullWidth={false} style={{ paddingHorizontal: spacing.xl }} />
                    </View>
                  </View>
                )}
                {pairError && pairStatus !== 'error' ? <Text style={styles.error}>{pairError}</Text> : null}
              </View>
            )}
          </View>
        </View>
      </Modal>

      {/* Live reading sheet */}
      <Modal visible={!!liveDevice} animationType="fade" transparent onRequestClose={onCloseLive}>
        <View style={styles.sheetScrim}>
          <View style={[styles.sheet, styles.liveSheet]}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>{liveDevice?.name}</Text>
              <Pressable onPress={onCloseLive} hitSlop={10}>
                <Ionicons name="close" size={22} color={colors.textSecondary} />
              </Pressable>
            </View>
            <View style={styles.readingBox}>
              {liveStatus === 'connecting' ? (
                <>
                  <ActivityIndicator color={colors.accent} />
                  <Text style={styles.readingLabel}>Connecting…</Text>
                </>
              ) : liveStatus === 'error' ? (
                <>
                  <Ionicons name="alert-circle-outline" size={26} color={colors.danger} />
                  <Text style={styles.sheetStateText}>{liveError}</Text>
                </>
              ) : (
                <>
                  <View style={styles.liveDot} />
                  <Text style={styles.readingValue}>
                    {liveReading ?? '--'}{' '}
                    <Text style={styles.readingUnit}>
                      {liveDevice ? READING_UNIT[DEVICE_TYPES.find((t) => t.value === liveDevice.type)!.sensorKind!] : ''}
                    </Text>
                  </Text>
                  <Text style={styles.readingLabel}>Live</Text>
                </>
              )}
            </View>
            <Button title="Done" onPress={onCloseLive} />
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { padding: spacing.md, paddingBottom: spacing.xxl, gap: spacing.md },
  hint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, lineHeight: 17 },
  sectionHeader: { gap: 4, marginTop: spacing.sm, paddingTop: spacing.md, borderTopWidth: 1, borderTopColor: colors.border },
  sectionTitle: { ...typeTokens.h3, color: colors.textPrimary },
  capHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center' },
  list: { gap: spacing.sm },
  deviceCard: {},
  deviceRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  deviceIcon: {
    width: 42,
    height: 42,
    borderRadius: radius.sm,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deviceName: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  deviceMeta: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  liveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.accentMuted,
    marginRight: spacing.xs,
  },
  liveButtonLabel: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.accent },
  addCard: { gap: spacing.sm },
  addCardLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  typeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  typeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceHigh,
  },
  typeChipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  typeChipLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  typeChipLabelActive: { color: colors.accent, fontFamily: fonts.semiBold },
  addActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: spacing.sm },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 13 },

  sheetScrim: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(14,15,18,0.45)' },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xl,
    maxHeight: '75%',
  },
  liveSheet: { alignItems: 'stretch', gap: spacing.md },
  sheetHandle: { width: 36, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: 'center', marginBottom: spacing.sm },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.sm },
  sheetTitle: { ...typeTokens.h3, color: colors.textPrimary },
  sheetList: { maxHeight: 320 },
  sheetState: { alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.lg, paddingHorizontal: spacing.sm },
  sheetStateText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, textAlign: 'center', lineHeight: 19 },
  scanningRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.md, justifyContent: 'center' },
  scanningText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary },
  foundRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.sm,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceHigh,
    borderWidth: 1,
    borderColor: colors.border,
  },
  foundIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  foundName: { flex: 1, fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },

  pairPanel: { gap: spacing.md },
  pairDeviceName: { ...typeTokens.h3, color: colors.textPrimary },
  pairHint: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary, marginTop: -spacing.xs },
  pairActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: spacing.sm },

  readingBox: { alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.lg },
  readingValue: { fontFamily: fonts.semiBold, fontSize: 40, color: colors.textPrimary },
  readingUnit: { fontFamily: fonts.medium, fontSize: 16, color: colors.textSecondary },
  readingLabel: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, textAlign: 'center', paddingHorizontal: spacing.md },
  liveDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.success },
});
