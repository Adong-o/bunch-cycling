import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { Avatar } from '@/components/ui/Avatar';
import { RidingStylePicker } from '@/components/profile/RidingStylePicker';
import { supabase } from '@/lib/supabase';
import { uploadImage } from '@/lib/api/storage';
import { getErrorMessage } from '@/lib/errors';
import { useAuthStore } from '@/state/authStore';
import { colors, fonts, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { RidingStyle, UnitSystem } from '@/lib/database.types';

export function EditProfileScreen({ navigation }: ProfileScreenProps<'EditProfile'>) {
  const profile = useAuthStore((s) => s.profile);
  const updateLocalProfile = useAuthStore((s) => s.updateLocalProfile);

  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [username, setUsername] = useState(profile?.username ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [units, setUnits] = useState<UnitSystem>(profile?.units ?? 'metric');
  const [weightInput, setWeightInput] = useState(
    profile?.weight_kg != null ? String(Math.round(units === 'imperial' ? profile.weight_kg * 2.20462 : profile.weight_kg)) : ''
  );
  const [ridingStyles, setRidingStyles] = useState<RidingStyle[]>(profile?.riding_styles ?? []);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(profile?.avatar_url ?? null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function pickAvatar() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Allow photo access to change your profile picture.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (result.canceled || !profile) return;
    setUploadingAvatar(true);
    try {
      const url = await uploadImage('avatars', profile.id, result.assets[0].uri);
      setAvatarUrl(url);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setUploadingAvatar(false);
    }
  }

  async function onSave() {
    if (!profile) return;
    setError(null);

    const cleanUsername = username.trim().toLowerCase();
    if (!/^[a-z0-9_]{3,20}$/.test(cleanUsername)) {
      setError('Username: 3–20 characters, lowercase letters, numbers or underscore only.');
      return;
    }
    if (!displayName.trim()) {
      setError('Enter a display name.');
      return;
    }

    let weightKg: number | null = null;
    if (weightInput.trim()) {
      const parsed = Number(weightInput.trim());
      if (!Number.isFinite(parsed) || parsed <= 0) {
        setError('Enter a valid weight, or leave it blank.');
        return;
      }
      weightKg = units === 'imperial' ? parsed / 2.20462 : parsed;
    }

    setSaving(true);
    const patch = {
      display_name: displayName.trim(),
      username: cleanUsername,
      bio: bio.trim(),
      units,
      weight_kg: weightKg,
      avatar_url: avatarUrl,
      riding_styles: ridingStyles,
    };
    const { error: updateError } = await supabase.from('profiles').update(patch).eq('id', profile.id);
    setSaving(false);

    if (updateError) {
      setError(/unique/i.test(getErrorMessage(updateError)) ? 'That username is already taken.' : getErrorMessage(updateError));
      return;
    }

    updateLocalProfile(patch);
    navigation.goBack();
  }

  if (!profile) return null;

  return (
    <ScreenContainer>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
          <Text style={styles.headerTitle}>Edit profile</Text>
          <View style={{ width: 26 }} />
        </View>

        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <Pressable onPress={pickAvatar} style={styles.avatarRow} disabled={uploadingAvatar}>
            <Avatar uri={avatarUrl} name={displayName || 'Rider'} size={84} />
            <View style={styles.avatarEditBadge}>
              <Ionicons name={uploadingAvatar ? 'hourglass-outline' : 'camera-outline'} size={14} color={colors.textOnAccent} />
            </View>
          </Pressable>

          <View style={styles.form}>
            <TextField label="Display name" value={displayName} onChangeText={setDisplayName} placeholder="Alex Rider" />
            <TextField label="Username" value={username} onChangeText={(v) => setUsername(v.toLowerCase())} autoCapitalize="none" />
            <TextField
              label="Bio"
              value={bio}
              onChangeText={setBio}
              placeholder="A line about how and where you ride"
              multiline
              numberOfLines={3}
              style={styles.bioInput}
            />
            <TextField
              label={`Weight (optional, ${units === 'imperial' ? 'lb' : 'kg'}) — used only to estimate calories`}
              value={weightInput}
              onChangeText={setWeightInput}
              keyboardType="numeric"
              placeholder={units === 'imperial' ? 'e.g. 165' : 'e.g. 75'}
            />

            <View>
              <Text style={styles.label}>Units</Text>
              <View style={styles.unitsRow}>
                {(['metric', 'imperial'] as const).map((u) => (
                  <Pressable key={u} onPress={() => setUnits(u)} style={[styles.unitOption, units === u && styles.unitOptionActive]}>
                    <Text style={[styles.unitLabel, units === u && styles.unitLabelActive]}>{u === 'metric' ? 'Kilometers' : 'Miles'}</Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View>
              <Text style={styles.label}>Riding styles</Text>
              <RidingStylePicker value={ridingStyles} onChange={setRidingStyles} />
            </View>

            {error ? <Text style={styles.error}>{error}</Text> : null}
            <Button title="Save changes" onPress={onSave} loading={saving} style={{ marginTop: spacing.xs }} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: spacing.sm },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { gap: spacing.lg, paddingTop: spacing.lg, paddingBottom: spacing.xl },
  avatarRow: { alignSelf: 'center' },
  avatarEditBadge: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.bg,
  },
  form: { gap: spacing.md },
  bioInput: { minHeight: 64, textAlignVertical: 'top', paddingTop: 12 },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.2 },
  unitsRow: { flexDirection: 'row', gap: spacing.sm },
  unitOption: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: 'center',
  },
  unitOptionActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  unitLabel: { fontFamily: fonts.semiBold, color: colors.textSecondary },
  unitLabelActive: { color: colors.accent },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14 },
});
