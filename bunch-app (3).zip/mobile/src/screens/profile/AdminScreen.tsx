import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Avatar } from '@/components/ui/Avatar';
import { Pill } from '@/components/ui/Pill';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { findProfileByUsername, setPremium } from '@/lib/api/admin';
import { getErrorMessage } from '@/lib/errors';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { Profile } from '@/lib/database.types';

export function AdminScreen({ navigation }: ProfileScreenProps<'Admin'>) {
  const profile = useAuthStore((s) => s.profile);

  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [result, setResult] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [updating, setUpdating] = useState(false);

  async function onSearch() {
    if (!query.trim()) return;
    setSearching(true);
    setSearched(false);
    setError(null);
    try {
      const found = await findProfileByUsername(query);
      setResult(found);
      setSearched(true);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setSearching(false);
    }
  }

  async function onTogglePremium() {
    if (!result) return;
    const next = !result.is_premium;
    const apply = async () => {
      setUpdating(true);
      try {
        const updated = await setPremium(result.id, next);
        setResult(updated);
      } catch (e) {
        Alert.alert('Could not update plan', getErrorMessage(e));
      } finally {
        setUpdating(false);
      }
    };
    if (next) {
      apply();
    } else {
      Alert.alert('Revoke Bunch Premium?', `@${result.username} will go back to the free plan and its limits.`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Revoke', style: 'destructive', onPress: apply },
      ]);
    }
  }

  if (!profile?.is_admin) {
    return (
      <ScreenContainer>
        <View style={styles.backRow}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
        </View>
        <EmptyState icon={<Ionicons name="lock-closed-outline" size={32} color={colors.textTertiary} />} title="Admins only" description="This screen is restricted to the Bunch team." />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Admin</Text>
        <View style={{ width: 26 }} />
      </View>

      <View style={styles.body}>
        <Text style={styles.hint}>
          Official challenges are created from the Challenges tab — an "Official challenge" toggle shows up there for admins. Use
          this screen to manually grant or revoke Bunch Premium for a rider.
        </Text>

        <View style={styles.searchRow}>
          <View style={{ flex: 1 }}>
            <TextField
              value={query}
              onChangeText={setQuery}
              placeholder="Search by username"
              autoCapitalize="none"
              autoCorrect={false}
              onSubmitEditing={onSearch}
              returnKeyType="search"
            />
          </View>
          <Button title="Search" onPress={onSearch} loading={searching} fullWidth={false} style={styles.searchButton} />
        </View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        {searched ? (
          result ? (
            <Card style={styles.resultCard}>
              <View style={styles.resultRow}>
                <Avatar uri={result.avatar_url} name={result.display_name} size={48} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.resultName}>{result.display_name}</Text>
                  <Text style={styles.resultUsername}>@{result.username}</Text>
                </View>
                {result.is_premium ? (
                  <Pill label="Premium" tone="gold" icon={<Ionicons name="star" size={11} color={colors.gold} />} />
                ) : (
                  <Pill label="Free" tone="neutral" />
                )}
              </View>
              <Button
                title={result.is_premium ? 'Revoke Premium' : 'Grant Premium'}
                onPress={onTogglePremium}
                loading={updating}
                variant={result.is_premium ? 'danger' : 'primary'}
                style={{ marginTop: spacing.sm }}
              />
            </Card>
          ) : (
            <Text style={styles.noResult}>No rider found with that username.</Text>
          )
        ) : null}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  backRow: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  body: { paddingHorizontal: spacing.md, paddingTop: spacing.sm, gap: spacing.md },
  hint: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, lineHeight: 19 },
  searchRow: { flexDirection: 'row', gap: spacing.sm, alignItems: 'flex-start' },
  searchButton: { paddingHorizontal: spacing.lg },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 13 },
  noResult: { fontFamily: fonts.regular, fontSize: 14, color: colors.textTertiary, textAlign: 'center', marginTop: spacing.md },
  resultCard: {},
  resultRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  resultName: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  resultUsername: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary, marginTop: 1 },
});
