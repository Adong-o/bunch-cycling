import React, { useCallback, useEffect, useState } from 'react';
import { Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Constants from 'expo-constants';
import * as Location from 'expo-location';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { Pill } from '@/components/ui/Pill';
import { SegmentedToggle } from '@/components/ui/SegmentedToggle';
import { RidingStylePicker } from '@/components/profile/RidingStylePicker';
import { useAuthStore } from '@/state/authStore';
import { supabase } from '@/lib/supabase';
import { getErrorMessage } from '@/lib/errors';
import { toPermState, type PermState } from '@/lib/permissions';
import { displayDistanceToMeters, distanceUnitLabel, metersToDisplayDistance } from '@/lib/units';
import { SUPPORT_ME_URL } from '@/lib/constants';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ProfileScreenProps } from '@/navigation/types';
import type { RidingStyle, TargetPeriod, UnitSystem } from '@/lib/database.types';

export function SettingsScreen({ navigation }: ProfileScreenProps<'Settings'>) {
  const profile = useAuthStore((s) => s.profile);
  const updateLocalProfile = useAuthStore((s) => s.updateLocalProfile);
  const signOut = useAuthStore((s) => s.signOut);
  const units = profile?.units ?? 'metric';
  const unitLabel = distanceUnitLabel(units);

  const [goalPeriod, setGoalPeriod] = useState<TargetPeriod>(profile?.target_period ?? 'weekly');
  const [goalValue, setGoalValue] = useState(() => Math.round(metersToDisplayDistance(profile?.target_distance_m ?? 50000, units)));
  const [goalSaving, setGoalSaving] = useState(false);
  const [goalSaved, setGoalSaved] = useState(false);
  const [goalError, setGoalError] = useState<string | null>(null);

  const [styles_, setStyles] = useState<RidingStyle[]>(profile?.riding_styles ?? []);
  const [stylesError, setStylesError] = useState<string | null>(null);

  async function onChangeStyles(next: RidingStyle[]) {
    if (!profile) return;
    const prev = styles_;
    setStyles(next);
    setStylesError(null);
    const { error } = await supabase.from('profiles').update({ riding_styles: next }).eq('id', profile.id);
    if (error) {
      setStyles(prev);
      setStylesError(getErrorMessage(error));
      return;
    }
    updateLocalProfile({ riding_styles: next });
  }

  async function onChangeUnits(next: UnitSystem) {
    if (!profile || next === units) return;
    const { error } = await supabase.from('profiles').update({ units: next }).eq('id', profile.id);
    if (!error) {
      setGoalValue(Math.round(metersToDisplayDistance(profile.target_distance_m, next)));
      updateLocalProfile({ units: next });
    }
  }

  const [foreground, setForeground] = useState<PermState>('undetermined');
  const [background, setBackground] = useState<PermState>('undetermined');
  const [requesting, setRequesting] = useState<'fg' | 'bg' | null>(null);

  const refreshPermissions = useCallback(async () => {
    setForeground(toPermState(await Location.getForegroundPermissionsAsync()));
    setBackground(toPermState(await Location.getBackgroundPermissionsAsync()));
  }, []);

  useEffect(() => {
    refreshPermissions();
  }, [refreshPermissions]);

  const goalMin = 5;
  const goalMax = goalPeriod === 'daily' ? 100 : 500;
  const goalStep = 5;

  function onPeriodChange(p: TargetPeriod) {
    setGoalPeriod(p);
    const max = p === 'daily' ? 100 : 500;
    setGoalValue((v) => Math.max(goalMin, Math.min(max, v)));
  }

  function adjustGoal(delta: number) {
    setGoalValue((v) => Math.max(goalMin, Math.min(goalMax, v + delta)));
  }

  async function onSaveGoal() {
    if (!profile) return;
    setGoalSaving(true);
    setGoalError(null);
    setGoalSaved(false);
    const targetDistanceM = Math.round(displayDistanceToMeters(goalValue, units));
    try {
      const { error } = await supabase.from('profiles').update({ target_period: goalPeriod, target_distance_m: targetDistanceM }).eq('id', profile.id);
      if (error) throw error;
      updateLocalProfile({ target_period: goalPeriod, target_distance_m: targetDistanceM });
      setGoalSaved(true);
      setTimeout(() => setGoalSaved(false), 2500);
    } catch (e) {
      setGoalError(getErrorMessage(e));
    } finally {
      setGoalSaving(false);
    }
  }

  async function onAllowForeground() {
    setRequesting('fg');
    try {
      await Location.requestForegroundPermissionsAsync();
    } finally {
      await refreshPermissions();
      setRequesting(null);
    }
  }

  async function onAllowBackground() {
    setRequesting('bg');
    try {
      await Location.requestBackgroundPermissionsAsync();
    } finally {
      await refreshPermissions();
      setRequesting(null);
    }
  }

  if (!profile) return null;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Settings</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.sectionLabel}>RIDER</Text>
        <View style={styles.list}>
          <SettingsRow icon="person-outline" label="Profile information" detail={`@${profile.username}`} onPress={() => navigation.navigate('EditProfile')} />
          <SettingsRow icon="star-outline" label="Premium" detail={profile.is_premium ? 'Active' : 'Free plan'} onPress={() => navigation.navigate('Premium')} />
          <SettingsRow icon="bicycle-outline" label="Garage" detail="Your bikes" onPress={() => navigation.navigate('Garage')} />
          <SettingsRow icon="bluetooth-outline" label="Devices" detail="Sensors & pairing" onPress={() => navigation.navigate('Devices')} />
          <SettingsRow icon="cloud-upload-outline" label="Import rides" detail="From another app" onPress={() => navigation.navigate('ImportRides')} />
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>FAVORITE RIDING STYLES</Text>
        <View style={styles.card}>
          <RidingStylePicker value={styles_} onChange={onChangeStyles} />
          {stylesError ? <Text style={styles.error}>{stylesError}</Text> : null}
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>UNITS</Text>
        <View style={styles.card}>
          <SegmentedToggle
            options={[
              { value: 'metric' as UnitSystem, label: 'Kilometers' },
              { value: 'imperial' as UnitSystem, label: 'Miles' },
            ]}
            value={units}
            onChange={onChangeUnits}
          />
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>GOAL</Text>
        <View style={styles.card}>
          <View style={styles.periodRow}>
            {(['daily', 'weekly'] as const).map((p) => (
              <Pressable key={p} onPress={() => onPeriodChange(p)} style={[styles.periodOption, goalPeriod === p && styles.periodOptionActive]}>
                <Text style={[styles.periodLabel, goalPeriod === p && styles.periodLabelActive]}>{p === 'daily' ? 'Daily' : 'Weekly'}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.stepper}>
            <Pressable onPress={() => adjustGoal(-goalStep)} style={styles.stepperButton}>
              <Ionicons name="remove" size={22} color={colors.textPrimary} />
            </Pressable>
            <View style={styles.stepperValue}>
              <Text style={styles.valueText}>{goalValue}</Text>
              <Text style={styles.valueUnit}>
                {unitLabel} / {goalPeriod === 'daily' ? 'day' : 'week'}
              </Text>
            </View>
            <Pressable onPress={() => adjustGoal(goalStep)} style={styles.stepperButton}>
              <Ionicons name="add" size={22} color={colors.textPrimary} />
            </Pressable>
          </View>
          {goalError ? <Text style={styles.error}>{goalError}</Text> : null}
          <View style={styles.goalSaveRow}>
            {goalSaved ? <Text style={styles.savedText}>Saved</Text> : <View />}
            <Button title="Save goal" onPress={onSaveGoal} loading={goalSaving} variant="secondary" fullWidth={false} style={styles.goalSaveButton} />
          </View>
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>LOCATION</Text>
        <View style={styles.list}>
          <PermissionRow
            icon="navigate-outline"
            title="Location"
            description="Required to record rides."
            state={foreground}
            busy={requesting === 'fg'}
            onPress={foreground === 'denied' ? () => Linking.openSettings() : onAllowForeground}
            actionLabel={foreground === 'denied' ? 'Open Settings' : 'Allow'}
          />
          <PermissionRow
            icon="moon-outline"
            title="Background location"
            description="Keeps recording if your screen locks."
            state={background}
            busy={requesting === 'bg'}
            disabled={foreground !== 'granted'}
            onPress={background === 'denied' ? () => Linking.openSettings() : onAllowBackground}
            actionLabel={background === 'denied' ? 'Open Settings' : 'Allow'}
          />
        </View>

        {Platform.OS === 'android' ? (
          <View style={styles.tipCard}>
            <View style={styles.tipIcon}>
              <Ionicons name="battery-charging-outline" size={18} color={colors.accent} />
            </View>
            <View style={styles.tipCopy}>
              <Text style={styles.tipTitle}>Rides stopping when the screen is off?</Text>
              <Text style={styles.tipBody}>
                Many phones — Tecno, Infinix, Xiaomi, Samsung and others — pause apps to save battery. Open Bunch's app settings, choose Battery, and set it to “Unrestricted”
                (on some phones it's “Don't optimise”, or switch on “Autostart”).
              </Text>
              <Pressable onPress={() => Linking.openSettings()} hitSlop={8} style={styles.planLinkRow} accessibilityRole="button">
                <Text style={styles.planLink}>Open app settings</Text>
                <Ionicons name="chevron-forward" size={16} color={colors.accent} />
              </Pressable>
            </View>
          </View>
        ) : null}

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>PLAN</Text>
        <View style={styles.card}>
          <View style={styles.planRow}>
            {profile.is_premium ? (
              <Pill label="Bunch Premium" tone="gold" icon={<Ionicons name="star" size={11} color={colors.gold} />} />
            ) : (
              <Pill label="Free plan" tone="neutral" />
            )}
          </View>
          <Text style={styles.planText}>
            {profile.is_premium
              ? `You've had Bunch Premium since ${new Date(profile.premium_since ?? profile.created_at).toLocaleDateString()}. Thanks for backing the app.`
              : 'Free plan limits: 2 bikes, 3 saved routes, and 5 starred segments.'}
          </Text>
          <Pressable onPress={() => navigation.navigate('Premium')} style={styles.planLinkRow}>
            <Text style={styles.planLink}>{profile.is_premium ? 'See everything included' : "See what's included"}</Text>
            <Ionicons name="chevron-forward" size={16} color={colors.accent} />
          </Pressable>
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>ACCOUNT</Text>
        <View style={styles.list}>
          <Pressable onPress={signOut} style={styles.linkRow}>
            <Ionicons name="log-out-outline" size={18} color={colors.danger} />
            <Text style={[styles.linkLabel, { color: colors.danger }]}>Sign out</Text>
          </Pressable>
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>SUPPORT</Text>
        <View style={styles.list}>
          <Pressable onPress={() => Linking.openURL(SUPPORT_ME_URL)} style={styles.linkRow}>
            <Ionicons name="heart-outline" size={18} color={colors.gold} />
            <Text style={styles.linkLabel}>Support Bunch</Text>
            <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
          </Pressable>
        </View>

        <Text style={[styles.sectionLabel, styles.sectionSpaced]}>LEGAL</Text>
        <View style={styles.list}>
          <Pressable onPress={() => navigation.navigate('PrivacyPolicy')} style={styles.linkRow}>
            <Ionicons name="shield-outline" size={18} color={colors.textSecondary} />
            <Text style={styles.linkLabel}>Privacy Policy</Text>
            <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
          </Pressable>
          <Pressable onPress={() => navigation.navigate('Terms')} style={styles.linkRow}>
            <Ionicons name="document-text-outline" size={18} color={colors.textSecondary} />
            <Text style={styles.linkLabel}>Terms of Service</Text>
            <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
          </Pressable>
        </View>

        {/* Reads the real build version instead of a hand-typed string that
            drifts out of date — app.config.ts's `version` is the one source
            of truth (it was stuck at "v1.0.0" here even after several real
            version bumps before this fix). */}
        <Text style={styles.footerText}>Bunch v{Constants.expoConfig?.version ?? '1.3.0'}</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function SettingsRow({ icon, label, detail, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; detail?: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.linkRow}>
      <Ionicons name={icon} size={18} color={colors.textSecondary} />
      <Text style={styles.linkLabel}>{label}</Text>
      {detail ? <Text style={styles.rowDetail}>{detail}</Text> : null}
      <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
    </Pressable>
  );
}

function PermissionRow({
  icon,
  title,
  description,
  state,
  busy,
  disabled,
  onPress,
  actionLabel,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  state: PermState;
  busy: boolean;
  disabled?: boolean;
  onPress: () => void;
  actionLabel: string;
}) {
  const granted = state === 'granted';
  return (
    <View style={[styles.permRow, disabled && !granted && styles.permRowDisabled]}>
      <View style={styles.permCopy}>
        <View style={styles.permTitleRow}>
          <Ionicons name={icon} size={16} color={granted ? colors.success : colors.textSecondary} />
          <Text style={styles.linkLabel}>{title}</Text>
        </View>
        <Text style={styles.permDescription}>{description}</Text>
      </View>
      {granted ? (
        <View style={styles.grantedPill}>
          <Ionicons name="checkmark" size={12} color={colors.success} />
          <Text style={styles.grantedText}>On</Text>
        </View>
      ) : (
        <Button title={busy ? '···' : actionLabel} onPress={onPress} variant="secondary" size="md" fullWidth={false} disabled={disabled || busy} style={styles.permAction} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  sectionLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textTertiary, letterSpacing: 0.4, marginBottom: spacing.sm },
  sectionSpaced: { marginTop: spacing.lg },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: spacing.sm },
  periodRow: { flexDirection: 'row', gap: spacing.sm },
  periodOption: { flex: 1, paddingVertical: 12, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceHigh, alignItems: 'center' },
  periodOptionActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  periodLabel: { fontFamily: fonts.semiBold, color: colors.textSecondary, fontSize: 13 },
  periodLabelActive: { color: colors.accent },
  stepper: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xl, paddingVertical: spacing.sm },
  stepperButton: { width: 44, height: 44, borderRadius: radius.pill, backgroundColor: colors.surfaceHigh, borderWidth: 1, borderColor: colors.borderStrong, alignItems: 'center', justifyContent: 'center' },
  stepperValue: { alignItems: 'center', minWidth: 110 },
  valueText: { fontFamily: fonts.bold, fontSize: 28, color: colors.textPrimary },
  valueUnit: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary, marginTop: 2 },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 13 },
  goalSaveRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  savedText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.success },
  goalSaveButton: { paddingHorizontal: spacing.lg },
  list: { gap: spacing.xs },
  linkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowDetail: { fontFamily: fonts.medium, fontSize: 13, color: colors.textTertiary },
  linkLabel: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary, flex: 1 },
  permRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  permRowDisabled: { opacity: 0.5 },
  permCopy: { flex: 1, gap: 2 },
  permTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  permDescription: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary },
  permAction: { paddingHorizontal: spacing.sm },
  grantedPill: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 10, borderRadius: radius.pill, backgroundColor: colors.successMuted },
  grantedText: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.success },
  planRow: { flexDirection: 'row' },
  planText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, lineHeight: 19 },
  tipCard: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm, padding: spacing.md, borderRadius: radius.lg, backgroundColor: colors.accentMuted },
  tipIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  tipCopy: { flex: 1, gap: 4 },
  tipTitle: { fontFamily: fonts.bold, fontSize: 14, color: colors.textPrimary },
  tipBody: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 19, color: colors.textSecondary },
  planLinkRow: { flexDirection: 'row', alignItems: 'center', gap: 2, marginTop: spacing.xs },
  planLink: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  footerText: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center', marginTop: spacing.xl },
});
