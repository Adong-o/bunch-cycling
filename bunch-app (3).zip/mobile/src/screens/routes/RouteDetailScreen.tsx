import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, Share, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { Button } from '@/components/ui/Button';
import { StatBlock } from '@/components/ui/StatBlock';
import { RideMap } from '@/components/RideMap';
import { ElevationProfile } from '@/components/ElevationProfile';
import { DIFFICULTY_LABEL, routeDifficulty, type Difficulty } from '@/components/routes/routeMeta';
import { useAuthStore } from '@/state/authStore';
import { useGuideRouteStore } from '@/state/guideRouteStore';
import { getRoute, getRouteRideCounts } from '@/lib/api/routes';
import { listProfilesByIds } from '@/lib/api/social';
import { getErrorMessage } from '@/lib/errors';
import { boundingBox, elevationGainLoss, geoJSONToCoordinates } from '@/lib/geo';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing } from '@/theme';
import type { RoutesScreenProps } from '@/navigation/types';
import type { Profile, RouteRow } from '@/lib/database.types';

const DIFFICULTY_TONE: Record<Difficulty, { fg: string; bg: string }> = {
  easy: { fg: colors.success, bg: colors.successMuted },
  moderate: { fg: colors.gold, bg: colors.goldMuted },
  hard: { fg: colors.danger, bg: colors.dangerMuted },
};

/**
 * One route: a map you can open full-screen and pinch/zoom, the numbers, the
 * climb, and the thing a rider actually came here to do — ride it. "Ride this
 * route" puts the route on the Record map as a guide line and links the ride
 * you save to it (which is what makes the rider counts on route cards real).
 */
export function RouteDetailScreen({ navigation, route: navRoute }: RoutesScreenProps<'RouteDetail'>) {
  const { routeId } = navRoute.params;
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';
  const setGuide = useGuideRouteStore((s) => s.setRoute);

  const [data, setData] = useState<RouteRow | null>(null);
  const [owner, setOwner] = useState<Profile | null>(null);
  const [counts, setCounts] = useState<{ rides: number; riders: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await getRoute(routeId);
        if (cancelled) return;
        setData(r);
        if (!r) return;
        const [c, owners] = await Promise.all([
          getRouteRideCounts([r.id]).catch(() => ({}) as Record<string, { rides: number; riders: number }>),
          r.user_id === profile?.id ? Promise.resolve([] as Profile[]) : listProfilesByIds([r.user_id]).catch(() => [] as Profile[]),
        ]);
        if (cancelled) return;
        setCounts(c[r.id] ?? { rides: 0, riders: 0 });
        setOwner(owners[0] ?? null);
      } catch (e) {
        if (!cancelled) setError(getErrorMessage(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [routeId, profile?.id]);

  const coords = useMemo(() => geoJSONToCoordinates(data?.route_geojson), [data]);
  const bounds = useMemo(() => boundingBox(data?.route_geojson), [data]);
  const elevation = useMemo(() => {
    const raw = data?.route_geojson?.coordinates ?? [];
    const withEle = raw.filter((c) => c[2] != null);
    if (withEle.length < 2) return null;
    const { loss } = elevationGainLoss(raw.map((c) => ({ lat: c[1], lng: c[0], elevationM: c[2] ?? null, timestamp: 0 })));
    return { loss };
  }, [data]);

  function onRide() {
    if (!data) return;
    setGuide({ id: data.id, name: data.name, distanceM: data.distance_m, coordinates: coords });
    navigation.navigate('RecordTab' as never);
  }

  function onShare() {
    if (!data) return;
    const climb = formatElevation(data.elevation_gain_m, units);
    Share.share({ message: `${data.name} — ${formatDistance(data.distance_m, units)}, ${climb} of climbing. Ride it with Bunch.` }).catch(() => {});
  }

  const header = (
    <View style={styles.header}>
      <Pressable onPress={() => navigation.goBack()} hitSlop={10} style={styles.roundButton} accessibilityRole="button" accessibilityLabel="Back">
        <Ionicons name="chevron-back" size={22} color={colors.textPrimary} />
      </Pressable>
      <Text style={styles.headerTitle}>Route</Text>
      {data ? (
        <Pressable onPress={onShare} hitSlop={10} style={styles.roundButton} accessibilityRole="button" accessibilityLabel="Share this route">
          <Ionicons name="share-outline" size={20} color={colors.textPrimary} />
        </Pressable>
      ) : (
        <View style={styles.roundSpacer} />
      )}
    </View>
  );

  if (loading) {
    return (
      <ScreenContainer padded={false}>
        {header}
        <LoadingView label="Loading route…" />
      </ScreenContainer>
    );
  }

  if (error || !data) {
    return (
      <ScreenContainer padded={false}>
        {header}
        <EmptyState
          icon={<Ionicons name="map-outline" size={32} color={colors.textTertiary} />}
          title={error ? "Couldn't load this route" : 'Route not found'}
          description={error ?? 'It may have been deleted or made private by its owner.'}
          actionLabel="Back to routes"
          onAction={() => navigation.goBack()}
        />
      </ScreenContainer>
    );
  }

  const difficulty = routeDifficulty(data);
  const tone = DIFFICULTY_TONE[difficulty];
  const mine = data.user_id === profile?.id;
  const riders = counts?.riders ?? 0;

  return (
    <ScreenContainer padded={false}>
      {header}
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {coords.length > 1 ? (
          <RideMap routeCoordinates={coords} bounds={bounds} expandable expandTitle={data.name} showEndpoints style={styles.map} />
        ) : (
          <View style={[styles.map, styles.mapEmpty]}>
            <Ionicons name="map-outline" size={28} color={colors.textTertiary} />
          </View>
        )}

        <View style={styles.titleBlock}>
          <Text style={styles.name}>{data.name}</Text>
          <Text style={styles.byline}>
            {mine ? 'Your route' : owner ? `By ${owner.display_name}` : 'Shared route'} · {data.is_public ? 'Public' : 'Private'}
          </Text>
          <View style={styles.chipRow}>
            <View style={[styles.chip, { backgroundColor: tone.bg }]}>
              <Text style={[styles.chipText, { color: tone.fg }]}>{DIFFICULTY_LABEL[difficulty]}</Text>
            </View>
            <View style={styles.chip}>
              <Text style={styles.chipText}>{data.surface_type}</Text>
            </View>
          </View>
        </View>

        <View style={styles.statsCard}>
          <StatBlock label="Distance" value={formatDistance(data.distance_m, units)} size="lg" labelFirst style={styles.stat} />
          <View style={styles.statDivider} />
          <StatBlock label="Climbing" value={formatElevation(data.elevation_gain_m, units)} size="lg" labelFirst style={styles.stat} />
          <View style={styles.statDivider} />
          <StatBlock label="Riders" value={String(riders)} size="lg" labelFirst style={styles.stat} />
        </View>

        {data.description ? <Text style={styles.description}>{data.description}</Text> : null}

        {elevation ? (
          <ElevationProfile routeGeojson={data.route_geojson} units={units} elevationGainM={data.elevation_gain_m} elevationLossM={elevation.loss} />
        ) : null}

        <Text style={styles.footnote}>
          {counts && counts.rides > 0
            ? `${counts.rides} ${counts.rides === 1 ? 'ride' : 'rides'} recorded on this route by ${riders} ${riders === 1 ? 'rider' : 'riders'}.`
            : 'No one has ridden this route with Bunch yet — be the first.'}
        </Text>
      </ScrollView>

      <View style={styles.actionBar}>
        <Button title="Ride this route" onPress={onRide} icon={<Ionicons name="navigate" size={18} color={colors.textOnAccent} />} />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.sm },
  headerTitle: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary },
  roundButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.surfaceHigh, alignItems: 'center', justifyContent: 'center' },
  roundSpacer: { width: 38, height: 38 },
  content: { paddingHorizontal: spacing.md, paddingBottom: 120, gap: spacing.md },
  map: { height: 250, borderRadius: radius.xl, overflow: 'hidden' },
  mapEmpty: { backgroundColor: colors.surfaceHigh, alignItems: 'center', justifyContent: 'center' },
  titleBlock: { gap: 6 },
  name: { fontFamily: fonts.extraBold, fontSize: 26, color: colors.textPrimary, letterSpacing: -0.5 },
  byline: { fontFamily: fonts.medium, fontSize: 14, color: colors.textSecondary },
  chipRow: { flexDirection: 'row', gap: 6, flexWrap: 'wrap', marginTop: 2 },
  chip: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill, backgroundColor: colors.surfaceHigh },
  chipText: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary, textTransform: 'capitalize' },
  statsCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: spacing.md,
  },
  stat: { flex: 1, paddingHorizontal: spacing.md },
  statDivider: { width: StyleSheet.hairlineWidth, alignSelf: 'stretch', backgroundColor: colors.borderStrong },
  description: { fontFamily: fonts.regular, fontSize: 15, lineHeight: 22, color: colors.textPrimary },
  footnote: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, lineHeight: 19 },
  actionBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
    backgroundColor: colors.surface,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
});
