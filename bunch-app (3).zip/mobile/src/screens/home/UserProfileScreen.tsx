import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Avatar } from '@/components/ui/Avatar';
import { Button } from '@/components/ui/Button';
import { StatBlock } from '@/components/ui/StatBlock';
import { Pill } from '@/components/ui/Pill';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { RideCard } from '@/components/RideCard';
import { useAuthStore } from '@/state/authStore';
import { getProfile, getFollowCounts, isFollowing, follow, unfollow, getKudosStateBatch, giveKudos, removeKudos, type KudosState } from '@/lib/api/social';
import { listMyRides, getRiderTotals, type RiderTotals } from '@/lib/api/rides';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { HomeScreenProps } from '@/navigation/types';
import type { Profile, Ride } from '@/lib/database.types';

export function UserProfileScreen({ navigation, route }: HomeScreenProps<'UserProfile'>) {
  const { userId } = route.params;
  const me = useAuthStore((s) => s.profile);
  const units = me?.units ?? 'metric';
  const isSelf = me?.id === userId;

  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [person, setPerson] = useState<Profile | null>(null);
  const [totals, setTotals] = useState<RiderTotals | null>(null);
  const [counts, setCounts] = useState({ followers: 0, following: 0 });
  const [following, setFollowingState] = useState(false);
  const [followBusy, setFollowBusy] = useState(false);
  const [rides, setRides] = useState<Ride[]>([]);
  const [kudos, setKudos] = useState<Record<string, KudosState>>({});

  const load = useCallback(async () => {
    if (!me) return;
    try {
      const p = await getProfile(userId);
      if (!p) {
        setNotFound(true);
        return;
      }
      const [riderTotals, followCounts, followingState, rideList] = await Promise.all([
        getRiderTotals(userId),
        getFollowCounts(userId),
        isSelf ? Promise.resolve(false) : isFollowing(me.id, userId),
        listMyRides(userId, 20),
      ]);
      setPerson(p);
      setTotals(riderTotals);
      setCounts(followCounts);
      setFollowingState(followingState);
      setRides(rideList);
      setKudos(await getKudosStateBatch(rideList.map((r) => r.id), me.id));
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, [userId, me, isSelf]);

  useEffect(() => {
    load();
  }, [load]);

  async function onToggleFollow() {
    if (!me || isSelf) return;
    setFollowBusy(true);
    try {
      if (following) {
        await unfollow(me.id, userId);
        setFollowingState(false);
        setCounts((c) => ({ ...c, followers: Math.max(0, c.followers - 1) }));
      } else {
        await follow(me.id, userId);
        setFollowingState(true);
        setCounts((c) => ({ ...c, followers: c.followers + 1 }));
      }
    } catch {
      // leave state as it was — a toast-free, low-drama failure for a secondary action
    } finally {
      setFollowBusy(false);
    }
  }

  async function onToggleKudos(ride: Ride) {
    if (!me) return;
    const current = kudos[ride.id] ?? { count: 0, byMe: false };
    const next: KudosState = current.byMe
      ? { count: Math.max(0, current.count - 1), byMe: false }
      : { count: current.count + 1, byMe: true };
    setKudos((prev) => ({ ...prev, [ride.id]: next }));
    try {
      if (current.byMe) await removeKudos(ride.id, me.id);
      else await giveKudos(ride.id, me.id);
    } catch {
      setKudos((prev) => ({ ...prev, [ride.id]: current }));
    }
  }

  if (loading) return <LoadingView />;

  if (notFound || !person) {
    return (
      <ScreenContainer>
        <View style={styles.backRow}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
        </View>
        <EmptyState icon={<Ionicons name="person-outline" size={32} color={colors.textTertiary} />} title="Rider not found" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer padded={false}>
      <View style={styles.backRow}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
      </View>

      <FlatList
        data={rides}
        keyExtractor={(r) => r.id}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        ListHeaderComponent={
          <View style={styles.headerBlock}>
            <Avatar uri={person.avatar_url} name={person.display_name} size={76} />
            <Text style={styles.name}>{person.display_name}</Text>
            <Text style={styles.username}>@{person.username}</Text>
            {person.is_premium ? <Pill label="Premium" tone="gold" icon={<Ionicons name="star" size={11} color={colors.gold} />} /> : null}
            {person.bio ? <Text style={styles.bio}>{person.bio}</Text> : null}

            <View style={styles.followRow}>
              <Text style={styles.followCount}>
                <Text style={styles.followCountNumber}>{counts.followers}</Text> followers
              </Text>
              <Text style={styles.followCount}>
                <Text style={styles.followCountNumber}>{counts.following}</Text> following
              </Text>
            </View>

            {!isSelf ? (
              <Button
                title={following ? 'Following' : 'Follow'}
                variant={following ? 'secondary' : 'primary'}
                onPress={onToggleFollow}
                loading={followBusy}
                style={styles.followButton}
              />
            ) : null}

            {totals ? (
              <View style={styles.statsCard}>
                <StatBlock label="RIDES" value={`${totals.totalRides}`} />
                <StatBlock label="DISTANCE" value={formatDistance(totals.totalDistanceM, units)} />
                <StatBlock label="ELEVATION" value={formatElevation(totals.totalElevationM, units)} />
              </View>
            ) : null}

            <Text style={styles.sectionLabel}>Rides</Text>
          </View>
        }
        renderItem={({ item }) => (
          <RideCard
            ride={item}
            owner={person}
            units={units}
            kudosCount={kudos[item.id]?.count ?? 0}
            kudosByMe={kudos[item.id]?.byMe ?? false}
            onPress={() => navigation.navigate('RideDetail', { rideId: item.id })}
            onToggleKudos={() => onToggleKudos(item)}
          />
        )}
        ListEmptyComponent={
          <EmptyState
            icon={<Ionicons name="bicycle-outline" size={28} color={colors.textTertiary} />}
            title="No rides yet"
            description={isSelf ? 'Rides you record will show up here.' : `${person.display_name} hasn't shared any rides yet.`}
          />
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  backRow: { paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  listContent: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  headerBlock: { alignItems: 'center', paddingBottom: spacing.lg, gap: 4 },
  name: { ...typeTokens.h2, color: colors.textPrimary, marginTop: spacing.sm },
  username: { fontFamily: fonts.medium, fontSize: 14, color: colors.textSecondary },
  bio: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xs, paddingHorizontal: spacing.lg },
  followRow: { flexDirection: 'row', gap: spacing.lg, marginTop: spacing.sm },
  followCount: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary },
  followCountNumber: { fontFamily: fonts.bold, color: colors.textPrimary },
  followButton: { marginTop: spacing.md, paddingHorizontal: spacing.xl },
  statsCard: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignSelf: 'stretch',
    marginTop: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  sectionLabel: {
    alignSelf: 'flex-start',
    fontFamily: fonts.semiBold,
    fontSize: 13,
    color: colors.textSecondary,
    letterSpacing: 0.3,
    marginTop: spacing.lg,
  },
});
