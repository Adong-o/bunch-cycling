import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Image, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { RideCard } from '@/components/RideCard';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { FeaturedChallengesCarousel } from '@/components/FeaturedChallengesCarousel';
import { RideShareModal } from '@/components/RideShareModal';
import { HomeTabs, type HomeTabKey } from '@/components/home/HomeTabs';
import { ChallengeRow } from '@/components/home/ChallengeRow';
import { PendingSyncBanner } from '@/components/PendingSyncBanner';
import { useAuthStore } from '@/state/authStore';
import { listHomeFeed } from '@/lib/api/rides';
import { listDiscoverChallenges, listMyChallenges, joinChallenge } from '@/lib/api/challenges';
import { listProfilesByIds, getKudosStateBatch, giveKudos, removeKudos, listRideTagsBatch, type KudosState } from '@/lib/api/social';
import { colors, fonts, radius, spacing } from '@/theme';
import type { HomeScreenProps, MainStackParamList } from '@/navigation/types';
import type { Ride, Profile, Challenge } from '@/lib/database.types';

const PAGE_SIZE = 20;

export function FeedScreen({ navigation }: HomeScreenProps<'Feed'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';
  // Escape-hatch typed nav, not the HomeStack-composed `navigation` prop:
  // Challenges now lives one level up, as a sibling of the tab navigator
  // (see MainStack.tsx), reached by name — React Navigation bubbles the
  // action up to whichever ancestor owns that route.
  const rootNavigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();

  const [rides, setRides] = useState<Ride[]>([]);
  const [owners, setOwners] = useState<Record<string, Profile>>({});
  const [kudos, setKudos] = useState<Record<string, KudosState>>({});
  const [companions, setCompanions] = useState<Record<string, Profile[]>>({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<HomeTabKey>('explore');
  const [shareRide, setShareRide] = useState<Ride | null>(null);
  const [myChallenges, setMyChallenges] = useState<Challenge[]>([]);
  const [popular, setPopular] = useState<Challenge[]>([]);
  const [joinedIds, setJoinedIds] = useState<Record<string, boolean>>({});
  const [joiningId, setJoiningId] = useState<string | null>(null);
  const [challengesLoading, setChallengesLoading] = useState(false);
  const [challengesError, setChallengesError] = useState(false);

  const enrich = useCallback(
    async (list: Ride[]) => {
      if (!profile || list.length === 0) return;
      const [profiles, kudosState, companionState] = await Promise.all([
        listProfilesByIds(list.map((r) => r.user_id)),
        getKudosStateBatch(list.map((r) => r.id), profile.id),
        listRideTagsBatch(list.map((r) => r.id)).catch(() => ({}) as Record<string, Profile[]>),
      ]);
      setOwners((prev) => {
        const next = { ...prev };
        for (const p of profiles) next[p.id] = p;
        return next;
      });
      setKudos((prev) => ({ ...prev, ...kudosState }));
      setCompanions((prev) => ({ ...prev, ...companionState }));
    },
    [profile]
  );

  const loadFirstPage = useCallback(async () => {
    setError(null);
    try {
      const list = await listHomeFeed(PAGE_SIZE);
      setRides(list);
      setHasMore(list.length === PAGE_SIZE);
      await enrich(list);
    } catch (e) {
      setError('Could not load your feed.');
    }
  }, [enrich]);

  useEffect(() => {
    setLoading(true);
    loadFirstPage().finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const loadChallenges = useCallback(async () => {
    if (!profile) return;
    setChallengesError(false);
    try {
      const [mine, discover] = await Promise.all([listMyChallenges(profile.id), listDiscoverChallenges()]);
      const today = new Date().toISOString().slice(0, 10);
      setMyChallenges(mine.filter((c) => c.end_date >= today));
      setPopular(discover);
      const joined: Record<string, boolean> = {};
      for (const c of mine) joined[c.id] = true;
      setJoinedIds(joined);
    } catch {
      setChallengesError(true);
    }
  }, [profile]);

  useEffect(() => {
    if (tab === 'explore') return;
    setChallengesLoading(true);
    loadChallenges().finally(() => setChallengesLoading(false));
  }, [tab, loadChallenges]);

  async function onJoinChallenge(challengeId: string) {
    if (!profile || joiningId) return;
    setJoiningId(challengeId);
    try {
      await joinChallenge(challengeId, profile.id);
      setJoinedIds((p) => ({ ...p, [challengeId]: true }));
      loadChallenges();
    } catch {
      // they can still join from the challenge's own screen
    } finally {
      setJoiningId(null);
    }
  }

  function openChallenge(challengeId: string) {
    rootNavigation.navigate('Challenges', { screen: 'ChallengeDetail', params: { challengeId } });
  }

  async function onRefresh() {
    setRefreshing(true);
    if (tab === 'explore') await loadFirstPage();
    else await loadChallenges();
    setRefreshing(false);
  }

  async function onLoadMore() {
    if (loadingMore || !hasMore || rides.length === 0) return;
    setLoadingMore(true);
    try {
      const last = rides[rides.length - 1];
      const nextPage = await listHomeFeed(PAGE_SIZE, last.started_at);
      setRides((prev) => [...prev, ...nextPage]);
      setHasMore(nextPage.length === PAGE_SIZE);
      await enrich(nextPage);
    } catch {
      // a failed "load more" just stops pagination quietly — the feed they already have stays intact
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }

  async function onToggleKudos(ride: Ride) {
    if (!profile) return;
    const current = kudos[ride.id] ?? { count: 0, byMe: false };
    const optimistic: KudosState = current.byMe
      ? { count: Math.max(0, current.count - 1), byMe: false }
      : { count: current.count + 1, byMe: true };
    setKudos((prev) => ({ ...prev, [ride.id]: optimistic }));
    try {
      if (current.byMe) {
        await removeKudos(ride.id, profile.id);
      } else {
        await giveKudos(ride.id, profile.id);
      }
    } catch {
      setKudos((prev) => ({ ...prev, [ride.id]: current }));
    }
  }

  if (loading) {
    return <LoadingView label="Loading your feed…" />;
  }

  const header = (
    <View>
      <View style={styles.header}>
        <Image source={require('../../../assets/wordmark_dark.png')} style={styles.logo} resizeMode="contain" accessibilityRole="image" accessibilityLabel="Bunch" />
        <View style={styles.headerActions}>
          {profile && profile.current_streak > 0 ? (
            <View
              style={styles.streakChip}
              accessible
              accessibilityLabel={`${profile.current_streak} ${profile.target_period === 'daily' ? 'day' : 'week'} streak`}
            >
              <Ionicons name="flame" size={14} color={colors.gold} />
              <Text style={styles.streakNum}>{profile.current_streak}</Text>
            </View>
          ) : null}
          {profile && !profile.is_premium ? (
            <Pressable onPress={() => navigation.navigate('ProfileTab', { screen: 'Premium' } as never)} style={styles.upgradePill} accessibilityLabel="Upgrade to Premium">
              <Ionicons name="sparkles" size={13} color={colors.accent} />
              <Text style={styles.upgradeLabel}>Upgrade</Text>
            </Pressable>
          ) : null}
        </View>
      </View>
      <HomeTabs value={tab} onChange={setTab} />
    </View>
  );

  const refresh = <RefreshControl tintColor={colors.accent} refreshing={refreshing} onRefresh={onRefresh} />;

  return (
    <ScreenContainer padded={false} edges={['top']}>
      {header}

      {tab === 'explore' ? (
        <FlatList
          data={rides}
          keyExtractor={(r) => r.id}
          contentContainerStyle={rides.length === 0 ? styles.emptyContent : styles.listContent}
          refreshControl={refresh}
          onEndReachedThreshold={0.4}
          onEndReached={onLoadMore}
          ListHeaderComponent={
            <View>
              <PendingSyncBanner />
              <Pressable onPress={() => navigation.navigate('FindRiders')} style={({ pressed }) => [styles.findRiders, pressed && { opacity: 0.85 }]} accessibilityRole="button" accessibilityLabel="Find riders to follow">
                <Ionicons name="search" size={17} color={colors.textTertiary} />
                <Text style={styles.findRidersText}>Find riders to follow</Text>
                <Ionicons name="person-add-outline" size={17} color={colors.accent} />
              </Pressable>
              <FeaturedChallengesCarousel onOpenChallenge={openChallenge} />
            </View>
          }
          renderItem={({ item }) => (
            <RideCard
              ride={item}
              owner={owners[item.user_id]}
              companions={companions[item.id] ?? []}
              units={units}
              kudosCount={kudos[item.id]?.count ?? 0}
              kudosByMe={kudos[item.id]?.byMe ?? false}
              onPress={() => navigation.navigate('RideDetail', { rideId: item.id })}
              onPressOwner={() => navigation.navigate('UserProfile', { userId: item.user_id })}
              onToggleKudos={() => onToggleKudos(item)}
              onShare={() => setShareRide(item)}
            />
          )}
          ItemSeparatorComponent={() => <View style={{ height: spacing.md }} />}
          ListEmptyComponent={
            error ? (
              <EmptyState
                icon={<Ionicons name="cloud-offline-outline" size={32} color={colors.textTertiary} />}
                title="Couldn't load your feed"
                description={error}
              />
            ) : (
              <EmptyState
                icon={<Ionicons name="bicycle-outline" size={32} color={colors.textTertiary} />}
                title="Your feed starts with a ride"
                description="Rides from you and the riders you follow will show up here. Record your first one, or find riders to follow above."
                primary
                actionLabel="Record a ride"
                onAction={() => rootNavigation.navigate('RecordTab' as never)}
              />
            )
          }
        />
      ) : challengesLoading && (tab === 'challenges' ? myChallenges : popular).length === 0 ? (
        <LoadingView label="Loading challenges…" />
      ) : (
        <FlatList
          data={tab === 'challenges' ? myChallenges : popular}
          keyExtractor={(c) => c.id}
          contentContainerStyle={(tab === 'challenges' ? myChallenges : popular).length === 0 ? styles.emptyContent : styles.listContent}
          refreshControl={refresh}
          ListHeaderComponent={
            tab === 'popular' ? <Text style={styles.sectionNote}>Public challenges anyone can join — not based on your location.</Text> : null
          }
          renderItem={({ item }) => (
            <ChallengeRow
              challenge={item}
              units={units}
              onPress={() => openChallenge(item.id)}
              {...(tab === 'popular'
                ? { joined: !!joinedIds[item.id], joining: joiningId === item.id, onJoin: () => onJoinChallenge(item.id) }
                : {})}
            />
          )}
          ItemSeparatorComponent={() => <View style={{ height: spacing.md }} />}
          ListEmptyComponent={
            challengesError ? (
              <EmptyState
                icon={<Ionicons name="cloud-offline-outline" size={32} color={colors.textTertiary} />}
                title="Couldn't load challenges"
                description="Check your connection and pull to refresh."
              />
            ) : tab === 'challenges' ? (
              <EmptyState
                icon={<Ionicons name="trophy-outline" size={32} color={colors.textTertiary} />}
                title="No active challenges"
                description="Join one from the Popular tab, or open a friend's invite code from Challenges."
                actionLabel="Browse popular challenges"
                onAction={() => setTab('popular')}
              />
            ) : (
              <EmptyState
                icon={<Ionicons name="flag-outline" size={32} color={colors.textTertiary} />}
                title="Nothing open right now"
                description="New public challenges will appear here."
              />
            )
          }
        />
      )}

      {shareRide ? (
        <RideShareModal
          visible
          ride={shareRide}
          ownerName={owners[shareRide.user_id]?.display_name || 'A rider'}
          ownerAvatarUrl={owners[shareRide.user_id]?.avatar_url}
          units={units}
          onClose={() => setShareRide(null)}
        />
      ) : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  // The supplied Bunch lockup (mark + wordmark), 4.25:1 — replaces the plain "Home" title.
  logo: { width: 124, height: 29 },
  findRiders: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginHorizontal: spacing.md,
    marginTop: spacing.xs,
    marginBottom: spacing.xs,
    paddingHorizontal: spacing.sm,
    height: 42,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  findRidersText: { flex: 1, fontFamily: fonts.medium, fontSize: 14, color: colors.textTertiary },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  streakChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: colors.goldMuted,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  streakNum: { fontFamily: fonts.bold, fontSize: 13, color: colors.gold },
  upgradePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.accentMuted,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm,
    paddingVertical: 7,
  },
  upgradeLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  sectionNote: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, marginBottom: spacing.sm },
  listContent: { paddingHorizontal: spacing.md, paddingTop: spacing.xs, paddingBottom: spacing.xxl },
  emptyContent: { flexGrow: 1, paddingHorizontal: spacing.md },
});
