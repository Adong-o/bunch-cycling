import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Avatar } from '@/components/ui/Avatar';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { follow, listFollowing, searchProfiles, unfollow } from '@/lib/api/social';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import type { HomeScreenProps } from '@/navigation/types';
import type { Profile } from '@/lib/database.types';

const MIN_QUERY = 2;
const DEBOUNCE_MS = 300;

/** Search riders by name or @username and follow them — the way a feed gets its first rides. */
export function FindRidersScreen({ navigation }: HomeScreenProps<'FindRiders'>) {
  const me = useAuthStore((s) => s.profile);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Profile[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [failed, setFailed] = useState(false);
  const [following, setFollowing] = useState<Set<string>>(new Set());
  const [busyId, setBusyId] = useState<string | null>(null);
  const latest = useRef(0);

  useEffect(() => {
    if (!me) return;
    listFollowing(me.id)
      .then((list) => setFollowing(new Set(list.map((p) => p.id))))
      .catch(() => {});
  }, [me?.id]);

  useEffect(() => {
    const term = query.trim();
    if (term.length < MIN_QUERY) {
      setResults(null);
      setSearching(false);
      setFailed(false);
      return;
    }
    setSearching(true);
    const ticket = ++latest.current;
    const timer = setTimeout(() => {
      searchProfiles(term, me?.id)
        .then((rows) => {
          if (ticket !== latest.current) return; // a newer search is already running
          setResults(rows);
          setFailed(false);
        })
        .catch(() => ticket === latest.current && setFailed(true))
        .finally(() => ticket === latest.current && setSearching(false));
    }, DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [query, me?.id]);

  async function toggleFollow(target: Profile) {
    if (!me || busyId) return;
    const was = following.has(target.id);
    setBusyId(target.id);
    setFollowing((prev) => {
      const next = new Set(prev);
      if (was) next.delete(target.id);
      else next.add(target.id);
      return next;
    });
    try {
      if (was) await unfollow(me.id, target.id);
      else await follow(me.id, target.id);
    } catch {
      // Put the button back the way it was.
      setFollowing((prev) => {
        const next = new Set(prev);
        if (was) next.add(target.id);
        else next.delete(target.id);
        return next;
      });
    } finally {
      setBusyId(null);
    }
  }

  const term = query.trim();

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Back">
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Find riders</Text>
        <View style={{ width: 26 }} />
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={colors.textTertiary} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search by name or @username"
          placeholderTextColor={colors.textTertiary}
          style={styles.searchInput}
          autoFocus
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType="search"
        />
        {searching ? <ActivityIndicator size="small" color={colors.accent} /> : null}
        {!searching && query.length > 0 ? (
          <Pressable onPress={() => setQuery('')} hitSlop={8} accessibilityLabel="Clear search">
            <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
          </Pressable>
        ) : null}
      </View>

      <FlatList
        data={results ?? []}
        keyExtractor={(p) => p.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.list}
        renderItem={({ item }) => {
          const isFollowing = following.has(item.id);
          return (
            <Pressable onPress={() => navigation.navigate('UserProfile', { userId: item.id })} style={({ pressed }) => [styles.row, pressed && { opacity: 0.85 }]} accessibilityRole="button">
              <Avatar uri={item.avatar_url} name={item.display_name} size={46} />
              <View style={styles.rowCopy}>
                <Text style={styles.name} numberOfLines={1}>
                  {item.display_name}
                </Text>
                <Text style={styles.username} numberOfLines={1}>
                  @{item.username}
                </Text>
              </View>
              <Pressable
                onPress={() => toggleFollow(item)}
                disabled={busyId === item.id}
                hitSlop={6}
                style={[styles.followButton, isFollowing && styles.followingButton]}
                accessibilityRole="button"
                accessibilityLabel={isFollowing ? `Unfollow ${item.display_name}` : `Follow ${item.display_name}`}
              >
                <Text style={[styles.followText, isFollowing && styles.followingText]}>{isFollowing ? 'Following' : 'Follow'}</Text>
              </Pressable>
            </Pressable>
          );
        }}
        ItemSeparatorComponent={() => <View style={{ height: spacing.xs }} />}
        ListEmptyComponent={
          failed ? (
            <EmptyState icon={<Ionicons name="cloud-offline-outline" size={32} color={colors.textTertiary} />} title="Couldn't search right now" description="Check your connection and try again." />
          ) : term.length < MIN_QUERY ? (
            <EmptyState
              icon={<Ionicons name="people-outline" size={32} color={colors.textTertiary} />}
              title="Find people to ride with"
              description="Search by name or @username. Follow a rider and their rides show up in your feed."
            />
          ) : searching || results === null ? null : (
            <EmptyState icon={<Ionicons name="search-outline" size={32} color={colors.textTertiary} />} title="No riders found" description={`Nobody matches “${term}”. Check the spelling, or try their @username.`} />
          )
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { fontFamily: fonts.bold, fontSize: 18, color: colors.textPrimary },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginHorizontal: spacing.md,
    marginTop: spacing.xs,
    paddingHorizontal: spacing.sm,
    height: 48,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadow.card,
  },
  searchInput: { flex: 1, fontFamily: fonts.medium, fontSize: 15, color: colors.textPrimary, padding: 0 },
  list: { paddingHorizontal: spacing.md, paddingTop: spacing.md, paddingBottom: spacing.xxl },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.xs },
  rowCopy: { flex: 1 },
  name: { fontFamily: fonts.bold, fontSize: 15, color: colors.textPrimary },
  username: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary, marginTop: 1 },
  followButton: { paddingHorizontal: 16, height: 36, borderRadius: radius.pill, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center' },
  followingButton: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.borderStrong },
  followText: { fontFamily: fonts.bold, fontSize: 13, color: colors.textOnAccent },
  followingText: { color: colors.textPrimary },
});
