import React, { useCallback, useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Linking, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDistanceToNow } from 'date-fns';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { RideMap } from '@/components/RideMap';
import { RideShareModal } from '@/components/RideShareModal';
import { ElevationChartCard, SpeedChartCard } from '@/components/ride/ProfileCharts';
import { HighlightsTab } from '@/components/ride/HighlightsTab';
import { Avatar } from '@/components/ui/Avatar';
import { TextField } from '@/components/ui/TextField';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuthStore } from '@/state/authStore';
import { getErrorMessage } from '@/lib/errors';
import { getRide, deleteRide } from '@/lib/api/rides';
import { createRoute } from '@/lib/api/routes';
import { createSegment } from '@/lib/api/segments';
import {
  getProfile,
  getKudosState,
  giveKudos,
  removeKudos,
  listComments,
  addComment,
  listRideTags,
  removeRideTag,
  type KudosState,
} from '@/lib/api/social';
import { getRecordingDevice, recordingDeviceBrandLabel } from '@/lib/api/recordingDevices';
import { exportRideAsGPX } from '@/lib/gpxExport';
import { boundingBox } from '@/lib/geo';
import { formatRideTimestamp } from '@/lib/dateFormat';
import { formatDistance, formatDuration, formatElevation, formatSpeed } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { HomeScreenProps } from '@/navigation/types';
import type { Ride, Profile, RecordingDevice } from '@/lib/database.types';

const VISIBILITY_ICON: Record<Ride['visibility'], keyof typeof Ionicons.glyphMap> = {
  public: 'earth-outline',
  followers: 'people-outline',
  private: 'lock-closed-outline',
};

type DetailTab = 'route' | 'elevation' | 'speed' | 'highlights';
const TABS: Array<{ key: DetailTab; label: string }> = [
  { key: 'route', label: 'Route' },
  { key: 'elevation', label: 'Elevation' },
  { key: 'speed', label: 'Speed' },
  { key: 'highlights', label: 'Highlights' },
];

interface Comment {
  id: string;
  body: string;
  created_at: string;
  profile: Profile;
}

export function RideDetailScreen({ navigation, route }: HomeScreenProps<'RideDetail'>) {
  const { rideId } = route.params;
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [ride, setRide] = useState<Ride | null>(null);
  const [owner, setOwner] = useState<Profile | null>(null);
  const [kudos, setKudos] = useState<KudosState>({ count: 0, byMe: false });
  const [companions, setCompanions] = useState<Profile[]>([]);
  const [recordingDevice, setRecordingDevice] = useState<RecordingDevice | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentBody, setCommentBody] = useState('');
  const [postingComment, setPostingComment] = useState(false);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [busy, setBusy] = useState(false);
  const [savingRoute, setSavingRoute] = useState(false);
  const [savingSegment, setSavingSegment] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [tab, setTab] = useState<DetailTab>('route');

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const r = await getRide(rideId);
      const [ownerProfile, kudosState, commentList, tagRows, device] = await Promise.all([
        getProfile(r.user_id),
        getKudosState(rideId, profile.id),
        listComments(rideId),
        listRideTags(rideId).catch(() => []), // non-critical — the ride itself already loaded fine
        r.recording_device_id ? getRecordingDevice(r.recording_device_id).catch(() => null) : Promise.resolve(null),
      ]);
      setRide(r);
      setOwner(ownerProfile);
      setKudos(kudosState);
      setComments(commentList);
      setCompanions(tagRows.map((t) => t.profile));
      setRecordingDevice(device);
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, [rideId, profile]);

  async function onRemoveCompanion(userId: string) {
    if (!ride) return;
    const previous = companions;
    setCompanions((prev) => prev.filter((c) => c.id !== userId));
    try {
      await removeRideTag(ride.id, userId);
    } catch (e) {
      setCompanions(previous);
      Alert.alert('Could not remove tag', getErrorMessage(e));
    }
  }

  useEffect(() => {
    load();
  }, [load]);

  async function onToggleKudos() {
    if (!profile || !ride) return;
    const previous = kudos;
    const next: KudosState = previous.byMe
      ? { count: Math.max(0, previous.count - 1), byMe: false }
      : { count: previous.count + 1, byMe: true };
    setKudos(next);
    try {
      if (previous.byMe) {
        await removeKudos(ride.id, profile.id);
      } else {
        await giveKudos(ride.id, profile.id);
      }
    } catch {
      setKudos(previous);
    }
  }

  async function onPostComment() {
    if (!profile || !ride || !commentBody.trim()) return;
    const body = commentBody.trim();
    setPostingComment(true);
    setCommentBody('');
    const optimistic: Comment = { id: `temp-${Date.now()}`, body, created_at: new Date().toISOString(), profile };
    setComments((prev) => [...prev, optimistic]);
    try {
      await addComment(ride.id, profile.id, body);
    } catch (e) {
      setComments((prev) => prev.filter((c) => c.id !== optimistic.id));
      Alert.alert('Could not post comment', getErrorMessage(e));
    } finally {
      setPostingComment(false);
    }
  }

  async function onExport() {
    if (!ride) return;
    try {
      await exportRideAsGPX(ride);
    } catch (e) {
      Alert.alert('Could not export ride', getErrorMessage(e));
    }
  }

  async function onSaveAsRoute() {
    if (!ride || !profile || !ride.route_geojson) return;
    setSavingRoute(true);
    try {
      await createRoute({
        user_id: profile.id,
        name: ride.title,
        distance_m: ride.distance_m,
        elevation_gain_m: ride.elevation_gain_m,
        route_geojson: ride.route_geojson,
        created_from_ride_id: ride.id,
      });
      Alert.alert('Route saved', `"${ride.title}" was added to your saved routes.`);
    } catch (e) {
      Alert.alert('Could not save route', getErrorMessage(e));
    } finally {
      setSavingRoute(false);
    }
  }

  async function onSaveAsSegment() {
    // Simplified, deliberately: a segment is carved from the whole ride
    // (start = first point, end = last point) rather than a user-trimmed
    // sub-section — same trade-off already made for "save as route", and it
    // keeps segment creation a single tap instead of a draggable-pin editor.
    if (!ride || !profile || !ride.route_geojson) return;
    const coords = ride.route_geojson.coordinates;
    if (coords.length < 2) return;
    setSavingSegment(true);
    try {
      const [startLng, startLat] = coords[0];
      const [endLng, endLat] = coords[coords.length - 1];
      await createSegment({
        created_by: profile.id,
        name: ride.title,
        distance_m: ride.distance_m,
        elevation_gain_m: ride.elevation_gain_m,
        avg_grade_pct: ride.distance_m > 0 ? Number(((ride.elevation_gain_m / ride.distance_m) * 100).toFixed(1)) : null,
        start_lat: startLat,
        start_lng: startLng,
        end_lat: endLat,
        end_lng: endLng,
        route_geojson: ride.route_geojson,
      });
      Alert.alert('Segment created', `"${ride.title}" is now a segment other riders can race. Star it to start tracking your efforts on it.`);
    } catch (e) {
      Alert.alert('Could not create segment', getErrorMessage(e));
    } finally {
      setSavingSegment(false);
    }
  }

  function onDelete() {
    if (!ride) return;
    Alert.alert('Delete this ride?', 'This permanently removes the ride, its route and its stats. This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setBusy(true);
          try {
            await deleteRide(ride.id);
            navigation.goBack();
          } catch (e) {
            setBusy(false);
            Alert.alert('Could not delete ride', getErrorMessage(e));
          }
        },
      },
    ]);
  }


  function onReport() {
    if (!ride) return;
    Linking.openURL(
      `mailto:adongoabc@proton.me?subject=${encodeURIComponent('Report a ride')}&body=${encodeURIComponent(`Ride ID: ${ride.id}\n\nWhat's wrong with this ride?\n`)}`,
    ).catch(() => Alert.alert('Could not open mail', 'Email adongoabc@proton.me and include this ride ID: ' + ride.id));
  }

  function menuAction(fn: () => void) {
    setMenuOpen(false);
    // Let the sheet finish closing before an Alert/share sheet opens on top of it.
    setTimeout(fn, 250);
  }

  if (loading) return <LoadingView />;

  if (notFound || !ride) {
    return (
      <ScreenContainer>
        <View style={styles.backRow}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
        </View>
        <EmptyState
          icon={<Ionicons name="help-circle-outline" size={32} color={colors.textTertiary} />}
          title="Ride not found"
          description="This ride may have been deleted, or it isn't shared with you."
        />
      </ScreenContainer>
    );
  }

  const isOwner = profile?.id === ride.user_id;
  const bounds = boundingBox(ride.route_geojson);
  const routeCoordinates = ride.route_geojson?.coordinates.map((c) => [c[0], c[1]] as [number, number]) ?? [];
  const hasRoute = routeCoordinates.length > 1;
  const movingLabel = formatDuration(ride.moving_time_s, 'long');
  const elapsedLabel = formatDuration(ride.elapsed_time_s, 'long');

  const menuItems: Array<{ icon: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void; danger?: boolean }> = [];
  if (hasRoute) {
    menuItems.push({ icon: 'download-outline', label: 'Download GPX file', onPress: onExport });
    menuItems.push({ icon: 'bookmark-outline', label: 'Save as route', onPress: onSaveAsRoute });
  }
  if (isOwner && hasRoute) menuItems.push({ icon: 'flag-outline', label: 'Create segment from ride', onPress: onSaveAsSegment });
  if (!isOwner) menuItems.push({ icon: 'alert-circle-outline', label: 'Report', onPress: onReport });
  if (isOwner) menuItems.push({ icon: 'trash-outline', label: 'Delete ride', onPress: onDelete, danger: true });

  return (
    <ScreenContainer padded={false}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }} keyboardVerticalOffset={8}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
          <View style={styles.headerActions}>
            <Pressable onPress={() => setShareOpen(true)} hitSlop={10} style={styles.headerIcon}>
              <Ionicons name="share-outline" size={22} color={colors.textPrimary} />
            </Pressable>
            {menuItems.length > 0 ? (
              <Pressable onPress={() => setMenuOpen(true)} hitSlop={10} disabled={busy} style={styles.headerIcon}>
                <Ionicons name="ellipsis-vertical" size={22} color={colors.textPrimary} />
              </Pressable>
            ) : null}
          </View>
        </View>

        <View style={styles.tabBar}>
          {TABS.map((t) => (
            <Pressable key={t.key} onPress={() => setTab(t.key)} style={styles.tab} hitSlop={4}>
              <Text style={[styles.tabLabel, tab === t.key && styles.tabLabelActive]}>{t.label}</Text>
              <View style={[styles.tabUnderline, tab === t.key && styles.tabUnderlineActive]} />
            </Pressable>
          ))}
        </View>

        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View style={styles.tabContent}>
            {tab === 'route' ? (
              hasRoute ? (
                <RideMap routeCoordinates={routeCoordinates} bounds={bounds} expandable expandTitle={ride.title || 'Route'} style={styles.map} />
              ) : (
                <View style={[styles.map, styles.noMap]}>
                  <Ionicons name="map-outline" size={28} color={colors.textTertiary} />
                  <Text style={styles.noMapText}>No route was recorded for this ride.</Text>
                </View>
              )
            ) : null}
            {tab === 'elevation' ? (
              <ElevationChartCard routeGeojson={ride.route_geojson} units={units} gainM={ride.elevation_gain_m} lossM={ride.elevation_loss_m} />
            ) : null}
            {tab === 'speed' ? (
              <SpeedChartCard
                samples={ride.speed_samples}
                units={units}
                avgSpeedMps={ride.avg_speed_mps}
                maxSpeedMps={ride.max_speed_mps}
                movingLabel={movingLabel}
                elapsedLabel={elapsedLabel}
              />
            ) : null}
            {tab === 'highlights' ? <HighlightsTab ride={ride} isOwner={isOwner} /> : null}
          </View>

          <View style={styles.summary}>
            <Pressable style={styles.ownerRow} onPress={() => owner && navigation.navigate('UserProfile', { userId: owner.id })}>
              <Avatar uri={owner?.avatar_url} name={owner?.display_name ?? '?'} size={40} />
              <View style={{ flex: 1 }}>
                <Text style={styles.ownerName}>
                  {owner?.display_name ?? 'A rider'} <Text style={styles.ownerAction}>went for a bike ride</Text>
                </Text>
                <Text style={styles.timestamp} numberOfLines={1}>
                  {formatRideTimestamp(ride.started_at)}
                  {ride.start_location_name ? ` · ${ride.start_location_name}` : ''}
                </Text>
              </View>
            </Pressable>

            <Text style={styles.title}>{ride.title}</Text>

            <View style={styles.statsGrid}>
              <SummaryStat label="Moving Time" value={movingLabel} />
              <SummaryStat label="Length" value={formatDistance(ride.distance_m, units)} />
              <SummaryStat label="Average Speed" value={formatSpeed(ride.avg_speed_mps, units)} />
              <SummaryStat label="Elevation Gain" value={formatElevation(ride.elevation_gain_m, units)} />
            </View>

            <View style={styles.infoRow}>
              <Ionicons name={VISIBILITY_ICON[ride.visibility]} size={16} color={colors.textSecondary} />
              <Text style={styles.infoLabel}>Visibility</Text>
              <Text style={styles.infoValue}>{ride.visibility === 'public' ? 'Public' : ride.visibility === 'followers' ? 'Followers' : 'Only me'}</Text>
            </View>

            {companions.length > 0 ? (
              <View style={styles.infoRow}>
                <Ionicons name="people-outline" size={16} color={colors.textSecondary} />
                <Text style={styles.infoLabel}>Participants</Text>
                <Text style={[styles.infoValue, { flex: 1 }]} numberOfLines={2}>
                  {companions.map((c, i) => (
                    <Text key={c.id} onPress={() => navigation.navigate('UserProfile', { userId: c.id })}>
                      {c.display_name || c.username}
                      {i < companions.length - 1 ? ', ' : ''}
                    </Text>
                  ))}
                </Text>
                {companions.some((c) => c.id === profile?.id) ? (
                  <Pressable onPress={() => profile && onRemoveCompanion(profile.id)} hitSlop={8}>
                    <Text style={styles.untagLink}>Remove me</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : null}

            {recordingDevice ? (
              <View style={styles.infoRow}>
                <Ionicons name="watch-outline" size={16} color={colors.textSecondary} />
                <Text style={styles.infoLabel}>Recorded with</Text>
                <Text style={[styles.infoValue, { flex: 1 }]} numberOfLines={1}>
                  {recordingDevice.name} ({recordingDeviceBrandLabel(recordingDevice.brand)})
                </Text>
              </View>
            ) : null}

            {ride.description ? <Text style={styles.description}>{ride.description}</Text> : null}

            <View style={styles.actionRow}>
              <Pressable onPress={onToggleKudos} style={styles.actionButton} hitSlop={6}>
                <Ionicons name={kudos.byMe ? 'heart' : 'heart-outline'} size={24} color={kudos.byMe ? colors.danger : colors.textPrimary} />
                <Text style={styles.actionCount}>{kudos.count}</Text>
              </Pressable>
              <View style={styles.actionButton}>
                <Ionicons name="chatbubble-outline" size={22} color={colors.textPrimary} />
                <Text style={styles.actionCount}>{comments.length}</Text>
              </View>
              <Pressable onPress={() => setShareOpen(true)} style={styles.actionButton} hitSlop={6}>
                <Ionicons name="share-outline" size={23} color={colors.textPrimary} />
              </Pressable>
              {hasRoute ? (
                <Pressable
                  onPress={onSaveAsRoute}
                  disabled={savingRoute}
                  style={({ pressed }) => [styles.saveRoute, pressed && { opacity: 0.8 }, savingRoute && { opacity: 0.6 }]}
                  accessibilityRole="button"
                  accessibilityLabel="Save this ride as a route"
                >
                  <Ionicons name="bookmark-outline" size={16} color={colors.accent} />
                  <Text style={styles.saveRouteText}>{savingRoute ? 'Saving…' : 'Save route'}</Text>
                </Pressable>
              ) : null}
            </View>

            <View style={styles.commentsSection}>
              <Text style={styles.sectionLabel}>Comments</Text>
              {comments.length === 0 ? (
                <Text style={styles.noComments}>No comments yet.</Text>
              ) : (
                comments.map((c) => (
                  <View key={c.id} style={styles.commentRow}>
                    <Avatar uri={c.profile.avatar_url} name={c.profile.display_name} size={30} />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.commentMeta}>
                        <Text style={styles.commentName}>{c.profile.display_name}</Text>
                        {'  '}
                        {formatDistanceToNow(new Date(c.created_at), { addSuffix: true })}
                      </Text>
                      <Text style={styles.commentBody}>{c.body}</Text>
                    </View>
                  </View>
                ))
              )}
            </View>
          </View>
        </ScrollView>

        <View style={styles.commentInputRow}>
          {/* TextField only forwards `style` to its inner TextInput, not its
              outer wrapper, so flex:1 has to be applied from out here for the
              field to actually share the row with the send button. */}
          <View style={styles.commentInput}>
            <TextField value={commentBody} onChangeText={setCommentBody} placeholder="Add a comment…" />
          </View>
          <Pressable onPress={onPostComment} disabled={postingComment || !commentBody.trim()} hitSlop={8} style={styles.sendButton}>
            <Ionicons name="send" size={18} color={commentBody.trim() ? colors.accent : colors.textTertiary} />
          </Pressable>
        </View>

      </KeyboardAvoidingView>

      <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
        <Pressable style={styles.menuBackdrop} onPress={() => setMenuOpen(false)}>
          <View style={styles.menuSheet}>
            {menuItems.map((item) => (
              <Pressable key={item.label} style={styles.menuItem} onPress={() => menuAction(item.onPress)}>
                <Ionicons name={item.icon} size={21} color={item.danger ? colors.danger : colors.textPrimary} />
                <Text style={[styles.menuLabel, item.danger && { color: colors.danger }]}>{item.label}</Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>

      <RideShareModal
        visible={shareOpen}
        ride={ride}
        ownerName={owner?.display_name ?? 'A rider'}
        ownerAvatarUrl={owner?.avatar_url}
        units={units}
        onClose={() => setShareOpen(false)}
      />
    </ScreenContainer>
  );
}

function SummaryStat({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.summaryStat}>
      <Text style={styles.summaryStatLabel}>{label}</Text>
      <Text style={styles.summaryStatValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  backRow: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  headerActions: { flexDirection: 'row', gap: spacing.md },
  headerIcon: { padding: 2 },
  tabBar: { flexDirection: 'row', paddingHorizontal: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  tab: { flex: 1, alignItems: 'center', paddingTop: spacing.xs },
  tabLabel: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textTertiary, paddingBottom: 10 },
  tabLabelActive: { color: colors.textPrimary },
  tabUnderline: { height: 3, alignSelf: 'stretch', borderRadius: 2, backgroundColor: 'transparent' },
  tabUnderlineActive: { backgroundColor: colors.accent },
  scroll: { paddingBottom: spacing.xl },
  tabContent: { paddingHorizontal: spacing.md, paddingTop: spacing.md },
  map: { height: 300, borderRadius: radius.lg, overflow: 'hidden' },
  noMap: { alignItems: 'center', justifyContent: 'center', gap: spacing.xs, backgroundColor: colors.surfaceHigh },
  noMapText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary },
  summary: { paddingHorizontal: spacing.md, gap: spacing.md, marginTop: spacing.lg },
  ownerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  ownerName: { fontFamily: fonts.bold, fontSize: 15, color: colors.textPrimary },
  ownerAction: { fontFamily: fonts.regular, color: colors.textSecondary },
  timestamp: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  title: { ...typeTokens.h2, color: colors.textPrimary },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', rowGap: spacing.md },
  summaryStat: { width: '50%', gap: 2 },
  summaryStatLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  summaryStatValue: { fontFamily: fonts.bold, fontSize: 20, color: colors.textPrimary },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, paddingVertical: 2 },
  infoLabel: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary },
  infoValue: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textPrimary },
  untagLink: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.accent },
  description: { fontFamily: fonts.regular, fontSize: 15, lineHeight: 21, color: colors.textPrimary },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, borderTopWidth: 1, borderBottomWidth: 1, borderColor: colors.border, paddingVertical: spacing.sm },
  actionButton: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionCount: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
  commentsSection: { gap: spacing.sm },
  sectionLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, letterSpacing: 0.3 },
  noComments: { fontFamily: fonts.regular, fontSize: 14, color: colors.textTertiary },
  commentRow: { flexDirection: 'row', gap: spacing.xs, alignItems: 'flex-start' },
  commentMeta: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary },
  commentName: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textPrimary },
  commentBody: { fontFamily: fonts.regular, fontSize: 14, color: colors.textPrimary, marginTop: 2 },
  commentInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.bg,
  },
  commentInput: { flex: 1 },
  sendButton: { padding: spacing.xs },
  saveRoute: { marginLeft: 'auto', flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 36, borderRadius: radius.pill, backgroundColor: colors.accentMuted },
  saveRouteText: { fontFamily: fonts.bold, fontSize: 13, color: colors.accent },
  menuBackdrop: { flex: 1, backgroundColor: 'rgba(21, 23, 27, 0.45)', justifyContent: 'flex-end' },
  menuSheet: { backgroundColor: colors.bg, borderTopLeftRadius: radius.xl, borderTopRightRadius: radius.xl, paddingVertical: spacing.sm, paddingBottom: spacing.xl },
  menuItem: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: 15 },
  menuLabel: { fontFamily: fonts.semiBold, fontSize: 16, color: colors.textPrimary },
});
