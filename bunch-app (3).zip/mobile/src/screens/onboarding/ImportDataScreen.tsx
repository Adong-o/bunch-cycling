import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { pickImportFile, saveImportedRide } from '@/lib/gpxImport';
import { getErrorMessage } from '@/lib/errors';
import { useAuthStore } from '@/state/authStore';
import { colors, fonts, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';

type Status = 'idle' | 'working' | 'done' | 'error';

export function ImportDataScreen({ navigation }: OnboardingScreenProps<'ImportData'>) {
  const profile = useAuthStore((s) => s.profile);
  const [status, setStatus] = useState<Status>('idle');
  const [importedTitle, setImportedTitle] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  function onSkip() {
    navigation.navigate('UpgradeOffer');
  }

  async function onImport() {
    if (!profile) return;
    setStatus('working');
    setError(null);
    try {
      const picked = await pickImportFile();
      if (!picked) {
        setStatus('idle'); // user canceled the file picker — let them tap again or skip
        return;
      }
      const ride = await saveImportedRide(profile.id, picked.parsed);
      setImportedTitle(ride.title);
      setStatus('done');
    } catch (e) {
      setError(getErrorMessage(e));
      setStatus('error');
    }
  }

  const done = status === 'done';

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={6} />
      <View style={styles.body}>
        <Animated.View entering={FadeInUp.duration(420)} style={styles.header}>
          <Text style={styles.title}>Bring your ride history</Text>
          <Text style={styles.subtitle}>
            Import past rides from Strava, Garmin, or any app that can export a GPX or TCX file. You can always do this
            later from your profile.
          </Text>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(140).duration(420)} style={styles.centerpiece}>
          <Ionicons name={done ? 'checkmark-circle' : 'cloud-upload-outline'} size={48} color={done ? colors.success : colors.accent} />
          {done ? (
            <>
              <Text style={styles.centerTitle}>Imported</Text>
              <Text style={styles.centerBody}>"{importedTitle}" is in your rides.</Text>
            </>
          ) : (
            <>
              <Text style={styles.centerTitle}>Choose a file</Text>
              <Text style={styles.centerBody}>.gpx or .tcx — exported from your old app's ride history.</Text>
            </>
          )}
          {error ? <Text style={styles.error}>{error}</Text> : null}
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(220).duration(420)} style={styles.footer}>
          {done ? (
            <Button title="Continue" onPress={() => navigation.navigate('UpgradeOffer')} />
          ) : (
            <Button title={status === 'working' ? 'Reading file…' : 'Import now'} onPress={onImport} loading={status === 'working'} />
          )}
          <Button title="Skip for now" variant="ghost" onPress={onSkip} disabled={status === 'working'} />
        </Animated.View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  body: { flex: 1, paddingHorizontal: spacing.lg },
  header: { paddingTop: spacing.lg, gap: spacing.xs },
  title: { ...type.h1, color: colors.textPrimary },
  subtitle: { ...type.body, color: colors.textSecondary },
  centerpiece: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 6, paddingHorizontal: spacing.lg },
  centerTitle: { fontFamily: fonts.semiBold, fontSize: 17, color: colors.textPrimary, marginTop: spacing.sm },
  centerBody: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center' },
  error: { fontFamily: fonts.medium, fontSize: 12, color: colors.danger, textAlign: 'center', marginTop: 4 },
  footer: { paddingBottom: spacing.md, gap: spacing.xs },
});
