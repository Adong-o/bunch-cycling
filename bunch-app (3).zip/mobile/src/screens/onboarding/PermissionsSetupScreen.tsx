import React, { useCallback, useEffect, useState } from 'react';
import { Linking, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { Waypoint } from '@/components/onboarding/OnboardingSpine';
import { toPermState, type PermState } from '@/lib/permissions';
import { colors, fonts, radius, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';

export function PermissionsSetupScreen({ navigation }: OnboardingScreenProps<'PermissionsSetup'>) {
  const [foreground, setForeground] = useState<PermState>('undetermined');
  const [background, setBackground] = useState<PermState>('undetermined');
  const [requesting, setRequesting] = useState<'fg' | 'bg' | null>(null);

  const refresh = useCallback(async () => {
    const fg = await Location.getForegroundPermissionsAsync();
    setForeground(toPermState(fg));
    const bg = await Location.getBackgroundPermissionsAsync();
    setBackground(toPermState(bg));
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  async function onAllowForeground() {
    setRequesting('fg');
    try {
      await Location.requestForegroundPermissionsAsync();
    } finally {
      await refresh();
      setRequesting(null);
    }
  }

  async function onAllowBackground() {
    setRequesting('bg');
    try {
      await Location.requestBackgroundPermissionsAsync();
    } finally {
      await refresh();
      setRequesting(null);
    }
  }

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={5} />
      <View style={styles.body}>
        <Animated.View entering={FadeInUp.duration(420)} style={styles.header}>
          <Text style={styles.title}>Turn on location</Text>
          <Text style={styles.subtitle}>
            Bunch records a ride using your phone's GPS — nothing is tracked until you tap Start.
          </Text>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(130).duration(420)} style={styles.spine}>
          <Waypoint state={foreground === 'granted' ? 'done' : 'active'}>
            <PermissionRow
              icon="navigate-outline"
              title="Location"
              description="Required to record distance, speed, elevation and your route on the map."
              state={foreground}
              busy={requesting === 'fg'}
              onPress={foreground === 'denied' ? () => Linking.openSettings() : onAllowForeground}
              actionLabel={foreground === 'denied' ? 'Open Settings' : 'Allow'}
            />
          </Waypoint>
          <Waypoint state={background === 'granted' ? 'done' : foreground === 'granted' ? 'active' : 'upcoming'} isLast>
            <PermissionRow
              icon="moon-outline"
              title="Background location"
              description="Keeps a ride recording if your screen locks or you switch apps. Optional — you can turn it on later."
              state={background}
              busy={requesting === 'bg'}
              disabled={foreground !== 'granted'}
              onPress={background === 'denied' ? () => Linking.openSettings() : onAllowBackground}
              actionLabel={background === 'denied' ? 'Open Settings' : 'Allow'}
            />
          </Waypoint>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(210).duration(420)} style={styles.footer}>
          <Button title="Continue" onPress={() => navigation.navigate('ImportData')} />
        </Animated.View>
      </View>
    </ScreenContainer>
  );
}

function PermissionRow({
  icon,
  title,
  description,
  state,
  busy,
  disabled,
  onPress,
  actionLabel,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  state: PermState;
  busy: boolean;
  disabled?: boolean;
  onPress: () => void;
  actionLabel: string;
}) {
  const granted = state === 'granted';
  return (
    <View style={[rowStyles.row, disabled && !granted && rowStyles.rowDisabled]}>
      <View style={rowStyles.copy}>
        <View style={rowStyles.titleRow}>
          <Ionicons name={icon} size={15} color={granted ? colors.success : colors.textPrimary} />
          <Text style={rowStyles.title}>{title}</Text>
        </View>
        <Text style={rowStyles.description}>{description}</Text>
      </View>
      {granted ? (
        <View style={rowStyles.grantedPill}>
          <Ionicons name="checkmark" size={13} color={colors.success} />
          <Text style={rowStyles.grantedText}>On</Text>
        </View>
      ) : (
        <Button
          title={busy ? '···' : actionLabel}
          onPress={onPress}
          variant="secondary"
          size="md"
          fullWidth={false}
          disabled={disabled || busy}
          style={rowStyles.action}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  body: { flex: 1, paddingHorizontal: spacing.lg },
  header: { paddingTop: spacing.lg, gap: spacing.xs },
  title: { ...type.h1, color: colors.textPrimary },
  subtitle: { ...type.body, color: colors.textSecondary },
  spine: { marginTop: spacing.xl },
  footer: { flex: 1, justifyContent: 'flex-end', paddingBottom: spacing.md },
});

const rowStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowDisabled: { opacity: 0.5 },
  copy: { flex: 1, gap: 3 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  title: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  description: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 18, color: colors.textSecondary },
  action: { paddingHorizontal: spacing.sm },
  grantedPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 7,
    paddingHorizontal: 12,
    borderRadius: radius.pill,
    backgroundColor: colors.successMuted,
  },
  grantedText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.success },
});
