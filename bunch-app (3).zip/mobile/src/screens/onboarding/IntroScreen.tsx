import React, { useRef, useState } from 'react';
import { Dimensions, NativeScrollEvent, NativeSyntheticEvent, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { ChallengeIcon, SpeedometerIcon, StreakIcon } from '@/components/icons/HeroIcons';
import { colors, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';

const { width } = Dimensions.get('window');

const SLIDES: Array<{ Icon: React.ComponentType<{ size?: number; color?: string }>; title: string; body: string }> = [
  {
    Icon: SpeedometerIcon,
    title: 'Your phone already has everything',
    body: 'GPS speed, distance, elevation and a live map — no bike computer required. Pair a sensor later if you want one.',
  },
  {
    Icon: StreakIcon,
    title: 'Small targets, kept daily',
    body: 'Set a distance goal for the day or week. Bunch tracks your streak and nudges you before it breaks — not after.',
  },
  {
    Icon: ChallengeIcon,
    title: 'Challenges you can actually win',
    body: 'Join one made by Bunch, or unlock your own after a couple of rides. Invite your group with a link.',
  },
];

export function IntroScreen({ navigation }: OnboardingScreenProps<'Intro'>) {
  const [index, setIndex] = useState(0);
  const scrollRef = useRef<ScrollView>(null);

  function onScroll(e: NativeSyntheticEvent<NativeScrollEvent>) {
    const i = Math.round(e.nativeEvent.contentOffset.x / width);
    if (i !== index) setIndex(i);
  }

  const isLast = index === SLIDES.length - 1;

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={1} />
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
      >
        {SLIDES.map((slide) => (
          <View key={slide.title} style={[styles.slide, { width }]}>
            <slide.Icon size={56} color={colors.accent} />
            <Text style={styles.title}>{slide.title}</Text>
            <Text style={styles.body}>{slide.body}</Text>
          </View>
        ))}
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.dots}>
          {SLIDES.map((slide, i) => (
            <View key={slide.title} style={[styles.dot, i === index && styles.dotActive]} />
          ))}
        </View>
        <Button
          title={isLast ? "Let's set up your profile" : 'Next'}
          onPress={() => {
            if (isLast) {
              navigation.navigate('RiderType');
            } else {
              scrollRef.current?.scrollTo({ x: width * (index + 1), animated: true });
            }
          }}
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  slide: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.xl, gap: spacing.md },
  title: { ...type.h1, color: colors.textPrimary, textAlign: 'center', marginTop: spacing.sm },
  body: { ...type.body, color: colors.textSecondary, textAlign: 'center' },
  footer: { paddingHorizontal: spacing.lg, paddingBottom: spacing.md, gap: spacing.lg },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 8 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.border },
  dotActive: { backgroundColor: colors.accent, width: 20 },
});
