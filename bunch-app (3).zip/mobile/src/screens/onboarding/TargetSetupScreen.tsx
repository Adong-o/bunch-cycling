import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { SegmentedToggle } from '@/components/ui/SegmentedToggle';
import { supabase } from '@/lib/supabase';
import { getErrorMessage } from '@/lib/errors';
import { useAuthStore } from '@/state/authStore';
import { displayDistanceToMeters, distanceUnitLabel, metersToDisplayDistance } from '@/lib/units';
import { colors, fonts, radius, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';
import type { RidingExperience, TargetPeriod } from '@/lib/database.types';

// Starting goals scaled to what the rider told us on the previous
// onboarding screen, rather than a single default for everyone — someone
// who just said they're new to cycling shouldn't land on the same weekly
// target as someone who said they train with structure and race. Values
// are deliberately modest; the stepper lets them adjust immediately, and
// the goal itself can change anytime from Settings.
const EXPERIENCE_TARGET_DEFAULTS_M: Record<RidingExperience, { daily: number; weekly: number }> = {
  new: { daily: 5000, weekly: 20000 },
  casual: { daily: 10000, weekly: 40000 },
  regular: { daily: 15000, weekly: 75000 },
  competitive: { daily: 25000, weekly: 150000 },
};
const FALLBACK_TARGET_M = { daily: 15000, weekly: 50000 };

function targetDefaultsFor(experience: RidingExperience | null | undefined): { daily: number; weekly: number } {
  if (experience && experience in EXPERIENCE_TARGET_DEFAULTS_M) return EXPERIENCE_TARGET_DEFAULTS_M[experience];
  return FALLBACK_TARGET_M;
}

const EXPERIENCE_HINT_LABELS: Record<RidingExperience, string> = {
  new: "you're new to cycling",
  casual: "you ride casually",
  regular: "you're a regular rider",
  competitive: "you train with structure",
};

const PERIOD_OPTIONS: Array<{ value: TargetPeriod; label: string }> = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
];

export function TargetSetupScreen({ navigation }: OnboardingScreenProps<'TargetSetup'>) {
  const profile = useAuthStore((s) => s.profile);
  const updateLocalProfile = useAuthStore((s) => s.updateLocalProfile);
  const units = profile?.units ?? 'metric';
  const unitLabel = distanceUnitLabel(units);
  const targetDefaultsM = targetDefaultsFor(profile?.riding_experience);
  const experienceHint = profile?.riding_experience ? EXPERIENCE_HINT_LABELS[profile.riding_experience] : null;

  const [period, setPeriod] = useState<TargetPeriod>('weekly');
  const [displayValue, setDisplayValue] = useState(() => Math.round(metersToDisplayDistance(targetDefaultsM.weekly, units)));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const step = units === 'metric' ? 5 : 5;
  const min = 5;
  const max = period === 'daily' ? 100 : 500;

  function adjust(delta: number) {
    setDisplayValue((v) => Math.max(min, Math.min(max, v + delta)));
  }

  function onChangePeriod(p: TargetPeriod) {
    setPeriod(p);
    setDisplayValue(
      p === 'daily' ? Math.round(metersToDisplayDistance(targetDefaultsM.daily, units)) : Math.round(metersToDisplayDistance(targetDefaultsM.weekly, units))
    );
  }

  async function onContinue() {
    if (!profile) return;
    setSaving(true);
    setError(null);
    const targetDistanceM = Math.round(displayDistanceToMeters(displayValue, units));
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ target_period: period, target_distance_m: targetDistanceM })
      .eq('id', profile.id);
    setSaving(false);
    if (updateError) {
      setError(getErrorMessage(updateError));
      return;
    }
    updateLocalProfile({ target_period: period, target_distance_m: targetDistanceM });
    navigation.navigate('PermissionsSetup');
  }

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={4} />
      <View style={styles.body}>
        <Animated.View entering={FadeInUp.duration(420)} style={styles.header}>
          <Text style={styles.title}>Set your target</Text>
          <Text style={styles.subtitle}>Hit it to build a streak. Miss a day and the streak waits — it doesn't reset until the period ends.</Text>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(130).duration(420)} style={styles.controls}>
          <SegmentedToggle options={PERIOD_OPTIONS} value={period} onChange={onChangePeriod} />

          <View style={styles.stepper}>
            <Pressable onPress={() => adjust(-step)} style={styles.stepperButton} hitSlop={8}>
              <Ionicons name="remove" size={24} color={colors.textPrimary} />
            </Pressable>
            <View style={styles.stepperValue}>
              <Text style={styles.valueText}>{displayValue}</Text>
              <Text style={styles.valueUnit}>
                {unitLabel} / {period === 'daily' ? 'day' : 'week'}
              </Text>
            </View>
            <Pressable onPress={() => adjust(step)} style={styles.stepperButton} hitSlop={8}>
              <Ionicons name="add" size={24} color={colors.textPrimary} />
            </Pressable>
          </View>

          {experienceHint ? (
            <Text style={styles.hint}>Since {experienceHint}, we've set a starting goal — adjust it anytime with the buttons above.</Text>
          ) : null}
        </Animated.View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Animated.View entering={FadeInUp.delay(210).duration(420)} style={styles.footer}>
          <Button title="Continue" onPress={onContinue} loading={saving} />
        </Animated.View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  body: { flex: 1, paddingHorizontal: spacing.lg },
  header: { paddingTop: spacing.lg, gap: spacing.xs },
  title: { ...type.h1, color: colors.textPrimary },
  subtitle: { ...type.body, color: colors.textSecondary },
  controls: { flex: 1, justifyContent: 'center' },
  stepper: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.lg, marginTop: spacing.xxl },
  stepperButton: {
    width: 52,
    height: 52,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperValue: { alignItems: 'center', minWidth: 140 },
  valueText: { fontFamily: fonts.monoBold, fontSize: 52, lineHeight: 56, color: colors.textPrimary, letterSpacing: -0.5 },
  valueUnit: { fontFamily: fonts.medium, fontSize: 14, color: colors.textSecondary, marginTop: 6 },
  hint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center', marginTop: spacing.lg, paddingHorizontal: spacing.md },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14, textAlign: 'center' },
  footer: { paddingBottom: spacing.md },
});
