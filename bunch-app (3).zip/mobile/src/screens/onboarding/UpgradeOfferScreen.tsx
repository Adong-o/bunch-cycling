import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { PREMIUM_MONTHLY_PRICE, PREMIUM_YEARLY_PRICE, PREMIUM_YEARLY_DISCOUNT } from '@/lib/pricing';
import { colors, fonts, radius, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';

const BENEFITS: Array<{ icon: keyof typeof Ionicons.glyphMap; text: string }> = [
  { icon: 'bicycle-outline', text: 'Unlimited bikes in your garage' },
  { icon: 'map-outline', text: 'Unlimited saved routes' },
  { icon: 'trending-up-outline', text: 'Unlimited starred segments' },
  { icon: 'bluetooth-outline', text: 'Unlimited recording devices' },
  { icon: 'star', text: 'A gold Premium badge on your profile' },
];

/**
 * The one-time pricing pitch shown at the end of onboarding — after every
 * setup screen but before the final "you're set" celebration, the classic
 * spot fitness apps show Premium, once there's already a rider profile and
 * target to frame the value against. Bunch isn't sold in-app yet (see
 * PremiumScreen.tsx's own note on the Settings side), so the only real
 * action here is moving on — "Continue with Free" is the honest, single
 * primary button, not a guilt-tripped "no thanks" link next to a button
 * that doesn't actually charge anyone.
 *
 * Content is scrollable but the CTA is pinned outside the ScrollView (unlike
 * the sparser ImportData/Done onboarding screens) because five benefit rows
 * plus the price block can run past the fold on a small phone — the button
 * to move on must stay reachable without scrolling regardless.
 */
export function UpgradeOfferScreen({ navigation }: OnboardingScreenProps<'UpgradeOffer'>) {
  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={7} />

      <ScrollView contentContainerStyle={styles.scroll}>
        <Animated.View entering={FadeInUp.duration(420)} style={styles.hero}>
          <View style={styles.heroBadge}>
            <Ionicons name="star" size={28} color={colors.gold} />
          </View>
          <Text style={styles.title}>Go further with Premium</Text>
          <Text style={styles.subtitle}>
            The free plan is everything you need to start riding. Premium lifts the limits once you're hooked.
          </Text>
          <View style={styles.priceRow}>
            <Text style={styles.price}>{PREMIUM_MONTHLY_PRICE}</Text>
            <Text style={styles.pricePeriod}>/ month</Text>
          </View>
          <Text style={styles.priceCaption}>
            or {PREMIUM_YEARLY_PRICE} billed yearly — about {PREMIUM_YEARLY_DISCOUNT} off
          </Text>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(140).duration(420)} style={styles.benefits}>
          {BENEFITS.map((b) => (
            <View key={b.text} style={styles.benefitRow}>
              <View style={styles.benefitIcon}>
                <Ionicons name={b.icon} size={16} color={colors.accent} />
              </View>
              <Text style={styles.benefitText}>{b.text}</Text>
            </View>
          ))}
        </Animated.View>
      </ScrollView>

      <Animated.View entering={FadeInUp.delay(240).duration(420)} style={styles.footer}>
        <Button title="Continue with Free" onPress={() => navigation.navigate('Done')} />
        <Text style={styles.footerCaption}>
          Bunch is in early access, so Premium isn't sold in-app yet — you can ask about upgrading any time from Settings.
        </Text>
      </Animated.View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: spacing.lg, paddingTop: spacing.sm, gap: spacing.xl },
  hero: { alignItems: 'center', gap: 6 },
  heroBadge: {
    width: 64,
    height: 64,
    borderRadius: radius.xl,
    backgroundColor: colors.goldMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  title: { ...type.h1, color: colors.textPrimary, textAlign: 'center' },
  subtitle: {
    fontFamily: fonts.regular,
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: spacing.sm,
  },
  priceRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 4, marginTop: spacing.sm },
  price: { ...type.display, color: colors.textPrimary },
  pricePeriod: { fontFamily: fonts.medium, fontSize: 16, color: colors.textSecondary, marginBottom: 6 },
  priceCaption: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary },
  benefits: { gap: spacing.sm },
  benefitRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  benefitIcon: {
    width: 32,
    height: 32,
    borderRadius: radius.sm,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  benefitText: { flex: 1, fontFamily: fonts.medium, fontSize: 14, color: colors.textPrimary },
  footer: { paddingHorizontal: spacing.lg, paddingBottom: spacing.md, paddingTop: spacing.sm, gap: spacing.xs },
  footerCaption: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center', lineHeight: 16 },
});
