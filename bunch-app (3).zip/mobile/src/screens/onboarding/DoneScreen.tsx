import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp, ZoomIn } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { Waypoint } from '@/components/onboarding/OnboardingSpine';
import { supabase } from '@/lib/supabase';
import { getErrorMessage } from '@/lib/errors';
import { useAuthStore } from '@/state/authStore';
import { formatDistance } from '@/lib/units';
import { colors, fonts, radius, spacing, type } from '@/theme';

export function DoneScreen() {
  const profile = useAuthStore((s) => s.profile);
  const updateLocalProfile = useAuthStore((s) => s.updateLocalProfile);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const units = profile?.units ?? 'metric';
  const targetLabel =
    profile?.target_distance_m != null
      ? `${formatDistance(profile.target_distance_m, units)} / ${profile.target_period === 'daily' ? 'day' : 'week'}`
      : null;

  async function onFinish() {
    if (!profile) return;
    setSaving(true);
    setError(null);
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ onboarding_completed: true })
      .eq('id', profile.id);
    setSaving(false);
    if (updateError) {
      setError(getErrorMessage(updateError));
      return;
    }
    // RootNavigator watches profile.onboarding_completed and swaps straight
    // into the main tabs once this flips — no explicit navigation call needed.
    updateLocalProfile({ onboarding_completed: true });
  }

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={8} />
      <View style={styles.container}>
        <Animated.View entering={ZoomIn.delay(100).duration(560).springify().damping(11)} style={styles.badge}>
          <Ionicons name="checkmark" size={36} color={colors.success} />
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(340).duration(420)}>
          <Text style={styles.title}>You're set, {profile?.display_name?.split(' ')[0] || 'rider'}</Text>
          <Text style={styles.subtitle}>Your garage is ready. Here's what you told us:</Text>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(440).duration(420)} style={styles.spine}>
          <Waypoint state="done">
            <Text style={styles.recapText}>{targetLabel ? `Target: ${targetLabel}` : 'Target set'}</Text>
          </Waypoint>
          <Waypoint state="done">
            <Text style={styles.recapText}>GPS tracking ready — no sensors required</Text>
          </Waypoint>
          <Waypoint state="done" isLast>
            <Text style={styles.recapText}>Join a challenge any time to start earning badges</Text>
          </Waypoint>
        </Animated.View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Animated.View entering={FadeInUp.delay(520).duration(420)} style={styles.footer}>
          <Button title="Let's ride" onPress={onFinish} loading={saving} />
        </Animated.View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: spacing.lg, paddingTop: spacing.xl },
  badge: {
    width: 76,
    height: 76,
    borderRadius: radius.xl,
    backgroundColor: colors.successMuted,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: spacing.lg,
  },
  title: { ...type.h1, color: colors.textPrimary, textAlign: 'center' },
  subtitle: { ...type.body, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xxs },
  spine: { marginTop: spacing.xl },
  recapText: { fontFamily: fonts.medium, fontSize: 15, color: colors.textPrimary, paddingTop: 2 },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14, textAlign: 'center' },
  footer: { flex: 1, justifyContent: 'flex-end', paddingBottom: spacing.md },
});
