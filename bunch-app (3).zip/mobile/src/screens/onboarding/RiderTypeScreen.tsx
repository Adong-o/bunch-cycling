import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { OptionRow, Waypoint } from '@/components/onboarding/OnboardingSpine';
import { supabase } from '@/lib/supabase';
import { createBike } from '@/lib/api/bikes';
import { getErrorMessage } from '@/lib/errors';
import { useAuthStore } from '@/state/authStore';
import { colors, fonts, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';
import type { BikeType, PrimaryGoal, RidingExperience } from '@/lib/database.types';

const EXPERIENCE_OPTIONS: Array<{ value: RidingExperience; label: string; description: string }> = [
  { value: 'new', label: 'New to cycling', description: 'Just getting started' },
  { value: 'casual', label: 'Casual rider', description: 'I ride sometimes, no fixed routine' },
  { value: 'regular', label: 'Regular rider', description: 'A few rides most weeks' },
  { value: 'competitive', label: 'Competitive / racer', description: 'I train with structure and race' },
];

const GOAL_OPTIONS: Array<{ value: PrimaryGoal; label: string }> = [
  { value: 'fitness', label: 'Get fitter' },
  { value: 'commuting', label: 'Commute by bike' },
  { value: 'racing', label: 'Train for racing' },
  { value: 'social', label: 'Ride with others' },
  { value: 'exploring', label: 'Explore new routes' },
];

// Mirrors GarageScreen's own bike-type vocabulary, so the type a rider picks
// here is exactly what they'll see on it later in their Garage.
const BIKE_TYPE_OPTIONS: Array<{ value: BikeType; label: string }> = [
  { value: 'road', label: 'Road' },
  { value: 'gravel', label: 'Gravel' },
  { value: 'mountain', label: 'Mountain' },
  { value: 'commuter', label: 'Commuter' },
  { value: 'ebike', label: 'E-Bike' },
  { value: 'other', label: 'Other' },
];

function defaultBikeName(type: BikeType): string {
  if (type === 'ebike') return 'My E-Bike';
  const label = BIKE_TYPE_OPTIONS.find((t) => t.value === type)?.label ?? 'Bike';
  return `My ${label} Bike`;
}

export function RiderTypeScreen({ navigation }: OnboardingScreenProps<'RiderType'>) {
  const profile = useAuthStore((s) => s.profile);
  const updateLocalProfile = useAuthStore((s) => s.updateLocalProfile);

  const [experience, setExperience] = useState<RidingExperience | null>(null);
  const [goal, setGoal] = useState<PrimaryGoal | null>(null);
  const [bikeType, setBikeType] = useState<BikeType | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canContinue = experience != null && goal != null && bikeType != null;

  async function onContinue() {
    if (!profile || !experience || !goal || !bikeType) return;
    setSaving(true);
    setError(null);
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ riding_experience: experience, primary_goal: goal })
      .eq('id', profile.id);
    setSaving(false);
    if (updateError) {
      setError(getErrorMessage(updateError));
      return;
    }
    updateLocalProfile({ riding_experience: experience, primary_goal: goal });

    // Best-effort: seeds a real Garage entry from the bike type they just
    // picked, so onboarding actually sets something up rather than just
    // asking questions nobody sees the point of again. A failure here
    // shouldn't block onboarding — worst case their Garage is empty, same
    // as before, and they can add a bike manually anytime.
    try {
      await createBike({ user_id: profile.id, name: defaultBikeName(bikeType), type: bikeType, is_default: true });
    } catch {
      // ignore
    }

    navigation.navigate('ProfileSetup');
  }

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={2} />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <Animated.View entering={FadeInUp.duration(420)}>
          <Text style={styles.title}>Tell us how you ride</Text>
          <Text style={styles.subtitle}>A few quick questions so Bunch fits you from the start.</Text>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(140).duration(420)} style={styles.spine}>
          <Waypoint state={experience ? 'done' : 'active'}>
            <Text style={styles.question}>How would you describe your riding?</Text>
            {EXPERIENCE_OPTIONS.map((opt) => (
              <OptionRow
                key={opt.value}
                label={opt.label}
                description={opt.description}
                selected={experience === opt.value}
                onPress={() => setExperience(opt.value)}
              />
            ))}
          </Waypoint>

          <Waypoint state={goal ? 'done' : experience ? 'active' : 'upcoming'}>
            <Text style={styles.question}>What are you looking to do with Bunch?</Text>
            {GOAL_OPTIONS.map((opt) => (
              <OptionRow key={opt.value} label={opt.label} selected={goal === opt.value} onPress={() => setGoal(opt.value)} />
            ))}
          </Waypoint>

          <Waypoint state={bikeType ? 'done' : goal ? 'active' : 'upcoming'} isLast>
            <Text style={styles.question}>What's your main bike?</Text>
            {BIKE_TYPE_OPTIONS.map((opt) => (
              <OptionRow key={opt.value} label={opt.label} selected={bikeType === opt.value} onPress={() => setBikeType(opt.value)} />
            ))}
            <Text style={styles.hint}>We'll add it to your Garage — rename or add more anytime.</Text>
          </Waypoint>
        </Animated.View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Animated.View entering={FadeInUp.delay(220).duration(420)} style={styles.footer}>
          <Button title="Continue" onPress={onContinue} loading={saving} disabled={!canContinue} />
        </Animated.View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg, paddingBottom: spacing.xl },
  title: { ...type.h1, color: colors.textPrimary },
  subtitle: { ...type.body, color: colors.textSecondary, marginTop: spacing.xxs },
  spine: { marginTop: spacing.xl },
  question: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary, marginBottom: 4 },
  hint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 6 },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14, marginTop: spacing.xs },
  footer: { marginTop: spacing.lg },
});
