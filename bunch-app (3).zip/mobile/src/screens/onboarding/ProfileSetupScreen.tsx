import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { Avatar } from '@/components/ui/Avatar';
import { OnboardingProgress } from '@/components/onboarding/OnboardingProgress';
import { SegmentedToggle } from '@/components/ui/SegmentedToggle';
import { supabase } from '@/lib/supabase';
import { uploadImage } from '@/lib/api/storage';
import { getErrorMessage } from '@/lib/errors';
import { useAuthStore } from '@/state/authStore';
import { colors, fonts, spacing, type } from '@/theme';
import type { OnboardingScreenProps } from '@/navigation/types';
import type { UnitSystem } from '@/lib/database.types';

const UNIT_OPTIONS: Array<{ value: UnitSystem; label: string }> = [
  { value: 'metric', label: 'Kilometers' },
  { value: 'imperial', label: 'Miles' },
];

export function ProfileSetupScreen({ navigation }: OnboardingScreenProps<'ProfileSetup'>) {
  const profile = useAuthStore((s) => s.profile);
  const updateLocalProfile = useAuthStore((s) => s.updateLocalProfile);

  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [username, setUsername] = useState(profile?.username ?? '');
  const [units, setUnits] = useState<UnitSystem>(profile?.units ?? 'metric');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(profile?.avatar_url ?? null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function pickAvatar() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Allow photo access to set a profile picture — or skip this for now.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (result.canceled || !profile) return;

    setUploadingAvatar(true);
    try {
      const url = await uploadImage('avatars', profile.id, result.assets[0].uri);
      setAvatarUrl(url);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setUploadingAvatar(false);
    }
  }

  async function onContinue() {
    if (!profile) return;
    setError(null);

    const cleanUsername = username.trim().toLowerCase();
    if (!/^[a-z0-9_]{3,20}$/.test(cleanUsername)) {
      setError('Username: 3–20 characters, lowercase letters, numbers or underscore only.');
      return;
    }
    if (!displayName.trim()) {
      setError('Enter a display name.');
      return;
    }

    setSaving(true);
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ display_name: displayName.trim(), username: cleanUsername, units, avatar_url: avatarUrl })
      .eq('id', profile.id);
    setSaving(false);

    if (updateError) {
      setError(/unique/i.test(getErrorMessage(updateError)) ? 'That username is already taken.' : getErrorMessage(updateError));
      return;
    }

    updateLocalProfile({ display_name: displayName.trim(), username: cleanUsername, units, avatar_url: avatarUrl });
    navigation.navigate('TargetSetup');
  }

  return (
    <ScreenContainer padded={false}>
      <OnboardingProgress step={3} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <Animated.View entering={FadeInUp.duration(420)}>
            <Text style={styles.title}>Set up your profile</Text>
            <Text style={styles.subtitle}>This is how other riders will see you.</Text>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(130).duration(420)} style={styles.form}>
            <Pressable onPress={pickAvatar} style={styles.avatarRow} disabled={uploadingAvatar}>
              <Avatar uri={avatarUrl} name={displayName || 'Rider'} size={76} />
              <View style={styles.avatarEditBadge}>
                <Ionicons name={uploadingAvatar ? 'hourglass-outline' : 'camera-outline'} size={14} color={colors.textOnAccent} />
              </View>
            </Pressable>

            <TextField label="Display name" value={displayName} onChangeText={setDisplayName} placeholder="Alex Rider" />
            <TextField
              label="Username"
              value={username}
              onChangeText={(v) => setUsername(v.toLowerCase())}
              placeholder="alexrides"
              autoCapitalize="none"
            />

            <View>
              <Text style={styles.label}>Units</Text>
              <SegmentedToggle options={UNIT_OPTIONS} value={units} onChange={setUnits} />
            </View>

            {error ? <Text style={styles.error}>{error}</Text> : null}
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(210).duration(420)} style={styles.footer}>
            <Button title="Continue" onPress={onContinue} loading={saving} />
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg, paddingBottom: spacing.xl },
  title: { ...type.h1, color: colors.textPrimary },
  subtitle: { ...type.body, color: colors.textSecondary, marginTop: spacing.xxs },
  form: { gap: spacing.md, marginTop: spacing.xl },
  avatarRow: { alignSelf: 'center', marginBottom: spacing.xs },
  avatarEditBadge: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.bg,
  },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.2 },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14 },
  footer: { marginTop: spacing.lg },
});
