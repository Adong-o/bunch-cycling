import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { LoadingView } from '@/components/ui/LoadingView';
import { ChallengeCoverArt, CHALLENGE_COVERS } from '@/components/ChallengeCoverArt';
import { useAuthStore } from '@/state/authStore';
import { createChallenge, joinChallenge, myJoinedChallengeCount, CHALLENGES_REQUIRED_TO_UNLOCK_CREATE } from '@/lib/api/challenges';
import { getErrorMessage } from '@/lib/errors';
import { displayDistanceToMeters, displayElevationToMeters, distanceUnitLabel } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ChallengesScreenProps } from '@/navigation/types';
import type { ChallengeType, UnitSystem } from '@/lib/database.types';

const CHALLENGE_TYPES: Array<{ value: ChallengeType; label: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { value: 'distance', label: 'Distance', icon: 'navigate-outline' },
  { value: 'elevation', label: 'Elevation', icon: 'trending-up-outline' },
  { value: 'duration', label: 'Time', icon: 'time-outline' },
  { value: 'ride_count', label: 'Ride count', icon: 'bicycle-outline' },
];

const DURATION_PRESETS = [
  { label: '1 week', days: 7 },
  { label: '2 weeks', days: 14 },
  { label: '1 month', days: 30 },
  { label: '3 months', days: 90 },
];

function defaultGoalDisplay(t: ChallengeType, units: UnitSystem): number {
  if (t === 'distance') return units === 'imperial' ? 60 : 100;
  if (t === 'elevation') return units === 'imperial' ? 3000 : 1000;
  if (t === 'duration') return 10;
  return 10;
}

function goalUnitLabel(t: ChallengeType, units: UnitSystem): string {
  if (t === 'distance') return distanceUnitLabel(units);
  if (t === 'elevation') return units === 'imperial' ? 'ft' : 'm';
  if (t === 'duration') return 'hours';
  return 'rides';
}

export function CreateChallengeScreen({ navigation }: ChallengesScreenProps<'CreateChallenge'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [checkingGate, setCheckingGate] = useState(true);
  const [joinedCount, setJoinedCount] = useState(0);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<ChallengeType>('distance');
  const [goalInput, setGoalInput] = useState(() => String(defaultGoalDisplay('distance', units)));
  const [durationDays, setDurationDays] = useState(14);
  const [isPublic, setIsPublic] = useState(true);
  const [isOfficial, setIsOfficial] = useState(false);
  const [coverKey, setCoverKey] = useState(CHALLENGE_COVERS[0].key);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    if (profile.is_admin) {
      setCheckingGate(false);
      return;
    }
    myJoinedChallengeCount(profile.id)
      .then(setJoinedCount)
      .finally(() => setCheckingGate(false));
  }, [profile]);

  function onTypeChange(t: ChallengeType) {
    setType(t);
    setGoalInput(String(defaultGoalDisplay(t, units)));
  }

  function goalValueInBaseUnits(): number | null {
    const n = Number(goalInput);
    if (!Number.isFinite(n) || n <= 0) return null;
    if (type === 'distance') return Math.round(displayDistanceToMeters(n, units));
    if (type === 'elevation') return Math.round(displayElevationToMeters(n, units));
    if (type === 'duration') return Math.round(n * 3600);
    return Math.round(n);
  }

  async function onCreate() {
    if (!profile) return;
    setError(null);
    if (!title.trim()) {
      setError('Give your challenge a title.');
      return;
    }
    const goalValue = goalValueInBaseUnits();
    if (goalValue == null) {
      setError('Enter a valid goal.');
      return;
    }

    setSaving(true);
    const start = new Date();
    const end = new Date(start.getTime() + durationDays * 86400000);
    try {
      const created = await createChallenge({
        created_by: profile.id,
        is_official: profile.is_admin ? isOfficial : false,
        title: title.trim(),
        description: description.trim(),
        type,
        goal_value: goalValue,
        start_date: start.toISOString().slice(0, 10),
        end_date: end.toISOString().slice(0, 10),
        is_public: isPublic,
        cover_image_url: coverKey,
      });
      try {
        // The creator almost always wants to be a participant too — best
        // effort, since failing to auto-join shouldn't block the create.
        await joinChallenge(created.id, profile.id);
      } catch {
        // ignore
      }
      navigation.replace('ChallengeDetail', { challengeId: created.id });
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  if (checkingGate) return <LoadingView />;

  const eligible = profile?.is_admin || joinedCount >= CHALLENGES_REQUIRED_TO_UNLOCK_CREATE;

  if (!eligible) {
    return (
      <ScreenContainer>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
          <Text style={styles.headerTitle}>Create challenge</Text>
          <View style={{ width: 26 }} />
        </View>
        <EmptyState
          icon={<Ionicons name="lock-closed-outline" size={32} color={colors.textTertiary} />}
          title="Not yet unlocked"
          description={`Join ${CHALLENGES_REQUIRED_TO_UNLOCK_CREATE - joinedCount} more challenge${CHALLENGES_REQUIRED_TO_UNLOCK_CREATE - joinedCount === 1 ? '' : 's'} to unlock creating your own. You've joined ${joinedCount} of ${CHALLENGES_REQUIRED_TO_UNLOCK_CREATE}.`}
          actionLabel="Browse challenges"
          onAction={() => navigation.goBack()}
        />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer padded={false}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
          <Text style={styles.headerTitle}>Create challenge</Text>
          <View style={{ width: 26 }} />
        </View>

        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View>
            <Text style={styles.label}>Cover</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.coverRow}>
              {CHALLENGE_COVERS.map((c) => (
                <Pressable key={c.key} onPress={() => setCoverKey(c.key)} style={styles.coverOption}>
                  <ChallengeCoverArt coverKey={c.key} style={[styles.coverThumb, coverKey === c.key && styles.coverThumbActive]} />
                  {coverKey === c.key ? (
                    <View style={styles.coverCheck}>
                      <Ionicons name="checkmark-circle" size={18} color={colors.accent} />
                    </View>
                  ) : null}
                  <Text style={styles.coverLabel} numberOfLines={1}>
                    {c.label}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>

          <TextField label="Title" value={title} onChangeText={setTitle} placeholder="e.g. October Gravel Grind" />
          <TextField label="Description (optional)" value={description} onChangeText={setDescription} placeholder="What's this challenge about?" multiline numberOfLines={3} style={styles.descriptionInput} />

          <View>
            <Text style={styles.label}>Goal type</Text>
            <View style={styles.chipRow}>
              {CHALLENGE_TYPES.map((t) => (
                <Pressable key={t.value} onPress={() => onTypeChange(t.value)} style={[styles.chip, type === t.value && styles.chipActive]}>
                  <Ionicons name={t.icon} size={14} color={type === t.value ? colors.accent : colors.textSecondary} />
                  <Text style={[styles.chipLabel, type === t.value && styles.chipLabelActive]}>{t.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          <TextField
            label={`Goal (${goalUnitLabel(type, units)})`}
            value={goalInput}
            onChangeText={setGoalInput}
            keyboardType="numeric"
            placeholder={String(defaultGoalDisplay(type, units))}
          />

          <View>
            <Text style={styles.label}>Duration</Text>
            <View style={styles.chipRow}>
              {DURATION_PRESETS.map((p) => (
                <Pressable key={p.days} onPress={() => setDurationDays(p.days)} style={[styles.chip, durationDays === p.days && styles.chipActive]}>
                  <Text style={[styles.chipLabel, durationDays === p.days && styles.chipLabelActive]}>{p.label}</Text>
                </Pressable>
              ))}
            </View>
            <Text style={styles.hint}>Starts today.</Text>
          </View>

          <View>
            <Text style={styles.label}>Visibility</Text>
            <View style={styles.optionRow}>
              <Pressable onPress={() => setIsPublic(true)} style={[styles.option, isPublic && styles.optionActive]}>
                <Ionicons name="earth-outline" size={16} color={isPublic ? colors.accent : colors.textSecondary} />
                <Text style={[styles.optionLabel, isPublic && styles.optionLabelActive]}>Public</Text>
              </Pressable>
              <Pressable onPress={() => setIsPublic(false)} style={[styles.option, !isPublic && styles.optionActive]}>
                <Ionicons name="lock-closed-outline" size={16} color={!isPublic ? colors.accent : colors.textSecondary} />
                <Text style={[styles.optionLabel, !isPublic && styles.optionLabelActive]}>Private</Text>
              </Pressable>
            </View>
            <Text style={styles.hint}>{isPublic ? 'Listed in Discover for anyone to find and join.' : 'Hidden from Discover — joinable only with the invite code.'}</Text>
          </View>

          {profile?.is_admin ? (
            <Pressable onPress={() => setIsOfficial((v) => !v)} style={styles.officialRow}>
              <View style={[styles.checkbox, isOfficial && styles.checkboxActive]}>
                {isOfficial ? <Ionicons name="checkmark" size={14} color={colors.textOnAccent} /> : null}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.optionLabel}>Official Bunch challenge</Text>
                <Text style={styles.hint}>Shown with a gold "Official" badge in Discover, so riders know it came from the Bunch team.</Text>
              </View>
            </Pressable>
          ) : null}

          {error ? <Text style={styles.error}>{error}</Text> : null}
          <Button title="Create challenge" onPress={onCreate} loading={saving} style={{ marginTop: spacing.xs }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xxl, gap: spacing.md },
  descriptionInput: { minHeight: 64, textAlignVertical: 'top', paddingTop: 12 },
  coverRow: { flexDirection: 'row', gap: spacing.sm, paddingRight: spacing.md },
  coverOption: { width: 88, alignItems: 'center' },
  coverThumb: { width: 88, height: 62, borderRadius: radius.md, borderWidth: 2, borderColor: 'transparent' },
  coverThumbActive: { borderColor: colors.accent },
  coverCheck: { position: 'absolute', top: 4, right: 4 },
  coverLabel: { fontFamily: fonts.medium, fontSize: 11, color: colors.textSecondary, marginTop: 4, textAlign: 'center' },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.2 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  chipLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  chipLabelActive: { color: colors.accent, fontFamily: fonts.semiBold },
  hint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: spacing.xs, lineHeight: 16 },
  optionRow: { flexDirection: 'row', gap: spacing.sm },
  option: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  optionActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  optionLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  optionLabelActive: { color: colors.accent },
  officialRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm, backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, padding: spacing.sm },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: colors.borderStrong, alignItems: 'center', justifyContent: 'center', marginTop: 1 },
  checkboxActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 13 },
});
