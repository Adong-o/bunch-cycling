import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Card } from '@/components/ui/Card';
import { Pill } from '@/components/ui/Pill';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { ChallengeCoverArt, isChallengeCoverKey } from '@/components/ChallengeCoverArt';
import { useAuthStore } from '@/state/authStore';
import { listDiscoverChallenges, listMyChallenges, formatChallengeValue } from '@/lib/api/challenges';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ChallengesScreenProps } from '@/navigation/types';
import type { Challenge, ChallengeParticipant, ChallengeType, UnitSystem } from '@/lib/database.types';

const CHALLENGE_TYPE_ICON: Record<ChallengeType, keyof typeof Ionicons.glyphMap> = {
  distance: 'navigate-outline',
  elevation: 'trending-up-outline',
  duration: 'time-outline',
  ride_count: 'bicycle-outline',
};

export function ChallengesListScreen({ navigation }: ChallengesScreenProps<'ChallengesList'>) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [tab, setTab] = useState<'mine' | 'discover'>('mine');
  const [mine, setMine] = useState<Array<Challenge & { participant: ChallengeParticipant }>>([]);
  const [discover, setDiscover] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!profile) return;
    const [mineList, discoverList] = await Promise.all([listMyChallenges(profile.id), listDiscoverChallenges()]);
    setMine(mineList);
    setDiscover(discoverList);
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) return <LoadingView />;

  const myIds = new Set(mine.map((c) => c.id));
  // Normalized to a common shape (participant optional) so the FlatList
  // below has one concrete item type instead of inferring a union from the
  // ternary — mine's participant is always present, discover's never is.
  const data: Array<Challenge & { participant?: ChallengeParticipant }> = tab === 'mine' ? mine : discover;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Challenges</Text>
        <View style={styles.headerActions}>
          <Pressable onPress={() => navigation.navigate('JoinByCode')} hitSlop={10} style={styles.headerIcon}>
            <Ionicons name="key-outline" size={20} color={colors.textSecondary} />
          </Pressable>
          <Pressable onPress={() => navigation.navigate('CreateChallenge')} hitSlop={10} style={styles.headerIcon}>
            <Ionicons name="add-circle-outline" size={24} color={colors.accent} />
          </Pressable>
        </View>
      </View>

      <View style={styles.tabRow}>
        {(['mine', 'discover'] as const).map((t) => (
          <Pressable key={t} onPress={() => setTab(t)} style={[styles.tabOption, tab === t && styles.tabOptionActive]}>
            <Text style={[styles.tabLabel, tab === t && styles.tabLabelActive]}>{t === 'mine' ? 'Mine' : 'Discover'}</Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={data}
        keyExtractor={(c) => c.id}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        renderItem={({ item }) => (
          <ChallengeRow
            challenge={item}
            units={units}
            participant={item.participant}
            joined={myIds.has(item.id)}
            onPress={() => navigation.navigate('ChallengeDetail', { challengeId: item.id })}
          />
        )}
        ListEmptyComponent={
          <EmptyState
            icon={<Ionicons name="trophy-outline" size={32} color={colors.textTertiary} />}
            title={tab === 'mine' ? "You haven't joined any challenges" : 'No challenges to discover right now'}
            description={
              tab === 'mine'
                ? "Switch to Discover to find one, or join with a friend's invite code."
                : "Check back soon, or create your own once you've joined a couple."
            }
          />
        }
      />
    </ScreenContainer>
  );
}

function ChallengeRow({
  challenge,
  units,
  participant,
  joined,
  onPress,
}: {
  challenge: Challenge;
  units: UnitSystem;
  participant?: ChallengeParticipant;
  joined: boolean;
  onPress: () => void;
}) {
  const progressPct = participant ? participant.current_progress / challenge.goal_value : 0;
  return (
    <Pressable onPress={onPress}>
      <Card style={styles.row}>
        <View style={styles.rowTop}>
          {isChallengeCoverKey(challenge.cover_image_url) ? (
            <ChallengeCoverArt coverKey={challenge.cover_image_url} style={styles.rowIcon} />
          ) : (
            <View style={styles.rowIcon}>
              <Ionicons name={CHALLENGE_TYPE_ICON[challenge.type]} size={18} color={colors.accent} />
            </View>
          )}
          <View style={{ flex: 1 }}>
            <View style={styles.titleRow}>
              <Text style={styles.rowTitle} numberOfLines={1}>
                {challenge.title}
              </Text>
              {challenge.is_official ? <Pill label="Official" tone="gold" /> : null}
            </View>
            <Text style={styles.rowMeta}>
              {formatChallengeValue(challenge.type, challenge.goal_value, units)} · ends {format(new Date(challenge.end_date), 'MMM d')}
            </Text>
          </View>
        </View>

        {participant ? (
          <View style={styles.progressWrap}>
            <ProgressBar progress={progressPct} color={participant.completed_at ? colors.success : colors.accent} />
            <Text style={styles.progressText}>
              {participant.completed_at
                ? 'Completed 🎉'
                : `${formatChallengeValue(challenge.type, participant.current_progress, units)} of ${formatChallengeValue(challenge.type, challenge.goal_value, units)}`}
            </Text>
          </View>
        ) : joined ? (
          <Pill label="Joined" tone="accent" />
        ) : null}
      </Card>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h2, color: colors.textPrimary },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  headerIcon: { padding: 2 },
  tabRow: { flexDirection: 'row', gap: spacing.sm, paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
  tabOption: { flex: 1, paddingVertical: 10, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, alignItems: 'center' },
  tabOptionActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  tabLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  tabLabelActive: { color: colors.accent },
  listContent: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  row: { gap: spacing.sm },
  rowTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowIcon: { width: 38, height: 38, borderRadius: radius.sm, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  rowTitle: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary, flexShrink: 1 },
  rowMeta: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  progressWrap: { gap: 6 },
  progressText: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
});
