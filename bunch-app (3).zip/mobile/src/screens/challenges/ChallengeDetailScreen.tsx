import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, Share, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { format } from 'date-fns';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Pill } from '@/components/ui/Pill';
import { Avatar } from '@/components/ui/Avatar';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { LoadingView } from '@/components/ui/LoadingView';
import { EmptyState } from '@/components/ui/EmptyState';
import { ChallengeCoverArt, isChallengeCoverKey } from '@/components/ChallengeCoverArt';
import { useAuthStore } from '@/state/authStore';
import { getChallenge, getChallengeLeaderboard, myParticipation, joinChallenge, leaveChallenge, formatChallengeValue, challengeTypeLabel } from '@/lib/api/challenges';
import { getErrorMessage } from '@/lib/errors';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { ChallengesScreenProps } from '@/navigation/types';
import type { Challenge, ChallengeLeaderboardRow, ChallengeParticipant, ChallengeType } from '@/lib/database.types';

const CHALLENGE_TYPE_ICON: Record<ChallengeType, keyof typeof Ionicons.glyphMap> = {
  distance: 'navigate-outline',
  elevation: 'trending-up-outline',
  duration: 'time-outline',
  ride_count: 'bicycle-outline',
};

export function ChallengeDetailScreen({ navigation, route }: ChallengesScreenProps<'ChallengeDetail'>) {
  const { challengeId } = route.params;
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [leaderboard, setLeaderboard] = useState<ChallengeLeaderboardRow[]>([]);
  const [participation, setParticipation] = useState<ChallengeParticipant | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      const c = await getChallenge(challengeId);
      if (!c) {
        setNotFound(true);
        return;
      }
      const [board, mine] = await Promise.all([getChallengeLeaderboard(challengeId), myParticipation(challengeId, profile.id)]);
      setChallenge(c);
      setLeaderboard(board);
      setParticipation(mine);
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }, [challengeId, profile]);

  useEffect(() => {
    load();
  }, [load]);

  async function onJoin() {
    if (!profile || !challenge) return;
    setBusy(true);
    try {
      await joinChallenge(challenge.id, profile.id);
      await load();
    } catch (e) {
      Alert.alert('Could not join challenge', getErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  function onLeave() {
    if (!challenge) return;
    Alert.alert('Leave this challenge?', 'Your progress on it will be removed. You can rejoin later.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Leave',
        style: 'destructive',
        onPress: async () => {
          if (!profile) return;
          setBusy(true);
          try {
            await leaveChallenge(challenge.id, profile.id);
            await load();
          } catch (e) {
            Alert.alert('Could not leave challenge', getErrorMessage(e));
          } finally {
            setBusy(false);
          }
        },
      },
    ]);
  }

  async function onShare() {
    if (!challenge) return;
    const link = Linking.createURL(`challenge/${challenge.invite_code}`);
    try {
      await Share.share({
        message: `Join me on Bunch — "${challenge.title}". Tap to join: ${link}\n\nOr open Bunch and enter code ${challenge.invite_code} under Challenges → Join by code.`,
      });
    } catch {
      // Share sheet dismissed or unavailable — nothing to recover from.
    }
  }

  if (loading) return <LoadingView />;

  if (notFound || !challenge) {
    return (
      <ScreenContainer>
        <View style={styles.backRow}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
            <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
          </Pressable>
        </View>
        <EmptyState icon={<Ionicons name="help-circle-outline" size={32} color={colors.textTertiary} />} title="Challenge not found" description="This challenge may have ended or been removed." />
      </ScreenContainer>
    );
  }

  const canSeeInviteCode = profile?.id === challenge.created_by || profile?.is_admin;
  // Any participant can invite a friend to a challenge they're already in —
  // not just the person who created it — since that's the normal way a
  // private challenge actually spreads. The raw code card further down
  // stays creator/admin-only so it's not cluttering every participant's view.
  const canShare = canSeeInviteCode || participation != null;
  const progressPct = participation ? participation.current_progress / challenge.goal_value : 0;

  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        {canShare ? (
          <Pressable onPress={onShare} hitSlop={10} style={styles.headerIcon}>
            <Ionicons name="share-outline" size={20} color={colors.textSecondary} />
          </Pressable>
        ) : (
          <View style={{ width: 26 }} />
        )}
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        {isChallengeCoverKey(challenge.cover_image_url) ? (
          <ChallengeCoverArt coverKey={challenge.cover_image_url} style={styles.cover} />
        ) : challenge.cover_image_url ? (
          <Image source={{ uri: challenge.cover_image_url }} style={styles.cover} />
        ) : (
          <View style={styles.coverFallback}>
            <Ionicons name={CHALLENGE_TYPE_ICON[challenge.type]} size={44} color={colors.accent} />
          </View>
        )}

        <View style={styles.body}>
          <View style={styles.titleRow}>
            <Text style={styles.title}>{challenge.title}</Text>
            {challenge.is_official ? <Pill label="Official" tone="gold" /> : null}
          </View>

          {challenge.description ? <Text style={styles.description}>{challenge.description}</Text> : null}

          <View style={styles.metaCard}>
            <View style={styles.metaRow}>
              <Ionicons name={CHALLENGE_TYPE_ICON[challenge.type]} size={16} color={colors.textSecondary} />
              <Text style={styles.metaText}>
                {challengeTypeLabel(challenge.type)} · goal {formatChallengeValue(challenge.type, challenge.goal_value, units)}
              </Text>
            </View>
            <View style={styles.metaRow}>
              <Ionicons name="calendar-outline" size={16} color={colors.textSecondary} />
              <Text style={styles.metaText}>
                {format(new Date(challenge.start_date), 'MMM d')} – {format(new Date(challenge.end_date), 'MMM d, yyyy')}
              </Text>
            </View>
            <View style={styles.metaRow}>
              <Ionicons name={challenge.is_public ? 'earth-outline' : 'lock-closed-outline'} size={16} color={colors.textSecondary} />
              <Text style={styles.metaText}>{challenge.is_public ? 'Public — listed for anyone to discover' : 'Private — invite code only'}</Text>
            </View>
          </View>

          {participation ? (
            <View style={styles.progressCard}>
              <Text style={styles.sectionLabel}>YOUR PROGRESS</Text>
              <ProgressBar progress={progressPct} color={participation.completed_at ? colors.success : colors.accent} height={10} />
              <Text style={styles.progressText}>
                {formatChallengeValue(challenge.type, participation.current_progress, units)} of {formatChallengeValue(challenge.type, challenge.goal_value, units)}
                {participation.completed_at ? ' — completed 🎉' : ''}
              </Text>
              <Button title="Leave challenge" variant="ghost" onPress={onLeave} loading={busy} style={{ marginTop: spacing.xs }} />
            </View>
          ) : (
            <Button title="Join challenge" onPress={onJoin} loading={busy} />
          )}

          {canSeeInviteCode ? (
            <View style={styles.inviteCard}>
              <Text style={styles.sectionLabel}>INVITE CODE</Text>
              <Text selectable style={styles.inviteCode}>
                {challenge.invite_code}
              </Text>
              <Text style={styles.inviteHint}>Share this so riders can join from "Join by code," even if the challenge is private.</Text>
            </View>
          ) : null}

          <View style={styles.leaderboardSection}>
            <Text style={styles.sectionLabel}>LEADERBOARD</Text>
            {leaderboard.length === 0 ? (
              <Text style={styles.noEntries}>No one has joined yet. Be the first.</Text>
            ) : (
              <View style={styles.leaderboardList}>
                {leaderboard.map((row) => (
                  <View key={row.user_id} style={[styles.leaderboardRow, row.user_id === profile?.id && styles.leaderboardRowMe]}>
                    <Text style={styles.rank}>{row.rank}</Text>
                    <Avatar uri={row.avatar_url} name={row.display_name} size={32} />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.leaderboardName} numberOfLines={1}>
                        {row.display_name}
                        {row.user_id === profile?.id ? ' (you)' : ''}
                      </Text>
                      <Text style={styles.leaderboardProgress}>{formatChallengeValue(challenge.type, row.current_progress, units)}</Text>
                    </View>
                    {row.completed_at ? <Ionicons name="checkmark-circle" size={18} color={colors.success} /> : null}
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  backRow: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerIcon: { padding: 2 },
  scroll: { paddingBottom: spacing.xxl },
  cover: { height: 180, marginHorizontal: spacing.md, marginTop: spacing.xs, borderRadius: radius.lg, backgroundColor: colors.surfaceHigh },
  coverFallback: {
    height: 140,
    marginHorizontal: spacing.md,
    marginTop: spacing.xs,
    borderRadius: radius.lg,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { paddingHorizontal: spacing.md, gap: spacing.md, marginTop: spacing.sm },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, flexWrap: 'wrap' },
  title: { ...typeTokens.h2, color: colors.textPrimary },
  description: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 20, color: colors.textSecondary },
  metaCard: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: spacing.sm },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  metaText: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary, flex: 1 },
  progressCard: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: spacing.xs },
  sectionLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary, letterSpacing: 0.4 },
  progressText: { fontFamily: fonts.medium, fontSize: 13, color: colors.textPrimary, marginTop: 2 },
  inviteCard: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: 4, alignItems: 'center' },
  inviteCode: { fontFamily: fonts.mono, fontSize: 26, letterSpacing: 4, color: colors.accent, marginVertical: 4 },
  inviteHint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center' },
  leaderboardSection: { gap: spacing.sm },
  noEntries: { fontFamily: fonts.regular, fontSize: 14, color: colors.textTertiary, lineHeight: 20 },
  leaderboardList: { gap: 2 },
  leaderboardRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.xs, paddingHorizontal: spacing.xs, borderRadius: radius.sm },
  leaderboardRowMe: { backgroundColor: colors.accentMuted },
  rank: { fontFamily: fonts.bold, fontSize: 14, color: colors.textTertiary, width: 22, textAlign: 'center' },
  leaderboardName: { fontFamily: fonts.medium, fontSize: 14, color: colors.textPrimary },
  leaderboardProgress: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 1 },
});
