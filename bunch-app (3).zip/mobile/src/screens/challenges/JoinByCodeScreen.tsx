import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/state/authStore';
import { getChallengeByInviteCode, joinChallenge, myParticipation } from '@/lib/api/challenges';
import { getErrorMessage } from '@/lib/errors';
import { colors, fonts, spacing, type as typeTokens } from '@/theme';
import type { ChallengesScreenProps } from '@/navigation/types';

export function JoinByCodeScreen({ navigation, route }: ChallengesScreenProps<'JoinByCode'>) {
  const profile = useAuthStore((s) => s.profile);
  const [code, setCode] = useState(route.params?.code?.toUpperCase() ?? '');
  const [joining, setJoining] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onJoin(codeOverride?: string) {
    const target = (codeOverride ?? code).trim();
    if (!profile || !target) return;
    setJoining(true);
    setError(null);
    try {
      const challenge = await getChallengeByInviteCode(target);
      if (!challenge) {
        setError("That code doesn't match any challenge. Double-check it with whoever shared it.");
        return;
      }
      // Already in it (e.g. tapped a code they joined earlier) — just open
      // it instead of letting the unique-participant constraint error out.
      const existing = await myParticipation(challenge.id, profile.id);
      if (!existing) {
        await joinChallenge(challenge.id, profile.id);
      }
      navigation.replace('ChallengeDetail', { challengeId: challenge.id });
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setJoining(false);
    }
  }

  // Arrived via a shared bunch://challenge/:code link — don't make them
  // retype what they just tapped.
  useEffect(() => {
    if (route.params?.code && profile) onJoin(route.params.code);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route.params?.code, profile?.id]);

  return (
    <ScreenContainer>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>Join by code</Text>
        <View style={{ width: 26 }} />
      </View>

      <View style={styles.body}>
        <Ionicons name="key-outline" size={32} color={colors.accent} style={styles.icon} />
        <Text style={styles.subtitle}>Enter the invite code a friend shared with you to join their challenge.</Text>
        <TextField
          value={code}
          onChangeText={(v) => setCode(v.toUpperCase())}
          placeholder="e.g. 7F3KXQ2"
          autoCapitalize="characters"
          autoCorrect={false}
          maxLength={12}
          style={styles.codeInput}
          error={error ?? undefined}
          onSubmitEditing={() => onJoin()}
          returnKeyType="go"
        />
        <Button title="Join challenge" onPress={() => onJoin()} loading={joining} disabled={!code.trim()} />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: spacing.sm },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  body: { flex: 1, justifyContent: 'center', gap: spacing.md, paddingBottom: spacing.xxl },
  icon: { alignSelf: 'center', marginBottom: spacing.xs },
  subtitle: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center', lineHeight: 20 },
  codeInput: { textAlign: 'center', letterSpacing: 3, fontFamily: fonts.mono, fontSize: 18 },
});
