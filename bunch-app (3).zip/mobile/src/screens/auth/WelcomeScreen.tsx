import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { Button } from '@/components/ui/Button';
import { GravelBikeIllustration } from '@/components/GravelBikeIllustration';
import { colors, fonts, spacing } from '@/theme';
import type { AuthScreenProps } from '@/navigation/types';

// Staggered after the bike illustration's own ~700–900ms draw-on animation,
// so the whole screen reads as one choreographed reveal rather than "the SVG
// animates, everything else just appears."
export function WelcomeScreen({ navigation }: AuthScreenProps<'Welcome'>) {
  return (
    <ScreenContainer edges={['top', 'bottom']}>
      <View style={styles.illustrationWrap}>
        <GravelBikeIllustration width={300} />
      </View>

      <View style={styles.content}>
        <Animated.View entering={FadeInDown.delay(480).duration(520).springify().damping(18)}>
          <Image source={require('../../../assets/wordmark_dark.png')} style={styles.wordmark} resizeMode="contain" />
        </Animated.View>

        <Animated.Text entering={FadeInDown.delay(580).duration(520).springify().damping(18)} style={styles.tagline}>
          Made for every cyclist — from your first ride to your fastest.
        </Animated.Text>

        <Animated.View entering={FadeInDown.delay(700).duration(520).springify().damping(18)} style={styles.actions}>
          <Button title="Get started" onPress={() => navigation.navigate('Auth', { initialTab: 'signup' })} />
          <Button
            title="I already have an account"
            variant="ghost"
            onPress={() => navigation.navigate('Auth', { initialTab: 'signin' })}
          />
        </Animated.View>

        <Animated.Text entering={FadeIn.delay(950).duration(450)} style={styles.legalText}>
          By continuing, you agree to our{' '}
          <Text style={styles.legalLink} onPress={() => navigation.navigate('Terms')}>
            Terms
          </Text>{' '}
          and{' '}
          <Text style={styles.legalLink} onPress={() => navigation.navigate('PrivacyPolicy')}>
            Privacy Policy
          </Text>
          .
        </Animated.Text>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  illustrationWrap: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { paddingBottom: spacing.lg, gap: spacing.lg },
  // Real Bunch lockup (mark + wordmark), 4.25:1.
  wordmark: { width: 212, height: 50, alignSelf: 'center' },
  tagline: {
    fontFamily: fonts.medium,
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.lg,
  },
  actions: { gap: spacing.sm },
  legalText: {
    fontFamily: fonts.regular,
    fontSize: 12,
    color: colors.textTertiary,
    textAlign: 'center',
    paddingHorizontal: spacing.xl,
    lineHeight: 17,
  },
  legalLink: { fontFamily: fonts.semiBold, color: colors.textSecondary },
});
