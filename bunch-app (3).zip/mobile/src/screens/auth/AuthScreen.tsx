import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, SlideInLeft, SlideInRight, SlideOutLeft, SlideOutRight } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { SegmentedToggle } from '@/components/ui/SegmentedToggle';
import { supabase } from '@/lib/supabase';
import { signInWithGoogle } from '@/lib/googleAuth';
import { getErrorMessage } from '@/lib/errors';
import { PREMIUM_MONTHLY_PRICE } from '@/lib/pricing';
import { colors, fonts, spacing, type } from '@/theme';
import type { AuthScreenProps } from '@/navigation/types';

type AuthTab = 'signin' | 'signup';

const TAB_OPTIONS: Array<{ value: AuthTab; label: string }> = [
  { value: 'signin', label: 'Sign in' },
  { value: 'signup', label: 'Create account' },
];

/**
 * Sign-in and sign-up used to be two separate screens that happened to look
 * almost identical — same fields, same shape, reached by a "switch" link
 * that actually pushed a whole new screen. This merges them into one: a
 * segmented tab picks the mode, the two forms live side by side on a strip
 * and slide past each other when the tab changes (sign-up lives to the
 * right of sign-in, so switching right slides new content in from the
 * right and the old content out to the left, and vice versa — see the
 * fixed entering/exiting pairs below), and "Continue with Google" sits
 * above both since it does the same thing regardless of which tab is open.
 */
export function AuthScreen({ navigation, route }: AuthScreenProps<'Auth'>) {
  const [tab, setTab] = useState<AuthTab>(route.params?.initialTab ?? 'signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checkEmail, setCheckEmail] = useState(false);
  const [sentTo, setSentTo] = useState('');

  function onChangeTab(t: AuthTab) {
    setTab(t);
    setError(null);
  }

  async function onGoogle() {
    setError(null);
    setGoogleLoading(true);
    try {
      await signInWithGoogle();
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setGoogleLoading(false);
    }
  }

  async function onSubmit() {
    setError(null);

    if (tab === 'signin') {
      if (!email.trim() || !password) {
        setError('Enter your email and password.');
        return;
      }
      setSubmitting(true);
      const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      setSubmitting(false);
      if (signInError) setError(getErrorMessage(signInError));
      // On success, the auth store's onAuthStateChange listener takes it from here.
      return;
    }

    if (!email.trim() || password.length < 6) {
      setError('Enter a valid email and a password of at least 6 characters.');
      return;
    }
    setSubmitting(true);
    const { data, error: signUpError } = await supabase.auth.signUp({ email: email.trim(), password });
    setSubmitting(false);
    if (signUpError) {
      setError(getErrorMessage(signUpError));
      return;
    }
    // If the project requires email confirmation, there's no session yet —
    // tell the rider to check their inbox. Otherwise the auth store's
    // listener picks up the new session automatically and moves on.
    if (!data.session) {
      setSentTo(email.trim());
      setCheckEmail(true);
    }
  }

  if (checkEmail) {
    return (
      <ScreenContainer style={styles.centered}>
        <Animated.View entering={FadeIn.duration(400)} style={styles.checkEmailBadge}>
          <Ionicons name="mail-outline" size={30} color={colors.accent} />
        </Animated.View>
        <Animated.Text entering={FadeInDown.delay(80).duration(420)} style={styles.title}>
          Check your email
        </Animated.Text>
        <Animated.Text entering={FadeInDown.delay(160).duration(420)} style={styles.subtitle}>
          We sent a confirmation link to {sentTo}. Tap it, then come back and sign in.
        </Animated.Text>
        <Button
          title="Back to sign in"
          onPress={() => {
            setCheckEmail(false);
            setTab('signin');
          }}
          style={{ marginTop: spacing.lg }}
        />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer padded={false}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <Animated.View entering={FadeIn.duration(380)}>
            <Button
              title="Continue with Google"
              variant="secondary"
              onPress={onGoogle}
              loading={googleLoading}
              icon={<Ionicons name="logo-google" size={18} color={colors.textPrimary} />}
            />
          </Animated.View>

          <Animated.View entering={FadeIn.delay(60).duration(380)} style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </Animated.View>

          <Animated.View entering={FadeIn.delay(100).duration(380)}>
            <SegmentedToggle options={TAB_OPTIONS} value={tab} onChange={onChangeTab} />
          </Animated.View>

          {tab === 'signin' ? (
            <Animated.View key="signin" entering={SlideInLeft.duration(300)} exiting={SlideOutLeft.duration(200)} style={styles.form}>
              <Text style={styles.formHint}>Sign in to keep your streak alive.</Text>
              <TextField
                label="Email"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                autoComplete="email"
                placeholder="you@example.com"
              />
              <TextField
                label="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                autoComplete="password"
                placeholder="••••••••"
              />
              {error ? <Text style={styles.error}>{error}</Text> : null}
              <Button title="Sign in" onPress={onSubmit} loading={submitting} style={{ marginTop: spacing.xs }} />
            </Animated.View>
          ) : (
            <Animated.View key="signup" entering={SlideInRight.duration(300)} exiting={SlideOutRight.duration(200)} style={styles.form}>
              <Text style={styles.formHint}>Free forever for the basics. {PREMIUM_MONTHLY_PRICE}/mo unlocks the rest.</Text>
              <TextField
                label="Email"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                autoComplete="email"
                placeholder="you@example.com"
              />
              <TextField
                label="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                autoComplete="password-new"
                placeholder="At least 6 characters"
              />
              {error ? <Text style={styles.error}>{error}</Text> : null}
              <Button title="Create account" onPress={onSubmit} loading={submitting} style={{ marginTop: spacing.xs }} />

              <Text style={styles.legalText}>
                By creating an account, you agree to our{' '}
                <Text style={styles.legalLink} onPress={() => navigation.navigate('Terms')}>
                  Terms
                </Text>{' '}
                and{' '}
                <Text style={styles.legalLink} onPress={() => navigation.navigate('PrivacyPolicy')}>
                  Privacy Policy
                </Text>
                .
              </Text>
            </Animated.View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 20, paddingVertical: spacing.xl, gap: spacing.md },
  divider: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  dividerLine: { flex: 1, height: 1, backgroundColor: colors.border },
  dividerText: { fontFamily: fonts.medium, fontSize: 12, color: colors.textTertiary },
  form: { gap: spacing.md },
  formHint: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14 },
  legalText: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, textAlign: 'center', lineHeight: 17, marginTop: 2 },
  legalLink: { fontFamily: fonts.semiBold, color: colors.textSecondary },
  centered: { alignItems: 'center', justifyContent: 'center', gap: spacing.sm },
  title: { ...type.h1, color: colors.textPrimary, textAlign: 'center' },
  subtitle: { ...type.body, color: colors.textSecondary, textAlign: 'center' },
  checkEmailBadge: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
});
