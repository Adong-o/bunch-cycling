import { buildSpeedSamples } from '@/components/ride/speedSamples';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import NetInfo from '@react-native-community/netinfo';
import { Ionicons } from '@expo/vector-icons';
import { RideMap } from '@/components/RideMap';
import { RideShareModal } from '@/components/RideShareModal';
import { TagRidersModal } from '@/components/TagRidersModal';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { StatBlock } from '@/components/ui/StatBlock';
import { useAuthStore } from '@/state/authStore';
import { getErrorMessage } from '@/lib/errors';
import { listBikes } from '@/lib/api/bikes';
import { uploadImage } from '@/lib/api/storage';
import { saveRideWithFollowUps } from '@/lib/saveRide';
import { recordingEngine } from '@/lib/recording/engine';
import { queueRideForUpload } from '@/lib/rideOutbox';
import { boundingBox, geoJSONToCoordinates } from '@/lib/geo';
import { reverseGeocodeStart } from '@/lib/geocode';
import { formatDistance, formatDuration, formatElevation, formatSpeed } from '@/lib/units';
import { colors, fonts, radius, spacing } from '@/theme';
import type { RecordScreenProps } from '@/navigation/types';
import type { Bike, Profile, Ride, RideVisibility, RouteGeoJSON, TablesInsert } from '@/lib/database.types';

const MAX_PHOTOS = 4;

function defaultRideTitle(startedAtIso: string): string {
  const hour = new Date(startedAtIso).getHours();
  if (hour < 12) return 'Morning Ride';
  if (hour < 17) return 'Afternoon Ride';
  if (hour < 21) return 'Evening Ride';
  return 'Night Ride';
}

/** Speed profile for the Ride detail ▸ Speed tab — null (never a made-up line)
 * when the track has too little speed data or can't be parsed. */
function safeSpeedSamples(trackJSON: string) {
  try {
    return buildSpeedSamples(JSON.parse(trackJSON));
  } catch {
    return null;
  }
}

export function RideSummaryScreen({ navigation, route }: RecordScreenProps<'RideSummary'>) {
  const params = route.params;
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const routeGeoJSON = useMemo(() => JSON.parse(params.routeGeoJSON) as RouteGeoJSON, [params.routeGeoJSON]);
  const bounds = useMemo(() => boundingBox(routeGeoJSON), [routeGeoJSON]);
  const routeCoordinates = useMemo(() => geoJSONToCoordinates(routeGeoJSON), [routeGeoJSON]);

  const [title, setTitle] = useState(defaultRideTitle(params.startedAt));
  const [description, setDescription] = useState('');
  const [visibility, setVisibility] = useState<RideVisibility>('public');
  const [bikes, setBikes] = useState<Bike[]>([]);
  const [selectedBikeId, setSelectedBikeId] = useState<string | null>(null);
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [taggedRiders, setTaggedRiders] = useState<Profile[]>([]);
  const [tagModalOpen, setTagModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shareRide, setShareRide] = useState<Ride | null>(null);

  function goHome() {
    navigation.popToTop();
    navigation.navigate('HomeTab');
  }

  useEffect(() => {
    if (!profile) return;
    listBikes(profile.id)
      .then((list) => setBikes(list.filter((b) => !b.is_retired)))
      .catch(() => {
        /* non-critical — the bike picker just stays empty */
      });
  }, [profile]);

  async function onAddPhotos() {
    if (!profile || photoUrls.length >= MAX_PHOTOS) return;
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Allow photo access to add a photo to this ride.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
      allowsMultipleSelection: true,
      selectionLimit: MAX_PHOTOS - photoUrls.length,
    });
    if (result.canceled) return;

    setUploadingPhoto(true);
    setError(null);
    try {
      for (const asset of result.assets) {
        const url = await uploadImage('ride-photos', profile.id, asset.uri);
        setPhotoUrls((prev) => [...prev, url]);
      }
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setUploadingPhoto(false);
    }
  }

  function removePhoto(url: string) {
    setPhotoUrls((prev) => prev.filter((u) => u !== url));
  }

  function onDiscard() {
    Alert.alert('Discard this ride?', "The route and stats you just recorded won't be saved. This can't be undone.", [
      { text: 'Keep editing', style: 'cancel' },
      {
        text: 'Discard',
        style: 'destructive',
        onPress: () => {
          void recordingEngine.clearFinished();
          navigation.popToTop();
        },
      },
    ]);
  }

  async function onSave() {
    if (!profile) return;
    setSaving(true);
    setError(null);

    const firstPoint = routeGeoJSON.coordinates[0];
    const lastPoint = routeGeoJSON.coordinates[routeGeoJSON.coordinates.length - 1];

    // Best-effort and purely cosmetic — reverseGeocodeStart() already
    // swallows its own errors and resolves to null (including offline), so
    // this never blocks or fails the save.
    const startLocationName = firstPoint ? await reverseGeocodeStart(firstPoint[1], firstPoint[0]).catch(() => null) : null;

    const payload: TablesInsert<'rides'> = {
      user_id: profile.id,
      bike_id: selectedBikeId,
      route_id: params.routeId ?? null,
      title: title.trim() || defaultRideTitle(params.startedAt),
      description: description.trim(),
      visibility,
      source: 'gps',
      is_indoor: false,
      started_at: params.startedAt,
      ended_at: params.endedAt,
      moving_time_s: params.movingTimeS,
      elapsed_time_s: params.elapsedTimeS,
      distance_m: params.distanceM,
      elevation_gain_m: params.elevationGainM,
      elevation_loss_m: params.elevationLossM,
      avg_speed_mps: params.avgSpeedMps,
      max_speed_mps: params.maxSpeedMps,
      start_lat: firstPoint?.[1] ?? null,
      start_lng: firstPoint?.[0] ?? null,
      end_lat: lastPoint?.[1] ?? null,
      end_lng: lastPoint?.[0] ?? null,
      route_geojson: routeGeoJSON,
      photo_urls: photoUrls,
      start_location_name: startLocationName,
      speed_samples: safeSpeedSamples(params.trackJSON),
    };

    const taggedRiderIds = taggedRiders.map((r) => r.id);

    // Known offline up front — go straight to queueing instead of waiting
    // out a request that can only time out.
    const netState = await NetInfo.fetch().catch(() => null);
    if (netState != null && netState.isConnected === false) {
      await queueOffline(payload, taggedRiderIds);
      return;
    }

    try {
      const result = await saveRideWithFollowUps(profile, payload, params.trackJSON, taggedRiderIds);
      // Saved for real — only now is it safe to let go of the on-disk recording.
      void recordingEngine.clearFinished();
      presentSaveResult(result);
    } catch (e) {
      // Either a real error, or a connection that looked reachable but
      // wasn't (wifi with no internet, a mid-ride dead zone that hasn't
      // cleared yet). Either way a recorded ride must never just vanish —
      // fall back to the same local queue the known-offline path uses
      // rather than leaving the rider at a dead end.
      console.warn('[RideSummaryScreen] online save failed, queueing for later:', e);
      await queueOffline(payload, taggedRiderIds);
    }
  }

  async function queueOffline(payload: TablesInsert<'rides'>, taggedRiderIds: string[]) {
    try {
      await queueRideForUpload(payload, params.trackJSON, taggedRiderIds);
      void recordingEngine.clearFinished(); // safely queued in the outbox
      setSaving(false);
      Alert.alert(
        'Saved on your phone',
        "No connection right now, so this ride is saved on your phone and will finish uploading to Bunch automatically once you're back online.",
        [{ text: 'OK', onPress: () => goHome() }]
      );
    } catch (e) {
      // The one failure left with no safety net under it: the local queue
      // write itself failed (e.g. device storage full).
      setError(getErrorMessage(e));
      setSaving(false);
    }
  }

  function presentSaveResult(result: Awaited<ReturnType<typeof saveRideWithFollowUps>>) {
    setSaving(false);
    const { ride, newBadgeNames, newPRs } = result;

    const sections: string[] = [];
    if (newBadgeNames.length > 0) sections.push(newBadgeNames.join(', '));
    if (newPRs.length > 0) {
      sections.push(
        newPRs
          .map((pr) => {
            const timeStr = formatDuration(pr.elapsedS, 'long');
            if (pr.previousBestS == null) return `${pr.segmentName} — first time, ${timeStr}`;
            const improvementStr = formatDuration(pr.previousBestS - pr.elapsedS, 'long');
            return `${pr.segmentName} — ${timeStr} (${improvementStr} faster)`;
          })
          .join('\n')
      );
    }

    if (sections.length > 0) {
      const alertTitle =
        newBadgeNames.length > 0 && newPRs.length > 0
          ? 'Nice ride!'
          : newBadgeNames.length > 0
            ? newBadgeNames.length === 1
              ? 'New badge earned!'
              : `${newBadgeNames.length} new badges earned!`
            : newPRs.length === 1
              ? 'New personal record!'
              : `${newPRs.length} new personal records!`;
      Alert.alert(alertTitle, sections.join('\n\n'), [{ text: 'Nice!', onPress: () => setShareRide(ride) }]);
    } else {
      setShareRide(ride);
    }
  }

  return (
    <ScreenContainer padded={false}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <Pressable onPress={onDiscard} hitSlop={10}>
              <Text style={styles.discardText}>Discard</Text>
            </Pressable>
            <Text style={styles.headerTitle}>Save ride</Text>
            <View style={{ width: 56 }} />
          </View>

          <RideMap routeCoordinates={routeCoordinates} bounds={bounds} expandable expandTitle="Your ride" style={styles.map} />

          <View style={styles.statsCard}>
            <View style={styles.statsRow}>
              <StatBlock label="DISTANCE" value={formatDistance(params.distanceM, units)} size="lg" />
              <StatBlock label="MOVING TIME" value={formatDuration(params.movingTimeS, 'long')} size="lg" />
            </View>
            <View style={styles.statsDivider} />
            <View style={styles.statsRow}>
              <StatBlock label="ELEVATION" value={formatElevation(params.elevationGainM, units)} />
              <StatBlock label="AVG SPEED" value={formatSpeed(params.avgSpeedMps, units)} />
              <StatBlock label="MAX SPEED" value={formatSpeed(params.maxSpeedMps, units)} />
            </View>
          </View>

          <View style={styles.form}>
            <TextField label="Title" value={title} onChangeText={setTitle} placeholder={defaultRideTitle(params.startedAt)} />
            <TextField
              label="Description (optional)"
              value={description}
              onChangeText={setDescription}
              placeholder="How was it?"
              multiline
              numberOfLines={3}
              style={styles.descriptionInput}
            />

            {bikes.length > 0 ? (
              <View>
                <Text style={styles.label}>Bike</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
                  <Pressable onPress={() => setSelectedBikeId(null)} style={[styles.chip, selectedBikeId === null && styles.chipActive]}>
                    <Text style={[styles.chipLabel, selectedBikeId === null && styles.chipLabelActive]}>None</Text>
                  </Pressable>
                  {bikes.map((bike) => (
                    <Pressable
                      key={bike.id}
                      onPress={() => setSelectedBikeId(bike.id)}
                      style={[styles.chip, selectedBikeId === bike.id && styles.chipActive]}
                    >
                      <Text style={[styles.chipLabel, selectedBikeId === bike.id && styles.chipLabelActive]}>{bike.name}</Text>
                    </Pressable>
                  ))}
                </ScrollView>
              </View>
            ) : null}

            <View>
              <Text style={styles.label}>Who can see this</Text>
              <View style={styles.visibilityRow}>
                {(
                  [
                    { value: 'public', label: 'Everyone', icon: 'earth-outline' },
                    { value: 'followers', label: 'Followers', icon: 'people-outline' },
                    { value: 'private', label: 'Only me', icon: 'lock-closed-outline' },
                  ] as const
                ).map((opt) => (
                  <Pressable
                    key={opt.value}
                    onPress={() => setVisibility(opt.value)}
                    style={[styles.visibilityOption, visibility === opt.value && styles.visibilityOptionActive]}
                  >
                    <Ionicons name={opt.icon} size={16} color={visibility === opt.value ? colors.accent : colors.textSecondary} />
                    <Text style={[styles.visibilityLabel, visibility === opt.value && styles.visibilityLabelActive]}>{opt.label}</Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View>
              <Text style={styles.label}>Rode with</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
                <Pressable onPress={() => setTagModalOpen(true)} style={styles.addTagChip}>
                  <Ionicons name="person-add-outline" size={14} color={colors.accent} />
                  <Text style={styles.addTagChipLabel}>{taggedRiders.length > 0 ? 'Edit' : 'Tag riders'}</Text>
                </Pressable>
                {taggedRiders.map((rider) => (
                  <View key={rider.id} style={styles.chip}>
                    <Text style={styles.chipLabel}>{rider.display_name || rider.username}</Text>
                  </View>
                ))}
              </ScrollView>
            </View>

            <View>
              <Text style={styles.label}>Photos</Text>
              <View style={styles.photoRow}>
                {photoUrls.map((url) => (
                  <View key={url} style={styles.photoThumbWrap}>
                    <Image source={{ uri: url }} style={styles.photoThumb} />
                    <Pressable onPress={() => removePhoto(url)} style={styles.photoRemove} hitSlop={8}>
                      <Ionicons name="close" size={12} color={colors.textOnAccent} />
                    </Pressable>
                  </View>
                ))}
                {photoUrls.length < MAX_PHOTOS ? (
                  <Pressable onPress={onAddPhotos} disabled={uploadingPhoto} style={styles.photoAdd}>
                    <Ionicons name={uploadingPhoto ? 'hourglass-outline' : 'camera-outline'} size={20} color={colors.textSecondary} />
                  </Pressable>
                ) : null}
              </View>
            </View>

            {error ? <Text style={styles.error}>{error}</Text> : null}
            <Button title="Save ride" onPress={onSave} loading={saving} style={{ marginTop: spacing.xs }} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <TagRidersModal
        visible={tagModalOpen}
        excludeUserId={profile?.id ?? ''}
        initialSelected={taggedRiders}
        onClose={() => setTagModalOpen(false)}
        onConfirm={(selected) => {
          setTaggedRiders(selected);
          setTagModalOpen(false);
        }}
      />

      {shareRide ? (
        <RideShareModal
          visible={!!shareRide}
          ride={shareRide}
          ownerName={profile?.display_name ?? 'You'}
          ownerAvatarUrl={profile?.avatar_url}
          units={units}
          onClose={() => {
            setShareRide(null);
            goHome();
          }}
        />
      ) : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingBottom: spacing.xxl, gap: spacing.md },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
  },
  discardText: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.danger, width: 56 },
  headerTitle: { fontFamily: fonts.semiBold, fontSize: 16, color: colors.textPrimary },
  map: { height: 220, marginHorizontal: spacing.md },
  statsCard: {
    marginHorizontal: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around' },
  statsDivider: { height: 1, backgroundColor: colors.border },
  form: { paddingHorizontal: spacing.md, gap: spacing.md },
  descriptionInput: { minHeight: 70, textAlignVertical: 'top', paddingTop: 12 },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, marginBottom: 8, letterSpacing: 0.2 },
  chipRow: { gap: spacing.xs, paddingRight: spacing.md },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  chipLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  chipLabelActive: { color: colors.accent },
  addTagChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.accent,
    backgroundColor: colors.accentMuted,
  },
  addTagChipLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  visibilityRow: { flexDirection: 'row', gap: spacing.xs },
  visibilityOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  visibilityOptionActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  visibilityLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  visibilityLabelActive: { color: colors.accent, fontFamily: fonts.semiBold },
  photoRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  photoThumbWrap: { position: 'relative' },
  photoThumb: { width: 64, height: 64, borderRadius: radius.sm, backgroundColor: colors.surfaceHigh },
  photoRemove: {
    position: 'absolute',
    top: -6,
    right: -6,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoAdd: {
    width: 64,
    height: 64,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: 'dashed',
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  error: { fontFamily: fonts.medium, color: colors.danger, fontSize: 14 },
});
