import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect, useIsFocused } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { RecordMap, type FollowMode, type RecordMapHandle, type RecordMapStyle } from '@/components/record/RecordMap';
import { RecordSheet } from '@/components/record/RecordSheet';
import { BackgroundAccessSheet } from '@/components/record/BackgroundAccessSheet';
import { LoadingView } from '@/components/ui/LoadingView';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/state/authStore';
import { useGuideRouteStore } from '@/state/guideRouteStore';
import { getErrorMessage } from '@/lib/errors';
import { loadLastKnownCoords, useLiveLocation } from '@/lib/liveLocation';
import {
  getRecordingAccess,
  openAppSettings,
  rememberBackgroundAccessDeclined,
  requestForegroundAccess,
  shouldExplainBackgroundAccess,
  type RecordingAccess,
} from '@/lib/recordingPermissions';
import { recordingEngine } from '@/lib/recording/engine';
import { useRecordingView } from '@/lib/recording/useRecording';
import type { FinishedRecording } from '@/lib/recording/types';
import { announceGpsSignalLost, announceRideFinish, announceRideStart, isVoiceAssistantMuted, setVoiceAssistantMuted } from '@/lib/voiceAssistant';
import { elevationGainLoss, pointsToGeoJSON } from '@/lib/geo';
import { formatDistance, formatDuration } from '@/lib/units';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import type { RecordScreenProps } from '@/navigation/types';

// Warm orange used only for the Paused state, as in the reference design;
// everything else stays on the Bunch accent.
const PAUSED_ORANGE = '#F28B30';
const GPS_SIGNAL_LOST_S = 15;
const AUTO_RECENTER_MS = 8000;
// Map controls float this far above the sheet — clear of the attribution chip that sits on its edge.
const CONTROLS_GAP = 36;

// The "you have an unsaved ride" check runs once per app launch — not on every
// mount — so it can never fire while the summary of a ride you just finished
// is already on screen.
let launchRecoveryDone = false;

export function RecordRideScreen({ navigation }: RecordScreenProps<'RecordRide'>) {
  const insets = useSafeAreaInsets();
  const units = useAuthStore((s) => s.profile?.units ?? 'metric');
  const focused = useIsFocused();

  const view = useRecordingView();
  const { phase, active } = view;
  const guide = useGuideRouteStore((s) => s.route);
  const clearGuide = useGuideRouteStore((s) => s.clear);

  const [access, setAccess] = useState<RecordingAccess | null>(null);
  const [initialCenter, setInitialCenter] = useState<{ lat: number; lng: number } | null>(null);
  const [centerChecked, setCenterChecked] = useState(false);
  const [starting, setStarting] = useState(false);
  const [accessSheet, setAccessSheet] = useState<null | 'start' | 'setup'>(null);

  const [followMode, setFollowMode] = useState<FollowMode>('north');
  const [autoRecenter, setAutoRecenter] = useState(true);
  const [mapStyle, setMapStyle] = useState<RecordMapStyle>('liberty');
  const [mapHeading, setMapHeading] = useState(0);
  const [sheetHeight, setSheetHeight] = useState(300);
  const [voiceMuted, setVoiceMuted] = useState(false);

  const mapRef = useRef<RecordMapHandle>(null);
  const lastFollowRef = useRef<FollowMode>('north');
  const signalLostRef = useRef(false);

  const live = useLiveLocation(focused && !!access?.foreground);

  const refreshAccess = useCallback(async () => {
    setAccess(await getRecordingAccess());
  }, []);

  // Re-check every time the tab gains focus — the rider may have just come
  // back from system settings after granting "all the time".
  useFocusEffect(
    useCallback(() => {
      void refreshAccess();
    }, [refreshAccess])
  );

  useEffect(() => {
    isVoiceAssistantMuted().then(setVoiceMuted);
    // Open the map on the rider's last known city instead of the middle of the ocean.
    let done = false;
    const timeout = setTimeout(() => {
      if (!done) setCenterChecked(true);
    }, 900);
    loadLastKnownCoords().then((c) => {
      done = true;
      setInitialCenter(c);
      setCenterChecked(true);
    });
    return () => clearTimeout(timeout);
  }, []);

  // Rebuild any ride that was open before this launch, and make sure GPS is
  // really still flowing (the OS may have stopped it while we were away).
  useEffect(() => {
    void recordingEngine.hydrate().then(() => recordingEngine.checkHealth());
  }, []);

  useEffect(() => {
    if (launchRecoveryDone) return;
    launchRecoveryDone = true;
    (async () => {
      try {
        await recordingEngine.hydrate();
        if (recordingEngine.getSession()?.status !== 'finished') return;
        const fin = await recordingEngine.getFinished();
        if (!fin || fin.track.length < 2) {
          await recordingEngine.discard();
          return;
        }
        Alert.alert(
          'You have an unsaved ride',
          `A ${formatDistance(fin.distanceM, units)} ride from ${new Date(fin.startedAtMs).toLocaleDateString()} was finished but never saved.`,
          [
            { text: 'Discard', style: 'destructive', onPress: () => void recordingEngine.discard() },
            { text: 'Review & save', onPress: () => navigateToSummary(fin) },
          ]
        );
      } catch (e) {
        console.warn('[RecordRideScreen] unsaved-ride check failed:', e);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // "GPS signal lost" — a sustained gap in fixes while recording (a tunnel,
  // underground parking), distinct from one noisy fix, which the engine drops quietly.
  useEffect(() => {
    if (phase !== 'recording') {
      signalLostRef.current = false;
      return;
    }
    if (view.fixAgeS > GPS_SIGNAL_LOST_S && !signalLostRef.current) {
      signalLostRef.current = true;
      announceGpsSignalLost();
    } else if (view.fixAgeS <= GPS_SIGNAL_LOST_S) {
      signalLostRef.current = false;
    }
  }, [view.fixAgeS, phase]);

  // The rider dragged the map: stop following so it doesn't fight them. With
  // auto-recenter on, follow resumes by itself a few seconds later, like a nav app.
  useEffect(() => {
    if (followMode !== 'off' || !autoRecenter || !active) return;
    const id = setTimeout(() => {
      setFollowMode(lastFollowRef.current === 'heading' ? 'heading' : 'north');
    }, AUTO_RECENTER_MS);
    return () => clearTimeout(id);
  }, [followMode, autoRecenter, active]);

  function onFollowModeChange(next: FollowMode) {
    if (next === 'off' && followMode !== 'off') lastFollowRef.current = followMode;
    setFollowMode(next);
  }

  function onFollowPress() {
    if (followMode === 'off') {
      setFollowMode(lastFollowRef.current === 'heading' ? 'heading' : 'north');
      mapRef.current?.recenter();
    } else if (followMode === 'north') {
      setFollowMode('heading');
    } else {
      setFollowMode('north');
    }
  }

  function onCompassPress() {
    mapRef.current?.resetNorth();
    if (followMode === 'heading') setFollowMode('north');
  }

  function navigateToSummary(fin: FinishedRecording) {
    const { gain, loss } = elevationGainLoss(fin.track);
    // The ride followed a planned route: link the saved ride to it, then let go of the guide.
    const routeId = useGuideRouteStore.getState().route?.id;
    clearGuide();
    const movingTimeS = Math.max(1, Math.round(fin.movingMs / 1000));
    const elapsedTimeS = Math.max(movingTimeS, Math.round((fin.endedAtMs - fin.startedAtMs) / 1000));
    navigation.navigate('RideSummary', {
      startedAt: new Date(fin.startedAtMs).toISOString(),
      endedAt: new Date(fin.endedAtMs).toISOString(),
      distanceM: fin.distanceM,
      movingTimeS,
      elapsedTimeS,
      elevationGainM: gain,
      elevationLossM: loss,
      avgSpeedMps: fin.distanceM / movingTimeS,
      maxSpeedMps: fin.maxSpeedMps,
      routeGeoJSON: JSON.stringify(pointsToGeoJSON(fin.track)),
      trackJSON: JSON.stringify(fin.track),
      ...(routeId ? { routeId } : {}),
    });
  }

  async function beginRecording() {
    try {
      await recordingEngine.start();
      announceRideStart();
      setFollowMode('north');
      void refreshAccess();
    } catch (e) {
      Alert.alert('Could not start recording', getErrorMessage(e));
    }
  }

  async function onStart() {
    if (starting) return;
    setStarting(true);
    try {
      let current = await getRecordingAccess();
      if (!current.foreground) {
        const granted = await requestForegroundAccess();
        current = await getRecordingAccess();
        setAccess(current);
        if (!granted) return;
      }
      if (!current.servicesEnabled) {
        Alert.alert('Location services are off', "Your phone's location services are turned off, so Bunch can't get a GPS signal. Turn them on in your phone's settings, then try again.");
        return;
      }
      if (!current.background && (await shouldExplainBackgroundAccess())) {
        setAccessSheet('start');
        return;
      }
      await beginRecording();
    } finally {
      setStarting(false);
    }
  }

  async function onAccessSheetContinue({ background }: { background: boolean }) {
    const from = accessSheet;
    setAccessSheet(null);
    if (!background) rememberBackgroundAccessDeclined();
    await refreshAccess();
    if (from === 'start') {
      setStarting(true);
      try {
        await beginRecording();
      } finally {
        setStarting(false);
      }
    }
  }

  async function onPause() {
    try {
      await recordingEngine.pause();
    } catch (e) {
      Alert.alert('Could not pause', getErrorMessage(e));
    }
  }

  async function onResume() {
    try {
      await recordingEngine.resume();
    } catch (e) {
      Alert.alert('Could not resume', getErrorMessage(e));
    }
  }

  function onFinishPress() {
    Alert.alert('Finish ride?', 'This stops recording and takes you to save it.', [
      { text: 'Keep riding', style: 'cancel' },
      { text: 'Finish', onPress: () => void onFinish() },
    ]);
  }

  async function onFinish() {
    try {
      const fin = await recordingEngine.finish();
      if (!fin || fin.track.length < 2) {
        await recordingEngine.discard();
        Alert.alert('Ride too short', 'Not enough GPS data was recorded to save this ride.');
        return;
      }
      announceRideFinish();
      navigateToSummary(fin);
    } catch (e) {
      Alert.alert('Could not finish the ride', getErrorMessage(e));
    }
  }

  function onToggleVoice() {
    const next = !voiceMuted;
    setVoiceMuted(next);
    void setVoiceAssistantMuted(next);
  }

  if (!access || !centerChecked) {
    return <LoadingView />;
  }

  if (!access.foreground && !active) {
    return (
      <View style={styles.permissionRoot}>
        <View style={styles.permissionIcon}>
          <Ionicons name="navigate-outline" size={34} color={colors.accent} />
        </View>
        <Text style={styles.permissionTitle}>Turn on location to record a ride</Text>
        <Text style={styles.permissionBody}>Bunch needs your phone's GPS to track distance, speed, elevation and your route.</Text>
        <Button
          title="Allow location"
          onPress={async () => {
            const granted = await requestForegroundAccess();
            await refreshAccess();
            if (!granted) openAppSettings();
          }}
          fullWidth={false}
        />
      </View>
    );
  }

  const sheetMode = !active ? 'idle' : phase === 'recording' ? 'recording' : 'paused';
  const source = view.session?.source;
  const interrupted = !!view.session?.interrupted && phase === 'paused';

  let banner: { text: string; tone: 'orange' | 'amber'; icon: keyof typeof Ionicons.glyphMap; action?: { label: string; onPress: () => void } } | null = null;
  if (interrupted) {
    banner = { text: 'Your phone stopped the recording. Resume to keep going, or Finish to save it.', tone: 'orange', icon: 'warning' };
  } else if (phase === 'autoPaused') {
    banner = { text: 'Auto-paused — start moving to resume', tone: 'orange', icon: 'pause-circle' };
  } else if (phase === 'recording' && source === 'foreground') {
    banner = { text: 'Recording only while Bunch is open', tone: 'amber', icon: 'alert-circle', action: { label: 'Fix', onPress: () => setAccessSheet('setup') } };
  }

  const followIcon: keyof typeof Ionicons.glyphMap = followMode === 'off' ? 'locate-outline' : followMode === 'north' ? 'navigate' : 'compass';
  const followLabel = followMode === 'off' ? 'Recenter on me' : followMode === 'north' ? 'Turn map with me' : 'Keep north up';
  const gpsStatus = active ? view.gps : live.accuracyM == null ? 'searching' : live.accuracyM <= 20 ? 'locked' : live.accuracyM <= 30 ? 'weak' : 'searching';

  return (
    <View style={styles.root}>
      <RecordMap
        ref={mapRef}
        style={StyleSheet.absoluteFillObject}
        location={live}
        initialCenter={initialCenter}
        followMode={followMode}
        onFollowModeChange={onFollowModeChange}
        routeCoordinates={active ? view.routeCoords : undefined}
        guideCoordinates={guide?.coordinates}
        mapStyle={mapStyle}
        bottomInset={sheetHeight}
        topInset={insets.top + (banner ? 64 : 8) + (guide ? 44 : 0)}
        onHeadingChange={setMapHeading}
      />

      {banner ? (
        <View style={[styles.topOverlay, { paddingTop: insets.top + spacing.xs }]} pointerEvents="box-none">
          <Pressable
            disabled={!banner.action}
            onPress={banner.action?.onPress}
            style={[styles.banner, { backgroundColor: banner.tone === 'orange' ? PAUSED_ORANGE : colors.gold }]}
          >
            <Ionicons name={banner.icon} size={18} color="#FFFFFF" />
            <Text style={styles.bannerText} numberOfLines={2}>
              {banner.text}
            </Text>
            {banner.action ? <Text style={styles.bannerAction}>{banner.action.label}</Text> : null}
          </Pressable>
        </View>
      ) : null}

      {guide ? (
        <View style={[styles.guideWrap, { top: insets.top + (banner ? 64 : 8) }]} pointerEvents="box-none">
          <View style={styles.guideChip}>
            <Ionicons name="navigate-circle" size={18} color={colors.accent} />
            <Text style={styles.guideText} numberOfLines={1}>
              {guide.name}
            </Text>
            {!active ? (
              <Pressable onPress={clearGuide} hitSlop={10} accessibilityLabel="Stop following this route">
                <Ionicons name="close" size={16} color={colors.textSecondary} />
              </Pressable>
            ) : null}
          </View>
        </View>
      ) : null}

      <View style={[styles.zoomPill, { bottom: sheetHeight + CONTROLS_GAP }]}>
        <Pressable onPress={() => mapRef.current?.zoomIn()} style={styles.zoomHalf} accessibilityLabel="Zoom in" hitSlop={4}>
          <Ionicons name="add" size={26} color={colors.textPrimary} />
        </Pressable>
        <View style={styles.zoomDivider} />
        <Pressable onPress={() => mapRef.current?.zoomOut()} style={styles.zoomHalf} accessibilityLabel="Zoom out" hitSlop={4}>
          <Ionicons name="remove" size={26} color={colors.textPrimary} />
        </Pressable>
      </View>

      <View style={[styles.sideColumn, { bottom: sheetHeight + CONTROLS_GAP }]}>
        <MapButton
          icon={voiceMuted ? 'volume-mute-outline' : 'volume-high-outline'}
          label={voiceMuted ? 'Turn voice assistant on' : 'Mute voice assistant'}
          active={!voiceMuted}
          onPress={onToggleVoice}
        />
        <MapButton icon={mapStyle === 'liberty' ? 'layers-outline' : 'layers'} label="Change map style" onPress={() => setMapStyle((m) => (m === 'liberty' ? 'positron' : 'liberty'))} />
        <Pressable onPress={onCompassPress} style={styles.mapButton} accessibilityLabel="Reset map to north">
          <Ionicons name="compass-outline" size={24} color={colors.textPrimary} style={{ transform: [{ rotate: `${-mapHeading}deg` }] }} />
        </Pressable>
        <MapButton icon={followIcon} label={followLabel} active={followMode !== 'off'} onPress={onFollowPress} />
      </View>

      <RecordSheet
        mode={sheetMode}
        units={units}
        distanceM={view.distanceM}
        currentSpeedMps={view.currentSpeedMps}
        currentElevationM={view.elevationM}
        avgSpeedMps={view.avgSpeedMps}
        ascentM={view.ascentM}
        descentM={view.descentM}
        movingS={view.movingS}
        maxSpeedMps={view.maxSpeedMps}
        gpsStatus={gpsStatus}
        starting={starting}
        voiceMuted={voiceMuted}
        autoRecenter={autoRecenter}
        backgroundReady={active ? source === 'background' : access.background}
        onToggleVoice={onToggleVoice}
        onToggleAutoRecenter={() => setAutoRecenter((v) => !v)}
        onSetupBackground={() => setAccessSheet('setup')}
        onStart={onStart}
        onPause={onPause}
        onResume={onResume}
        onFinish={onFinishPress}
        onHeightChange={setSheetHeight}
      />

      <BackgroundAccessSheet visible={accessSheet != null} onContinue={onAccessSheetContinue} onCancel={() => setAccessSheet(null)} />
    </View>
  );
}

function MapButton({ icon, label, onPress, active = false }: { icon: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void; active?: boolean }) {
  return (
    <Pressable onPress={onPress} style={[styles.mapButton, active && styles.mapButtonActive]} accessibilityLabel={label}>
      <Ionicons name={icon} size={22} color={active ? colors.accent : colors.textPrimary} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  topOverlay: { position: 'absolute', top: 0, left: 0, right: 0 },
  banner: {
    marginHorizontal: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 11,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    ...shadow.card,
  },
  bannerText: { flexShrink: 1, fontFamily: fonts.bold, fontSize: 14, color: '#FFFFFF', textAlign: 'center' },
  bannerAction: { fontFamily: fonts.extraBold, fontSize: 14, color: '#FFFFFF', textDecorationLine: 'underline' },

  guideWrap: { position: 'absolute', left: 0, right: 0, alignItems: 'center' },
  guideChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: '82%',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.overlay,
    ...shadow.card,
  },
  guideText: { flexShrink: 1, fontFamily: fonts.bold, fontSize: 13, color: colors.textPrimary },

  zoomPill: {
    position: 'absolute',
    left: spacing.md,
    width: 48,
    borderRadius: 24,
    backgroundColor: colors.surface,
    ...shadow.card,
  },
  zoomHalf: { height: 48, alignItems: 'center', justifyContent: 'center' },
  zoomDivider: { height: StyleSheet.hairlineWidth, marginHorizontal: 10, backgroundColor: colors.borderStrong },

  sideColumn: { position: 'absolute', right: spacing.md, gap: 10 },
  mapButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
    ...shadow.card,
  },
  mapButtonActive: { backgroundColor: colors.accentMuted, borderWidth: 1.5, borderColor: colors.accent },

  permissionRoot: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: spacing.xl, gap: spacing.sm },
  permissionIcon: { width: 76, height: 76, borderRadius: 26, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.sm },
  permissionTitle: { fontFamily: fonts.extraBold, fontSize: 24, color: colors.textPrimary, textAlign: 'center', letterSpacing: -0.4 },
  permissionBody: { fontFamily: fonts.regular, fontSize: 15, lineHeight: 22, color: colors.textSecondary, textAlign: 'center', marginBottom: spacing.sm },
});
