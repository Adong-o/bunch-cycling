import { Linking, Platform } from 'react-native';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface RecordingAccess {
  foreground: boolean;
  /** "Allow all the time" (Android) / "Always" (iOS) — what lets a ride keep recording with the screen off. */
  background: boolean;
  servicesEnabled: boolean;
}

export async function getRecordingAccess(): Promise<RecordingAccess> {
  const [fg, bg, services] = await Promise.all([
    Location.getForegroundPermissionsAsync().catch(() => null),
    Location.getBackgroundPermissionsAsync().catch(() => null),
    Location.hasServicesEnabledAsync().catch(() => true),
  ]);
  return { foreground: !!fg?.granted, background: !!bg?.granted, servicesEnabled: services };
}

export async function requestForegroundAccess(): Promise<boolean> {
  const res = await Location.requestForegroundPermissionsAsync();
  return res.granted;
}

/**
 * Asks for background ("all the time") location. Android 11+ cannot show this
 * as a normal pop-up — the OS sends the rider to the app's location settings
 * and the promise resolves when they come back — which is why the Record
 * screen explains it first instead of firing the request cold.
 */
export async function requestBackgroundAccess(): Promise<boolean> {
  try {
    const res = await Location.requestBackgroundPermissionsAsync();
    return res.granted;
  } catch {
    return false;
  }
}

export function openAppSettings(): void {
  Linking.openSettings().catch(() => {});
}

const DISMISSED_KEY = 'bunch:bgAccessPrompt:dismissedAt';
const REPROMPT_AFTER_MS = 3 * 24 * 3600 * 1000;

/** Don't nag: after "record only while open", wait a few days before explaining again. */
export async function shouldExplainBackgroundAccess(): Promise<boolean> {
  try {
    const raw = await AsyncStorage.getItem(DISMISSED_KEY);
    if (!raw) return true;
    return Date.now() - Number(raw) > REPROMPT_AFTER_MS;
  } catch {
    return true;
  }
}

export function rememberBackgroundAccessDeclined(): void {
  AsyncStorage.setItem(DISMISSED_KEY, String(Date.now())).catch(() => {});
}

export const IS_ANDROID = Platform.OS === 'android';
