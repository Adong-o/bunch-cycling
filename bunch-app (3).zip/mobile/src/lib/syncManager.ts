import NetInfo from '@react-native-community/netinfo';
import { AppState } from 'react-native';
import * as Notifications from 'expo-notifications';
import { useAuthStore } from '@/state/authStore';
import { listQueuedRides, removeQueuedRide, type QueuedRide } from '@/lib/rideOutbox';
import { saveRideWithFollowUps } from '@/lib/saveRide';

/**
 * Drains the offline ride queue (rideOutbox.ts) whenever there's a real
 * chance of success: once on app start, every time connectivity comes back,
 * and every time the app returns to the foreground (covers a rider who
 * reopens Bunch on wifi without a NetInfo event firing in between). Rides
 * upload one at a time, oldest first, and stop at the first failure — still
 * offline, or a genuine error — rather than hammering every queued ride
 * against a connection that just isn't there; the next trigger picks up
 * again from the front of the queue.
 */

let syncing = false;
let started = false;

async function notifySynced(title: string, newBadgeCount: number) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Ride saved to Bunch',
        body: newBadgeCount > 0 ? `"${title}" just finished uploading — and you earned a new badge.` : `"${title}" just finished uploading.`,
      },
      trigger: null,
    });
  } catch {
    // non-critical — the ride is synced either way, this is just a nice-to-have nudge
  }
}

async function syncOne(entry: QueuedRide): Promise<boolean> {
  const profile = useAuthStore.getState().profile;
  if (!profile) return false; // not signed in / profile not hydrated yet — try again on the next trigger

  try {
    const result = await saveRideWithFollowUps(profile, entry.payload, entry.trackJSON, entry.taggedRiderIds);
    await removeQueuedRide(entry.localId);
    void notifySynced(result.ride.title, result.newBadgeNames.length);
    return true;
  } catch (e) {
    // Still offline, or a real error on the server side — either way the
    // ride stays queued (nothing is lost) and this gets retried on the next
    // trigger. Logged so a persistent, non-connectivity failure is at least
    // visible in dev rather than silently retrying forever.
    console.warn('[syncManager] could not sync a queued ride, will retry later:', e);
    return false;
  }
}

export async function syncPendingRides(): Promise<void> {
  if (syncing) return;
  syncing = true;
  try {
    const pending = await listQueuedRides();
    for (const entry of pending) {
      // One at a time, in order — never race several uploads of rides that
      // may themselves affect shared state (streaks, badges) against each other.
      // eslint-disable-next-line no-await-in-loop
      const ok = await syncOne(entry);
      if (!ok) break;
    }
  } finally {
    syncing = false;
  }
}

export async function getPendingRideCount(): Promise<number> {
  return (await listQueuedRides()).length;
}

/** Starts the background triggers. Call once from App.tsx; safe to call more than once. Returns a teardown function. */
export function startSyncManager(): () => void {
  if (started) return () => {};
  started = true;

  void syncPendingRides();

  const unsubscribeNetInfo = NetInfo.addEventListener((state) => {
    if (state.isConnected && state.isInternetReachable !== false) {
      void syncPendingRides();
    }
  });

  const appStateSub = AppState.addEventListener('change', (next) => {
    if (next === 'active') void syncPendingRides();
  });

  return () => {
    unsubscribeNetInfo();
    appStateSub.remove();
    started = false;
  };
}
