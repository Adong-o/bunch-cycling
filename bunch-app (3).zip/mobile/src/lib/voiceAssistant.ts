import * as Speech from 'expo-speech';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * The ride's voice callouts — deliberately small and literal: exactly the
 * three moments a cyclist actually wants a word from the app mid-ride
 * (starting, losing GPS, finishing), not a running commentary. Muting is
 * remembered locally and checked before every line, so a rider who doesn't
 * want it can turn it off once and never hear it again, without that
 * touching recording itself — this is purely a spoken-feedback layer on top.
 */

const MUTE_KEY = 'bunch:voiceAssistantMuted';
let mutedCache: boolean | null = null;

export async function isVoiceAssistantMuted(): Promise<boolean> {
  if (mutedCache != null) return mutedCache;
  const raw = await AsyncStorage.getItem(MUTE_KEY).catch(() => null);
  mutedCache = raw === '1';
  return mutedCache;
}

export async function setVoiceAssistantMuted(muted: boolean): Promise<void> {
  mutedCache = muted;
  await AsyncStorage.setItem(MUTE_KEY, muted ? '1' : '0').catch(() => {});
}

async function say(line: string) {
  try {
    if (await isVoiceAssistantMuted()) return;
    Speech.speak(line, { rate: 1.0, pitch: 1.0 });
  } catch {
    // Speech is a nice-to-have, never something a ride should fail over.
  }
}

export function announceRideStart(): void {
  void say("Let's go!");
}

export function announceGpsSignalLost(): void {
  void say('GPS signal lost.');
}

export function announceRideFinish(): void {
  void say('Woohoo! That was amazing!');
}
