// Hand-written to exactly match supabase/schema.sql, verified column-by-column
// against a live Postgres instance running that file. If you change the
// schema, the easiest way to keep this in sync is the Supabase CLI:
//   npx supabase gen types typescript --project-id xlvaybaekgmzstheekqo > src/lib/database.types.ts
// (requires `npx supabase login` once). Until then, this file is accurate.

export type UnitSystem = 'metric' | 'imperial';
export type TargetPeriod = 'daily' | 'weekly';
export type BikeType = 'road' | 'gravel' | 'mountain' | 'commuter' | 'ebike' | 'other';
export type SurfaceType = 'paved' | 'gravel' | 'mixed' | 'dirt';
export type RideVisibility = 'public' | 'followers' | 'private';
export type RideSource = 'gps' | 'manual' | 'import';
export type ChallengeType = 'distance' | 'elevation' | 'duration' | 'ride_count';
export type DeviceType = 'heart_rate' | 'speed_cadence' | 'power' | 'combo' | 'other';
export type RecordingDeviceBrand = 'garmin' | 'coros' | 'suunto' | 'polar' | 'apple_watch' | 'amazfit' | 'wahoo' | 'other';
export type RidingExperience = 'new' | 'casual' | 'regular' | 'competitive';
export type PrimaryGoal = 'fitness' | 'commuting' | 'racing' | 'social' | 'exploring';

export type BadgeCriteriaType =
  | 'total_rides'
  | 'total_distance_m'
  | 'total_elevation_m'
  | 'longest_streak'
  | 'challenges_completed'
  | 'single_ride_distance_m'
  | 'single_ride_elevation_m';

/** GeoJSON LineString with an optional third (elevation, meters) coordinate per point. */
/** [distance_m, speed_mps] — downsampled per-ride speed profile. */
export type SpeedSample = [distanceM: number, speedMps: number];

export type RidingStyle = 'road' | 'gravel' | 'mountain' | 'commute' | 'ebike' | 'indoor';

export interface RouteGeoJSON {
  type: 'LineString';
  coordinates: Array<[lng: number, lat: number, elevationM?: number]>;
}

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          username: string;
          display_name: string;
          avatar_url: string | null;
          bio: string;
          units: UnitSystem;
          weight_kg: number | null;
          target_period: TargetPeriod;
          target_distance_m: number;
          timezone: string;
          riding_experience: RidingExperience | null;
          primary_goal: PrimaryGoal | null;
          riding_styles: RidingStyle[];
          onboarding_completed: boolean;
          is_admin: boolean;
          is_premium: boolean;
          premium_since: string | null;
          current_streak: number;
          longest_streak: number;
          last_streak_date: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          username: string;
          display_name?: string;
          avatar_url?: string | null;
          riding_styles?: RidingStyle[];
          bio?: string;
          units?: UnitSystem;
          weight_kg?: number | null;
          target_period?: TargetPeriod;
          target_distance_m?: number;
          timezone?: string;
          riding_experience?: RidingExperience | null;
          primary_goal?: PrimaryGoal | null;
          onboarding_completed?: boolean;
          is_admin?: boolean;
          is_premium?: boolean;
          premium_since?: string | null;
          current_streak?: number;
          longest_streak?: number;
          last_streak_date?: string | null;
        };
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>;
      };
      profiles_private: {
        Row: { id: string; email: string | null };
        Insert: { id: string; email?: string | null };
        Update: { id?: string; email?: string | null };
      };
      bikes: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          type: BikeType;
          is_default: boolean;
          is_retired: boolean;
          total_distance_m: number;
          total_rides: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          type?: BikeType;
          is_default?: boolean;
          is_retired?: boolean;
        };
        Update: Partial<Database['public']['Tables']['bikes']['Insert']>;
      };
      routes: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          description: string;
          distance_m: number;
          elevation_gain_m: number;
          route_geojson: RouteGeoJSON;
          surface_type: SurfaceType;
          is_public: boolean;
          created_from_ride_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          description?: string;
          distance_m?: number;
          elevation_gain_m?: number;
          route_geojson: RouteGeoJSON;
          surface_type?: SurfaceType;
          is_public?: boolean;
          created_from_ride_id?: string | null;
        };
        Update: Partial<Database['public']['Tables']['routes']['Insert']>;
      };
      rides: {
        Row: {
          id: string;
          user_id: string;
          bike_id: string | null;
          route_id: string | null;
          title: string;
          description: string;
          visibility: RideVisibility;
          source: RideSource;
          is_indoor: boolean;
          started_at: string;
          ended_at: string;
          moving_time_s: number;
          elapsed_time_s: number;
          distance_m: number;
          elevation_gain_m: number;
          elevation_loss_m: number;
          avg_speed_mps: number;
          max_speed_mps: number;
          avg_heart_rate: number | null;
          max_heart_rate: number | null;
          calories: number | null;
          start_lat: number | null;
          start_lng: number | null;
          end_lat: number | null;
          end_lng: number | null;
          route_geojson: RouteGeoJSON | null;
          photo_urls: string[];
          recording_device_id: string | null;
          start_location_name: string | null;
          speed_samples: SpeedSample[] | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          bike_id?: string | null;
          route_id?: string | null;
          title?: string;
          description?: string;
          visibility?: RideVisibility;
          source?: RideSource;
          is_indoor?: boolean;
          started_at: string;
          ended_at: string;
          moving_time_s?: number;
          elapsed_time_s?: number;
          distance_m?: number;
          elevation_gain_m?: number;
          elevation_loss_m?: number;
          avg_speed_mps?: number;
          max_speed_mps?: number;
          avg_heart_rate?: number | null;
          max_heart_rate?: number | null;
          calories?: number | null;
          start_lat?: number | null;
          start_lng?: number | null;
          end_lat?: number | null;
          end_lng?: number | null;
          route_geojson?: RouteGeoJSON | null;
          photo_urls?: string[];
          recording_device_id?: string | null;
          start_location_name?: string | null;
          speed_samples?: SpeedSample[] | null;
        };
        Update: Partial<Database['public']['Tables']['rides']['Insert']>;
      };
      segments: {
        Row: {
          id: string;
          created_by: string;
          name: string;
          distance_m: number;
          elevation_gain_m: number;
          avg_grade_pct: number | null;
          surface_type: SurfaceType;
          start_lat: number;
          start_lng: number;
          end_lat: number;
          end_lng: number;
          route_geojson: RouteGeoJSON;
          created_at: string;
        };
        Insert: {
          id?: string;
          created_by: string;
          name: string;
          distance_m: number;
          elevation_gain_m?: number;
          avg_grade_pct?: number | null;
          surface_type?: SurfaceType;
          start_lat: number;
          start_lng: number;
          end_lat: number;
          end_lng: number;
          route_geojson: RouteGeoJSON;
        };
        Update: Partial<Database['public']['Tables']['segments']['Insert']>;
      };
      segment_stars: {
        Row: { id: string; user_id: string; segment_id: string; created_at: string };
        Insert: { id?: string; user_id: string; segment_id: string };
        Update: { id?: string; user_id?: string; segment_id?: string };
      };
      segment_efforts: {
        Row: {
          id: string;
          segment_id: string;
          ride_id: string;
          user_id: string;
          elapsed_s: number;
          avg_speed_mps: number | null;
          started_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          segment_id: string;
          ride_id: string;
          user_id: string;
          elapsed_s: number;
          avg_speed_mps?: number | null;
          started_at: string;
        };
        Update: Partial<Database['public']['Tables']['segment_efforts']['Insert']>;
      };
      challenges: {
        Row: {
          id: string;
          created_by: string;
          is_official: boolean;
          title: string;
          description: string;
          cover_image_url: string | null;
          type: ChallengeType;
          goal_value: number;
          start_date: string;
          end_date: string;
          is_public: boolean;
          is_featured: boolean;
          invite_code: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          created_by: string;
          is_official?: boolean;
          title: string;
          description?: string;
          cover_image_url?: string | null;
          type: ChallengeType;
          goal_value: number;
          start_date: string;
          end_date: string;
          is_public?: boolean;
          is_featured?: boolean;
          invite_code?: string;
        };
        Update: Partial<Database['public']['Tables']['challenges']['Insert']>;
      };
      challenge_participants: {
        Row: {
          id: string;
          challenge_id: string;
          user_id: string;
          current_progress: number;
          joined_at: string;
          completed_at: string | null;
        };
        Insert: { id?: string; challenge_id: string; user_id: string };
        Update: { current_progress?: number; completed_at?: string | null };
      };
      badges: {
        Row: {
          id: string;
          slug: string;
          name: string;
          description: string;
          icon: string;
          criteria_type: BadgeCriteriaType;
          criteria_value: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          slug: string;
          name: string;
          description: string;
          icon: string;
          criteria_type: BadgeCriteriaType;
          criteria_value: number;
        };
        Update: Partial<Database['public']['Tables']['badges']['Insert']>;
      };
      user_badges: {
        Row: {
          id: string;
          user_id: string;
          badge_id: string;
          ride_id: string | null;
          challenge_id: string | null;
          awarded_at: string;
        };
        Insert: never; // only ever inserted server-side; see check_and_award_badges() in schema.sql
        Update: never;
      };
      follows: {
        Row: { id: string; follower_id: string; following_id: string; created_at: string };
        Insert: { id?: string; follower_id: string; following_id: string };
        Update: never;
      };
      kudos: {
        Row: { id: string; ride_id: string; user_id: string; created_at: string };
        Insert: { id?: string; ride_id: string; user_id: string };
        Update: never;
      };
      ride_comments: {
        Row: { id: string; ride_id: string; user_id: string; body: string; created_at: string };
        Insert: { id?: string; ride_id: string; user_id: string; body: string };
        Update: { body?: string };
      };
      ride_tags: {
        Row: { id: string; ride_id: string; user_id: string; tagged_by: string; created_at: string };
        Insert: { id?: string; ride_id: string; user_id: string; tagged_by: string };
        Update: never; // tags are only ever added or removed, never edited in place
      };
      ride_highlights: {
        Row: {
          id: string;
          ride_id: string;
          user_id: string;
          name: string;
          photo_url: string | null;
          lat: number | null;
          lng: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          ride_id: string;
          user_id: string;
          name?: string;
          photo_url?: string | null;
          lat?: number | null;
          lng?: number | null;
        };
        Update: Partial<Database['public']['Tables']['ride_highlights']['Insert']>;
      };
      devices: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          type: DeviceType;
          ble_identifier: string | null;
          last_connected_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          type?: DeviceType;
          ble_identifier?: string | null;
          last_connected_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['devices']['Insert']>;
      };
      recording_devices: {
        Row: { id: string; user_id: string; brand: RecordingDeviceBrand; name: string; created_at: string };
        Insert: { id?: string; user_id: string; brand?: RecordingDeviceBrand; name: string };
        Update: Partial<Database['public']['Tables']['recording_devices']['Insert']>;
      };
    };
    Views: {
      route_ride_counts: {
        Row: { route_id: string; ride_count: number; rider_count: number };
      };
      home_feed: { Row: Database['public']['Tables']['rides']['Row'] };
      challenge_leaderboard: {
        Row: {
          challenge_id: string;
          user_id: string;
          username: string;
          display_name: string;
          avatar_url: string | null;
          current_progress: number;
          completed_at: string | null;
          joined_at: string;
          rank: number;
        };
      };
      segment_leaderboard: {
        Row: {
          segment_id: string;
          user_id: string;
          username: string;
          display_name: string;
          avatar_url: string | null;
          is_ebike: boolean;
          best_elapsed_s: number;
          rank: number;
        };
      };
    };
  };
}

export type Tables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Row'];
export type TablesInsert<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Insert'];
export type TablesUpdate<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Update'];
export type Views<T extends keyof Database['public']['Views']> = Database['public']['Views'][T]['Row'];

export type Profile = Tables<'profiles'>;
export type Bike = Tables<'bikes'>;
export type RouteRow = Tables<'routes'>;
export type Ride = Tables<'rides'>;
export type Segment = Tables<'segments'>;
export type SegmentEffort = Tables<'segment_efforts'>;
export type Challenge = Tables<'challenges'>;
export type ChallengeParticipant = Tables<'challenge_participants'>;
export type Badge = Tables<'badges'>;
export type UserBadge = Tables<'user_badges'>;
export type Device = Tables<'devices'>;
export type RideTag = Tables<'ride_tags'>;
export type RecordingDevice = Tables<'recording_devices'>;
export type ChallengeLeaderboardRow = Views<'challenge_leaderboard'>;
export type SegmentLeaderboardRow = Views<'segment_leaderboard'>;
export type RideHighlight = Tables<'ride_highlights'>;
export type RouteRideCount = Views<'route_ride_counts'>;
