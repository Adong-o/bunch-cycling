import {
  applyUpdates,
  AUTO_PAUSE_DELAY_MS,
  createSession,
  finishSession,
  gpsQuality,
  interruptSession,
  MAX_ACCEPTABLE_ACCURACY_M,
  movingMsAt,
  pauseSession,
  recoveredMovingMs,
  resumeSession,
  thinForDisplay,
} from '../reducer';
import type { RawLocationUpdate } from '../types';

// The recording rules are pure: the same fixes in, the same ride out — whether they
// arrive from the Record screen, the OS background task, or this file.

const T0 = 1_700_000_000_000;
const M_PER_DEG_LAT = 111_195; // haversine's own degree length (R = 6,371 km)

/** A fix `distM` metres north of the start, `t` seconds after T0. */
function fix(t: number, distM: number, over: Partial<RawLocationUpdate> = {}): RawLocationUpdate {
  return { lat: -1.29 + distM / M_PER_DEG_LAT, lng: 36.82, elevationM: 1600, speedMps: null, accuracyM: 5, timestamp: T0 + t * 1000, ...over };
}

/** Rides at a steady speed for `seconds`, one fix per second, starting at second `from`. */
function ride(speed: number, seconds: number, from = 1): RawLocationUpdate[] {
  return Array.from({ length: seconds }, (_, i) => fix(from + i, (from + i) * speed, { speedMps: speed }));
}

describe('applyUpdates: distance and the track', () => {
  it('adds up distance and keeps every accepted point', () => {
    const { session, accepted } = applyUpdates(createSession(T0, 'background'), ride(6, 60), T0 + 60_000);
    expect(accepted).toHaveLength(60);
    expect(session.pointCount).toBe(60);
    // 59 hops of 6 m (the first fix has nothing to measure from).
    expect(session.distanceM).toBeGreaterThan(354 * 0.98);
    expect(session.distanceM).toBeLessThan(354 * 1.02);
    expect(session.maxSpeedMps).toBe(6);
  });

  it('drops fixes that are too inaccurate, but still notes how good the signal is', () => {
    const base = applyUpdates(createSession(T0, 'background'), [fix(1, 0), fix(2, 6)], T0).session;
    const { session, accepted } = applyUpdates(base, [fix(3, 500, { accuracyM: MAX_ACCEPTABLE_ACCURACY_M + 1 })], T0 + 3000);
    expect(accepted).toHaveLength(0);
    expect(session.pointCount).toBe(2);
    expect(session.distanceM).toBeLessThan(10); // the wild fix never touched the distance
    expect(session.lastAccuracyM).toBe(MAX_ACCEPTABLE_ACCURACY_M + 1);
  });

  it('ignores replayed or duplicate deliveries', () => {
    const batch = ride(5, 10);
    const once = applyUpdates(createSession(T0, 'background'), batch, T0).session;
    const twice = applyUpdates(once, batch, T0 + 1000);
    expect(twice.accepted).toHaveLength(0);
    expect(twice.session.distanceM).toBe(once.distanceM);
    expect(twice.session.pointCount).toBe(once.pointCount);
  });

  it('sorts a batch that arrives out of order', () => {
    const batch = ride(5, 10).reverse();
    const { session } = applyUpdates(createSession(T0, 'background'), batch, T0);
    const forward = applyUpdates(createSession(T0, 'background'), ride(5, 10), T0).session;
    expect(session.distanceM).toBeCloseTo(forward.distanceM, 5);
  });

  it('rejects a GPS teleport instead of drawing a 5 km spike', () => {
    const base = applyUpdates(createSession(T0, 'background'), ride(6, 10), T0).session;
    const { accepted, session } = applyUpdates(base, [fix(11, 5000, { speedMps: 6 })], T0 + 11_000);
    expect(accepted).toHaveLength(0);
    expect(session.distanceM).toBeLessThan(70);
  });

  it('does not count stationary jitter as distance', () => {
    const jitter = Array.from({ length: 20 }, (_, i) => fix(1 + i, i % 2 === 0 ? 0 : 0.5, { speedMps: 5 }));
    const { session } = applyUpdates(createSession(T0, 'background'), jitter, T0);
    expect(session.distanceM).toBe(0);
  });

  it('derives speed from the hop when the device gives none', () => {
    const { session, accepted } = applyUpdates(createSession(T0, 'background'), [fix(1, 0), fix(2, 7)], T0);
    expect(accepted[0].speedMps).toBeNull();
    expect(accepted[1].speedMps).toBeGreaterThan(6.8);
    expect(accepted[1].speedMps).toBeLessThan(7.2);
    expect(session.lastSpeedMps).toBe(accepted[1].speedMps);
  });

  it('ignores updates while paused or finished', () => {
    const s = createSession(T0, 'background');
    expect(applyUpdates(pauseSession(s, T0 + 1000), ride(5, 5), T0).accepted).toHaveLength(0);
    expect(applyUpdates(finishSession(s, T0 + 1000), ride(5, 5), T0).accepted).toHaveLength(0);
  });
});

describe('applyUpdates: auto-pause and resume', () => {
  /** 20 s of riding, then standing still for `stopS` seconds, then riding again for `goS` seconds. */
  function stopAndGo(stopS: number, goS: number, goSpeed = 5) {
    const moving = ride(5, 20);
    const stopped = Array.from({ length: stopS }, (_, i) => fix(21 + i, 100, { speedMps: 0 }));
    const go = Array.from({ length: goS }, (_, i) => fix(21 + stopS + i, 100 + (i + 1) * goSpeed, { speedMps: goSpeed }));
    return [...moving, ...stopped, ...go];
  }

  it('auto-pauses after a sustained stop and freezes the moving clock', () => {
    const s0 = createSession(T0, 'background');
    const { session } = applyUpdates(s0, stopAndGo(10, 0), T0);
    expect(session.status).toBe('autoPaused');
    expect(session.segmentStartMs).toBeNull();
    // Moving time stops at the moment the pause kicked in: ~20 s riding + the 3 s grace.
    const expected = 20_000 + AUTO_PAUSE_DELAY_MS;
    expect(session.movingMsAccumulated).toBeGreaterThanOrEqual(expected - 1500);
    expect(session.movingMsAccumulated).toBeLessThanOrEqual(expected + 2500);
  });

  it('a brief stop shorter than the grace period does not pause', () => {
    const { session } = applyUpdates(createSession(T0, 'background'), stopAndGo(2, 5), T0);
    expect(session.status).toBe('recording');
  });

  it('resumes by itself when the rider sets off again', () => {
    const { session } = applyUpdates(createSession(T0, 'background'), stopAndGo(10, 10), T0);
    expect(session.status).toBe('recording');
    expect(session.segmentStartMs).not.toBeNull();
  });

  it('needs a real pace to resume — creeping along does not (hysteresis)', () => {
    const creeping = stopAndGo(10, 10, 1.1);
    const { session } = applyUpdates(createSession(T0, 'background'), creeping, T0);
    expect(session.status).toBe('autoPaused');
  });

  it('adds no distance and no points while auto-paused', () => {
    const paused = applyUpdates(createSession(T0, 'background'), stopAndGo(10, 0), T0).session;
    const before = { d: paused.distanceM, n: paused.pointCount };
    const more = Array.from({ length: 10 }, (_, i) => fix(40 + i, 100, { speedMps: 0.2 }));
    const after = applyUpdates(paused, more, T0 + 50_000).session;
    expect(after.distanceM).toBe(before.d);
    expect(after.pointCount).toBe(before.n);
  });
});

describe('pause / resume / finish / interrupt', () => {
  it('pausing banks the moving time and stops the clock', () => {
    const s = createSession(T0, 'background');
    const paused = pauseSession(s, T0 + 90_000);
    expect(paused.status).toBe('paused');
    expect(paused.movingMsAccumulated).toBe(90_000);
    expect(movingMsAt(paused, T0 + 500_000)).toBe(90_000); // time on the couch does not count
  });

  it('resuming restarts the clock from now', () => {
    const paused = pauseSession(createSession(T0, 'background'), T0 + 60_000);
    const resumed = resumeSession(paused, T0 + 600_000);
    expect(resumed.status).toBe('recording');
    expect(movingMsAt(resumed, T0 + 630_000)).toBe(60_000 + 30_000);
  });

  it('finishing freezes the ride and records when it ended', () => {
    const done = finishSession(createSession(T0, 'background'), T0 + 120_000);
    expect(done.status).toBe('finished');
    expect(done.endedAtMs).toBe(T0 + 120_000);
    expect(done.movingMsAccumulated).toBe(120_000);
    expect(resumeSession(done, T0 + 130_000).status).toBe('finished'); // cannot be re-opened
  });

  it('an interruption is anchored at the last fix, not at "now"', () => {
    const riding = applyUpdates(createSession(T0, 'background'), ride(6, 30), T0 + 30_000).session;
    // The phone's battery manager killed GPS; the app notices an hour later.
    const interrupted = interruptSession(riding, T0 + 3_600_000);
    expect(interrupted.interrupted).toBe(true);
    expect(interrupted.status).toBe('paused');
    expect(interrupted.movingMsAccumulated).toBeLessThan(31_000);
    expect(interrupted.movingMsAccumulated).toBeGreaterThan(28_000);
  });

  it('recoveredMovingMs credits time up to the last fix only', () => {
    const riding = applyUpdates(createSession(T0, 'background'), ride(6, 45), T0 + 45_000).session;
    const recovered = recoveredMovingMs(riding);
    expect(recovered).toBeLessThanOrEqual(45_500);
    expect(recovered).toBeGreaterThan(43_000);
  });

  it('resuming clears the interrupted flag', () => {
    const riding = applyUpdates(createSession(T0, 'background'), ride(6, 10), T0 + 10_000).session;
    const back = resumeSession(interruptSession(riding, T0 + 100_000), T0 + 200_000);
    expect(back.interrupted).toBe(false);
    expect(back.status).toBe('recording');
  });
});

describe('gpsQuality', () => {
  it('reads the newest fix', () => {
    expect(gpsQuality(null)).toBe('searching');
    expect(gpsQuality(undefined)).toBe('searching');
    expect(gpsQuality(8)).toBe('locked');
    expect(gpsQuality(20)).toBe('locked');
    expect(gpsQuality(25)).toBe('weak');
    expect(gpsQuality(30)).toBe('weak');
    expect(gpsQuality(60)).toBe('searching');
  });
});

describe('thinForDisplay', () => {
  it('leaves short tracks alone', () => {
    const pts = [1, 2, 3];
    expect(thinForDisplay(pts, 10)).toEqual([1, 2, 3]);
  });

  it('thins long tracks but keeps the first and last point', () => {
    const pts = Array.from({ length: 10_000 }, (_, i) => i);
    const out = thinForDisplay(pts, 500);
    expect(out.length).toBeLessThanOrEqual(501);
    expect(out[0]).toBe(0);
    expect(out[out.length - 1]).toBe(9_999);
  });
});
