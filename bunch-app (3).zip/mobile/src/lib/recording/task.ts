import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { LOCATION_TRACKING_TASK } from '@/lib/locationTracking';
import { recordingEngine } from './engine';
import type { RawLocationUpdate } from './types';

/** Converts an expo-location fix into the engine's input shape. */
export function toRawUpdate(loc: Location.LocationObject): RawLocationUpdate {
  return {
    lat: loc.coords.latitude,
    lng: loc.coords.longitude,
    elevationM: loc.coords.altitude,
    speedMps: loc.coords.speed != null && loc.coords.speed >= 0 ? loc.coords.speed : null,
    accuracyM: loc.coords.accuracy,
    timestamp: loc.timestamp,
  };
}

/**
 * The background location task. Registered at module scope so it exists as
 * soon as the JS bundle loads — including the cold, UI-less start the OS
 * performs to hand over a batch of fixes while Bunch's screens don't exist.
 * It deliberately knows nothing about React or any screen: it hands the
 * batch to the recording engine, which persists it to disk and (if a screen
 * happens to be listening) updates the live UI. The returned promise is
 * awaited by expo-task-manager, so the OS keeps the process alive until the
 * batch is safely written.
 */
if (!TaskManager.isTaskDefined(LOCATION_TRACKING_TASK)) {
  TaskManager.defineTask(LOCATION_TRACKING_TASK, async ({ data, error }) => {
    if (error) {
      console.warn('[recording] background task error:', error.message);
      return;
    }
    const locations = (data as { locations?: Location.LocationObject[] } | undefined)?.locations;
    if (!locations?.length) return;
    try {
      await recordingEngine.ingest(locations.map(toRawUpdate));
    } catch (e) {
      console.warn('[recording] failed to record a background batch:', e);
    }
  });
}
