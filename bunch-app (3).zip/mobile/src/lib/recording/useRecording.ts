import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { elevationGainLoss, type TrackPoint } from '@/lib/geo';
import { gpsQuality, movingMsAt, thinForDisplay } from './reducer';
import { recordingEngine } from './engine';
import type { RecordingSession, RecordingStatus } from './types';

export type RecordingPhase = 'idle' | RecordingStatus;

export function useRecordingSession(): RecordingSession | null {
  return useSyncExternalStore(recordingEngine.subscribe, recordingEngine.getSession, recordingEngine.getSession);
}

/** Everything a screen needs to draw a live ride. Safe to call from any screen; cheap when idle. */
export interface RecordingView {
  session: RecordingSession | null;
  phase: RecordingPhase;
  /** True for recording / paused / autoPaused — i.e. a ride is open and not yet finished. */
  active: boolean;
  movingS: number;
  distanceM: number;
  currentSpeedMps: number | null;
  elevationM: number | null;
  ascentM: number;
  descentM: number;
  maxSpeedMps: number;
  avgSpeedMps: number;
  gps: 'searching' | 'locked' | 'weak';
  /** Seconds since the last GPS fix arrived (Infinity before the first). */
  fixAgeS: number;
  routeCoords: Array<[number, number]>;
  trackLoaded: boolean;
}

export function useRecordingView(): RecordingView {
  const session = useRecordingSession();
  const trackVersion = useSyncExternalStore(recordingEngine.subscribe, recordingEngine.getTrackVersion, recordingEngine.getTrackVersion);
  const sessionId = session?.id;

  // Pull the full track from disk into memory once a ride exists in this JS context.
  useEffect(() => {
    if (sessionId) void recordingEngine.ensureTrackLoaded();
  }, [sessionId]);

  // 1 Hz clock only while the moving timer is actually running.
  const running = session?.status === 'recording' || session?.status === 'autoPaused';
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    setNow(Date.now());
    if (!running) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [running, session?.status]);

  const track: TrackPoint[] | null = recordingEngine.getTrack();
  const gainLoss = useMemo(() => (track && track.length > 1 ? elevationGainLoss(track) : { gain: 0, loss: 0 }), [track, trackVersion]);
  const routeCoords = useMemo(
    () => (track && track.length > 1 ? thinForDisplay(track).map((p) => [p.lng, p.lat] as [number, number]) : []),
    [track, trackVersion]
  );

  return useMemo<RecordingView>(() => {
    if (!session) {
      return {
        session: null,
        phase: 'idle',
        active: false,
        movingS: 0,
        distanceM: 0,
        currentSpeedMps: null,
        elevationM: null,
        ascentM: 0,
        descentM: 0,
        maxSpeedMps: 0,
        avgSpeedMps: 0,
        gps: 'searching',
        fixAgeS: Infinity,
        routeCoords: [],
        trackLoaded: false,
      };
    }
    const movingS = Math.floor(movingMsAt(session, now) / 1000);
    const phase: RecordingPhase = session.status;
    const active = session.status !== 'finished';
    const fixAgeS = session.lastFixArrivedAtMs != null ? Math.max(0, (now - session.lastFixArrivedAtMs) / 1000) : Infinity;
    const stale = fixAgeS > 8;
    const speed = session.status === 'autoPaused' || session.status === 'paused' ? 0 : stale ? null : session.lastSpeedMps;
    let lastWithEle: number | null = session.lastPoint?.elevationM ?? null;
    if (track) {
      lastWithEle = null;
      for (let i = track.length - 1; i >= 0; i--) {
        const e = track[i].elevationM;
        if (e != null) {
          lastWithEle = e;
          break;
        }
      }
    }
    return {
      session,
      phase,
      active,
      movingS,
      distanceM: session.distanceM,
      currentSpeedMps: speed,
      elevationM: lastWithEle,
      ascentM: gainLoss.gain,
      descentM: gainLoss.loss,
      maxSpeedMps: session.maxSpeedMps,
      avgSpeedMps: movingS > 0 ? session.distanceM / movingS : 0,
      gps: stale && session.status === 'recording' ? 'searching' : gpsQuality(session.lastAccuracyM),
      fixAgeS,
      routeCoords,
      trackLoaded: track != null,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, now, gainLoss, routeCoords, track, trackVersion]);
}
