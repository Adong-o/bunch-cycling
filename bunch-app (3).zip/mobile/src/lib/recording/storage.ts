import * as FileSystem from 'expo-file-system';
import type { TrackPoint } from '@/lib/geo';
import type { RecordingSession } from './types';

/**
 * On-disk layout of an in-progress ride (all inside <documents>/recording/):
 *
 *   session.json        small; rewritten after every GPS batch
 *   tail-0000042.json   the points of one GPS batch (written once, never edited)
 *   main-a.json / main-b.json
 *                       every point older than the tail chunks, compacted into
 *                       one file. Compaction writes the *other* file first and
 *                       only then flips `session.mainFile`, so a crash at any
 *                       moment leaves a complete, readable ride behind.
 *
 * Plain files via expo-file-system (not AsyncStorage): this is written from
 * the headless JS context the OS spins up to deliver background location
 * batches, where the file API is dependable and the AsyncStorage bridge isn't
 * always warm yet.
 */
const DIR = `${FileSystem.documentDirectory ?? ''}recording/`;
const SESSION_PATH = `${DIR}session.json`;

const mainPath = (which: 'a' | 'b') => `${DIR}main-${which}.json`;
const tailName = (seq: number) => `tail-${String(seq).padStart(7, '0')}.json`;
const TAIL_RE = /^tail-(\d+)\.json$/;

// [lat, lng, elevationM | null, speedMps | null, timestampMs]
type Packed = [number, number, number | null, number | null, number];

const round = (n: number, d: number) => Math.round(n * 10 ** d) / 10 ** d;

function pack(points: TrackPoint[]): Packed[] {
  return points.map((p) => [round(p.lat, 6), round(p.lng, 6), p.elevationM != null ? round(p.elevationM, 1) : null, p.speedMps != null ? round(p.speedMps, 2) : null, p.timestamp]);
}

function unpack(rows: Packed[]): TrackPoint[] {
  return rows.map(([lat, lng, elevationM, speedMps, timestamp]) => ({ lat, lng, elevationM, speedMps, timestamp }));
}

async function ensureDir(): Promise<void> {
  try {
    await FileSystem.makeDirectoryAsync(DIR, { intermediates: true });
  } catch {
    // Already exists — fine.
  }
}

export async function writeSession(session: RecordingSession): Promise<void> {
  await ensureDir();
  await FileSystem.writeAsStringAsync(SESSION_PATH, JSON.stringify(session));
}

export async function readSession(): Promise<RecordingSession | null> {
  try {
    const info = await FileSystem.getInfoAsync(SESSION_PATH);
    if (!info.exists) return null;
    const parsed = JSON.parse(await FileSystem.readAsStringAsync(SESSION_PATH)) as RecordingSession;
    if (!parsed || parsed.version !== 1 || typeof parsed.startedAtMs !== 'number') return null;
    return parsed;
  } catch {
    return null;
  }
}

export async function appendTail(seq: number, points: TrackPoint[]): Promise<void> {
  await ensureDir();
  await FileSystem.writeAsStringAsync(`${DIR}${tailName(seq)}`, JSON.stringify(pack(points)));
}

async function listTailSeqs(): Promise<number[]> {
  const names = await FileSystem.readDirectoryAsync(DIR).catch(() => [] as string[]);
  const seqs: number[] = [];
  for (const n of names) {
    const m = TAIL_RE.exec(n);
    if (m) seqs.push(parseInt(m[1], 10));
  }
  return seqs.sort((a, b) => a - b);
}

/** Highest tail chunk number on disk (or -1). Lets a recovered session never reuse a chunk number. */
export async function highestTailSeq(): Promise<number> {
  const seqs = await listTailSeqs();
  return seqs.length ? seqs[seqs.length - 1] : -1;
}

async function readPackedFile(path: string): Promise<TrackPoint[]> {
  try {
    return unpack(JSON.parse(await FileSystem.readAsStringAsync(path)) as Packed[]);
  } catch {
    return []; // a half-written file from a crash — everything before it is still in the other files
  }
}

/** The full ride as currently on disk: compacted main file plus every newer tail chunk, in time order. */
export async function readTrack(session: RecordingSession): Promise<TrackPoint[]> {
  const collected: TrackPoint[] = [];
  if (session.mainFile) {
    for (const p of await readPackedFile(mainPath(session.mainFile))) collected.push(p);
  }
  for (const seq of await listTailSeqs()) {
    if (seq < session.tailStartSeq) continue;
    for (const p of await readPackedFile(`${DIR}${tailName(seq)}`)) collected.push(p);
  }
  collected.sort((a, b) => a.timestamp - b.timestamp);
  const out: TrackPoint[] = [];
  let lastTs = -Infinity;
  for (const p of collected) {
    if (p.timestamp <= lastTs) continue; // duplicate from an interrupted compaction
    lastTs = p.timestamp;
    out.push(p);
  }
  return out;
}

/** Folds all tail chunks into the main file. `full` must be the complete track as of `session.chunkSeq`. */
export async function compact(session: RecordingSession, full: TrackPoint[]): Promise<RecordingSession> {
  await ensureDir();
  const target: 'a' | 'b' = session.mainFile === 'a' ? 'b' : 'a';
  await FileSystem.writeAsStringAsync(mainPath(target), JSON.stringify(pack(full)));

  const next: RecordingSession = { ...session, mainFile: target, tailStartSeq: session.chunkSeq };
  await writeSession(next); // the commit point — until this lands, the old files still describe the ride

  // Best-effort cleanup of what the new main file replaced.
  for (const seq of await listTailSeqs()) {
    if (seq < next.tailStartSeq) await FileSystem.deleteAsync(`${DIR}${tailName(seq)}`, { idempotent: true }).catch(() => {});
  }
  if (session.mainFile) await FileSystem.deleteAsync(mainPath(session.mainFile), { idempotent: true }).catch(() => {});
  return next;
}

export async function clearRecording(): Promise<void> {
  await FileSystem.deleteAsync(DIR, { idempotent: true }).catch(() => {});
}
