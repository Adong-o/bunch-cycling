import { haversineDistanceM, type TrackPoint } from '@/lib/geo';
import type { RawLocationUpdate, RecordingSession, RecordingSource } from './types';

// GPS fixes worse than this are dropped before they can touch the recorded
// route — a single bad fix in a tunnel or beside tall buildings can throw
// the line and the distance total off by a surprising amount otherwise.
export const MAX_ACCEPTABLE_ACCURACY_M = 30;
// Fixes closer together than this count as stationary jitter, not distance.
export const STATIONARY_JITTER_FLOOR_M = 1;
// Auto-pause: below walking pace for a sustained stretch counts as stopped.
// Resuming needs a higher speed than pausing (hysteresis) so a rider sitting
// right at the boundary doesn't flicker between the two states.
export const AUTO_PAUSE_SPEED_MPS = 0.8; // ~2.9 km/h
export const AUTO_RESUME_SPEED_MPS = 1.5; // ~5.4 km/h
export const AUTO_PAUSE_DELAY_MS = 3000;
// A hop that implies more than this is a GPS glitch, not a rider (126 km/h —
// faster than any realistic cycling descent).
export const MAX_PLAUSIBLE_SPEED_MPS = 35;
// Fixes at or under this accuracy are a real lock; above it (but under the
// hard cutoff) reads as "weak".
export const GPS_LOCKED_ACCURACY_M = 20;

function uid(now: number): string {
  return `${now.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function createSession(nowMs: number, source: RecordingSource): RecordingSession {
  return {
    version: 1,
    id: uid(nowMs),
    startedAtMs: nowMs,
    status: 'recording',
    source,
    movingMsAccumulated: 0,
    segmentStartMs: nowMs,
    maxSpeedMps: 0,
    distanceM: 0,
    pointCount: 0,
    lastPoint: null,
    lastSpeedMps: null,
    interrupted: false,
    endedAtMs: null,
    lastSeenTimestampMs: 0,
    lastAccuracyM: null,
    lastFixArrivedAtMs: null,
    belowThresholdSinceMs: null,
    chunkSeq: 0,
    tailStartSeq: 0,
    mainFile: null,
    updatedAtMs: nowMs,
  };
}

/** Moving time right now: the closed segments plus the open one, if any. */
export function movingMsAt(session: RecordingSession, nowMs: number): number {
  if (session.status === 'recording' && session.segmentStartMs != null) {
    return session.movingMsAccumulated + Math.max(0, nowMs - session.segmentStartMs);
  }
  return session.movingMsAccumulated;
}

/**
 * Moving time for a ride recovered after the app/phone died mid-ride —
 * anchored to the last GPS fix rather than "now", so a phone that sat dead
 * in a pocket for an hour isn't credited an hour of extra moving time.
 */
export function recoveredMovingMs(session: RecordingSession): number {
  if (session.status === 'recording' && session.segmentStartMs != null) {
    const anchor = session.lastSeenTimestampMs || session.segmentStartMs;
    return session.movingMsAccumulated + Math.max(0, anchor - session.segmentStartMs);
  }
  return session.movingMsAccumulated;
}

export function pauseSession(session: RecordingSession, nowMs: number): RecordingSession {
  if (session.status === 'paused' || session.status === 'finished') return session;
  let accumulated = session.movingMsAccumulated;
  if (session.status === 'recording' && session.segmentStartMs != null) {
    accumulated += Math.max(0, nowMs - session.segmentStartMs);
  }
  return {
    ...session,
    status: 'paused',
    movingMsAccumulated: accumulated,
    segmentStartMs: null,
    belowThresholdSinceMs: null,
    updatedAtMs: nowMs,
  };
}

/** Rider tapped Finish: closes the open moving segment and freezes the ride. */
export function finishSession(session: RecordingSession, nowMs: number): RecordingSession {
  const closed = pauseSession(session, nowMs);
  return { ...closed, status: 'finished', endedAtMs: nowMs, updatedAtMs: nowMs };
}

/**
 * The OS stopped delivering GPS while a ride was recording. Closes the open
 * segment at the last fix we actually have (not "now"), so the gap is never
 * counted as moving time, and flags it so the UI can say what happened.
 */
export function interruptSession(session: RecordingSession, nowMs: number): RecordingSession {
  if (session.status !== 'recording' && session.status !== 'autoPaused') return session;
  const anchor = Math.max(session.lastSeenTimestampMs, session.segmentStartMs ?? 0, session.startedAtMs);
  const closed = pauseSession(session, Math.min(anchor, nowMs));
  return { ...closed, interrupted: true, updatedAtMs: nowMs };
}

export function resumeSession(session: RecordingSession, nowMs: number): RecordingSession {
  if (session.status === 'recording' || session.status === 'finished') return session;
  return {
    ...session,
    status: 'recording',
    interrupted: false,
    segmentStartMs: nowMs,
    belowThresholdSinceMs: null,
    lastFixArrivedAtMs: nowMs,
    updatedAtMs: nowMs,
  };
}

/** Speed for a fix: the device's own reading if it gave one, else derived from the hop. */
function resolveSpeed(u: RawLocationUpdate, prev: TrackPoint | null, hopM: number): number | null {
  if (u.speedMps != null) return u.speedMps;
  if (!prev) return null;
  const dt = (u.timestamp - prev.timestamp) / 1000;
  if (dt <= 0 || dt > 15) return null;
  return hopM / dt;
}

/**
 * The one place recording rules live: accuracy filtering, glitch rejection,
 * distance, max speed and auto-pause/resume. Pure — no I/O, no clocks — so
 * it behaves identically whether it's fed by the Record screen, the OS
 * background task, or a unit test, and so a ride can be rebuilt exactly
 * from what was persisted.
 */
export function applyUpdates(
  session: RecordingSession,
  updates: RawLocationUpdate[],
  arrivedAtMs: number
): { session: RecordingSession; accepted: TrackPoint[] } {
  if (session.status === 'paused' || session.status === 'finished' || updates.length === 0) {
    return { session, accepted: [] };
  }

  let s = { ...session };
  const accepted: TrackPoint[] = [];
  const sorted = [...updates].sort((a, b) => a.timestamp - b.timestamp);

  for (const u of sorted) {
    if (u.timestamp <= s.lastSeenTimestampMs) continue; // replay / duplicate delivery
    s.lastSeenTimestampMs = u.timestamp;
    s.lastAccuracyM = u.accuracyM;
    s.lastFixArrivedAtMs = arrivedAtMs;

    if (u.accuracyM != null && u.accuracyM > MAX_ACCEPTABLE_ACCURACY_M) continue;

    const prev = s.lastPoint;
    const hop = prev ? haversineDistanceM(prev, u) : 0;

    // Teleport guard: an implausible jump between two nearby-in-time fixes.
    if (prev) {
      const dt = (u.timestamp - prev.timestamp) / 1000;
      if (dt > 0 && dt < 120 && hop / dt > MAX_PLAUSIBLE_SPEED_MPS) continue;
    }

    const speed = resolveSpeed(u, prev, hop);
    s.lastSpeedMps = speed;

    if (s.status === 'autoPaused') {
      if (speed != null && speed >= AUTO_RESUME_SPEED_MPS) {
        // Moving again — resume for real, anchored to this fix's timestamp
        // rather than whenever the batch happened to arrive.
        s.status = 'recording';
        s.segmentStartMs = u.timestamp;
        s.belowThresholdSinceMs = null;
      } else {
        continue; // still stopped — leave the track and distance untouched
      }
    }

    const point: TrackPoint = {
      lat: u.lat,
      lng: u.lng,
      elevationM: u.elevationM,
      speedMps: speed,
      timestamp: u.timestamp,
    };
    accepted.push(point);
    s.lastPoint = point;
    s.pointCount += 1;
    if (prev && hop > STATIONARY_JITTER_FLOOR_M) s.distanceM += hop;
    if (speed != null && speed > s.maxSpeedMps && speed <= MAX_PLAUSIBLE_SPEED_MPS) s.maxSpeedMps = speed;

    // Auto-pause: a sustained stretch below walking pace closes the moving
    // segment but leaves GPS running, so this same loop can see the rider
    // moving again.
    if (s.status === 'recording' && s.segmentStartMs != null) {
      const below = speed != null && speed < AUTO_PAUSE_SPEED_MPS;
      if (below) {
        if (s.belowThresholdSinceMs == null) s.belowThresholdSinceMs = u.timestamp;
        if (u.timestamp - s.belowThresholdSinceMs >= AUTO_PAUSE_DELAY_MS) {
          s.movingMsAccumulated += Math.max(0, u.timestamp - s.segmentStartMs);
          s.segmentStartMs = null;
          s.status = 'autoPaused';
          s.belowThresholdSinceMs = null;
        }
      } else {
        s.belowThresholdSinceMs = null;
      }
    }
  }

  s.updatedAtMs = arrivedAtMs;
  return { session: s, accepted };
}

/** GPS strength indicator from the newest fix. */
export function gpsQuality(accuracyM: number | null | undefined): 'searching' | 'locked' | 'weak' {
  if (accuracyM == null) return 'searching';
  if (accuracyM <= GPS_LOCKED_ACCURACY_M) return 'locked';
  if (accuracyM <= MAX_ACCEPTABLE_ACCURACY_M) return 'weak';
  return 'searching';
}

/** Thins a long track for drawing on the map (keeps first and last). */
export function thinForDisplay<T>(points: T[], maxPoints = 1200): T[] {
  if (points.length <= maxPoints) return points;
  const step = points.length / maxPoints;
  const out: T[] = [];
  for (let i = 0; i < maxPoints; i++) out.push(points[Math.floor(i * step)]);
  out.push(points[points.length - 1]);
  return out;
}
