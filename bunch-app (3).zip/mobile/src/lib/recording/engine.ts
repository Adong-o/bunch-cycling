import * as Location from 'expo-location';
import type { TrackPoint } from '@/lib/geo';
import { isLocationTrackingActive, startLocationTracking, stopLocationTracking } from '@/lib/locationTracking';
import { freezeRideTimerNotification, refreshRideTimerNotification, startRideTimerNotification, stopRideTimerNotification } from '@/lib/rideNotification';
import { formatDuration } from '@/lib/units';
import { applyUpdates, createSession, finishSession, interruptSession, movingMsAt, pauseSession, resumeSession } from './reducer';
import * as storage from './storage';
import type { FinishedRecording, RawLocationUpdate, RecordingSession } from './types';

type Listener = () => void;

/** Fold the per-batch chunk files into the main file every this many batches. */
const COMPACT_EVERY_CHUNKS = 25;
/** In-app (foreground-source) GPS going quiet for this long means the app was suspended. */
const FOREGROUND_SOURCE_GAP_MS = 45_000;

function toRaw(loc: Location.LocationObject): RawLocationUpdate {
  return {
    lat: loc.coords.latitude,
    lng: loc.coords.longitude,
    elevationM: loc.coords.altitude,
    speedMps: loc.coords.speed != null && loc.coords.speed >= 0 ? loc.coords.speed : null,
    accuracyM: loc.coords.accuracy,
    timestamp: loc.timestamp,
  };
}

/**
 * The single owner of an in-progress ride. Everything that has to keep
 * working with the screen off lives here, with no dependency on React or any
 * mounted screen:
 *
 *  - the OS background task (recording/task.ts) and the in-app fallback watcher
 *    both feed `ingest`, which applies the recording rules and writes every
 *    batch to disk before anything else;
 *  - screens only *read* — they subscribe, and render whatever is current;
 *  - state survives the Activity being destroyed, a cold start, or the app
 *    being swiped away: `hydrate()` rebuilds from disk.
 *
 * All state-changing work is serialized through one promise chain, so a batch
 * arriving from the background task can never interleave with a pause tap.
 */
class RecordingEngine {
  private session: RecordingSession | null = null;
  private track: TrackPoint[] | null = null;
  private trackVersion = 0;
  private hydration: Promise<void> | null = null;
  private chain: Promise<unknown> = Promise.resolve();
  private listeners = new Set<Listener>();
  private watcher: Location.LocationSubscription | null = null;

  // ---- subscription (useSyncExternalStore-friendly: arrow props keep `this`) ----
  subscribe = (fn: Listener): (() => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };
  getSession = (): RecordingSession | null => this.session;
  getTrackVersion = (): number => this.trackVersion;
  getTrack = (): TrackPoint[] | null => this.track;

  private emit() {
    for (const l of [...this.listeners]) {
      try {
        l();
      } catch (e) {
        console.warn('[recording] listener failed:', e);
      }
    }
  }

  private enqueue<T>(fn: () => Promise<T>): Promise<T> {
    const run = this.chain.then(fn);
    this.chain = run.then(
      () => undefined,
      () => undefined
    );
    return run;
  }

  // ---- loading ----
  hydrate(): Promise<void> {
    if (!this.hydration) {
      this.hydration = (async () => {
        const s = await storage.readSession();
        if (s) {
          // A crash between writing a chunk and writing the session can leave
          // a chunk the session doesn't know about — never reuse its number.
          const highest = await storage.highestTailSeq();
          this.session = highest >= s.chunkSeq ? { ...s, chunkSeq: highest + 1 } : s;
        }
        this.emit();
      })().catch((e) => {
        this.hydration = null;
        throw e;
      });
    }
    return this.hydration;
  }

  /** Loads the full track from disk into memory (for the map and elevation stats). Cheap if already loaded. */
  ensureTrackLoaded(): Promise<void> {
    // Queued behind any in-flight GPS batch so a point can never fall into
    // the gap between "read the files" and "start appending to memory".
    return this.enqueue(() => this.loadTrackInner());
  }

  private async loadTrackInner(): Promise<void> {
    const s = this.session;
    if (this.track || !s) return;
    try {
      this.track = await storage.readTrack(s);
      this.trackVersion += 1;
      this.emit();
    } catch (e) {
      console.warn('[recording] could not load track:', e);
    }
  }

  // ---- the hot path ----
  ingest(updates: RawLocationUpdate[]): Promise<void> {
    return this.enqueue(async () => {
      await this.hydrate();
      const current = this.session;
      if (!current || current.status === 'paused' || current.status === 'finished') return;

      const arrivedAt = Date.now();
      const { session: next, accepted } = applyUpdates(current, updates, arrivedAt);
      let toSave = next;

      try {
        if (accepted.length > 0) {
          await storage.appendTail(next.chunkSeq, accepted);
          toSave = { ...next, chunkSeq: next.chunkSeq + 1 };
        }
      } catch (e) {
        // Disk trouble must not stop the live ride: keep it in memory.
        console.warn('[recording] could not persist a batch:', e);
      }

      if (accepted.length > 0 && this.track) {
        for (const p of accepted) this.track.push(p);
        this.trackVersion += 1;
      }
      this.session = toSave;

      try {
        await storage.writeSession(toSave);
        if (toSave.chunkSeq - toSave.tailStartSeq >= COMPACT_EVERY_CHUNKS) await this.compactNow();
      } catch (e) {
        console.warn('[recording] could not persist session:', e);
      }

      this.emit();
      this.refreshNotification();
    });
  }

  private async compactNow() {
    const s = this.session;
    if (!s) return;
    const full = this.track ?? (await storage.readTrack(s));
    this.session = await storage.compact(s, full);
  }

  // ---- lifecycle ----
  start(): Promise<RecordingSession> {
    return this.enqueue(async () => {
      await this.hydrate();
      if (this.session && this.session.status !== 'finished') {
        throw new Error('A ride is already being recorded.');
      }
      await storage.clearRecording();
      const base = createSession(Date.now(), 'background');
      await storage.writeSession(base);
      this.session = base;
      this.track = [];
      this.trackVersion += 1;
      this.emit();
      try {
        await this.startSource(base);
      } catch (e) {
        this.session = null;
        this.track = null;
        await storage.clearRecording();
        this.emit();
        throw e;
      }
      this.beginNotification();
      return this.session as RecordingSession;
    });
  }

  pause(): Promise<void> {
    return this.enqueue(async () => {
      const s = this.session;
      if (!s || s.status === 'paused' || s.status === 'finished') return;
      const next = pauseSession(s, Date.now());
      this.session = next;
      await storage.writeSession(next).catch(() => {});
      await this.stopSources();
      this.emit();
      freezeRideTimerNotification(this.notificationBody());
    });
  }

  resume(): Promise<void> {
    return this.enqueue(async () => {
      const s = this.session;
      if (!s || (s.status !== 'paused' && s.status !== 'autoPaused')) return;
      const next = resumeSession(s, Date.now());
      this.session = next;
      await storage.writeSession(next).catch(() => {});
      try {
        await this.startSource(next);
      } catch (e) {
        // Couldn't get GPS back — stay paused rather than show a clock that runs with no tracking.
        this.session = s;
        await storage.writeSession(s).catch(() => {});
        this.emit();
        throw e;
      }
      this.emit();
      this.beginNotification();
    });
  }

  /** Stops recording and freezes the ride on disk until it's saved or discarded. Returns null if there's nothing worth saving. */
  finish(): Promise<FinishedRecording | null> {
    return this.enqueue(async () => {
      const s = this.session;
      if (!s) return null;
      if (s.status === 'finished') return this.readFinished();
      await this.stopSources();
      await this.loadTrackInner();
      const now = Date.now();
      const done = finishSession(s, now);
      this.session = done;
      await storage.writeSession(done).catch(() => {});
      this.emit();
      await stopRideTimerNotification();
      return this.readFinished();
    });
  }

  private async readFinished(): Promise<FinishedRecording | null> {
    const s = this.session;
    if (!s || s.status !== 'finished') return null;
    if (!this.track) await this.loadTrackInner();
    const track = this.track ?? [];
    return {
      track: [...track],
      distanceM: s.distanceM,
      startedAtMs: s.startedAtMs,
      endedAtMs: s.endedAtMs ?? s.updatedAtMs,
      movingMs: s.movingMsAccumulated,
      maxSpeedMps: s.maxSpeedMps,
    };
  }

  /** The finished-but-not-yet-saved ride, if there is one (used to offer it again after a restart). */
  getFinished(): Promise<FinishedRecording | null> {
    return this.enqueue(async () => {
      await this.hydrate();
      return this.readFinished();
    });
  }

  /** Throws away the in-progress or finished ride, for good. */
  discard(): Promise<void> {
    return this.enqueue(async () => {
      await this.stopSources();
      await storage.clearRecording();
      this.session = null;
      this.track = null;
      this.trackVersion += 1;
      this.emit();
      await stopRideTimerNotification();
    });
  }

  /** Called once the finished ride has been saved (or queued offline) — only ever clears a *finished* ride. */
  clearFinished(): Promise<void> {
    return this.enqueue(async () => {
      await this.hydrate();
      if (this.session?.status !== 'finished') return;
      await storage.clearRecording();
      this.session = null;
      this.track = null;
      this.trackVersion += 1;
      this.emit();
    });
  }

  /**
   * Run on app start and every time the app returns to the foreground: if the
   * OS stopped delivering GPS under an active ride (a battery manager, a
   * crash), close the ride at the last real fix and flag it, so the clock
   * doesn't keep counting a gap and the rider can choose Resume or Finish.
   * If GPS is still flowing, just make sure the notification is present.
   */
  checkHealth(): Promise<void> {
    return this.enqueue(async () => {
      await this.hydrate();
      const s = this.session;
      if (!s || (s.status !== 'recording' && s.status !== 'autoPaused')) return;

      let alive: boolean;
      if (s.source === 'background') {
        alive = await isLocationTrackingActive();
      } else {
        const lastArrival = s.lastFixArrivedAtMs ?? s.startedAtMs;
        alive = this.watcher != null && Date.now() - lastArrival < FOREGROUND_SOURCE_GAP_MS;
      }

      if (!alive) {
        const next = interruptSession(s, Date.now());
        this.session = next;
        await storage.writeSession(next).catch(() => {});
        await this.stopSources();
        this.emit();
        freezeRideTimerNotification(this.notificationBody());
        return;
      }
      this.beginNotification();
    });
  }

  // ---- GPS sources ----
  private async startSource(s: RecordingSession): Promise<void> {
    if (s.source === 'background') {
      try {
        await startLocationTracking();
        return;
      } catch (e) {
        console.warn('[recording] background tracking unavailable, using in-app GPS instead:', e);
      }
    }
    await this.startForegroundWatcher();
    if (s.source !== 'foreground') {
      const next: RecordingSession = { ...s, source: 'foreground' };
      this.session = next;
      await storage.writeSession(next).catch(() => {});
    }
  }

  private async startForegroundWatcher(): Promise<void> {
    this.watcher?.remove();
    this.watcher = null;
    this.watcher = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 0 },
      (loc) => {
        void this.ingest([toRaw(loc)]);
      }
    );
  }

  private async stopSources(): Promise<void> {
    this.watcher?.remove();
    this.watcher = null;
    await stopLocationTracking();
  }

  // ---- notification ----
  private notificationBody(): string {
    const s = this.session;
    if (!s) return '';
    const t = formatDuration(Math.floor(movingMsAt(s, Date.now()) / 1000));
    if (s.status === 'paused') return s.interrupted ? `Interrupted — ${t}` : `Paused — ${t}`;
    if (s.status === 'autoPaused') return `Auto-paused — ${t}`;
    return t;
  }

  private beginNotification() {
    const s = this.session;
    if (!s || s.status === 'paused' || s.status === 'finished') return;
    void startRideTimerNotification(() => this.notificationBody());
  }

  /** Keeps the shade fresh from the background task even if JS timers are throttled. */
  private refreshNotification() {
    const s = this.session;
    if (!s || s.status === 'paused' || s.status === 'finished') return;
    refreshRideTimerNotification(this.notificationBody());
  }
}

export const recordingEngine = new RecordingEngine();
