import type { TrackPoint } from '@/lib/geo';

/** One GPS fix as delivered by the OS (background task or in-app watcher). */
export interface RawLocationUpdate {
  lat: number;
  lng: number;
  elevationM: number | null;
  speedMps: number | null;
  accuracyM: number | null;
  timestamp: number;
}

/**
 * - recording:  GPS is being tracked and the moving clock is running.
 * - paused:     the rider paused manually (GPS stopped, clock stopped).
 * - autoPaused: the rider stopped moving (red light, photo stop). GPS keeps
 *               running so riding off again resumes on its own.
 * - finished:   the rider tapped Finish. The ride stays on disk, untouched,
 *               until it has been saved (or deliberately discarded) on the
 *               summary screen — a ride is never lost by closing the app
 *               between "Finish" and "Save".
 */
export type RecordingStatus = 'recording' | 'paused' | 'autoPaused' | 'finished';

/**
 * - background: the OS location task + Android foreground service. Keeps
 *               recording with the screen off or the app in the background.
 * - foreground: in-app GPS watcher. Only used when the OS refuses the
 *               background task (permission not granted). Stops when the
 *               app is not on screen — the UI says so plainly.
 */
export type RecordingSource = 'background' | 'foreground';

/**
 * Everything needed to resume or finish a ride, small enough to rewrite to
 * disk after every GPS batch. The (large) list of track points lives in
 * separate chunk files — see storage.ts.
 */
export interface RecordingSession {
  version: 1;
  id: string;
  startedAtMs: number;
  status: RecordingStatus;
  source: RecordingSource;
  movingMsAccumulated: number;
  /** Wall-clock start of the current moving segment; null while paused. */
  segmentStartMs: number | null;
  maxSpeedMps: number;
  distanceM: number;
  /** Accepted points so far (excludes fixes dropped as inaccurate / while auto-paused). */
  pointCount: number;
  lastPoint: TrackPoint | null;
  /** Speed of the newest fix seen (accepted or not), for the live speed readout. */
  lastSpeedMps: number | null;
  /** True when the OS stopped delivering GPS while the rider was recording (battery manager, crash). */
  interrupted: boolean;
  /** Set when the rider finishes. */
  endedAtMs: number | null;
  /** Timestamp of the newest fix seen at all (accepted or not) — used to ignore replays. */
  lastSeenTimestampMs: number;
  /** Accuracy of the newest fix seen, for the GPS-strength indicator. */
  lastAccuracyM: number | null;
  /** Wall-clock time the newest fix *arrived*, for "GPS signal lost" detection. */
  lastFixArrivedAtMs: number | null;
  belowThresholdSinceMs: number | null;
  /** Next tail chunk number to write. */
  chunkSeq: number;
  /** First tail chunk not yet folded into the main file. */
  tailStartSeq: number;
  /** Which main file currently holds the compacted points (alternates a/b). */
  mainFile: 'a' | 'b' | null;
  updatedAtMs: number;
}

export interface FinishedRecording {
  track: TrackPoint[];
  distanceM: number;
  startedAtMs: number;
  endedAtMs: number;
  movingMs: number;
  maxSpeedMps: number;
}

export type { TrackPoint };
