import { useEffect, useRef, useState } from 'react';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * A live, always-updating view of where the phone is and which way it's
 * facing — the thing that keeps the Record map *moving* instead of sitting
 * wherever it first loaded. Separate from the recording engine on purpose:
 * this is purely for display (1 Hz position + compass heading, only while
 * a screen is on), whereas the engine owns what actually gets recorded and
 * keeps working with the screen off.
 */
export interface LiveLocation {
  coords: { lat: number; lng: number } | null;
  accuracyM: number | null;
  speedMps: number | null;
  /** Which way the phone is facing (compass), degrees, 0 = north. Smoothed. */
  headingDeg: number | null;
  /** Direction of travel from GPS, degrees — only meaningful while moving. */
  courseDeg: number | null;
  updatedAt: number | null;
  permission: 'checking' | 'granted' | 'denied';
}

const LAST_KEY = 'bunch:lastLocation:v1';
const HEADING_ALPHA = 0.3;
const HEADING_MIN_DELTA = 2;
const HEADING_MAX_HZ = 6;

function shortestDelta(from: number, to: number): number {
  return ((to - from + 540) % 360) - 180;
}

/** Last place the phone was seen, so the map can open on the right city instantly instead of the middle of the ocean. */
export async function loadLastKnownCoords(): Promise<{ lat: number; lng: number } | null> {
  try {
    const raw = await AsyncStorage.getItem(LAST_KEY);
    if (raw) {
      const p = JSON.parse(raw) as { lat: number; lng: number };
      if (Number.isFinite(p.lat) && Number.isFinite(p.lng)) return p;
    }
  } catch {
    /* fall through */
  }
  try {
    const last = await Location.getLastKnownPositionAsync();
    if (last) return { lat: last.coords.latitude, lng: last.coords.longitude };
  } catch {
    /* no cached position either */
  }
  return null;
}

export function useLiveLocation(enabled: boolean): LiveLocation {
  const [state, setState] = useState<LiveLocation>({
    coords: null,
    accuracyM: null,
    speedMps: null,
    headingDeg: null,
    courseDeg: null,
    updatedAt: null,
    permission: 'checking',
  });
  const headingRef = useRef<number | null>(null);
  const lastHeadingEmitRef = useRef(0);
  const lastSavedRef = useRef(0);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    let posSub: Location.LocationSubscription | null = null;
    let headSub: Location.LocationSubscription | null = null;

    (async () => {
      const perm = await Location.getForegroundPermissionsAsync().catch(() => null);
      if (cancelled) return;
      if (!perm?.granted) {
        setState((s) => ({ ...s, permission: 'denied' }));
        return;
      }
      setState((s) => ({ ...s, permission: 'granted' }));

      // Show *something* immediately: the cached position, then the OS's last fix.
      const cached = await loadLastKnownCoords();
      if (cancelled) return;
      if (cached) setState((s) => (s.coords ? s : { ...s, coords: cached }));

      try {
        posSub = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 0 },
          (loc) => {
            const course = loc.coords.heading != null && loc.coords.heading >= 0 ? loc.coords.heading : null;
            setState((s) => ({
              ...s,
              coords: { lat: loc.coords.latitude, lng: loc.coords.longitude },
              accuracyM: loc.coords.accuracy,
              speedMps: loc.coords.speed != null && loc.coords.speed >= 0 ? loc.coords.speed : null,
              courseDeg: course,
              updatedAt: loc.timestamp,
            }));
            const now = Date.now();
            if (now - lastSavedRef.current > 15000) {
              lastSavedRef.current = now;
              AsyncStorage.setItem(LAST_KEY, JSON.stringify({ lat: loc.coords.latitude, lng: loc.coords.longitude })).catch(() => {});
            }
          }
        );
        if (cancelled) posSub.remove();
      } catch {
        /* GPS unavailable — the screen keeps showing the cached position */
      }

      try {
        headSub = await Location.watchHeadingAsync((h) => {
          const raw = h.trueHeading != null && h.trueHeading >= 0 ? h.trueHeading : h.magHeading;
          if (raw == null || raw < 0) return;
          const prev = headingRef.current;
          const next = prev == null ? raw : (prev + HEADING_ALPHA * shortestDelta(prev, raw) + 360) % 360;
          headingRef.current = next;
          const now = Date.now();
          if (now - lastHeadingEmitRef.current < 1000 / HEADING_MAX_HZ) return;
          setState((s) => {
            if (s.headingDeg != null && Math.abs(shortestDelta(s.headingDeg, next)) < HEADING_MIN_DELTA) return s;
            lastHeadingEmitRef.current = now;
            return { ...s, headingDeg: next };
          });
        });
        if (cancelled) headSub.remove();
      } catch {
        /* no compass on this device — heading-up simply falls back to course */
      }
    })();

    return () => {
      cancelled = true;
      posSub?.remove();
      headSub?.remove();
    };
  }, [enabled]);

  return state;
}
