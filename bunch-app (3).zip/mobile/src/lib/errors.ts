/**
 * Supabase/PostgREST throws plain `{ message, details, hint, code }` objects
 * — not real `Error` instances — so pulling a readable message out of
 * "whatever got thrown" needs to handle that shape explicitly.
 */
export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === 'object' && error !== null && 'message' in error) {
    const msg = (error as { message?: unknown }).message;
    if (typeof msg === 'string') return msg;
  }
  return 'Something went wrong. Please try again.';
}

/** True when the error is one of our free-plan-limit triggers (see schema.sql section 4). */
export function isPlanLimitError(error: unknown): boolean {
  return /free plan is limited|join at least 2 challenges|only bunch admins/i.test(getErrorMessage(error));
}
