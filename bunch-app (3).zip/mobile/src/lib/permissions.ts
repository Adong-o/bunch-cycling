import * as Location from 'expo-location';

export type PermState = 'undetermined' | 'granted' | 'denied';

/**
 * Collapses an expo-location permission result into a simple 3-state UI
 * value. Shared between onboarding's PermissionsSetupScreen and the
 * Settings screen (where riders can revisit the same permissions later)
 * so both stay in sync with a single definition of "denied forever" vs.
 * "not asked yet".
 */
export function toPermState(result: { granted: boolean; status: Location.PermissionStatus; canAskAgain: boolean }): PermState {
  if (result.granted) return 'granted';
  if (result.status === Location.PermissionStatus.DENIED && !result.canAskAgain) return 'denied';
  return 'undetermined';
}
