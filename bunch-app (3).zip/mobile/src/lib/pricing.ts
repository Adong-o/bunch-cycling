// Single source of truth for Bunch Premium's price, so the paywall, the
// sign-up screen's teaser line, and the Terms of Service can never quote
// three different numbers. Mirrored on the website at
// website/src/lib/constants.ts — keep the two in sync by hand (separate
// apps, no shared package), and bump PREMIUM_LAST_UPDATED-style comments
// here if that ever changes.
export const PREMIUM_MONTHLY_PRICE = '$4.99';
// 12 x $4.99 = $59.88; 8% off, rounded to the cent = $55.09.
export const PREMIUM_YEARLY_PRICE = '$55.09';
export const PREMIUM_YEARLY_DISCOUNT = '8%';
