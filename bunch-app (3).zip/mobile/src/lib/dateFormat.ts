import { format, isToday, isYesterday } from 'date-fns';

/**
 * "Today at 7:15 AM" / "Yesterday at 2:30 PM" / "Mon, Oct 19 at 6:00 AM" —
 * the escalating-precision pattern Strava/Instagram use for an activity's
 * timestamp: exact time of day always shown (not just "3 hours ago"), with
 * the date collapsing to "Today"/"Yesterday" while that's still the more
 * useful read, and a real calendar date once it isn't. Used on both the
 * feed card and the ride detail screen so a ride reads the same timestamp
 * wherever it appears.
 */
export function formatRideTimestamp(iso: string): string {
  const date = new Date(iso);
  const time = format(date, 'h:mm a');
  if (isToday(date)) return `Today at ${time}`;
  if (isYesterday(date)) return `Yesterday at ${time}`;
  return `${format(date, 'EEE, MMM d')} at ${time}`;
}
