import type { Profile, Ride, TablesInsert } from '@/lib/database.types';
import { createRide, syncStreak } from '@/lib/api/rides';
import { matchAndRecordEfforts, type SegmentEffortResult } from '@/lib/api/segments';
import { listMyBadges } from '@/lib/api/badges';
import { addRideTags } from '@/lib/api/social';
import type { TrackPoint } from '@/lib/geo';

export interface SaveRideResult {
  ride: Ride;
  newBadgeNames: string[];
  newPRs: SegmentEffortResult[];
}

/**
 * Saves a finished ride and runs every best-effort follow-up that belongs
 * right after it: segment-effort matching, streak sync, "rode with"
 * tagging, badge diffing. Factored out of RideSummaryScreen so syncManager
 * can run the exact same sequence when it uploads a ride that was queued
 * offline (see rideOutbox.ts) instead of a second, hand-copied version
 * drifting out of sync with this one over time.
 */
export async function saveRideWithFollowUps(
  profile: Profile,
  payload: TablesInsert<'rides'>,
  trackJSON: string,
  taggedRiderIds: string[] = []
): Promise<SaveRideResult> {
  const beforeBadgeIds = new Set((await listMyBadges(profile.id).catch(() => [])).map((b) => b.badge_id));

  const ride = await createRide(payload);

  // Best-effort follow-up work. The ride itself is already safely saved at
  // this point, so a hiccup in any of these shouldn't block the rider or
  // surface a scary error for something secondary.
  let newPRs: SegmentEffortResult[] = [];
  try {
    const track = JSON.parse(trackJSON) as TrackPoint[];
    const effortResults = await matchAndRecordEfforts(profile.id, ride.id, track);
    newPRs = effortResults.filter((r) => r.isPR);
  } catch {
    // ignore
  }
  try {
    await syncStreak(profile);
  } catch {
    // ignore
  }
  try {
    if (taggedRiderIds.length > 0) {
      await addRideTags(ride.id, taggedRiderIds, profile.id);
    }
  } catch {
    // ignore — the ride itself is already saved either way
  }

  let newBadgeNames: string[] = [];
  try {
    const afterBadges = await listMyBadges(profile.id);
    newBadgeNames = afterBadges.filter((b) => !beforeBadgeIds.has(b.badge_id)).map((b) => b.badge.name);
  } catch {
    // ignore
  }

  return { ride, newBadgeNames, newPRs };
}
