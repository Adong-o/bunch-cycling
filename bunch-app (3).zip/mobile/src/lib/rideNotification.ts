import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

/**
 * The persistent "Bunch is recording" notification shown in the system
 * notification bar for the whole time a ride is active — separate from (and
 * in addition to) the plain foreground-service notification
 * startLocationTracking() in locationTracking.ts puts up to keep Android
 * legally allowed to track location in the background. That one has to
 * exist for the OS's sake and says the same static thing the whole ride;
 * this one is the actual user-facing ask: the app's name and icon in the
 * shade, with a live hours:minutes:seconds count while the ride is going.
 *
 * Android: ticks for real, once a second, by re-presenting a notification
 * with the same `identifier` — expo-notifications updates a notification
 * with a matching identifier in place rather than stacking a new one, which
 * is the standard, documented way to drive a "live" ongoing notification
 * without native code. iOS deliberately does NOT get a per-second ticking
 * notification: repeatedly re-posting a local notification isn't how iOS
 * surfaces an ongoing activity (that's what Live Activities are for, which
 * need their own native WidgetKit extension — out of scope for this
 * Expo-managed codebase; see the README). iOS riders still get the OS's own
 * blue "background location in use" status-bar pill automatically, with no
 * code needed — see showsBackgroundLocationIndicator in locationTracking.ts
 * — and this module posts a single, non-repeating notification there
 * instead, mirroring what most iOS fitness apps do.
 */

const NOTIFICATION_ID = 'bunch-ride-timer';
const CHANNEL_ID = 'ride-recording';

let tickTimer: ReturnType<typeof setInterval> | null = null;
let permissionChecked = false;
let havePermission = false;

async function ensureReady(): Promise<boolean> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
      name: 'Ride recording',
      description: 'The ongoing timer shown while Bunch is recording a ride.',
      // LOW: visible and persistent, but no sound/heads-up popup on every
      // per-second update — this is an ambient status, not an alert.
      importance: Notifications.AndroidImportance.LOW,
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      showBadge: false,
    }).catch(() => {});
  }

  if (permissionChecked) return havePermission;
  try {
    const current = await Notifications.getPermissionsAsync();
    havePermission = current.granted || current.status === 'granted';
    if (!havePermission) {
      const requested = await Notifications.requestPermissionsAsync();
      havePermission = requested.granted || requested.status === 'granted';
    }
  } catch {
    havePermission = false;
  }
  permissionChecked = true;
  return havePermission;
}

function present(body: string) {
  Notifications.scheduleNotificationAsync({
    identifier: NOTIFICATION_ID,
    content: {
      title: 'Bunch — recording your ride',
      body,
      sticky: true,
      autoDismiss: false,
      ...(Platform.OS === 'android' ? { channelId: CHANNEL_ID } : {}),
    },
    trigger: null,
  }).catch((e) => {
    console.warn('[rideNotification] failed to present:', e);
  });
}

/**
 * Starts (or restarts) the ticking notification. `getBody` is called once a
 * second and returns the text to show (the recording engine passes the same
 * moving time the on-screen clock reads, so the two never disagree, plus a
 * "Paused"/"Auto-paused" prefix when relevant).
 */
export async function startRideTimerNotification(getBody: () => string): Promise<void> {
  const ok = await ensureReady();
  if (tickTimer) {
    clearInterval(tickTimer);
    tickTimer = null;
  }
  if (!ok) return; // no permission granted — recording itself is unaffected, there's just no visible timer

  const tick = () => present(getBody());
  tick();

  if (Platform.OS === 'android') {
    // Only Android gets a real per-second tick — see the module comment.
    tickTimer = setInterval(tick, 1000);
  }
}

/** Freezes the notification on the given text (manual pause) and stops the per-second tick. */
export function freezeRideTimerNotification(body: string): void {
  if (tickTimer) {
    clearInterval(tickTimer);
    tickTimer = null;
  }
  present(body);
}

/** One immediate refresh without touching the tick timer — used when a background batch arrives and JS timers may be throttled. */
export function refreshRideTimerNotification(body: string): void {
  if (Platform.OS === 'android') present(body);
}

export async function stopRideTimerNotification(): Promise<void> {
  if (tickTimer) {
    clearInterval(tickTimer);
    tickTimer = null;
  }
  await Notifications.dismissNotificationAsync(NOTIFICATION_ID).catch(() => {});
}
