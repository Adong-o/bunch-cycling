import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import type { Ride } from './database.types';

function xmlEscape(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Builds a GPX 1.1 file string from a saved ride's route_geojson. */
export function buildGPX(ride: Ride): string {
  const coords = ride.route_geojson?.coordinates ?? [];
  const startedAt = new Date(ride.started_at);
  const totalMs = new Date(ride.ended_at).getTime() - startedAt.getTime();
  const stepMs = coords.length > 1 ? totalMs / (coords.length - 1) : 0;

  const trkpts = coords
    .map(([lng, lat, ele], i) => {
      const t = new Date(startedAt.getTime() + stepMs * i).toISOString();
      const eleTag = ele != null ? `<ele>${ele.toFixed(1)}</ele>` : '';
      return `      <trkpt lat="${lat.toFixed(6)}" lon="${lng.toFixed(6)}">${eleTag}<time>${t}</time></trkpt>`;
    })
    .join('\n');

  const title = xmlEscape(ride.title || 'Bunch ride');

  return `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="Bunch" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>${title}</name>
    <time>${startedAt.toISOString()}</time>
  </metadata>
  <trk>
    <name>${title}</name>
    <trkseg>
${trkpts}
    </trkseg>
  </trk>
</gpx>`;
}

/** Writes the ride's GPX to a temp file and opens the native share sheet. */
export async function exportRideAsGPX(ride: Ride): Promise<void> {
  const gpx = buildGPX(ride);
  const safeName = (ride.title || 'ride').replace(/[^a-z0-9]+/gi, '-').toLowerCase();
  const fileUri = `${FileSystem.cacheDirectory}${safeName}-${ride.id.slice(0, 8)}.gpx`;

  await FileSystem.writeAsStringAsync(fileUri, gpx, { encoding: FileSystem.EncodingType.UTF8 });

  const canShare = await Sharing.isAvailableAsync();
  if (!canShare) {
    throw new Error('Sharing is not available on this device.');
  }
  await Sharing.shareAsync(fileUri, { mimeType: 'application/gpx+xml', dialogTitle: `Export "${ride.title || 'ride'}"` });
}
