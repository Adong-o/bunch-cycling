import * as Location from 'expo-location';
import { colors } from '@/theme';

/**
 * Starts/stops the OS-level background location task that records a ride.
 * The task body itself lives in recording/task.ts (it must be registered at
 * JS-bundle load, including the headless start the OS performs to deliver a
 * background batch — see the side-effect import at the top of App.tsx). Every
 * fix it receives goes straight into the recording engine, which writes it to
 * disk, so a ride keeps recording with the screen off, the app backgrounded,
 * or even the Activity destroyed — no screen has to be mounted.
 */
export const LOCATION_TRACKING_TASK = 'bunch-location-tracking';

/** Starts (or no-ops if already running) the background-capable GPS task used while a ride is recording. */
export async function startLocationTracking(): Promise<void> {
  const alreadyStarted = await Location.hasStartedLocationUpdatesAsync(LOCATION_TRACKING_TASK).catch(() => false);
  if (alreadyStarted) return;

  await Location.startLocationUpdatesAsync(LOCATION_TRACKING_TASK, {
    accuracy: Location.Accuracy.BestForNavigation,
    timeInterval: 1000,
    // No distanceInterval filter: on Android it throttles the sample rate
    // hard when fixes are coarsest (exactly when a clean route needs the
    // most points), so timeInterval alone paces sampling.
    distanceInterval: 0,
    // Deliver fixes as they happen rather than letting the OS batch them
    // up for minutes — a live map and timer need them promptly.
    deferredUpdatesInterval: 0,
    deferredUpdatesDistance: 0,
    pausesUpdatesAutomatically: false,
    showsBackgroundLocationIndicator: true,
    activityType: Location.ActivityType.Fitness,
    foregroundService: {
      notificationTitle: 'Bunch is recording your ride',
      notificationBody: 'Tap to return to the app.',
      notificationColor: colors.accent,
      // false, deliberately: true tears the foreground service down the
      // moment a rider swipes Bunch away from recent apps — which people do
      // absent-mindedly mid-ride without meaning to stop recording.
      killServiceOnDestroy: false,
    },
  });
}

export async function stopLocationTracking(): Promise<void> {
  const started = await Location.hasStartedLocationUpdatesAsync(LOCATION_TRACKING_TASK).catch(() => false);
  if (started) {
    await Location.stopLocationUpdatesAsync(LOCATION_TRACKING_TASK).catch(() => {});
  }
}

/** Whether the OS background task is actually running — distinct from any React state, which can't see a battery manager killing the native task underneath it. */
export async function isLocationTrackingActive(): Promise<boolean> {
  return Location.hasStartedLocationUpdatesAsync(LOCATION_TRACKING_TASK).catch(() => false);
}

export async function hasForegroundLocationPermission(): Promise<boolean> {
  const { granted } = await Location.getForegroundPermissionsAsync();
  return granted;
}
