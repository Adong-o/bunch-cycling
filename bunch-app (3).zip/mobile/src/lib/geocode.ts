import * as Location from 'expo-location';

/**
 * Turns GPS coordinates into a short human-readable place name ("Boulder,
 * Colorado") for a ride's start location — shown on the feed card and ride
 * detail screen. Purely cosmetic, so any failure (permission revoked since
 * recording started, offline, no result from the OS geocoder) resolves to
 * null rather than throwing: a ride must never fail to save because this
 * didn't work. Runs once, at save time, via the platform's own geocoder —
 * not on every render, and not during active recording, so it has no
 * bearing on offline tracking (see locationTracking.ts for that guarantee).
 */
export async function reverseGeocodeStart(latitude: number, longitude: number): Promise<string | null> {
  try {
    const { granted } = await Location.getForegroundPermissionsAsync();
    if (!granted) return null;

    const [place] = await Location.reverseGeocodeAsync({ latitude, longitude });
    if (!place) return null;

    const locality = place.city || place.subregion || place.district || null;
    const region = place.region || null;
    if (locality && region && locality !== region) return `${locality}, ${region}`;
    return locality || region || place.country || null;
  } catch {
    return null;
  }
}
