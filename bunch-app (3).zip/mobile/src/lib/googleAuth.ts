import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import { supabase } from './supabase';
import { parseAuthRedirect } from './authRedirect';

// Required once per app so a dismissed in-app browser session hands control
// back to this module instead of leaving a hung promise on iOS — Expo's own
// documented requirement for the WebBrowser + OAuth redirect pattern. Safe
// at module scope: it runs once, the first time this file is imported
// (AuthScreen imports it eagerly), which is early enough to matter.
WebBrowser.maybeCompleteAuthSession();

// Supabase's redirect lands back in the app at this URL — resolves to
// `bunch://auth-callback` in a real build (the `bunch` scheme is set in
// app.config.ts). This exact string has to be added to Supabase's
// Authentication -> URL Configuration -> Redirect URLs allowlist, or the
// redirect gets rejected before it ever reaches the app. See the root
// README's "Before you charge anyone real money" section.
const REDIRECT_URL = Linking.createURL('auth-callback');

/**
 * "Continue with Google" for Expo + Supabase. Supabase hosts the actual
 * OAuth exchange — it already knows the Google Client ID/Secret once
 * they're configured in its dashboard — so this app never touches Google
 * credentials directly. It only opens Supabase's own authorize URL in an
 * in-app browser tab, waits for the redirect back into the app, and hands
 * the session tokens that redirect carries to supabase.auth.setSession().
 *
 * Needs two one-time dashboard steps the Bunch team has to do themselves
 * (a Google Cloud OAuth client + enabling Supabase's Google provider — see
 * the root README). Until that's done, Supabase responds with a clear
 * "provider is not enabled" error, which surfaces through the thrown Error
 * the same way a bad password does on the sign-in form — not a crash or a
 * silent hang.
 */
export async function signInWithGoogle(): Promise<void> {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: REDIRECT_URL, skipBrowserRedirect: true },
  });
  if (error) throw error;
  if (!data?.url) throw new Error('Could not start Google sign-in — try again.');

  const result = await WebBrowser.openAuthSessionAsync(data.url, REDIRECT_URL);

  if (result.type === 'cancel' || result.type === 'dismiss') {
    return; // the rider closed the browser themselves — not an error, just no-op
  }
  if (result.type !== 'success' || !result.url) {
    throw new Error("Google sign-in didn't complete — try again.");
  }

  const { accessToken, refreshToken, errorDescription } = parseAuthRedirect(result.url);
  if (errorDescription) throw new Error(errorDescription);
  if (!accessToken || !refreshToken) {
    throw new Error("Google sign-in didn't return a session — try again.");
  }

  const { error: sessionError } = await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
  if (sessionError) throw sessionError;
  // On success, the auth store's onAuthStateChange listener takes it from
  // here, same as email/password sign-in.
}
