import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import { supabase } from './supabase';
import { reverseGeocodeStart } from './geocode';
import { elevationGainLoss, haversineDistanceM, pointsToGeoJSON, totalDistanceM, type TrackPoint } from './geo';
import type { Ride, RideVisibility, RouteGeoJSON, TablesInsert } from './database.types';

export interface ParsedImportedRide {
  title: string;
  startedAt: string; // ISO
  endedAt: string; // ISO
  distanceM: number;
  elevationGainM: number;
  elevationLossM: number;
  avgSpeedMps: number;
  maxSpeedMps: number;
  movingTimeS: number;
  elapsedTimeS: number;
  routeGeoJSON: RouteGeoJSON;
}

interface RawPoint {
  lat: number;
  lng: number;
  elevationM: number | null;
  timestamp: number; // ms epoch
}

// No XML parser is available in this sandbox (no npm registry access, and
// React Native has no built-in DOMParser) — same "hand-built strings, no
// library" approach this app already uses in the other direction, in
// gpxExport.ts. Real-world GPX/TCX exports from Strava, Garmin, Wahoo etc.
// are consistent enough in attribute/tag order for this to be reliable.

function parseGPX(content: string): RawPoint[] {
  const points: RawPoint[] = [];
  const trkptRe = /<trkpt[^>]*\slat="([^"]+)"[^>]*\slon="([^"]+)"[^>]*>([\s\S]*?)<\/trkpt>/g;
  let m: RegExpExecArray | null;
  while ((m = trkptRe.exec(content)) !== null) {
    const lat = parseFloat(m[1]);
    const lng = parseFloat(m[2]);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;

    const inner = m[3];
    const timeMatch = /<time>([^<]*)<\/time>/.exec(inner);
    const timestamp = timeMatch ? Date.parse(timeMatch[1]) : NaN;
    if (!Number.isFinite(timestamp)) continue; // need a real timestamp to compute duration/speed

    const eleMatch = /<ele>([^<]*)<\/ele>/.exec(inner);
    const elevationM = eleMatch ? parseFloat(eleMatch[1]) : NaN;

    points.push({ lat, lng, elevationM: Number.isFinite(elevationM) ? elevationM : null, timestamp });
  }
  return points;
}

function parseTCX(content: string): RawPoint[] {
  const points: RawPoint[] = [];
  const tpRe = /<Trackpoint>([\s\S]*?)<\/Trackpoint>/g;
  let m: RegExpExecArray | null;
  while ((m = tpRe.exec(content)) !== null) {
    const inner = m[1];
    const latMatch = /<LatitudeDegrees>([^<]*)<\/LatitudeDegrees>/.exec(inner);
    const lngMatch = /<LongitudeDegrees>([^<]*)<\/LongitudeDegrees>/.exec(inner);
    if (!latMatch || !lngMatch) continue; // e.g. a paused/indoor lap with no <Position>

    const lat = parseFloat(latMatch[1]);
    const lng = parseFloat(lngMatch[1]);
    const timeMatch = /<Time>([^<]*)<\/Time>/.exec(inner);
    const timestamp = timeMatch ? Date.parse(timeMatch[1]) : NaN;
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || !Number.isFinite(timestamp)) continue;

    const eleMatch = /<AltitudeMeters>([^<]*)<\/AltitudeMeters>/.exec(inner);
    const elevationM = eleMatch ? parseFloat(eleMatch[1]) : NaN;

    points.push({ lat, lng, elevationM: Number.isFinite(elevationM) ? elevationM : null, timestamp });
  }
  return points;
}

function detectFormat(content: string, fileName: string): 'gpx' | 'tcx' | null {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.gpx')) return 'gpx';
  if (lower.endsWith('.tcx')) return 'tcx';
  if (content.includes('<gpx')) return 'gpx';
  if (content.includes('<TrainingCenterDatabase')) return 'tcx';
  return null;
}

function titleFromFileName(fileName: string): string {
  const base = fileName.replace(/\.(gpx|tcx)$/i, '');
  const spaced = base.replace(/[-_]+/g, ' ').trim();
  if (!spaced) return 'Imported ride';
  return spaced.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
}

/** Parses a GPX or TCX file's raw text into ride stats + route. Throws a user-readable Error on anything unparseable. */
export function parseImportFile(fileContent: string, fileName: string): ParsedImportedRide {
  const format = detectFormat(fileContent, fileName);
  if (!format) {
    throw new Error("This file doesn't look like a GPX or TCX file.");
  }

  const rawPoints = (format === 'gpx' ? parseGPX(fileContent) : parseTCX(fileContent)).sort((a, b) => a.timestamp - b.timestamp);
  if (rawPoints.length < 2) {
    throw new Error("This file doesn't contain a valid GPS track.");
  }

  // Reuse the exact same distance/elevation math as a GPS-recorded ride, so
  // an imported ride's numbers are computed consistently with every other
  // ride in the app rather than trusting whatever total the source app embedded.
  const trackPoints: TrackPoint[] = rawPoints.map((p) => ({ lat: p.lat, lng: p.lng, elevationM: p.elevationM, timestamp: p.timestamp }));
  const distanceM = totalDistanceM(trackPoints);
  const { gain, loss } = elevationGainLoss(trackPoints);

  const first = rawPoints[0];
  const last = rawPoints[rawPoints.length - 1];
  // An imported file has no "paused" concept, so moving time == elapsed time.
  const elapsedS = Math.max(1, Math.round((last.timestamp - first.timestamp) / 1000));
  const avgSpeedMps = distanceM / elapsedS;

  let maxSpeedMps = 0;
  for (let i = 1; i < rawPoints.length; i++) {
    const dt = (rawPoints[i].timestamp - rawPoints[i - 1].timestamp) / 1000;
    if (dt <= 0) continue; // guard duplicate/out-of-order timestamps rather than divide by zero
    const speed = haversineDistanceM(rawPoints[i - 1], rawPoints[i]) / dt;
    if (speed > maxSpeedMps) maxSpeedMps = speed;
  }

  return {
    title: titleFromFileName(fileName),
    startedAt: new Date(first.timestamp).toISOString(),
    endedAt: new Date(last.timestamp).toISOString(),
    distanceM,
    elevationGainM: gain,
    elevationLossM: loss,
    avgSpeedMps,
    maxSpeedMps,
    movingTimeS: elapsedS,
    elapsedTimeS: elapsedS,
    routeGeoJSON: pointsToGeoJSON(trackPoints),
  };
}

/** Opens the native document picker, reads the picked file, and parses it. Returns null if the user cancels. */
export async function pickImportFile(): Promise<{ parsed: ParsedImportedRide; fileName: string } | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
  if (result.canceled || !result.assets?.[0]) return null;

  const asset = result.assets[0];
  const fileName = asset.name ?? 'ride';
  const content = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.UTF8 });
  const parsed = parseImportFile(content, fileName); // throws a clear, user-readable Error for an unrecognizable file
  return { parsed, fileName };
}

/** Saves a parsed import as a real ride row, owned by userId. */
export async function saveImportedRide(
  userId: string,
  parsed: ParsedImportedRide,
  overrides?: { title?: string; visibility?: RideVisibility; recordingDeviceId?: string | null }
): Promise<Ride> {
  const coords = parsed.routeGeoJSON.coordinates;
  const first = coords[0];
  const last = coords[coords.length - 1];

  // Best-effort, same as a live-recorded ride — an imported ride that
  // can't be reverse-geocoded (offline, rate-limited) still saves fine,
  // it just won't show a location on the feed card.
  const startLocationName = first ? await reverseGeocodeStart(first[1], first[0]) : null;

  const payload: TablesInsert<'rides'> = {
    user_id: userId,
    title: overrides?.title?.trim() || parsed.title,
    description: '',
    visibility: overrides?.visibility ?? 'public',
    source: 'import',
    is_indoor: false,
    started_at: parsed.startedAt,
    ended_at: parsed.endedAt,
    moving_time_s: parsed.movingTimeS,
    elapsed_time_s: parsed.elapsedTimeS,
    distance_m: parsed.distanceM,
    elevation_gain_m: parsed.elevationGainM,
    elevation_loss_m: parsed.elevationLossM,
    avg_speed_mps: parsed.avgSpeedMps,
    max_speed_mps: parsed.maxSpeedMps,
    start_lat: first?.[1] ?? null,
    start_lng: first?.[0] ?? null,
    end_lat: last?.[1] ?? null,
    end_lng: last?.[0] ?? null,
    start_location_name: startLocationName,
    route_geojson: parsed.routeGeoJSON,
    photo_urls: [],
    recording_device_id: overrides?.recordingDeviceId ?? null,
  };

  const { data, error } = await supabase.from('rides').insert(payload).select('*').single();
  if (error) throw error;
  return data;
}
