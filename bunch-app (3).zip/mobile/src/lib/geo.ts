import type { RouteGeoJSON } from './database.types';

export interface TrackPoint {
  lat: number;
  lng: number;
  elevationM?: number | null;
  speedMps?: number | null;
  timestamp: number; // ms epoch
}

const EARTH_RADIUS_M = 6371000;

/** Great-circle distance between two points, in meters. */
export function haversineDistanceM(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);

  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_M * Math.asin(Math.min(1, Math.sqrt(h)));
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

/** Total path distance over a sequence of points, in meters. */
export function totalDistanceM(points: TrackPoint[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i++) {
    total += haversineDistanceM(points[i - 1], points[i]);
  }
  return total;
}

/**
 * Elevation gain/loss from a recorded track.
 *
 * Phone GPS altitude is noisy (a few metres, wandering slowly), so two things
 * are needed, and getting either wrong is very visible to a cyclist:
 *
 *  1. Smooth with a moving average (`smoothWindow` fixes — about 11 s on a 1 Hz
 *     recording) to take the jitter off the individual fixes.
 *  2. Accumulate with a dead-band ("hysteresis"): a rise or fall only counts
 *     once the smoothed altitude has moved at least `stepThresholdM` away from
 *     the last level that was counted, and the reference then jumps to it.
 *
 * Do NOT sum the per-fix deltas that clear a threshold instead: at 1 Hz a 6 %
 * climb changes altitude by only ~0.3 m per fix, so no single step ever clears
 * the threshold and a whole hilly ride reports ~0 m of climbing. The dead-band
 * version recovers ~96 % of the true climb on noisy data while keeping the
 * phantom gain on a flat road to a few tens of metres per hour.
 */
export function elevationGainLoss(points: TrackPoint[], stepThresholdM = 4, smoothWindow = 11): { gain: number; loss: number } {
  const raw = points.map((p) => p.elevationM).filter((e): e is number => e != null);
  if (raw.length < 2) return { gain: 0, loss: 0 };

  const before = Math.floor(smoothWindow / 2);
  const after = Math.ceil(smoothWindow / 2);
  // Sliding-window mean in O(n) (this runs on every GPS batch while recording).
  const prefix: number[] = [0];
  for (const v of raw) prefix.push(prefix[prefix.length - 1] + v);
  const smoothed: number[] = raw.map((_, i) => {
    const start = Math.max(0, i - before);
    const end = Math.min(raw.length, i + after);
    return (prefix[end] - prefix[start]) / (end - start);
  });

  let gain = 0;
  let loss = 0;
  let ref = smoothed[0];
  for (let i = 1; i < smoothed.length; i++) {
    const delta = smoothed[i] - ref;
    if (delta >= stepThresholdM) {
      gain += delta;
      ref = smoothed[i];
    } else if (delta <= -stepThresholdM) {
      loss += -delta;
      ref = smoothed[i];
    }
  }

  return { gain: Math.round(gain), loss: Math.round(loss) };
}

export function pointsToGeoJSON(points: TrackPoint[]): RouteGeoJSON {
  return {
    type: 'LineString',
    coordinates: points.map((p) => (p.elevationM != null ? [p.lng, p.lat, p.elevationM] : [p.lng, p.lat])),
  };
}

export function geoJSONToCoordinates(geojson: RouteGeoJSON | null | undefined): Array<[number, number]> {
  if (!geojson?.coordinates) return [];
  return geojson.coordinates.map((c) => [c[0], c[1]]);
}

/** Bounding box [minLng, minLat, maxLng, maxLat], for fitting a map camera to a route. */
export function boundingBox(geojson: RouteGeoJSON | null | undefined): [number, number, number, number] | null {
  const coords = geoJSONToCoordinates(geojson);
  if (coords.length === 0) return null;
  let minLng = Infinity;
  let minLat = Infinity;
  let maxLng = -Infinity;
  let maxLat = -Infinity;
  for (const [lng, lat] of coords) {
    if (lng < minLng) minLng = lng;
    if (lng > maxLng) maxLng = lng;
    if (lat < minLat) minLat = lat;
    if (lat > maxLat) maxLat = lat;
  }
  return [minLng, minLat, maxLng, maxLat];
}

/**
 * Distance in meters from point `p` to the segment start->end, used for
 * matching a ride's track against a saved segment's start/end points.
 */
export function distanceToPointM(p: { lat: number; lng: number }, target: { lat: number; lng: number }): number {
  return haversineDistanceM(p, target);
}

/**
 * Finds the best-matching [startIndex, endIndex] window in `track` where the
 * rider passed within `radiusM` of both the segment's start and end points,
 * in order. Returns null if no match. This is the client-side segment
 * matcher referenced throughout the product spec — deliberately simple
 * (nearest-point-in-radius, not a full map-matching algorithm) so it runs
 * instantly on-device right after a ride is saved.
 */
export function matchSegment(
  track: TrackPoint[],
  segmentStart: { lat: number; lng: number },
  segmentEnd: { lat: number; lng: number },
  radiusM = 25
): { startIndex: number; endIndex: number } | null {
  let startIndex = -1;
  for (let i = 0; i < track.length; i++) {
    if (haversineDistanceM(track[i], segmentStart) <= radiusM) {
      startIndex = i;
      break;
    }
  }
  if (startIndex === -1) return null;

  for (let j = track.length - 1; j > startIndex; j--) {
    if (haversineDistanceM(track[j], segmentEnd) <= radiusM) {
      return { startIndex, endIndex: j };
    }
  }
  return null;
}
