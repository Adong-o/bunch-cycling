import { parseAuthRedirect } from '../authRedirect';

describe('parseAuthRedirect', () => {
  it('reads access and refresh tokens out of a URL fragment', () => {
    const result = parseAuthRedirect('bunch://auth-callback#access_token=abc123&refresh_token=xyz789&token_type=bearer&expires_in=3600');
    expect(result.accessToken).toBe('abc123');
    expect(result.refreshToken).toBe('xyz789');
    expect(result.errorDescription).toBeUndefined();
  });

  it('decodes a +-encoded error description from the fragment', () => {
    const result = parseAuthRedirect('bunch://auth-callback#error=access_denied&error_description=User+denied+access');
    expect(result.accessToken).toBeUndefined();
    expect(result.refreshToken).toBeUndefined();
    expect(result.errorDescription).toBe('User denied access');
  });

  it('falls back to the plain "error" param when there is no error_description', () => {
    const result = parseAuthRedirect('bunch://auth-callback#error=server_error');
    expect(result.errorDescription).toBe('server_error');
  });

  it('falls back to query-string parsing when there is no fragment', () => {
    const result = parseAuthRedirect('bunch://auth-callback?error=server_error&error_description=Something+broke');
    expect(result.errorDescription).toBe('Something broke');
  });

  it('prefers the fragment over the query string when both are present', () => {
    // Not a shape Supabase actually sends, but it pins down the
    // `hashIndex !== -1` branch taking priority over `queryIndex`.
    const result = parseAuthRedirect('bunch://auth-callback?ignored=1#access_token=fromhash');
    expect(result.accessToken).toBe('fromhash');
  });

  it('returns an all-undefined result for a URL with neither a fragment nor a query string', () => {
    const result = parseAuthRedirect('bunch://auth-callback');
    expect(result).toEqual({ accessToken: undefined, refreshToken: undefined, errorDescription: undefined });
  });

  it('returns undefined fields rather than empty strings when params are simply missing', () => {
    const result = parseAuthRedirect('bunch://auth-callback#token_type=bearer');
    expect(result.accessToken).toBeUndefined();
    expect(result.refreshToken).toBeUndefined();
  });
});
