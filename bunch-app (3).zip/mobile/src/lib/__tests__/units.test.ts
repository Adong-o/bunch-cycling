import {
  displayDistanceToMeters,
  displayElevationToMeters,
  distanceUnitLabel,
  estimateCalories,
  formatDistance,
  formatDuration,
  formatElevation,
  formatPace,
  formatSpeed,
  formatWeight,
  metersToDisplayDistance,
} from '../units';

describe('formatDistance', () => {
  it('formats metric distances at 2dp under 10km and 1dp at or above', () => {
    expect(formatDistance(5000, 'metric')).toBe('5.00 km');
    expect(formatDistance(42195, 'metric')).toBe('42.2 km'); // marathon distance
  });

  it('formats imperial distances in miles', () => {
    expect(formatDistance(42195, 'imperial')).toBe('26.2 mi');
  });

  it('drops the space before the unit in compact mode', () => {
    expect(formatDistance(1000, 'metric', { compact: true })).toBe('1.00km');
  });
});

describe('distanceUnitLabel', () => {
  it('returns the short unit for each system', () => {
    expect(distanceUnitLabel('metric')).toBe('km');
    expect(distanceUnitLabel('imperial')).toBe('mi');
  });
});

describe('metersToDisplayDistance / displayDistanceToMeters', () => {
  it('converts a known value cleanly in each direction', () => {
    expect(metersToDisplayDistance(1000, 'metric')).toBe(1);
    expect(metersToDisplayDistance(1609.344, 'imperial')).toBe(1);
  });

  it('round-trips meters -> display -> meters for metric', () => {
    expect(displayDistanceToMeters(metersToDisplayDistance(50000, 'metric'), 'metric')).toBe(50000);
  });

  it('round-trips meters -> display -> meters for imperial', () => {
    expect(displayDistanceToMeters(metersToDisplayDistance(50000, 'imperial'), 'imperial')).toBeCloseTo(50000);
  });
});

describe('displayElevationToMeters', () => {
  it('is the identity for metric', () => {
    expect(displayElevationToMeters(100, 'metric')).toBe(100);
  });

  it('converts feet to meters for imperial', () => {
    expect(displayElevationToMeters(100, 'imperial')).toBeCloseTo(30.48);
  });
});

describe('formatElevation', () => {
  it('rounds to whole meters for metric', () => {
    expect(formatElevation(612, 'metric')).toBe('612 m');
  });

  it('converts and rounds to whole feet for imperial', () => {
    expect(formatElevation(100, 'imperial')).toBe('328 ft');
  });
});

describe('formatSpeed', () => {
  it('converts m/s to km/h for metric', () => {
    expect(formatSpeed(100 / 3.6, 'metric')).toBe('100.0 km/h');
  });

  it('converts m/s to mph for imperial', () => {
    // 10 m/s = 36 km/h ~= 22.4 mph
    expect(formatSpeed(10, 'imperial')).toMatch(/^22\.\d mph$/);
  });
});

describe('formatPace', () => {
  it('shows a placeholder for zero or negative speed', () => {
    expect(formatPace(0, 'metric')).toBe('--:--');
    expect(formatPace(-2, 'metric')).toBe('--:--');
  });

  it('matches the documented example pace for metric', () => {
    // 1000 / (1000/128) = 128s/km exactly -> 2:08 /km
    expect(formatPace(1000 / 128, 'metric')).toBe('2:08 /km');
  });

  it('formats imperial pace with zero-padded seconds', () => {
    // METERS_PER_MILE / (METERS_PER_MILE/200) = 200s/mi exactly -> 3:20 /mi
    expect(formatPace(1609.344 / 200, 'imperial')).toBe('3:20 /mi');
  });
});

describe('formatDuration', () => {
  it('formats clock style with and without an hours place', () => {
    expect(formatDuration(3600, 'clock')).toBe('1:00:00');
    expect(formatDuration(65, 'clock')).toBe('1:05');
  });

  it('formats long style, dropping units that are zero', () => {
    expect(formatDuration(3725, 'long')).toBe('1h 02m');
    expect(formatDuration(125, 'long')).toBe('2m 05s');
    expect(formatDuration(45, 'long')).toBe('45s');
  });

  it('floors negative input at zero instead of going negative', () => {
    expect(formatDuration(-10)).toBe('0:00');
  });
});

describe('formatWeight', () => {
  it('rounds to whole kg for metric', () => {
    expect(formatWeight(75, 'metric')).toBe('75 kg');
  });

  it('converts and rounds to whole lb for imperial', () => {
    expect(formatWeight(75, 'imperial')).toBe('165 lb');
  });
});

describe('estimateCalories', () => {
  it('returns zero for no moving time', () => {
    expect(estimateCalories(0, 0, 0)).toBe(0);
  });

  it('estimates a flat ride from distance, time and weight alone', () => {
    // 20km in 1h = 20km/h -> MET 8; no climbing, so no climb bonus.
    expect(estimateCalories(20000, 0, 3600, 75)).toBe(600);
  });

  it('adds a climbing bonus on top of the flat-ride estimate', () => {
    // 10km in 30min = 20km/h -> MET 8; 500m of gain adds a bonus.
    expect(estimateCalories(10000, 500, 1800, 80)).toBe(480);
  });
});
