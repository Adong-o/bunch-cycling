import {
  boundingBox,
  elevationGainLoss,
  haversineDistanceM,
  matchSegment,
  totalDistanceM,
  type TrackPoint,
} from '../geo';

function pt(lat: number, lng: number, elevationM?: number | null): TrackPoint {
  return { lat, lng, elevationM, timestamp: 0 };
}

describe('haversineDistanceM', () => {
  it('is zero for identical points', () => {
    expect(haversineDistanceM({ lat: 51.5, lng: -0.1 }, { lat: 51.5, lng: -0.1 })).toBe(0);
  });

  it('is symmetric', () => {
    const a = { lat: 40.7, lng: -74.0 };
    const b = { lat: 34.0, lng: -118.2 };
    expect(haversineDistanceM(a, b)).toBeCloseTo(haversineDistanceM(b, a), 6);
  });

  it('matches the well-known ~111.2km for one degree of latitude', () => {
    // On a sphere, a pure latitude difference is a meridian arc — exactly
    // EARTH_RADIUS_M * deltaLat(radians), independent of longitude.
    const d = haversineDistanceM({ lat: 0, lng: 0 }, { lat: 1, lng: 0 });
    expect(d).toBeGreaterThan(111000);
    expect(d).toBeLessThan(111400);
  });

  it('never returns a negative distance', () => {
    const d = haversineDistanceM({ lat: 10, lng: 170 }, { lat: -10, lng: -170 });
    expect(d).toBeGreaterThanOrEqual(0);
  });
});

describe('totalDistanceM', () => {
  it('is zero for an empty track', () => {
    expect(totalDistanceM([])).toBe(0);
  });

  it('is zero for a single point', () => {
    expect(totalDistanceM([pt(51.5, -0.1)])).toBe(0);
  });

  it('sums to exactly one leg for a two-point track', () => {
    const a = pt(0, 0);
    const b = pt(1, 0);
    expect(totalDistanceM([a, b])).toBeCloseTo(haversineDistanceM(a, b), 6);
  });

  it('accumulates distance across multiple legs rather than shortcutting to the direct distance', () => {
    // An L-shaped path: by the triangle inequality, going via the corner is
    // strictly longer than a straight line from start to end.
    const start = pt(0, 0);
    const corner = pt(0, 0.01);
    const end = pt(0.01, 0.01);
    const path = totalDistanceM([start, corner, end]);
    const direct = haversineDistanceM(start, end);
    expect(path).toBeGreaterThan(direct);
  });
});

describe('elevationGainLoss', () => {
  // A 1 Hz style track: `n` fixes at the same spot whose altitude follows `alt(i)`.
  const track = (n: number, alt: (i: number) => number) => Array.from({ length: n }, (_, i) => pt(0, 0, alt(i)));

  it('returns zero gain/loss when fewer than two points have elevation data', () => {
    expect(elevationGainLoss([pt(0, 0, null), pt(0, 0, undefined)])).toEqual({ gain: 0, loss: 0 });
  });

  it('counts a steady climb', () => {
    // 300 fixes rising 0.2 m each = 60 m of climbing.
    const { gain, loss } = elevationGainLoss(track(300, (i) => 100 + i * 0.2));
    expect(gain).toBeGreaterThan(52);
    expect(gain).toBeLessThanOrEqual(60);
    expect(loss).toBe(0);
  });

  it('counts a long, gentle climb that no single fix-to-fix step would clear (regression)', () => {
    // 0.05 m per fix over 1,200 fixes: every step is far below any noise floor,
    // but it is still a 60 m climb. The old per-step version reported 0.
    const { gain } = elevationGainLoss(track(1200, (i) => 1700 + i * 0.05));
    expect(gain).toBeGreaterThan(50);
  });

  it('ignores jitter smaller than the dead-band', () => {
    expect(elevationGainLoss([pt(0, 0, 100), pt(0, 0, 100.5), pt(0, 0, 101)])).toEqual({ gain: 0, loss: 0 });
    // ±1.5 m of alternating noise around a flat road is not climbing.
    expect(elevationGainLoss(track(600, (i) => 1700 + (i % 2 === 0 ? 1.5 : -1.5)))).toEqual({ gain: 0, loss: 0 });
  });

  it('tracks loss separately from gain on a rolling profile', () => {
    // Climb 40 m, then drop back 40 m, over a few hundred fixes.
    const { gain, loss } = elevationGainLoss(track(400, (i) => 1700 + (i < 200 ? i * 0.2 : (400 - i) * 0.2)));
    // The dead-band holds back at most one threshold (4 m) at each turning point.
    expect(gain).toBeGreaterThan(28);
    expect(loss).toBeGreaterThan(28);
    expect(Math.abs(gain - loss)).toBeLessThan(8);
  });

  it('adds up several hills on a rolling ride', () => {
    // 5 hills of 30 m amplitude (60 m up each) = ~300 m of climbing.
    const { gain } = elevationGainLoss(track(3000, (i) => 1700 + 30 * Math.sin((2 * Math.PI * i) / 600)));
    expect(gain).toBeGreaterThan(270);
    expect(gain).toBeLessThan(330);
  });
});

describe('boundingBox', () => {
  it('returns null for a missing route', () => {
    expect(boundingBox(null)).toBeNull();
    expect(boundingBox(undefined)).toBeNull();
  });

  it('returns null for a route with no coordinates', () => {
    expect(boundingBox({ type: 'LineString', coordinates: [] })).toBeNull();
  });

  it('finds the min/max lng/lat envelope', () => {
    const box = boundingBox({
      type: 'LineString',
      coordinates: [
        [-1, 50],
        [1, 52],
        [0, 51],
      ],
    });
    expect(box).toEqual([-1, 50, 1, 52]);
  });
});

describe('matchSegment', () => {
  // Five points ~111m apart along the equator.
  const track: TrackPoint[] = [0, 0.001, 0.002, 0.003, 0.004].map((lng) => pt(0, lng));

  it('finds the track window between the segment start and end points', () => {
    const match = matchSegment(track, { lat: 0, lng: 0.001 }, { lat: 0, lng: 0.003 });
    expect(match).toEqual({ startIndex: 1, endIndex: 3 });
  });

  it('returns null when the segment is nowhere near the track', () => {
    const match = matchSegment(track, { lat: 45, lng: 45 }, { lat: 46, lng: 46 });
    expect(match).toBeNull();
  });

  it('returns null when the end point never appears after the start point', () => {
    // Start matches near the end of the track, but the "end" point only
    // exists earlier in it — the backward search must not wrap around.
    const match = matchSegment(track, { lat: 0, lng: 0.004 }, { lat: 0, lng: 0 });
    expect(match).toBeNull();
  });
});
