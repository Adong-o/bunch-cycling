import type { Ride, TargetPeriod } from './database.types';

export interface StreakResult {
  currentStreak: number;
  longestStreak: number;
}

type RideForStreak = Pick<Ride, 'started_at' | 'distance_m'>;

// All of this runs on-device against the phone's local clock on purpose —
// "today" and "this week" are defined in the rider's own timezone, not UTC,
// so a streak never breaks just because the server happens to be a few
// hours ahead or behind them.

function periodStart(date: Date, period: TargetPeriod): Date {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  if (period === 'weekly') {
    const mondayOffset = (d.getDay() + 6) % 7; // Mon=0 .. Sun=6
    d.setDate(d.getDate() - mondayOffset);
  }
  return d;
}

function stepPeriod(date: Date, period: TargetPeriod, direction: 1 | -1): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + direction * (period === 'daily' ? 1 : 7));
  return d;
}

function keyOf(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function computeStreak(
  rides: RideForStreak[],
  targetPeriod: TargetPeriod,
  targetDistanceM: number,
  now: Date = new Date()
): StreakResult {
  if (!(targetDistanceM > 0)) return { currentStreak: 0, longestStreak: 0 };

  const totals = new Map<string, number>();
  for (const ride of rides) {
    const start = periodStart(new Date(ride.started_at), targetPeriod);
    const key = keyOf(start);
    totals.set(key, (totals.get(key) ?? 0) + ride.distance_m);
  }

  const met = new Set<string>();
  totals.forEach((total, key) => {
    if (total >= targetDistanceM) met.add(key);
  });

  // Current streak: walk backward from today. If today's period hasn't hit
  // the target yet, that's not a broken streak — the period just isn't over
  // — so we simply start counting from the period before it instead.
  const todayStart = periodStart(now, targetPeriod);
  let cursor = met.has(keyOf(todayStart)) ? todayStart : stepPeriod(todayStart, targetPeriod, -1);
  let currentStreak = 0;
  while (met.has(keyOf(cursor))) {
    currentStreak++;
    cursor = stepPeriod(cursor, targetPeriod, -1);
  }

  // Longest streak ever: measure the run length starting at every period
  // whose previous period was NOT met (i.e. every run's first period).
  let longestStreak = currentStreak;
  met.forEach((key) => {
    const [y, m, d] = key.split('-').map(Number);
    const start = new Date(y, m - 1, d);
    const prevKey = keyOf(stepPeriod(start, targetPeriod, -1));
    if (met.has(prevKey)) return; // not the start of a run

    let runLength = 0;
    let runCursor = start;
    while (met.has(keyOf(runCursor))) {
      runLength++;
      runCursor = stepPeriod(runCursor, targetPeriod, 1);
    }
    longestStreak = Math.max(longestStreak, runLength);
  });

  return { currentStreak, longestStreak };
}
