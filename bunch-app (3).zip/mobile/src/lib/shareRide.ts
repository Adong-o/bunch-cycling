import type { RefObject } from 'react';
import type { View } from 'react-native';
import { captureRef } from 'react-native-view-shot';
import * as Sharing from 'expo-sharing';

/**
 * Captures the off-screen RideShareCard (via the ref RideShareModal hands
 * us) to a PNG and opens the native share sheet — same "render to a file,
 * then hand it to the OS" shape as lib/gpxExport.ts's exportRideAsGPX.
 */
export async function shareRideImage(cardRef: RefObject<View>): Promise<void> {
  if (!cardRef.current) {
    throw new Error('Nothing to share yet — try again in a moment.');
  }

  const uri = await captureRef(cardRef, { format: 'png', quality: 0.95 });

  const canShare = await Sharing.isAvailableAsync();
  if (!canShare) {
    throw new Error('Sharing is not available on this device.');
  }
  await Sharing.shareAsync(uri, { mimeType: 'image/png', dialogTitle: 'Share your ride' });
}
