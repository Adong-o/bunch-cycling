import { supabase } from '@/lib/supabase';
import type { Badge, UserBadge } from '@/lib/database.types';

export async function listAllBadges(): Promise<Badge[]> {
  const { data, error } = await supabase.from('badges').select('*').order('criteria_value', { ascending: true });
  if (error) throw error;
  return data;
}

export async function listMyBadges(userId: string): Promise<Array<UserBadge & { badge: Badge }>> {
  const { data, error } = await supabase
    .from('user_badges')
    .select('*, badge:badge_id(*)')
    .eq('user_id', userId)
    .order('awarded_at', { ascending: false });
  if (error) throw error;
  return data.map((row) => ({ ...row, badge: row.badge as unknown as Badge }));
}
