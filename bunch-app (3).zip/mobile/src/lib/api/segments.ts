import { supabase } from '@/lib/supabase';
import type { Segment, SegmentLeaderboardRow, TablesInsert } from '@/lib/database.types';
import { matchSegment, totalDistanceM, type TrackPoint } from '@/lib/geo';

export const FREE_STARRED_SEGMENT_LIMIT = 5;

export async function createSegment(segment: TablesInsert<'segments'>): Promise<Segment> {
  const { data, error } = await supabase.from('segments').insert(segment).select('*').single();
  if (error) throw error;
  return data;
}

export async function getSegment(id: string): Promise<Segment | null> {
  const { data, error } = await supabase.from('segments').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function listNearbySegments(lat: number, lng: number, radiusDeg = 0.3): Promise<Segment[]> {
  // Simple bounding-box pre-filter (fine at city scale) — no PostGIS in this
  // schema, so we keep geo queries approximate and client-side.
  const { data, error } = await supabase
    .from('segments')
    .select('*')
    .gte('start_lat', lat - radiusDeg)
    .lte('start_lat', lat + radiusDeg)
    .gte('start_lng', lng - radiusDeg)
    .lte('start_lng', lng + radiusDeg)
    .limit(50);
  if (error) throw error;
  return data;
}

export async function listStarredSegments(userId: string): Promise<Segment[]> {
  const { data, error } = await supabase
    .from('segment_stars')
    .select('segment_id, segments(*)')
    .eq('user_id', userId);
  if (error) throw error;
  return data.map((row) => row.segments as unknown as Segment).filter(Boolean);
}

/** How many segments this rider has starred (Profile "Starred segments" tile). */
export async function countStarredSegments(userId: string): Promise<number> {
  const { count, error } = await supabase.from('segment_stars').select('segment_id', { count: 'exact', head: true }).eq('user_id', userId);
  if (error) throw error;
  return count ?? 0;
}

export async function starSegment(userId: string, segmentId: string): Promise<void> {
  const { error } = await supabase.from('segment_stars').insert({ user_id: userId, segment_id: segmentId });
  if (error) throw error;
}

export async function unstarSegment(userId: string, segmentId: string): Promise<void> {
  const { error } = await supabase.from('segment_stars').delete().eq('user_id', userId).eq('segment_id', segmentId);
  if (error) throw error;
}

export async function isSegmentStarred(userId: string, segmentId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('segment_stars')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('segment_id', segmentId);
  if (error) throw error;
  return (count ?? 0) > 0;
}

export async function deleteSegment(id: string): Promise<void> {
  const { error } = await supabase.from('segments').delete().eq('id', id);
  if (error) throw error;
}

/**
 * The view ranks acoustic and e-bike riders separately (rank() is
 * partitioned by (segment_id, is_ebike) in schema.sql), so one query
 * returns two interleaved #1..#N sequences. Order by is_ebike first so
 * each group's ranks come back contiguous and easy to split client-side
 * (see SegmentDetailScreen), and double the limit since it's now two
 * boards in one result set.
 */
export async function getSegmentLeaderboard(segmentId: string): Promise<SegmentLeaderboardRow[]> {
  const { data, error } = await supabase
    .from('segment_leaderboard')
    .select('*')
    .eq('segment_id', segmentId)
    .order('is_ebike', { ascending: true })
    .order('rank', { ascending: true })
    .limit(100);
  if (error) throw error;
  return data;
}

export interface SegmentEffortResult {
  segmentId: string;
  segmentName: string;
  elapsedS: number;
  /** The rider's best elapsed_s on this segment before this effort, or null if this is their first time on it. */
  previousBestS: number | null;
  /** True if this effort is now the rider's best on the segment (including a first-ever effort). */
  isPR: boolean;
}

/**
 * Runs right after a ride is saved, while the full-resolution in-memory
 * track (with real per-point timestamps) is still around — matching against
 * the rider's STARRED segments only, since live effort tracking is the
 * free/paid-gated feature (schema.sql: segment_stars cap), not segment
 * creation itself. Simple nearest-point-in-radius matching, not full map
 * matching — see matchSegment() in lib/geo.ts for the trade-off.
 *
 * Looks up the rider's own best time on each matched segment BEFORE
 * recording the new effort, so callers can announce a new PR — starring a
 * segment should feel like something, not just quietly add a leaderboard
 * row nobody is told about.
 */
export async function matchAndRecordEfforts(userId: string, rideId: string, track: TrackPoint[]): Promise<SegmentEffortResult[]> {
  if (track.length < 2) return [];
  const starred = await listStarredSegments(userId);
  if (starred.length === 0) return [];

  const results: SegmentEffortResult[] = [];
  for (const segment of starred) {
    const match = matchSegment(
      track,
      { lat: segment.start_lat, lng: segment.start_lng },
      { lat: segment.end_lat, lng: segment.end_lng }
    );
    if (!match) continue;

    const slice = track.slice(match.startIndex, match.endIndex + 1);
    const elapsedS = Math.round((slice[slice.length - 1].timestamp - slice[0].timestamp) / 1000);
    if (elapsedS <= 0) continue;
    const distance = totalDistanceM(slice);

    const { data: priorBest } = await supabase
      .from('segment_efforts')
      .select('elapsed_s')
      .eq('segment_id', segment.id)
      .eq('user_id', userId)
      .order('elapsed_s', { ascending: true })
      .limit(1)
      .maybeSingle();
    const previousBestS = priorBest?.elapsed_s ?? null;

    const { error } = await supabase.from('segment_efforts').insert({
      segment_id: segment.id,
      ride_id: rideId,
      user_id: userId,
      elapsed_s: elapsedS,
      avg_speed_mps: distance / elapsedS,
      started_at: new Date(slice[0].timestamp).toISOString(),
    });
    if (error) continue;

    results.push({
      segmentId: segment.id,
      segmentName: segment.name,
      elapsedS,
      previousBestS,
      isPR: previousBestS === null || elapsedS < previousBestS,
    });
  }
  return results;
}
