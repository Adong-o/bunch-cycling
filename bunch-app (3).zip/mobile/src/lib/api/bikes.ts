import { supabase } from '@/lib/supabase';
import type { Bike, TablesInsert } from '@/lib/database.types';

export const FREE_BIKE_LIMIT = 2;

export async function listBikes(userId: string): Promise<Bike[]> {
  const { data, error } = await supabase
    .from('bikes')
    .select('*')
    .eq('user_id', userId)
    .order('is_retired', { ascending: true })
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data;
}

export async function createBike(bike: TablesInsert<'bikes'>): Promise<Bike> {
  const { data, error } = await supabase.from('bikes').insert(bike).select('*').single();
  if (error) throw error;
  return data;
}

export async function updateBike(id: string, patch: Partial<Bike>): Promise<void> {
  const { error } = await supabase.from('bikes').update(patch).eq('id', id);
  if (error) throw error;
}

export async function deleteBike(id: string): Promise<void> {
  const { error } = await supabase.from('bikes').delete().eq('id', id);
  if (error) throw error;
}
