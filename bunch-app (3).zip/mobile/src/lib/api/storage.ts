import * as FileSystem from 'expo-file-system';
import { decode } from 'base64-arraybuffer';
import { supabase } from '@/lib/supabase';

export type UploadBucket = 'avatars' | 'ride-photos' | 'challenge-covers';

/**
 * Uploads a local image (from expo-image-picker) to Supabase Storage under
 * `<userId>/...` — required by the bucket's RLS policy (see schema.sql) —
 * and returns its public URL. All three buckets are public-read, so the URL
 * works everywhere immediately (ride feed, profile, shared links).
 */
export async function uploadImage(bucket: UploadBucket, userId: string, localUri: string): Promise<string> {
  const base64 = await FileSystem.readAsStringAsync(localUri, { encoding: FileSystem.EncodingType.Base64 });
  const extMatch = localUri.match(/\.(\w+)$/);
  const ext = (extMatch?.[1] ?? 'jpg').toLowerCase();
  const path = `${userId}/${Date.now()}.${ext}`;
  const contentType = ext === 'png' ? 'image/png' : ext === 'heic' ? 'image/heic' : 'image/jpeg';

  const { error } = await supabase.storage.from(bucket).upload(path, decode(base64), {
    contentType,
    upsert: false,
  });
  if (error) throw error;

  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}
