import { supabase } from '@/lib/supabase';
import type { Device, TablesInsert } from '@/lib/database.types';

export async function listDevices(userId: string): Promise<Device[]> {
  const { data, error } = await supabase.from('devices').select('*').eq('user_id', userId).order('created_at', { ascending: true });
  if (error) throw error;
  return data;
}

export async function addDevice(device: TablesInsert<'devices'>): Promise<Device> {
  const { data, error } = await supabase.from('devices').insert(device).select('*').single();
  if (error) throw error;
  return data;
}

export async function removeDevice(id: string): Promise<void> {
  const { error } = await supabase.from('devices').delete().eq('id', id);
  if (error) throw error;
}
