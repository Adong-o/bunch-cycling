import { supabase } from '@/lib/supabase';
import { formatDistance, formatDuration, formatElevation } from '@/lib/units';
import type { Challenge, ChallengeLeaderboardRow, ChallengeParticipant, ChallengeType, TablesInsert, UnitSystem } from '@/lib/database.types';

export const CHALLENGES_REQUIRED_TO_UNLOCK_CREATE = 2;

/** Renders a raw progress/goal number (its unit depends on `type`) for display. */
export function formatChallengeValue(type: ChallengeType, value: number, units: UnitSystem): string {
  switch (type) {
    case 'distance':
      return formatDistance(value, units);
    case 'elevation':
      return formatElevation(value, units);
    case 'duration':
      return formatDuration(value, 'long');
    case 'ride_count':
      return `${Math.round(value)} ride${Math.round(value) === 1 ? '' : 's'}`;
    default:
      return `${value}`;
  }
}

export function challengeTypeLabel(type: ChallengeType): string {
  switch (type) {
    case 'distance':
      return 'Distance';
    case 'elevation':
      return 'Elevation';
    case 'duration':
      return 'Time in the saddle';
    case 'ride_count':
      return 'Ride count';
    default:
      return type;
  }
}

export async function getChallenge(id: string): Promise<Challenge | null> {
  const { data, error } = await supabase.from('challenges').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function listFeaturedChallenges(): Promise<Challenge[]> {
  const today = new Date().toISOString().slice(0, 10);
  const { data, error } = await supabase
    .from('challenges')
    .select('*')
    .eq('is_featured', true)
    .eq('is_public', true)
    .gte('end_date', today)
    .order('start_date', { ascending: true })
    .limit(10);
  if (error) throw error;
  return data;
}

export async function setChallengeFeatured(id: string, featured: boolean): Promise<void> {
  const { error } = await supabase.from('challenges').update({ is_featured: featured }).eq('id', id);
  if (error) throw error;
}

export async function listDiscoverChallenges(): Promise<Challenge[]> {
  const today = new Date().toISOString().slice(0, 10);
  const { data, error } = await supabase
    .from('challenges')
    .select('*')
    .eq('is_public', true)
    .gte('end_date', today)
    .order('is_official', { ascending: false })
    .order('start_date', { ascending: true })
    .limit(50);
  if (error) throw error;
  return data;
}

export async function listMyChallenges(userId: string): Promise<Array<Challenge & { participant: ChallengeParticipant }>> {
  const { data, error } = await supabase
    .from('challenge_participants')
    .select('*, challenges(*)')
    .eq('user_id', userId)
    .order('joined_at', { ascending: false });
  if (error) throw error;
  return data
    .filter((row) => row.challenges)
    .map((row) => ({ ...(row.challenges as unknown as Challenge), participant: row as unknown as ChallengeParticipant }));
}

export async function myJoinedChallengeCount(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from('challenge_participants')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId);
  if (error) throw error;
  return count ?? 0;
}

export async function getChallengeByInviteCode(code: string): Promise<Challenge | null> {
  const { data, error } = await supabase.from('challenges').select('*').eq('invite_code', code.toUpperCase()).maybeSingle();
  if (error) throw error;
  return data;
}

export async function joinChallenge(challengeId: string, userId: string): Promise<void> {
  const { error } = await supabase.from('challenge_participants').insert({ challenge_id: challengeId, user_id: userId });
  if (error) throw error;
}

export async function leaveChallenge(challengeId: string, userId: string): Promise<void> {
  const { error } = await supabase.from('challenge_participants').delete().eq('challenge_id', challengeId).eq('user_id', userId);
  if (error) throw error;
}

export async function createChallenge(challenge: TablesInsert<'challenges'>): Promise<Challenge> {
  const { data, error } = await supabase.from('challenges').insert(challenge).select('*').single();
  if (error) throw error;
  return data;
}

export async function getChallengeLeaderboard(challengeId: string): Promise<ChallengeLeaderboardRow[]> {
  const { data, error } = await supabase
    .from('challenge_leaderboard')
    .select('*')
    .eq('challenge_id', challengeId)
    .order('rank', { ascending: true })
    .limit(100);
  if (error) throw error;
  return data;
}

export async function myParticipation(challengeId: string, userId: string): Promise<ChallengeParticipant | null> {
  const { data, error } = await supabase
    .from('challenge_participants')
    .select('*')
    .eq('challenge_id', challengeId)
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data;
}
