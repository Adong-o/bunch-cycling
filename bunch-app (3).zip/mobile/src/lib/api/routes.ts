import { supabase } from '@/lib/supabase';
import type { RouteRow, TablesInsert } from '@/lib/database.types';

export const FREE_ROUTE_LIMIT = 3;

export async function listMyRoutes(userId: string): Promise<RouteRow[]> {
  const { data, error } = await supabase.from('routes').select('*').eq('user_id', userId).order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/** How many routes this rider owns (Profile "Saved routes" tile). */
export async function countMyRoutes(userId: string): Promise<number> {
  const { count, error } = await supabase.from('routes').select('id', { count: 'exact', head: true }).eq('user_id', userId);
  if (error) throw error;
  return count ?? 0;
}

export async function createRoute(route: TablesInsert<'routes'>): Promise<RouteRow> {
  const { data, error } = await supabase.from('routes').insert(route).select('*').single();
  if (error) throw error;
  return data;
}

export async function deleteRoute(id: string): Promise<void> {
  const { error } = await supabase.from('routes').delete().eq('id', id);
  if (error) throw error;
}

export async function setRouteVisibility(id: string, isPublic: boolean): Promise<void> {
  const { error } = await supabase.from('routes').update({ is_public: isPublic }).eq('id', id);
  if (error) throw error;
}

/** One route by id, or null when it doesn't exist or isn't visible to this rider (RLS). */
export async function getRoute(id: string): Promise<RouteRow | null> {
  const { data, error } = await supabase.from('routes').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

/** Every route the viewer can see (their own plus other riders' public ones — RLS does the filtering), newest first. */
export async function listVisibleRoutes(limit = 60): Promise<RouteRow[]> {
  const { data, error } = await supabase.from('routes').select('*').order('created_at', { ascending: false }).limit(limit);
  if (error) throw error;
  return data;
}

/** Ride + rider counts per route id, from the route_ride_counts view (schema_v3.sql). Missing ids simply have no rides yet. */
export async function getRouteRideCounts(routeIds: string[]): Promise<Record<string, { rides: number; riders: number }>> {
  if (routeIds.length === 0) return {};
  const { data, error } = await supabase.from('route_ride_counts').select('*').in('route_id', routeIds);
  if (error) throw error;
  const out: Record<string, { rides: number; riders: number }> = {};
  for (const row of data) out[row.route_id] = { rides: row.ride_count, riders: row.rider_count };
  return out;
}
