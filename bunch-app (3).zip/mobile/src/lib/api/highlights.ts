import { supabase } from '@/lib/supabase';
import type { RideHighlight, TablesInsert } from '@/lib/database.types';

export async function listRideHighlights(rideId: string): Promise<RideHighlight[]> {
  const { data, error } = await supabase.from('ride_highlights').select('*').eq('ride_id', rideId).order('created_at', { ascending: true });
  if (error) throw error;
  return data;
}

export async function createRideHighlight(highlight: TablesInsert<'ride_highlights'>): Promise<RideHighlight> {
  const { data, error } = await supabase.from('ride_highlights').insert(highlight).select('*').single();
  if (error) throw error;
  return data;
}

export async function deleteRideHighlight(id: string): Promise<void> {
  const { error } = await supabase.from('ride_highlights').delete().eq('id', id);
  if (error) throw error;
}

/** Number of highlights a rider has added across all their rides (Profile "Highlights" tile). */
export async function countMyHighlights(userId: string): Promise<number> {
  const { count, error } = await supabase.from('ride_highlights').select('id', { count: 'exact', head: true }).eq('user_id', userId);
  if (error) throw error;
  return count ?? 0;
}
