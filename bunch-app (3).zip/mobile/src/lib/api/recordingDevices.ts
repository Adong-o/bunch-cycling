import { supabase } from '@/lib/supabase';
import type { RecordingDevice, RecordingDeviceBrand, TablesInsert } from '@/lib/database.types';

export const FREE_RECORDING_DEVICE_LIMIT = 1;

// Shared brand -> label map so DevicesScreen, ImportRidesScreen's device
// picker, and the RideDetailScreen "Recorded with" chip never drift into
// showing three different names for the same brand.
export const RECORDING_DEVICE_BRANDS: Array<{ value: RecordingDeviceBrand; label: string }> = [
  { value: 'garmin', label: 'Garmin' },
  { value: 'coros', label: 'Coros' },
  { value: 'suunto', label: 'Suunto' },
  { value: 'polar', label: 'Polar' },
  { value: 'apple_watch', label: 'Apple Watch' },
  { value: 'amazfit', label: 'Amazfit' },
  { value: 'wahoo', label: 'Wahoo' },
  { value: 'other', label: 'Other' },
];

export function recordingDeviceBrandLabel(brand: RecordingDeviceBrand): string {
  return RECORDING_DEVICE_BRANDS.find((b) => b.value === brand)?.label ?? 'Other';
}

/** Looks up one device by id — used on RideDetailScreen to show "Recorded
 * with X". RLS only lets the device's own owner read it (see
 * schema.sql's "Users manage their own recording devices (select)"), so
 * this resolves to null for any other viewer rather than erroring — the
 * chip just doesn't render for them, same as a ride with no device tagged
 * at all. A deliberate scoping choice: gear is personal info by default,
 * not shown off on a ride the way Strava shows equipment publicly. */
export async function getRecordingDevice(id: string): Promise<RecordingDevice | null> {
  const { data, error } = await supabase.from('recording_devices').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function listRecordingDevices(userId: string): Promise<RecordingDevice[]> {
  const { data, error } = await supabase
    .from('recording_devices')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data;
}

export async function createRecordingDevice(device: TablesInsert<'recording_devices'>): Promise<RecordingDevice> {
  const { data, error } = await supabase.from('recording_devices').insert(device).select('*').single();
  if (error) throw error;
  return data;
}

export async function updateRecordingDevice(id: string, patch: Partial<RecordingDevice>): Promise<void> {
  const { error } = await supabase.from('recording_devices').update(patch).eq('id', id);
  if (error) throw error;
}

export async function deleteRecordingDevice(id: string): Promise<void> {
  const { error } = await supabase.from('recording_devices').delete().eq('id', id);
  if (error) throw error;
}
