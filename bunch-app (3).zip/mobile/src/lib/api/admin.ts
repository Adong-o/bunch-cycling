import { supabase } from '@/lib/supabase';
import type { Profile } from '@/lib/database.types';

/**
 * Admin-only actions. These rely entirely on the `profiles` RLS policy +
 * prevent_privilege_escalation() trigger in schema.sql — an admin's own
 * row makes is_admin(auth.uid()) true server-side, which is what actually
 * authorizes the update; there's no service_role key involved anywhere in
 * the client. A non-admin calling these just has their write silently
 * stripped of the privileged fields by that trigger, not blocked outright,
 * so the UI itself also hides this screen from non-admins.
 */

export async function findProfileByUsername(username: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('username', username.trim().toLowerCase()).maybeSingle();
  if (error) throw error;
  return data;
}

export async function setPremium(userId: string, isPremium: boolean): Promise<Profile> {
  const patch: { is_premium: boolean; premium_since?: string } = { is_premium: isPremium };
  // Only stamp a fresh grant date when turning Premium ON — revoking leaves
  // premium_since alone so "member since" history survives a lapse.
  if (isPremium) patch.premium_since = new Date().toISOString();
  const { data, error } = await supabase.from('profiles').update(patch).eq('id', userId).select('*').single();
  if (error) throw error;
  return data;
}
