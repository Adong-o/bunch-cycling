import { supabase } from '@/lib/supabase';
import type { Profile } from '@/lib/database.types';

export async function searchProfiles(query: string, excludeUserId?: string): Promise<Profile[]> {
  // The text goes into a PostgREST or() filter, where commas, parentheses and wildcards are syntax —
  // strip them so a name like "a,b" searches for what was typed instead of breaking (or widening) the query.
  const term = query.replace(/[,()%*\\"']/g, ' ').replace(/\s+/g, ' ').trim();
  if (term.length === 0) return [];
  let q = supabase.from('profiles').select('*').or(`username.ilike.%${term}%,display_name.ilike.%${term}%`).limit(20);
  if (excludeUserId) q = q.neq('id', excludeUserId);
  const { data, error } = await q;
  if (error) throw error;
  return data;
}

export async function getProfileByUsername(username: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('username', username).maybeSingle();
  if (error) throw error;
  return data;
}

export async function getProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) throw error;
  return data;
}

/** Batch profile lookup for a page of feed rides — one query instead of one per card. */
export async function listProfilesByIds(userIds: string[]): Promise<Profile[]> {
  const unique = Array.from(new Set(userIds));
  if (unique.length === 0) return [];
  const { data, error } = await supabase.from('profiles').select('*').in('id', unique);
  if (error) throw error;
  return data;
}

export async function isFollowing(followerId: string, followingId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('follows')
    .select('id', { count: 'exact', head: true })
    .eq('follower_id', followerId)
    .eq('following_id', followingId);
  if (error) throw error;
  return (count ?? 0) > 0;
}

export async function follow(followerId: string, followingId: string): Promise<void> {
  const { error } = await supabase.from('follows').insert({ follower_id: followerId, following_id: followingId });
  if (error) throw error;
}

export async function unfollow(followerId: string, followingId: string): Promise<void> {
  const { error } = await supabase.from('follows').delete().eq('follower_id', followerId).eq('following_id', followingId);
  if (error) throw error;
}

export async function getFollowCounts(userId: string): Promise<{ followers: number; following: number }> {
  const [followers, following] = await Promise.all([
    supabase.from('follows').select('id', { count: 'exact', head: true }).eq('following_id', userId),
    supabase.from('follows').select('id', { count: 'exact', head: true }).eq('follower_id', userId),
  ]);
  if (followers.error) throw followers.error;
  if (following.error) throw following.error;
  return { followers: followers.count ?? 0, following: following.count ?? 0 };
}

export async function listFollowing(userId: string): Promise<Profile[]> {
  const { data, error } = await supabase.from('follows').select('profiles:following_id(*)').eq('follower_id', userId);
  if (error) throw error;
  return data.map((row) => row.profiles as unknown as Profile).filter(Boolean);
}

export async function listFollowers(userId: string): Promise<Profile[]> {
  const { data, error } = await supabase.from('follows').select('profiles:follower_id(*)').eq('following_id', userId);
  if (error) throw error;
  return data.map((row) => row.profiles as unknown as Profile).filter(Boolean);
}

export async function giveKudos(rideId: string, userId: string): Promise<void> {
  const { error } = await supabase.from('kudos').insert({ ride_id: rideId, user_id: userId });
  if (error) throw error;
}

export async function removeKudos(rideId: string, userId: string): Promise<void> {
  const { error } = await supabase.from('kudos').delete().eq('ride_id', rideId).eq('user_id', userId);
  if (error) throw error;
}

export interface KudosState {
  count: number;
  byMe: boolean;
}

export async function getKudosState(rideId: string, userId: string): Promise<KudosState> {
  const { data, error } = await supabase.from('kudos').select('user_id').eq('ride_id', rideId);
  if (error) throw error;
  return { count: data.length, byMe: data.some((row) => row.user_id === userId) };
}

/** Batch kudos lookup for a page of feed rides — one query instead of one per card. */
export async function getKudosStateBatch(rideIds: string[], userId: string): Promise<Record<string, KudosState>> {
  const result: Record<string, KudosState> = {};
  for (const id of rideIds) result[id] = { count: 0, byMe: false };
  if (rideIds.length === 0) return result;

  const { data, error } = await supabase.from('kudos').select('ride_id, user_id').in('ride_id', rideIds);
  if (error) throw error;

  for (const row of data) {
    const entry = result[row.ride_id];
    if (!entry) continue;
    entry.count++;
    if (row.user_id === userId) entry.byMe = true;
  }
  return result;
}

export async function listComments(rideId: string): Promise<Array<{ id: string; body: string; created_at: string; profile: Profile }>> {
  const { data, error } = await supabase
    .from('ride_comments')
    .select('id, body, created_at, profile:user_id(*)')
    .eq('ride_id', rideId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data.map((row) => ({ ...row, profile: row.profile as unknown as Profile }));
}

export async function addComment(rideId: string, userId: string, body: string): Promise<void> {
  const { error } = await supabase.from('ride_comments').insert({ ride_id: rideId, user_id: userId, body });
  if (error) throw error;
}

// ---- Ride tags ("Rode with") -----------------------------------------
// Tagging shares the ride with the tagged rider regardless of its
// visibility — see the "Ride tags visible if the underlying ride is
// visible" / "Rides visible per visibility setting" policies in schema.sql.

export interface RideTagRow {
  id: string;
  user_id: string;
  tagged_by: string;
  profile: Profile;
}

export async function listRideTags(rideId: string): Promise<RideTagRow[]> {
  const { data, error } = await supabase.from('ride_tags').select('id, user_id, tagged_by, profile:user_id(*)').eq('ride_id', rideId);
  if (error) throw error;
  return data.map((row) => ({ ...row, profile: row.profile as unknown as Profile }));
}

/** Batch "who's tagged on this ride" lookup for a page of feed cards — one query instead of one per card, same shape as getKudosStateBatch. */
export async function listRideTagsBatch(rideIds: string[]): Promise<Record<string, Profile[]>> {
  const result: Record<string, Profile[]> = {};
  for (const id of rideIds) result[id] = [];
  if (rideIds.length === 0) return result;

  const { data, error } = await supabase.from('ride_tags').select('ride_id, profile:user_id(*)').in('ride_id', rideIds);
  if (error) throw error;

  for (const row of data) {
    const entry = result[row.ride_id];
    if (!entry) continue;
    entry.push(row.profile as unknown as Profile);
  }
  return result;
}

/** Tags riders as having been on a ride. Only the ride's own owner may call this — enforced by RLS (`tagged_by` must be `auth.uid()`, which must own the ride) and by a trigger rejecting a self-tag of the owner. */
export async function addRideTags(rideId: string, userIds: string[], taggedBy: string): Promise<void> {
  if (userIds.length === 0) return;
  const rows = userIds.map((user_id) => ({ ride_id: rideId, user_id, tagged_by: taggedBy }));
  const { error } = await supabase.from('ride_tags').insert(rows);
  if (error) throw error;
}

/** Removes one tag. RLS allows this to either the ride owner or the tagged rider themself (an "untag me" right). */
export async function removeRideTag(rideId: string, userId: string): Promise<void> {
  const { error } = await supabase.from('ride_tags').delete().eq('ride_id', rideId).eq('user_id', userId);
  if (error) throw error;
}
