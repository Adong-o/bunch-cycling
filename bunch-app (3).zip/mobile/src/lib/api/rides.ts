import { supabase } from '@/lib/supabase';
import type { Ride, TablesInsert, TablesUpdate } from '@/lib/database.types';
import { computeStreak } from '@/lib/streaks';
import type { Profile } from '@/lib/database.types';

export async function createRide(ride: TablesInsert<'rides'>): Promise<Ride> {
  const { data, error } = await supabase.from('rides').insert(ride).select('*').single();
  if (error) throw error;
  return data;
}

export async function updateRide(id: string, patch: TablesUpdate<'rides'>): Promise<void> {
  const { error } = await supabase.from('rides').update(patch).eq('id', id);
  if (error) throw error;
}

export async function deleteRide(id: string): Promise<void> {
  const { error } = await supabase.from('rides').delete().eq('id', id);
  if (error) throw error;
}

export async function getRide(id: string): Promise<Ride> {
  const { data, error } = await supabase.from('rides').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

/** The signed-in rider's own rides, most recent first — for their profile tab. */
export async function listMyRides(userId: string, limit = 30, before?: string): Promise<Ride[]> {
  let query = supabase.from('rides').select('*').eq('user_id', userId).order('started_at', { ascending: false }).limit(limit);
  if (before) query = query.lt('started_at', before);
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

/** Just the geometry of every ride the rider has recorded — deliberately
 * narrow (no distance/time/etc columns) since this only feeds the personal
 * heatmap, which draws hundreds of tracks at once and has no use for the
 * rest of the row. */
export async function listMyRideTracks(userId: string): Promise<Array<{ id: string; route_geojson: Ride['route_geojson'] }>> {
  const { data, error } = await supabase.from('rides').select('id, route_geojson').eq('user_id', userId).not('route_geojson', 'is', null);
  if (error) throw error;
  return data;
}

/** Own rides + followed riders' rides, via the home_feed view (see schema.sql). */
export async function listHomeFeed(limit = 20, before?: string): Promise<Ride[]> {
  let query = supabase.from('home_feed').select('*').order('started_at', { ascending: false }).limit(limit);
  if (before) query = query.lt('started_at', before);
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

export interface RiderTotals {
  totalRides: number;
  totalDistanceM: number;
  totalElevationM: number;
  totalMovingTimeS: number;
}

export async function getRiderTotals(userId: string): Promise<RiderTotals> {
  const { data, error } = await supabase
    .from('rides')
    .select('distance_m, elevation_gain_m, moving_time_s')
    .eq('user_id', userId);
  if (error) throw error;

  return data.reduce(
    (acc, r) => ({
      totalRides: acc.totalRides + 1,
      totalDistanceM: acc.totalDistanceM + r.distance_m,
      totalElevationM: acc.totalElevationM + r.elevation_gain_m,
      totalMovingTimeS: acc.totalMovingTimeS + r.moving_time_s,
    }),
    { totalRides: 0, totalDistanceM: 0, totalElevationM: 0, totalMovingTimeS: 0 }
  );
}

/**
 * Recomputes the rider's streak from their recent ride history and writes
 * it back to `profiles` (RLS: a user may always update their own row — see
 * schema.sql). Call this after saving a ride and whenever the home/profile
 * screen loads. A generous 400-day lookback comfortably covers any
 * realistic streak without pulling a rider's entire ride history.
 */
export async function syncStreak(profile: Profile): Promise<{ currentStreak: number; longestStreak: number }> {
  const since = new Date();
  since.setDate(since.getDate() - 400);

  const { data, error } = await supabase
    .from('rides')
    .select('started_at, distance_m')
    .eq('user_id', profile.id)
    .gte('started_at', since.toISOString());
  if (error) throw error;

  const { currentStreak, longestStreak } = computeStreak(data, profile.target_period, profile.target_distance_m);
  const longest = Math.max(longestStreak, profile.longest_streak);

  if (currentStreak !== profile.current_streak || longest !== profile.longest_streak) {
    await supabase
      .from('profiles')
      .update({ current_streak: currentStreak, longest_streak: longest, last_streak_date: new Date().toISOString().slice(0, 10) })
      .eq('id', profile.id);
  }

  return { currentStreak, longestStreak: longest };
}
