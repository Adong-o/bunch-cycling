/**
 * Parses an OAuth redirect URL for the session it carries. Supabase's
 * redirect puts the session in the URL FRAGMENT (#access_token=...), not
 * query params — fragments are a client-only concept, never sent to a
 * server, so nothing but the client can read them. Falls back to parsing
 * the query string too, since some error redirects use `?` instead of `#`.
 *
 * Deliberately has no imports beyond the URL/URLSearchParams globals
 * (polyfilled app-wide by react-native-url-polyfill in lib/supabase.ts) so
 * it stays pure and trivially unit-testable without pulling in Supabase or
 * any native module — see lib/__tests__/authRedirect.test.ts.
 */
export function parseAuthRedirect(url: string): { accessToken?: string; refreshToken?: string; errorDescription?: string } {
  const hashIndex = url.indexOf('#');
  const queryIndex = url.indexOf('?');
  const paramsString = hashIndex !== -1 ? url.slice(hashIndex + 1) : queryIndex !== -1 ? url.slice(queryIndex + 1) : '';
  const params = new URLSearchParams(paramsString);
  return {
    accessToken: params.get('access_token') ?? undefined,
    refreshToken: params.get('refresh_token') ?? undefined,
    errorDescription: params.get('error_description') ?? params.get('error') ?? undefined,
  };
}
