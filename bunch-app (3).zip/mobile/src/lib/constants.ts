// Placeholder — swap for a real donation/sponsorship link before launch
// (Buy Me a Coffee, Ko-fi, GitHub Sponsors, etc.). Deliberately an obvious,
// easy-to-find stand-in rather than a guessed real-looking URL that might
// resolve to someone else's account — same idea as
// REPLACE_WITH_YOUR_EAS_PROJECT_ID in app.config.ts. Surfaced from Settings
// — see SettingsScreen.tsx's SUPPORT section.
export const SUPPORT_ME_URL = 'https://www.buymeacoffee.com/REPLACE_ME';
