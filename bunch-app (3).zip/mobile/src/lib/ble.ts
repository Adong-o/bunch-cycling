import { decode as decodeBase64 } from 'base64-arraybuffer';

// Real Bluetooth LE pairing for the three cycling sensor types that have a
// standard GATT profile: heart rate straps, speed/cadence sensors, and
// power meters. This module is deliberately scoped to pairing and a live
// on-screen reading — it is NOT wired into ride recording. DevicesScreen.tsx
// is the only file that should ever import this module.
//
// Crash-safety rule: react-native-ble-plx's BleManager opens a native
// Bluetooth session the moment it is constructed, and on iOS that can
// trigger the system permission prompt immediately. If that construction
// ever ran at module-evaluation time (e.g. a bare `new BleManager()` at the
// top of this file), it would run the instant anything imports this module
// — including, by mistake, on app launch. So the class itself is pulled in
// with a plain `require()` inside getManager(), and getManager() is only
// ever called from inside a function a screen invokes after the user taps
// something. Nothing here runs at import time.

type BleManagerT = import('react-native-ble-plx').BleManager;
type BleErrorT = import('react-native-ble-plx').BleError;

const HEART_RATE_SERVICE = '0000180d-0000-1000-8000-00805f9b34fb';
const HEART_RATE_MEASUREMENT = '00002a37-0000-1000-8000-00805f9b34fb';
const CSC_SERVICE = '00001816-0000-1000-8000-00805f9b34fb';
const CSC_MEASUREMENT = '00002a5b-0000-1000-8000-00805f9b34fb';
const POWER_SERVICE = '00001818-0000-1000-8000-00805f9b34fb';
const POWER_MEASUREMENT = '00002a63-0000-1000-8000-00805f9b34fb';

export type SensorKind = 'heart_rate' | 'speed_cadence' | 'power';

export const SENSOR_PROFILES: Record<SensorKind, { service: string; characteristic: string }> = {
  heart_rate: { service: HEART_RATE_SERVICE, characteristic: HEART_RATE_MEASUREMENT },
  speed_cadence: { service: CSC_SERVICE, characteristic: CSC_MEASUREMENT },
  power: { service: POWER_SERVICE, characteristic: POWER_MEASUREMENT },
};

export interface ScannedPeripheral {
  id: string;
  name: string;
}

let manager: BleManagerT | null = null;

function getManager(): BleManagerT {
  if (!manager) {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { BleManager } = require('react-native-ble-plx');
    manager = new BleManager();
  }
  return manager;
}

/** Releases the native Bluetooth session. Call when the Devices screen unmounts. Safe to call even if a manager was never created. */
export function destroyBleManager(): void {
  if (manager) {
    manager.destroy();
    manager = null;
  }
}

/**
 * Scans for nearby peripherals advertising one of the three supported
 * sensor services. Calls onFound once per unique device seen and stops on
 * its own after timeoutMs (default 12s). Returns a function that cancels
 * the scan early — callers should call it when the user picks a device,
 * closes the sheet, or the screen unmounts.
 */
export function scanForSensors(
  onFound: (peripheral: ScannedPeripheral) => void,
  onError: (message: string) => void,
  timeoutMs = 12000
): () => void {
  const m = getManager();
  const seen = new Set<string>();
  const serviceUUIDs = Object.values(SENSOR_PROFILES).map((p) => p.service);

  let stopped = false;
  function stop() {
    if (stopped) return;
    stopped = true;
    clearTimeout(timer);
    m.stopDeviceScan();
  }

  try {
    m.startDeviceScan(serviceUUIDs, { allowDuplicates: false }, (error: BleErrorT | null, device) => {
      if (error) {
        onError(error.message ?? 'Bluetooth scan failed.');
        stop();
        return;
      }
      if (!device || seen.has(device.id)) return;
      seen.add(device.id);
      onFound({ id: device.id, name: device.name ?? device.localName ?? 'Unnamed sensor' });
    });
  } catch (e) {
    onError(e instanceof Error ? e.message : 'Could not start Bluetooth scan.');
  }

  const timer = setTimeout(stop, timeoutMs);
  return stop;
}

async function connectAndDiscover(peripheralId: string) {
  const m = getManager();
  const device = await m.connectToDevice(peripheralId, { timeout: 10000 });
  await device.discoverAllServicesAndCharacteristics();
  return device;
}

function parseHeartRate(view: DataView): number | null {
  if (view.byteLength < 2) return null;
  const flags = view.getUint8(0);
  const isUint16 = (flags & 0x01) === 1;
  if (isUint16) {
    return view.byteLength >= 3 ? view.getUint16(1, true) : null;
  }
  return view.getUint8(1);
}

function parseCyclingPower(view: DataView): number | null {
  if (view.byteLength < 4) return null;
  // Flags (UINT16 LE) at offset 0; Instantaneous Power (INT16 LE) always
  // comes immediately after it at offset 2, regardless of which optional
  // fields the flags say follow.
  return view.getInt16(2, true);
}

/** Cadence is derived from two consecutive crank-revolution readings, so the parser is a closure that remembers the last one. */
function makeCscParser() {
  let lastCrankRevs: number | null = null;
  let lastCrankEventTime: number | null = null;

  return (view: DataView): number | null => {
    if (view.byteLength < 1) return null;
    const flags = view.getUint8(0);
    const hasWheel = (flags & 0x01) !== 0;
    const hasCrank = (flags & 0x02) !== 0;

    let offset = 1;
    if (hasWheel) offset += 6; // 4-byte cumulative wheel revs + 2-byte last wheel event time — not used for cadence
    if (!hasCrank || view.byteLength < offset + 4) return null;

    const crankRevs = view.getUint16(offset, true);
    const crankEventTime = view.getUint16(offset + 2, true); // 1/1024s units

    if (lastCrankRevs == null || lastCrankEventTime == null) {
      lastCrankRevs = crankRevs;
      lastCrankEventTime = crankEventTime;
      return null; // first notification — no delta to derive a rate from yet
    }

    let revDelta = crankRevs - lastCrankRevs;
    let timeDelta = crankEventTime - lastCrankEventTime;
    if (revDelta < 0) revDelta += 65536; // UINT16 counters wrap around
    if (timeDelta < 0) timeDelta += 65536;
    lastCrankRevs = crankRevs;
    lastCrankEventTime = crankEventTime;

    if (timeDelta === 0) return null; // duplicate notification or stopped pedaling — avoid a divide by zero
    const seconds = timeDelta / 1024;
    return Math.round((revDelta / seconds) * 60);
  };
}

/**
 * Connects to a peripheral, subscribes to the GATT characteristic for the
 * given sensor kind, and calls onReading with each decoded value (bpm, rpm
 * or watts). Returns an unsubscribe function that also disconnects — always
 * call it when the caller is done, even on error paths.
 */
export async function subscribeToSensor(
  peripheralId: string,
  kind: SensorKind,
  onReading: (value: number) => void,
  onError: (message: string) => void
): Promise<() => void> {
  try {
    const device = await connectAndDiscover(peripheralId);
    const profile = SENSOR_PROFILES[kind];
    const cscParser = kind === 'speed_cadence' ? makeCscParser() : null;

    const subscription = device.monitorCharacteristicForService(
      profile.service,
      profile.characteristic,
      (error: BleErrorT | null, characteristic) => {
        if (error) {
          onError(error.message ?? 'Lost connection to the sensor.');
          return;
        }
        if (!characteristic?.value) return;
        try {
          const buffer = decodeBase64(characteristic.value);
          const view = new DataView(buffer);
          const value = kind === 'heart_rate' ? parseHeartRate(view) : kind === 'power' ? parseCyclingPower(view) : cscParser!(view);
          if (value != null) onReading(value);
        } catch {
          // One malformed notification shouldn't kill the whole subscription — skip it and wait for the next.
        }
      }
    );

    return () => {
      subscription.remove();
      device.cancelConnection().catch(() => {});
    };
  } catch (e) {
    onError(e instanceof Error ? e.message : 'Could not connect to this sensor.');
    return () => {};
  }
}

export async function disconnectPeripheral(peripheralId: string): Promise<void> {
  try {
    await getManager().cancelDeviceConnection(peripheralId);
  } catch {
    // Already disconnected — nothing to do.
  }
}
