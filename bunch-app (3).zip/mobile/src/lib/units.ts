import type { UnitSystem } from './database.types';

const METERS_PER_MILE = 1609.344;
const METERS_PER_FOOT = 0.3048;

/** Distance for display, e.g. "42.3 km" / "26.3 mi". */
export function formatDistance(meters: number, units: UnitSystem, opts?: { compact?: boolean }): string {
  if (units === 'imperial') {
    const mi = meters / METERS_PER_MILE;
    return `${mi.toFixed(mi < 10 ? 2 : 1)}${opts?.compact ? '' : ' '}mi`;
  }
  const km = meters / 1000;
  return `${km.toFixed(km < 10 ? 2 : 1)}${opts?.compact ? '' : ' '}km`;
}

/** Short unit label only, e.g. for axis labels: "km" / "mi". */
export function distanceUnitLabel(units: UnitSystem): string {
  return units === 'imperial' ? 'mi' : 'km';
}

export function metersToDisplayDistance(meters: number, units: UnitSystem): number {
  return units === 'imperial' ? meters / METERS_PER_MILE : meters / 1000;
}

export function displayDistanceToMeters(value: number, units: UnitSystem): number {
  return units === 'imperial' ? value * METERS_PER_MILE : value * 1000;
}

/** Inverse of formatElevation's conversion — feet back to meters when imperial. */
export function displayElevationToMeters(value: number, units: UnitSystem): number {
  return units === 'imperial' ? value * METERS_PER_FOOT : value;
}

/** Elevation for display, e.g. "612 m" / "2,008 ft". */
export function formatElevation(meters: number, units: UnitSystem): string {
  if (units === 'imperial') {
    const ft = meters / METERS_PER_FOOT;
    return `${Math.round(ft).toLocaleString()} ft`;
  }
  return `${Math.round(meters).toLocaleString()} m`;
}

/** Speed for display, e.g. "28.4 km/h" / "17.6 mph". */
export function formatSpeed(metersPerSecond: number, units: UnitSystem): string {
  const kmh = metersPerSecond * 3.6;
  if (units === 'imperial') {
    const mph = kmh / 1.60934;
    return `${mph.toFixed(1)} mph`;
  }
  return `${kmh.toFixed(1)} km/h`;
}

/** Pace for display, e.g. "2:08 /km" / "3:26 /mi" — handy for climbs/segments. */
export function formatPace(metersPerSecond: number, units: UnitSystem): string {
  if (metersPerSecond <= 0) return '--:--';
  const secondsPerUnit = units === 'imperial' ? METERS_PER_MILE / metersPerSecond : 1000 / metersPerSecond;
  const m = Math.floor(secondsPerUnit / 60);
  const s = Math.round(secondsPerUnit % 60);
  return `${m}:${s.toString().padStart(2, '0')} /${units === 'imperial' ? 'mi' : 'km'}`;
}

/** Duration for display. Compact ("1:04:32") or long ("1h 04m"). */
export function formatDuration(totalSeconds: number, style: 'clock' | 'long' = 'clock'): string {
  const s = Math.max(0, Math.round(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;

  if (style === 'long') {
    if (h > 0) return `${h}h ${m.toString().padStart(2, '0')}m`;
    if (m > 0) return `${m}m ${sec.toString().padStart(2, '0')}s`;
    return `${sec}s`;
  }

  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

export function formatWeight(kg: number, units: UnitSystem): string {
  if (units === 'imperial') return `${Math.round(kg * 2.20462)} lb`;
  return `${Math.round(kg)} kg`;
}

/** Rough calorie estimate from distance/elevation/rider weight — shown as an estimate, never a paywalled or precise figure. */
export function estimateCalories(distanceM: number, elevationGainM: number, movingTimeS: number, weightKg = 75): number {
  const hours = movingTimeS / 3600;
  if (hours <= 0) return 0;
  const avgKmh = distanceM / 1000 / hours;
  // MET approximation for moderate cycling, nudged up for climbing.
  const met = avgKmh < 16 ? 6 : avgKmh < 22 ? 8 : avgKmh < 28 ? 10 : 12;
  const climbBonus = (elevationGainM / 100) * 0.4 * weightKg;
  return Math.round(met * weightKg * hours + climbBonus);
}

// ---------------------------------------------------------------------------
// "Parts" variants: the number and its unit separately, for stat displays that
// render the number big and the unit small (the way every bike computer and
// Strava/Komoot stat does). The plain format* helpers above stay the source of
// truth for rounding — these just split their output.
// ---------------------------------------------------------------------------
export interface ValueUnit {
  value: string;
  unit: string;
}

function splitLast(text: string): ValueUnit {
  const i = text.lastIndexOf(' ');
  return i < 0 ? { value: text, unit: '' } : { value: text.slice(0, i), unit: text.slice(i + 1) };
}

export function distanceParts(meters: number, units: UnitSystem): ValueUnit {
  return splitLast(formatDistance(meters, units));
}
export function speedParts(metersPerSecond: number, units: UnitSystem): ValueUnit {
  return splitLast(formatSpeed(metersPerSecond, units));
}
export function elevationParts(meters: number, units: UnitSystem): ValueUnit {
  return splitLast(formatElevation(meters, units));
}
