import * as FileSystem from 'expo-file-system';
import type { TablesInsert } from '@/lib/database.types';

/**
 * Durable local queue for rides finished with no connection. A ride is
 * written here in full the moment saving it is attempted with no network —
 * this is the primary path for that case, not a fallback bolted on after a
 * failure: "no signal" must never be able to mean "lost ride." syncManager.ts
 * drains this queue (in order) whenever there's a real chance of success.
 *
 * One file per queued ride, named by a locally generated id, mirroring
 * recording/storage.ts's reasoning for using expo-file-system directly
 * instead of AsyncStorage: adding or removing one ride is a single file
 * write/delete, never a read-modify-write of one shared blob that a crash
 * mid-write could corrupt wholesale.
 */
const OUTBOX_DIR = `${FileSystem.documentDirectory}ride_outbox/`;

export interface QueuedRide {
  localId: string;
  queuedAt: number;
  payload: TablesInsert<'rides'>;
  trackJSON: string;
  taggedRiderIds: string[];
}

async function ensureDir(): Promise<void> {
  const info = await FileSystem.getInfoAsync(OUTBOX_DIR);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(OUTBOX_DIR, { intermediates: true });
  }
}

function fileFor(localId: string): string {
  return `${OUTBOX_DIR}${localId}.json`;
}

/** Queues a finished ride for upload and returns its local id. Safe to call whether or not there's actually a connection — syncManager decides when to try. */
export async function queueRideForUpload(
  payload: TablesInsert<'rides'>,
  trackJSON: string,
  taggedRiderIds: string[] = []
): Promise<string> {
  await ensureDir();
  const localId = `local_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  const entry: QueuedRide = { localId, queuedAt: Date.now(), payload, trackJSON, taggedRiderIds };
  await FileSystem.writeAsStringAsync(fileFor(localId), JSON.stringify(entry));
  return localId;
}

/** Every ride still waiting to upload, oldest first — the order syncManager uploads them in. */
export async function listQueuedRides(): Promise<QueuedRide[]> {
  await ensureDir();
  const names = await FileSystem.readDirectoryAsync(OUTBOX_DIR).catch(() => [] as string[]);
  const entries = await Promise.all(
    names
      .filter((n) => n.endsWith('.json'))
      .map(async (name) => {
        try {
          const raw = await FileSystem.readAsStringAsync(`${OUTBOX_DIR}${name}`);
          return JSON.parse(raw) as QueuedRide;
        } catch {
          return null; // one corrupt entry never blocks the rest of the queue
        }
      })
  );
  return entries.filter((e): e is QueuedRide => e != null).sort((a, b) => a.queuedAt - b.queuedAt);
}

export async function removeQueuedRide(localId: string): Promise<void> {
  await FileSystem.deleteAsync(fileFor(localId), { idempotent: true }).catch(() => {});
}

export async function getQueuedRideCount(): Promise<number> {
  return (await listQueuedRides()).length;
}
