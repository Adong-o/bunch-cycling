import { colors } from './colors';

export const spacing = {
  xxs: 4,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
} as const;

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
  xl: 28,
  pill: 999,
} as const;

// Manrope for everything readable, JetBrains Mono for numbers that need to
// line up and feel like they came off a bike computer (speed, distance,
// time readouts on the record screen and ride summary).
export const fonts = {
  regular: 'Manrope_400Regular',
  medium: 'Manrope_500Medium',
  semiBold: 'Manrope_600SemiBold',
  bold: 'Manrope_700Bold',
  extraBold: 'Manrope_800ExtraBold',
  mono: 'JetBrainsMono_500Medium',
  monoBold: 'JetBrainsMono_700Bold',
} as const;

export const type = {
  display: { fontFamily: fonts.extraBold, fontSize: 40, lineHeight: 46 },
  h1: { fontFamily: fonts.bold, fontSize: 28, lineHeight: 34 },
  h2: { fontFamily: fonts.bold, fontSize: 22, lineHeight: 28 },
  h3: { fontFamily: fonts.semiBold, fontSize: 18, lineHeight: 24 },
  body: { fontFamily: fonts.regular, fontSize: 16, lineHeight: 23 },
  bodyMedium: { fontFamily: fonts.medium, fontSize: 16, lineHeight: 23 },
  small: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 20 },
  smallMedium: { fontFamily: fonts.medium, fontSize: 14, lineHeight: 20 },
  caption: { fontFamily: fonts.medium, fontSize: 12, lineHeight: 16, letterSpacing: 0.3 },
  statLarge: { fontFamily: fonts.monoBold, fontSize: 36, lineHeight: 40 },
  statMedium: { fontFamily: fonts.mono, fontSize: 20, lineHeight: 24 },
} as const;

// Soft, ambient shadows tuned for a light surface — tinted toward ink
// instead of pure black, and much lower opacity than the old dark-theme
// values (0.3–0.4 opacity reads as a heavy, slapped-on drop shadow once the
// surface behind it is white instead of near-black). elevation (Android)
// stays modest for the same reason.
export const shadow = {
  card: {
    shadowColor: '#15171B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 2,
  },
  floating: {
    shadowColor: '#15171B',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.10,
    shadowRadius: 22,
    elevation: 6,
  },
} as const;

export const theme = { colors, spacing, radius, fonts, type, shadow };
export { colors };
export type Theme = typeof theme;
