// Sampled directly from the Bunch logo files. These four are the only
// "brand" colors — everything else here is a tonal scale built around them
// so the app has somewhere to put a border, a disabled state, a second
// elevation of card, etc. without anyone picking random hex values later.
//
// v1.2: moved off a dark-by-default palette to a clean, light one — the
// brand blue is untouched (it's literally sampled from the logo), only the
// neutral scale changed. `bg` is a hair off pure white rather than #FFFFFF
// itself so cards (`surface`, which IS pure white) read as a subtle lift
// without needing a heavy shadow to do all the work — the same trick behind
// why most premium light-mode apps don't look flat.
const brand = {
  ink: '#15171B', // primary text — was the background in v1
  blue: '#4D47FC', // primary accent — CTAs, active states, links (unchanged)
  slate: '#6B7280', // secondary text, icons, muted UI
  cream: '#FAFAF8', // base app background
};

export const colors = {
  ...brand,

  // Surfaces, the app's new light-by-default base (see app.config.ts
  // userInterfaceStyle). bg sits a shade below surface so flat cards still
  // read as lifted against the page.
  bg: brand.cream,
  surface: '#FFFFFF', // cards, list rows
  surfaceHigh: '#F2F2EF', // sheets, modals, the record-ride control bar
  surfaceHighest: '#E6E6E2', // pressed/selected state of surfaceHigh

  border: '#EAEAE6',
  borderStrong: '#D8D8D3',

  textPrimary: brand.ink,
  textSecondary: brand.slate,
  textTertiary: '#9B9B94',
  textOnAccent: '#FFFFFF',

  accent: brand.blue,
  accentPressed: '#3C37CC',
  accentMuted: 'rgba(77, 71, 252, 0.10)',

  // Deepened from the dark-theme values — a pastel mint/rose/gold that read
  // fine against near-black surfaces loses too much contrast as TEXT against
  // a near-white one, so these are darkened to stay legible as label color,
  // not just as a tinted chip background.
  success: '#17875A',
  successMuted: 'rgba(23, 135, 90, 0.12)',
  danger: '#C8372F',
  dangerMuted: 'rgba(200, 55, 47, 0.10)',
  gold: '#AD7D0A', // streaks, badges, premium accents
  goldMuted: 'rgba(173, 125, 10, 0.12)',

  // Floating chrome that sits ON TOP of live map imagery (the recording
  // status pill, map attribution) rather than on the app's own background —
  // a light frosted chip with dark text over a map reads as current and
  // premium (think Apple/Google Maps overlays), and it means this chrome can
  // keep using the same textPrimary/textSecondary tokens as everything else
  // instead of a separate "text that sits on dark chrome" token.
  overlay: 'rgba(255, 255, 255, 0.90)',
  mapAttributionBg: 'rgba(255, 255, 255, 0.85)',
} as const;

export type ColorToken = keyof typeof colors;
