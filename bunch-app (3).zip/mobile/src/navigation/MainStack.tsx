import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { MainStackParamList } from './types';
import { MainTabs } from './MainTabs';
import { ChallengesStack } from './ChallengesStack';

const Stack = createNativeStackNavigator<MainStackParamList>();

// The actual root once signed in and onboarded: the 4-tab bar, plus
// Challenges presented as a full-screen modal that slides up over it. Any
// screen inside the tabs reaches it with navigation.navigate('Challenges')
// (optionally `{ screen: 'ChallengeDetail', params: { challengeId } }` to
// deep-link straight to a specific screen inside ChallengesStack) — React
// Navigation bubbles an unrecognized route name up to the nearest ancestor
// navigator that owns it, so this works from Feed, Routes, or Profile
// without any of them needing to know MainStack exists.
export function MainStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Tabs" component={MainTabs} />
      <Stack.Screen name="Challenges" component={ChallengesStack} options={{ presentation: 'modal' }} />
    </Stack.Navigator>
  );
}
