import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';

export type AuthStackParamList = {
  Welcome: undefined;
  // Sign-in and sign-up are one screen with a sliding tab, not two routes —
  // `initialTab` just picks which tab is open when it's reached.
  Auth: { initialTab?: 'signin' | 'signup' } | undefined;
  PrivacyPolicy: undefined;
  Terms: undefined;
};

export type OnboardingStackParamList = {
  Intro: undefined;
  RiderType: undefined;
  ProfileSetup: undefined;
  TargetSetup: undefined;
  PermissionsSetup: undefined;
  ImportData: undefined;
  UpgradeOffer: undefined;
  Done: undefined;
};

export type HomeStackParamList = {
  Feed: undefined;
  FindRiders: undefined;
  RideDetail: { rideId: string };
  UserProfile: { userId: string };
};

export type RecordStackParamList = {
  RecordRide: undefined;
  RideSummary: {
    startedAt: string;
    endedAt: string;
    distanceM: number;
    movingTimeS: number;
    elapsedTimeS: number;
    elevationGainM: number;
    elevationLossM: number;
    avgSpeedMps: number;
    maxSpeedMps: number;
    routeGeoJSON: string; // JSON-stringified RouteGeoJSON (nav params must be serializable)
    trackJSON: string; // JSON-stringified TrackPoint[] for segment matching after save
    /** Set when the ride followed a planned route ("Ride this route"), so the saved ride is linked to it. */
    routeId?: string;
  };
};

export type ChallengesStackParamList = {
  ChallengesList: undefined;
  ChallengeDetail: { challengeId: string };
  CreateChallenge: undefined;
  // Optional `code` is set when arriving from a shared bunch://challenge/:code
  // deep link (see RootNavigator's `linking` config) — pre-fills and
  // auto-submits instead of making someone retype a code they just tapped.
  JoinByCode: { code?: string } | undefined;
};

export type RoutesStackParamList = {
  RoutesList: undefined;
  SavedRoutes: undefined;
  RouteBuilder: undefined;
  RouteDetail: { routeId: string };
};

export type ProfileStackParamList = {
  MyProfile: undefined;
  EditProfile: undefined;
  Garage: undefined;
  Badges: undefined;
  Segments: undefined;
  SegmentDetail: { segmentId: string };
  Devices: undefined;
  Stats: undefined;
  RideHeatmap: undefined;
  ImportRides: undefined;
  Premium: undefined;
  Settings: undefined;
  Admin: undefined;
  PrivacyPolicy: undefined;
  Terms: undefined;
};

export type MainTabParamList = {
  HomeTab: undefined;
  RoutesTab: undefined;
  RecordTab: undefined;
  ProfileTab: undefined;
};

// Wraps MainTabs and anything that should slide in OVER the tab bar rather
// than live inside one tab's own push stack — today just Challenges, which
// the 1.2.1 tab bar (Feed / Routes / Record / Profile) has no slot for. It's
// reachable from a header icon on Feed and from the featured-challenges
// carousel, both via navigation.navigate('Challenges', ...), which React
// Navigation bubbles up to whichever ancestor navigator actually owns that
// route — no need to thread a MainStack-aware prop type through every screen.
export type MainStackParamList = {
  Tabs: undefined;
  Challenges: { screen?: keyof ChallengesStackParamList; params?: ChallengesStackParamList[keyof ChallengesStackParamList] } | undefined;
};

export type AuthScreenProps<T extends keyof AuthStackParamList> = NativeStackScreenProps<AuthStackParamList, T>;
export type OnboardingScreenProps<T extends keyof OnboardingStackParamList> = NativeStackScreenProps<OnboardingStackParamList, T>;

export type HomeScreenProps<T extends keyof HomeStackParamList> = CompositeScreenProps<
  NativeStackScreenProps<HomeStackParamList, T>,
  BottomTabScreenProps<MainTabParamList>
>;
export type RecordScreenProps<T extends keyof RecordStackParamList> = CompositeScreenProps<
  NativeStackScreenProps<RecordStackParamList, T>,
  BottomTabScreenProps<MainTabParamList>
>;
export type ChallengesScreenProps<T extends keyof ChallengesStackParamList> = CompositeScreenProps<
  NativeStackScreenProps<ChallengesStackParamList, T>,
  NativeStackScreenProps<MainStackParamList>
>;
export type RoutesScreenProps<T extends keyof RoutesStackParamList> = CompositeScreenProps<
  NativeStackScreenProps<RoutesStackParamList, T>,
  BottomTabScreenProps<MainTabParamList>
>;
export type ProfileScreenProps<T extends keyof ProfileStackParamList> = CompositeScreenProps<
  NativeStackScreenProps<ProfileStackParamList, T>,
  BottomTabScreenProps<MainTabParamList>
>;
