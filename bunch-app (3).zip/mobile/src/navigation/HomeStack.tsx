import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { HomeStackParamList } from './types';
import { FeedScreen } from '@/screens/home/FeedScreen';
import { RideDetailScreen } from '@/screens/home/RideDetailScreen';
import { UserProfileScreen } from '@/screens/home/UserProfileScreen';
import { FindRidersScreen } from '@/screens/home/FindRidersScreen';
import { colors } from '@/theme';

const Stack = createNativeStackNavigator<HomeStackParamList>();

export function HomeStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="Feed" component={FeedScreen} />
      <Stack.Screen name="RideDetail" component={RideDetailScreen} />
      <Stack.Screen name="UserProfile" component={UserProfileScreen} />
      <Stack.Screen name="FindRiders" component={FindRidersScreen} />
    </Stack.Navigator>
  );
}
