import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { RoutesStackParamList } from './types';
import { RoutesScreen } from '@/screens/profile/RoutesScreen';
import { SavedRoutesScreen } from '@/screens/profile/SavedRoutesScreen';
import { RouteBuilderScreen } from '@/screens/profile/RouteBuilderScreen';
import { RouteDetailScreen } from '@/screens/routes/RouteDetailScreen';
import { colors } from '@/theme';

const Stack = createNativeStackNavigator<RoutesStackParamList>();

export function RoutesStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="RoutesList" component={RoutesScreen} />
      <Stack.Screen name="RouteDetail" component={RouteDetailScreen} />
      <Stack.Screen name="SavedRoutes" component={SavedRoutesScreen} />
      <Stack.Screen name="RouteBuilder" component={RouteBuilderScreen} options={{ presentation: 'fullScreenModal' }} />
    </Stack.Navigator>
  );
}
