import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import type { MainTabParamList } from './types';
import { HomeStack } from './HomeStack';
import { RecordStack } from './RecordStack';
import { RoutesStack } from './RoutesStack';
import { ProfileStack } from './ProfileStack';
import { AppTabBar } from './AppTabBar';

const Tab = createBottomTabNavigator<MainTabParamList>();

// Four equal, labelled tabs — Home, Routes, Record, Profile — drawn by
// AppTabBar (icon + caption for every tab, Record included; it turns into a
// live "Recording" indicator while a ride is open). Challenges lives behind a
// header icon on Home and the featured-challenges carousel (see MainStack.tsx).
export function MainTabs() {
  return (
    <Tab.Navigator tabBar={(props) => <AppTabBar {...props} />} screenOptions={{ headerShown: false }}>
      <Tab.Screen name="HomeTab" component={HomeStack} options={{ title: 'Home' }} />
      <Tab.Screen name="RoutesTab" component={RoutesStack} options={{ title: 'Routes' }} />
      <Tab.Screen name="RecordTab" component={RecordStack} options={{ title: 'Record' }} />
      <Tab.Screen name="ProfileTab" component={ProfileStack} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}
