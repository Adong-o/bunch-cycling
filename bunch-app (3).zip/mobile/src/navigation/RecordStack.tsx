import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { RecordStackParamList } from './types';
import { RecordRideScreen } from '@/screens/record/RecordRideScreen';
import { RideSummaryScreen } from '@/screens/record/RideSummaryScreen';
import { colors } from '@/theme';

const Stack = createNativeStackNavigator<RecordStackParamList>();

export function RecordStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="RecordRide" component={RecordRideScreen} />
      <Stack.Screen name="RideSummary" component={RideSummaryScreen} options={{ gestureEnabled: false }} />
    </Stack.Navigator>
  );
}
