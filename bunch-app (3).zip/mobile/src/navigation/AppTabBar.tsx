import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { MainTabParamList } from './types';
import { HomeTabIcon, ProfileTabIcon, RecordTabIcon, RoutesTabIcon, type TabIconProps } from '@/components/icons/HeroIcons';
import { useRecordingView } from '@/lib/recording/useRecording';
import { useAuthStore } from '@/state/authStore';
import { formatDistance, formatDuration } from '@/lib/units';
import { PulseDot, RECORDING_RED } from '@/components/ui/PulseDot';
import { colors, fonts, radius, shadow, spacing } from '@/theme';

// Four equal, always-labelled tabs — Home, Routes, Record, Profile. Record is a
// tab like the others (ring-and-dot glyph + a caption), not a floating circle:
// an unlabelled centre button made the bar read as "three tabs and a button".
// While a ride is open the Record tab turns into a live indicator
// ("Recording" + pulsing red dot) so it is obvious from any screen.

const PAUSED_ORANGE = '#F28B30';

type TabName = keyof MainTabParamList;

const ICONS: Record<TabName, React.ComponentType<TabIconProps>> = {
  HomeTab: HomeTabIcon,
  RoutesTab: RoutesTabIcon,
  RecordTab: RecordTabIcon,
  ProfileTab: ProfileTabIcon,
};

/** Shown above the tab bar on every tab but Record while a ride is open — tap to jump back to it. */
function RecordingMiniBar({ onOpen }: { onOpen: () => void }) {
  const view = useRecordingView();
  const units = useAuthStore((s) => s.profile?.units ?? 'metric');
  if (!view.active) return null;
  const paused = view.phase !== 'recording';
  return (
    <Pressable
      onPress={onOpen}
      style={({ pressed }) => [styles.mini, pressed && { opacity: 0.9 }]}
      accessibilityRole="button"
      accessibilityLabel="Open the ride you are recording"
    >
      {paused ? <View style={styles.pausedDot} /> : <PulseDot size={10} />}
      <Text style={styles.miniTitle}>{paused ? 'Ride paused' : 'Recording'}</Text>
      <Text style={styles.miniStat}>{formatDuration(view.movingS)}</Text>
      <Text style={styles.miniStat}>{formatDistance(view.distanceM, units)}</Text>
      <View style={styles.miniOpen}>
        <Text style={styles.miniOpenText}>Open</Text>
      </View>
    </Pressable>
  );
}

/** 0 → 1 as the tab becomes focused; drives the soft pill behind the active icon. */
function useFocusAnim(focused: boolean) {
  const v = useRef(new Animated.Value(focused ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(v, { toValue: focused ? 1 : 0, duration: 220, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [focused, v]);
  return v;
}

interface ItemProps {
  name: TabName;
  label: string;
  focused: boolean;
  onPress: () => void;
  onLongPress: () => void;
}

function TabItem({ name, label, focused, onPress, onLongPress }: ItemProps) {
  const anim = useFocusAnim(focused);
  const Icon = ICONS[name];
  const isRecord = name === 'RecordTab';
  // Only the Record tab cares about a live ride; the hook is cheap and keeps
  // the item a single component rather than two near-identical ones.
  const view = useRecordingView();
  const live = isRecord && view.active;
  const paused = live && view.phase !== 'recording';

  const liveColor = paused ? PAUSED_ORANGE : RECORDING_RED;
  const tint = live ? liveColor : focused ? colors.accent : colors.textSecondary;
  const caption = live ? (paused ? 'Paused' : 'Recording') : label;

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      style={({ pressed }) => [styles.item, pressed && { opacity: 0.7 }]}
      accessibilityRole="tab"
      accessibilityState={{ selected: focused }}
      accessibilityLabel={live ? (paused ? 'Record, ride paused' : 'Record, ride in progress') : label}
      testID={`tab-${name}`}
    >
      <View style={styles.iconWrap}>
        <Animated.View
          pointerEvents="none"
          style={[
            styles.pill,
            { backgroundColor: live ? 'rgba(242, 84, 45, 0.12)' : colors.accentMuted },
            { opacity: anim, transform: [{ scaleX: anim.interpolate({ inputRange: [0, 1], outputRange: [0.45, 1] }) }] },
          ]}
        />
        <Icon size={24} color={tint} focused={focused} />
        {live ? (
          <View style={styles.liveBadge}>{paused ? <View style={styles.pausedDot} /> : <PulseDot size={9} color={liveColor} />}</View>
        ) : null}
      </View>
      <Text style={[styles.label, { color: tint }, (focused || live) && styles.labelActive]} numberOfLines={1}>
        {caption}
      </Text>
    </Pressable>
  );
}

export function AppTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const bottomPad = Math.max(insets.bottom, 8);
  const current = state.routes[state.index]?.name;

  return (
    <View>
      {current !== 'RecordTab' ? <RecordingMiniBar onOpen={() => navigation.navigate('RecordTab')} /> : null}
      <View style={[styles.bar, { paddingBottom: bottomPad }]} accessibilityRole="tablist">
        {state.routes.map((route, index) => {
          const focused = state.index === index;
          const label = descriptors[route.key]?.options.title ?? route.name;
          const onPress = () => {
            const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
            if (!focused && !event.defaultPrevented) navigation.navigate(route.name as never);
          };
          const onLongPress = () => navigation.emit({ type: 'tabLongPress', target: route.key });
          return <TabItem key={route.key} name={route.name as TabName} label={label} focused={focused} onPress={onPress} onLongPress={onLongPress} />;
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderTopColor: colors.border,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: 7,
    paddingHorizontal: 4,
  },
  // Every tab gets exactly the same width and centres its own content.
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, paddingBottom: 1 },
  iconWrap: { width: 58, height: 30, alignItems: 'center', justifyContent: 'center' },
  pill: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, borderRadius: 15 },
  label: { fontFamily: fonts.medium, fontSize: 11, letterSpacing: 0.1 },
  labelActive: { fontFamily: fonts.bold },
  liveBadge: {
    position: 'absolute',
    top: -1,
    right: 8,
    width: 15,
    height: 15,
    borderRadius: 8,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mini: {
    marginHorizontal: spacing.sm,
    marginBottom: spacing.xs,
    paddingVertical: 10,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.ink,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    ...shadow.floating,
  },
  pausedDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: PAUSED_ORANGE },
  miniTitle: { fontFamily: fonts.bold, fontSize: 13, color: '#FFFFFF', flex: 1 },
  miniStat: { fontFamily: fonts.monoBold, fontSize: 13, color: 'rgba(255,255,255,0.85)', fontVariant: ['tabular-nums'] },
  miniOpen: { backgroundColor: colors.accent, borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 5 },
  miniOpenText: { fontFamily: fonts.bold, fontSize: 12, color: '#FFFFFF' },
});
