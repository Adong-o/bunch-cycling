import React from 'react';
import { NavigationContainer, DarkTheme, Theme, LinkingOptions } from '@react-navigation/native';
import * as Linking from 'expo-linking';
import { useAuthStore } from '@/state/authStore';
import { AuthStack } from './AuthStack';
import { OnboardingStack } from './OnboardingStack';
import { MainStack } from './MainStack';
import { LoadingView } from '@/components/ui/LoadingView';
import { colors } from '@/theme';

// Lets a shared "Join me on Bunch" link (see ChallengeDetailScreen's
// onShare) open the app straight to the join flow with the code already
// filled in, instead of someone having to retype it. Only resolves while
// MainStack is actually mounted (signed in + onboarded) — a link tapped
// before then just opens the app normally; it isn't remembered through
// sign-in, which is a reasonable gap for how this link is shared (between
// riders who both already use the app).
const linking: LinkingOptions<Record<string, unknown>> = {
  prefixes: [Linking.createURL('/'), 'bunch://'],
  config: {
    screens: {
      Challenges: {
        screens: {
          JoinByCode: 'challenge/:code',
        },
      },
    },
  },
};

const navTheme: Theme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.bg,
    card: colors.surfaceHigh,
    text: colors.textPrimary,
    border: colors.border,
    primary: colors.accent,
  },
};

export function RootNavigator() {
  const initializing = useAuthStore((s) => s.initializing);
  const session = useAuthStore((s) => s.session);
  const profile = useAuthStore((s) => s.profile);
  const profileLoading = useAuthStore((s) => s.profileLoading);

  if (initializing) {
    return <LoadingView />;
  }

  return (
    <NavigationContainer theme={navTheme} linking={linking}>
      {!session ? (
        <AuthStack />
      ) : profileLoading && !profile ? (
        <LoadingView label="Getting your garage ready…" />
      ) : !profile?.onboarding_completed ? (
        <OnboardingStack />
      ) : (
        <MainStack />
      )}
    </NavigationContainer>
  );
}
