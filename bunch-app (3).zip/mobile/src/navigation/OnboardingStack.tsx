import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { OnboardingStackParamList } from './types';
import { IntroScreen } from '@/screens/onboarding/IntroScreen';
import { RiderTypeScreen } from '@/screens/onboarding/RiderTypeScreen';
import { ProfileSetupScreen } from '@/screens/onboarding/ProfileSetupScreen';
import { TargetSetupScreen } from '@/screens/onboarding/TargetSetupScreen';
import { PermissionsSetupScreen } from '@/screens/onboarding/PermissionsSetupScreen';
import { ImportDataScreen } from '@/screens/onboarding/ImportDataScreen';
import { UpgradeOfferScreen } from '@/screens/onboarding/UpgradeOfferScreen';
import { DoneScreen } from '@/screens/onboarding/DoneScreen';
import { colors } from '@/theme';

const Stack = createNativeStackNavigator<OnboardingStackParamList>();

export function OnboardingStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg }, gestureEnabled: false }}>
      <Stack.Screen name="Intro" component={IntroScreen} />
      <Stack.Screen name="RiderType" component={RiderTypeScreen} />
      <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
      <Stack.Screen name="TargetSetup" component={TargetSetupScreen} />
      <Stack.Screen name="PermissionsSetup" component={PermissionsSetupScreen} />
      <Stack.Screen name="ImportData" component={ImportDataScreen} />
      <Stack.Screen name="UpgradeOffer" component={UpgradeOfferScreen} />
      <Stack.Screen name="Done" component={DoneScreen} />
    </Stack.Navigator>
  );
}
