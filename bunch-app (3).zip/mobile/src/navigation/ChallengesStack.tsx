import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { ChallengesStackParamList } from './types';
import { ChallengesListScreen } from '@/screens/challenges/ChallengesListScreen';
import { ChallengeDetailScreen } from '@/screens/challenges/ChallengeDetailScreen';
import { CreateChallengeScreen } from '@/screens/challenges/CreateChallengeScreen';
import { JoinByCodeScreen } from '@/screens/challenges/JoinByCodeScreen';
import { colors } from '@/theme';

const Stack = createNativeStackNavigator<ChallengesStackParamList>();

export function ChallengesStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="ChallengesList" component={ChallengesListScreen} />
      <Stack.Screen name="ChallengeDetail" component={ChallengeDetailScreen} />
      <Stack.Screen name="CreateChallenge" component={CreateChallengeScreen} />
      <Stack.Screen name="JoinByCode" component={JoinByCodeScreen} />
    </Stack.Navigator>
  );
}
