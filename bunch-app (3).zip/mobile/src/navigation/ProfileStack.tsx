import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { ProfileStackParamList } from './types';
import { MyProfileScreen } from '@/screens/profile/MyProfileScreen';
import { EditProfileScreen } from '@/screens/profile/EditProfileScreen';
import { GarageScreen } from '@/screens/profile/GarageScreen';
import { BadgesScreen } from '@/screens/profile/BadgesScreen';
import { SegmentsScreen } from '@/screens/profile/SegmentsScreen';
import { SegmentDetailScreen } from '@/screens/profile/SegmentDetailScreen';
import { DevicesScreen } from '@/screens/profile/DevicesScreen';
import { StatsScreen } from '@/screens/profile/StatsScreen';
import { RideHeatmapScreen } from '@/screens/profile/RideHeatmapScreen';
import { ImportRidesScreen } from '@/screens/profile/ImportRidesScreen';
import { PremiumScreen } from '@/screens/profile/PremiumScreen';
import { SettingsScreen } from '@/screens/profile/SettingsScreen';
import { AdminScreen } from '@/screens/profile/AdminScreen';
import { PrivacyPolicyScreen } from '@/screens/legal/PrivacyPolicyScreen';
import { TermsScreen } from '@/screens/legal/TermsScreen';
import { colors } from '@/theme';

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export function ProfileStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
      <Stack.Screen name="MyProfile" component={MyProfileScreen} />
      <Stack.Screen name="EditProfile" component={EditProfileScreen} />
      <Stack.Screen name="Garage" component={GarageScreen} />
      <Stack.Screen name="Badges" component={BadgesScreen} />
      <Stack.Screen name="Segments" component={SegmentsScreen} />
      <Stack.Screen name="SegmentDetail" component={SegmentDetailScreen} />
      <Stack.Screen name="Devices" component={DevicesScreen} />
      <Stack.Screen name="Stats" component={StatsScreen} />
      <Stack.Screen name="RideHeatmap" component={RideHeatmapScreen} />
      <Stack.Screen name="ImportRides" component={ImportRidesScreen} />
      <Stack.Screen name="Premium" component={PremiumScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="Admin" component={AdminScreen} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} />
      <Stack.Screen name="Terms" component={TermsScreen} />
    </Stack.Navigator>
  );
}
