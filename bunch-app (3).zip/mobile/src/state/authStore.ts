import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { Profile } from '@/lib/database.types';

interface AuthState {
  initializing: boolean;
  session: Session | null;
  profile: Profile | null;
  profileLoading: boolean;
  init: () => () => void;
  refreshProfile: () => Promise<void>;
  updateLocalProfile: (patch: Partial<Profile>) => void;
  signOut: () => Promise<void>;
}

// A cached copy of the signed-in rider's own profile row, so the app can
// open straight to MainStack on a cold start with no network at all.
// supabase-js's own session (see supabase.ts) already persists to
// AsyncStorage and restores offline fine — but the *profile* row has
// always required a fresh network fetch (refreshProfile below), and with
// no local copy of it, a rider opening Bunch with no signal got `profile:
// null` forever. RootNavigator reads a null profile as "hasn't finished
// onboarding" and sends them to OnboardingStack — which is exactly the
// "it starts again from onboarding with no wifi" bug this cache fixes.
const CACHED_PROFILE_KEY = 'bunch:cachedProfile:v1';

export const useAuthStore = create<AuthState>((set, get) => ({
  initializing: true,
  session: null,
  profile: null,
  profileLoading: false,

  init: () => {
    supabase.auth
      .getSession()
      .then(async ({ data }) => {
        const session = data.session;
        if (session) {
          // Show the last-known profile immediately, before the network
          // fetch below has any chance to fail — guarded by user id so a
          // leftover cache from a previously signed-out account on a
          // shared device is never shown for someone else.
          try {
            const raw = await AsyncStorage.getItem(CACHED_PROFILE_KEY);
            const cached = raw ? (JSON.parse(raw) as Profile) : null;
            if (cached && cached.id === session.user.id) {
              set({ profile: cached });
            }
          } catch {
            // Corrupt cache — ignore; refreshProfile() below repopulates it
            // the moment there's a connection.
          }
        }
        set({ session, initializing: false });
        if (session) void get().refreshProfile();
      })
      .catch(() => {
        // getSession() reads from local storage and shouldn't normally
        // reject even offline, but if it ever does, fail open to signed-out
        // rather than leaving the splash screen up forever.
        set({ initializing: false });
      });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      set({ session, initializing: false });
      if (session) {
        void get().refreshProfile();
      } else {
        set({ profile: null });
        AsyncStorage.removeItem(CACHED_PROFILE_KEY).catch(() => {});
      }
    });

    return () => sub.subscription.unsubscribe();
  },

  refreshProfile: async () => {
    const userId = get().session?.user.id;
    if (!userId) return;
    set({ profileLoading: true });
    const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single();
    if (!error && data) {
      set({ profile: data });
      AsyncStorage.setItem(CACHED_PROFILE_KEY, JSON.stringify(data)).catch(() => {});
    }
    // A failed fetch (most commonly: no connection) deliberately leaves
    // `profile` exactly as it was — either the cache above already filled
    // it in, or there was genuinely nothing to show yet — rather than ever
    // clearing a profile the rider already had.
    set({ profileLoading: false });
  },

  updateLocalProfile: (patch) => {
    const current = get().profile;
    if (!current) return;
    const next = { ...current, ...patch };
    set({ profile: next });
    AsyncStorage.setItem(CACHED_PROFILE_KEY, JSON.stringify(next)).catch(() => {});
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ profile: null, session: null });
    await AsyncStorage.removeItem(CACHED_PROFILE_KEY).catch(() => {});
  },
}));
