import { create } from 'zustand';

/** A planned route the rider chose to follow ("Ride this route"). Purely a visual aid + a link saved with the ride. */
export interface GuideRoute {
  id: string;
  name: string;
  distanceM: number;
  coordinates: Array<[number, number]>;
}

interface GuideRouteState {
  route: GuideRoute | null;
  setRoute: (route: GuideRoute) => void;
  clear: () => void;
}

export const useGuideRouteStore = create<GuideRouteState>((set) => ({
  route: null,
  setRoute: (route) => set({ route }),
  clear: () => set({ route: null }),
}));
