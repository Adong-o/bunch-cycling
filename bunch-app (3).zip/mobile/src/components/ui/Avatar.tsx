import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { colors, fonts } from '@/theme';

interface Props {
  uri?: string | null;
  name: string;
  size?: number;
}

export function Avatar({ uri, name, size = 44 }: Props) {
  const initial = name.trim().charAt(0).toUpperCase() || '?';
  const dim = { width: size, height: size, borderRadius: size / 2 };

  if (uri) {
    return <Image source={{ uri }} style={[styles.image, dim]} />;
  }

  return (
    <View style={[styles.fallback, dim]}>
      <Text style={[styles.initial, { fontSize: size * 0.4 }]}>{initial}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  image: { backgroundColor: colors.surfaceHigh },
  fallback: { backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center' },
  initial: { fontFamily: fonts.bold, color: colors.accent },
});
