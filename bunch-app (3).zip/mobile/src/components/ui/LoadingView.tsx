import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { colors, fonts } from '@/theme';

export function LoadingView({ label }: { label?: string }) {
  return (
    <View style={styles.root}>
      <ActivityIndicator color={colors.accent} size="large" />
      {label ? <Text style={styles.label}>{label}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg, gap: 12 },
  label: { fontFamily: fonts.medium, color: colors.textSecondary, fontSize: 14 },
});
