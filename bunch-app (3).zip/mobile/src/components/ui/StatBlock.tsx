import React from 'react';
import { StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { colors, fonts } from '@/theme';

interface Props {
  label: string;
  /**
   * The formatted value. Units are picked out automatically ("24.0 km" renders
   * a big "24.0" and a small "km"; "1h 05m" renders big 1 / small h / big 05 /
   * small m) so call sites keep passing the same strings they always did.
   */
  value: string;
  /** Pass a unit explicitly when `value` is only the number. */
  unit?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  align?: 'left' | 'center';
  /** Put the label above the number (profile/summary style) instead of below. */
  labelFirst?: boolean;
  /** Mono numerals (bike-computer look) — for live readouts only. */
  mono?: boolean;
  style?: StyleProp<ViewStyle>;
}

interface Token {
  text: string;
  isUnit: boolean;
}

/** "22.0 km/h" -> [22.0][ km/h]; "1:05:41" -> [1:05:41]; "1h 05m" -> [1][h ][05][m]. */
export function tokenizeValue(value: string): Token[] {
  const out: Token[] = [];
  const re = /([0-9][0-9.,:]*|[–—-]$)|([A-Za-z%/°′″][A-Za-z%/°′″\s]*)/g;
  let m: RegExpExecArray | null;
  let last = 0;
  while ((m = re.exec(value))) {
    if (m.index > last) out.push({ text: value.slice(last, m.index), isUnit: false });
    out.push({ text: m[0], isUnit: m[2] !== undefined });
    last = m.index + m[0].length;
  }
  if (last < value.length) out.push({ text: value.slice(last), isUnit: false });
  return out;
}

const SIZES = {
  sm: { value: 16, unit: 11, label: 11, line: 20 },
  md: { value: 22, unit: 12, label: 11, line: 26 },
  lg: { value: 30, unit: 14, label: 12, line: 34 },
  xl: { value: 40, unit: 16, label: 12, line: 44 },
} as const;

export function StatBlock({ label, value, unit, size = 'md', align = 'left', labelFirst = false, mono = false, style }: Props) {
  const s = SIZES[size];
  const tokens = unit ? [{ text: value, isUnit: false }, { text: ` ${unit}`, isUnit: true }] : tokenizeValue(value);
  const valueFont = mono ? fonts.monoBold : fonts.extraBold;
  const labelEl = <Text style={[styles.label, { fontSize: s.label, textAlign: align }, labelFirst ? { marginBottom: 2 } : { marginTop: 2 }]}>{label}</Text>;
  return (
    <View style={[{ alignItems: align === 'center' ? 'center' : 'flex-start' }, style]}>
      {labelFirst ? labelEl : null}
      <Text numberOfLines={1} style={{ fontFamily: valueFont, fontSize: s.value, lineHeight: s.line, color: colors.textPrimary, letterSpacing: mono ? -0.5 : -0.3, fontVariant: ['tabular-nums'] }}>
        {tokens.map((t, i) =>
          t.isUnit ? (
            <Text key={i} style={{ fontFamily: fonts.semiBold, fontSize: s.unit, color: colors.textSecondary, letterSpacing: 0 }}>
              {t.text}
            </Text>
          ) : (
            t.text
          )
        )}
      </Text>
      {labelFirst ? null : labelEl}
    </View>
  );
}

const styles = StyleSheet.create({
  label: { fontFamily: fonts.semiBold, color: colors.textSecondary, letterSpacing: 0.2 },
});
