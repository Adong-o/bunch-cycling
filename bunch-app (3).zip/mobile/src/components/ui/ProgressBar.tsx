import React from 'react';
import { StyleSheet, View } from 'react-native';
import { colors } from '@/theme';

interface Props {
  /** 0..1 — values outside that range are clamped. */
  progress: number;
  color?: string;
  trackColor?: string;
  height?: number;
}

export function ProgressBar({ progress, color = colors.accent, trackColor = colors.surfaceHigh, height = 8 }: Props) {
  const pct = Math.max(0, Math.min(1, Number.isFinite(progress) ? progress : 0));
  return (
    <View style={[styles.track, { backgroundColor: trackColor, height, borderRadius: height / 2 }]}>
      <View style={[styles.fill, { backgroundColor: color, width: `${pct * 100}%`, borderRadius: height / 2 }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  track: { width: '100%', overflow: 'hidden' },
  fill: { height: '100%' },
});
