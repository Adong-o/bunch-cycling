import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radius } from '@/theme';

type Tone = 'accent' | 'gold' | 'success' | 'danger' | 'neutral';

interface Props {
  label: string;
  tone?: Tone;
  icon?: React.ReactNode;
}

export function Pill({ label, tone = 'neutral', icon }: Props) {
  const toneStyle = toneStyles[tone];
  return (
    <View style={[styles.base, { backgroundColor: toneStyle.bg }]}>
      {icon}
      <Text style={[styles.label, { color: toneStyle.fg }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: radius.pill,
    alignSelf: 'flex-start',
  },
  label: { fontFamily: fonts.semiBold, fontSize: 12 },
});

const toneStyles: Record<Tone, { bg: string; fg: string }> = {
  accent: { bg: colors.accentMuted, fg: colors.accent },
  gold: { bg: colors.goldMuted, fg: colors.gold },
  success: { bg: colors.successMuted, fg: colors.success },
  danger: { bg: colors.dangerMuted, fg: colors.danger },
  neutral: { bg: colors.surfaceHigh, fg: colors.textSecondary },
};
