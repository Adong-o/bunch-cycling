import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radius, spacing } from '@/theme';
import { Button } from './Button';

interface Props {
  /** Usually an <Ionicons/> element — it is tinted with the brand colour and set on a soft tile. */
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  /** Fill the main action with the brand colour — for the one thing to do on an otherwise empty screen. */
  primary?: boolean;
  secondaryLabel?: string;
  onSecondary?: () => void;
}

/**
 * What a screen shows before there is anything on it — and on a brand-new
 * account that is most screens, because Bunch ships no sample data. Every one
 * should say what will live here and give the rider something to do about it.
 */
export function EmptyState({ icon, title, description, actionLabel, onAction, primary = false, secondaryLabel, onSecondary }: Props) {
  const tinted = React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<{ color?: string }>, { color: colors.accent }) : icon;
  return (
    <View style={styles.root}>
      {tinted ? <View style={styles.iconTile}>{tinted}</View> : null}
      <Text style={styles.title}>{title}</Text>
      {description ? <Text style={styles.description}>{description}</Text> : null}
      {actionLabel && onAction ? (
        <Button title={actionLabel} onPress={onAction} variant={primary ? 'primary' : 'secondary'} size="md" fullWidth={false} style={styles.button} />
      ) : null}
      {secondaryLabel && onSecondary ? <Button title={secondaryLabel} onPress={onSecondary} variant="ghost" size="md" fullWidth={false} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { alignItems: 'center', justifyContent: 'center', paddingVertical: spacing.xxl, paddingHorizontal: spacing.lg, gap: 6 },
  iconTile: { width: 68, height: 68, borderRadius: 24, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.xs },
  title: { fontFamily: fonts.bold, fontSize: 18, color: colors.textPrimary, textAlign: 'center' },
  description: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary, textAlign: 'center', lineHeight: 21, maxWidth: 320 },
  button: { marginTop: spacing.sm, paddingHorizontal: spacing.lg },
});
