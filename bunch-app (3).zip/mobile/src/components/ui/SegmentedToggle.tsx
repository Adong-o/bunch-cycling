import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radius } from '@/theme';

interface Option<T extends string> {
  value: T;
  label: string;
}

interface Props<T extends string> {
  options: Option<T>[];
  value: T;
  onChange: (value: T) => void;
}

/**
 * A pill-tracked toggle for a genuinely binary choice (metric vs imperial,
 * daily vs weekly) — used instead of two side-by-side bordered boxes, which
 * is the same card chrome as every multi-option list in the app and reads
 * as one more identical box rather than a distinct, two-sided control.
 */
export function SegmentedToggle<T extends string>({ options, value, onChange }: Props<T>) {
  return (
    <View style={styles.track}>
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <Pressable key={opt.value} onPress={() => onChange(opt.value)} style={[styles.segment, active && styles.segmentActive]}>
            <Text style={[styles.label, active && styles.labelActive]}>{opt.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  track: { flexDirection: 'row', backgroundColor: colors.surfaceHigh, borderRadius: radius.pill, padding: 4 },
  segment: { flex: 1, paddingVertical: 11, borderRadius: radius.pill, alignItems: 'center' },
  segmentActive: { backgroundColor: colors.bg },
  label: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textSecondary },
  labelActive: { color: colors.textPrimary },
});
