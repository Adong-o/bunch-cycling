import React, { useEffect, useRef } from 'react';
import { Animated, Easing, View } from 'react-native';

export const RECORDING_RED = '#F2542D';

/** A softly pulsing dot — "a ride is being recorded right now". */
export function PulseDot({ size = 10, color = RECORDING_RED }: { size?: number; color?: string }) {
  const scale = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(scale, { toValue: 1.9, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(scale, { toValue: 1, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [scale]);
  const ringOpacity = scale.interpolate({ inputRange: [1, 1.9], outputRange: [0.5, 0] });
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View style={{ position: 'absolute', width: size, height: size, borderRadius: size / 2, backgroundColor: color, opacity: ringOpacity, transform: [{ scale }] }} />
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color }} />
    </View>
  );
}
