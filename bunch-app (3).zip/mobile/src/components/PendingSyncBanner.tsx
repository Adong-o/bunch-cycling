import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, AppState, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getPendingRideCount, syncPendingRides } from '@/lib/syncManager';
import { colors, fonts, radius, spacing } from '@/theme';

/**
 * A small reassurance banner shown while a ride recorded with no connection
 * is still sitting in the local offline queue (rideOutbox.ts) waiting to
 * upload — answers "did my ride actually save?" without the rider having to
 * dig for it. Renders nothing once the queue is empty. Polls lightly rather
 * than subscribing to syncManager directly, since this count only needs to
 * be approximately fresh, not instant.
 */
export function PendingSyncBanner() {
  const [count, setCount] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const refresh = useCallback(() => {
    getPendingRideCount()
      .then(setCount)
      .catch(() => {});
  }, []);

  useEffect(() => {
    refresh();
    const sub = AppState.addEventListener('change', (next) => {
      if (next === 'active') refresh();
    });
    const interval = setInterval(refresh, 15000);
    return () => {
      sub.remove();
      clearInterval(interval);
    };
  }, [refresh]);

  if (count === 0) return null;

  async function onRetry() {
    setSyncing(true);
    await syncPendingRides().catch(() => {});
    setSyncing(false);
    refresh();
  }

  return (
    <View style={styles.root}>
      <Ionicons name="cloud-upload-outline" size={18} color={colors.accent} />
      <Text style={styles.text}>
        {count} ride{count === 1 ? '' : 's'} waiting to sync
      </Text>
      <Pressable onPress={onRetry} disabled={syncing} style={styles.retryButton} hitSlop={8}>
        {syncing ? <ActivityIndicator size="small" color={colors.accent} /> : <Text style={styles.retryText}>Retry now</Text>}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    // No marginHorizontal: unlike FeaturedChallengesCarousel (which cancels
    // the parent FlatList's own paddingHorizontal to scroll edge-to-edge),
    // this sits inset exactly like a normal RideCard — flush with the
    // FlatList's existing horizontal padding, not doubled up on top of it.
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: spacing.sm,
    marginBottom: spacing.xs,
    backgroundColor: colors.accentMuted,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.accent,
    paddingVertical: 10,
    paddingHorizontal: spacing.sm,
  },
  text: { flex: 1, fontFamily: fonts.medium, fontSize: 13, color: colors.textPrimary },
  retryButton: { paddingHorizontal: 8, paddingVertical: 4 },
  retryText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
});
