import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button } from '@/components/ui/Button';
import { searchProfiles } from '@/lib/api/social';
import { colors, fonts, radius, spacing } from '@/theme';
import type { Profile } from '@/lib/database.types';

interface Props {
  visible: boolean;
  excludeUserId: string;
  initialSelected: Profile[];
  onClose: () => void;
  onConfirm: (selected: Profile[]) => void;
}

/** Bottom-sheet rider picker for "Rode with" tagging — used on the ride save
 * screen, and reusable later for editing tags after the fact from
 * RideDetailScreen. Search is the same searchProfiles() the follow-someone
 * flow already uses, so results match what riders expect from elsewhere in
 * the app. Selection persists across search queries (a chip row up top),
 * since a chosen rider can easily scroll out of the current results. */
export function TagRidersModal({ visible, excludeUserId, initialSelected, onClose, onConfirm }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Profile[]>([]);
  const [searching, setSearching] = useState(false);
  const [selected, setSelected] = useState<Profile[]>(initialSelected);

  // Re-seed from whatever was already tagged each time the sheet opens, so
  // reopening it after a Cancel doesn't carry over an abandoned selection.
  useEffect(() => {
    if (visible) {
      setSelected(initialSelected);
      setQuery('');
      setResults([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  async function runSearch(text: string) {
    setQuery(text);
    if (text.trim().length < 2) {
      setResults([]);
      return;
    }
    setSearching(true);
    try {
      const found = await searchProfiles(text.trim(), excludeUserId);
      setResults(found);
    } catch {
      setResults([]);
    } finally {
      setSearching(false);
    }
  }

  function toggle(p: Profile) {
    setSelected((prev) => (prev.some((s) => s.id === p.id) ? prev.filter((s) => s.id !== p.id) : [...prev, p]));
  }

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={styles.sheet}>
          <View style={styles.handle} />
          <View style={styles.header}>
            <Text style={styles.title}>Who rode with you?</Text>
            <Pressable onPress={onClose} hitSlop={10}>
              <Ionicons name="close" size={22} color={colors.textSecondary} />
            </Pressable>
          </View>

          {selected.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.selectedRow}>
              {selected.map((p) => (
                <Pressable key={p.id} onPress={() => toggle(p)} style={styles.selectedChip}>
                  <Text style={styles.selectedChipText} numberOfLines={1}>
                    {p.display_name || p.username}
                  </Text>
                  <Ionicons name="close" size={13} color={colors.accent} />
                </Pressable>
              ))}
            </ScrollView>
          ) : null}

          <View style={styles.searchBox}>
            <Ionicons name="search" size={16} color={colors.textTertiary} />
            <TextInput
              value={query}
              onChangeText={runSearch}
              placeholder="Search by name or username"
              placeholderTextColor={colors.textTertiary}
              style={styles.searchInput}
              autoCapitalize="none"
            />
            {searching ? <ActivityIndicator size="small" color={colors.textTertiary} /> : null}
          </View>

          <FlatList
            data={results}
            keyExtractor={(item) => item.id}
            style={styles.list}
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              query.trim().length >= 2 && !searching ? <Text style={styles.emptyText}>No riders found.</Text> : null
            }
            renderItem={({ item }) => {
              const isSelected = selected.some((s) => s.id === item.id);
              return (
                <Pressable onPress={() => toggle(item)} style={styles.row}>
                  {item.avatar_url ? (
                    <Image source={{ uri: item.avatar_url }} style={styles.avatar} />
                  ) : (
                    <View style={styles.avatarPlaceholder}>
                      <Text style={styles.avatarInitial}>{(item.display_name || item.username).charAt(0).toUpperCase()}</Text>
                    </View>
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={styles.rowName} numberOfLines={1}>
                      {item.display_name || item.username}
                    </Text>
                    <Text style={styles.rowUsername}>@{item.username}</Text>
                  </View>
                  <Ionicons
                    name={isSelected ? 'checkmark-circle' : 'ellipse-outline'}
                    size={22}
                    color={isSelected ? colors.accent : colors.borderStrong}
                  />
                </Pressable>
              );
            }}
          />

          <Button title={selected.length > 0 ? `Done · ${selected.length} tagged` : 'Done'} onPress={() => onConfirm(selected)} />
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(21, 23, 27, 0.5)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.lg,
    maxHeight: '82%',
    gap: spacing.sm,
  },
  handle: { width: 36, height: 4, borderRadius: 2, backgroundColor: colors.borderStrong, alignSelf: 'center', marginBottom: spacing.xs },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { fontFamily: fonts.semiBold, fontSize: 17, color: colors.textPrimary },
  selectedRow: { gap: spacing.xs, paddingVertical: 2 },
  selectedChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: radius.pill,
    backgroundColor: colors.accentMuted,
    maxWidth: 160,
  },
  selectedChipText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent, flexShrink: 1 },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.md,
    paddingHorizontal: spacing.sm,
    height: 42,
  },
  searchInput: { flex: 1, fontFamily: fonts.regular, fontSize: 15, color: colors.textPrimary, height: '100%' },
  list: { flexGrow: 0 },
  emptyText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary, textAlign: 'center', paddingVertical: spacing.lg },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: 10 },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.surfaceHigh },
  avatarPlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.accentMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarInitial: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.accent },
  rowName: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
  rowUsername: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary },
});
