import React, { useEffect } from 'react';
import Animated, { useAnimatedStyle, useSharedValue, withDelay, withTiming, Easing } from 'react-native-reanimated';
import Svg, { Circle, Ellipse, Line, Path } from 'react-native-svg';
import { colors } from '@/theme';

interface Props {
  width?: number;
  color?: string;
  accentColor?: string;
  animated?: boolean;
}

/**
 * A gravel bike, drawn entirely in code (no image asset) — side profile,
 * drop bars, chunky tires, a frame bag for gravel character. This is the
 * centerpiece of the opening screen: "built by code, to show what we do."
 */
export function GravelBikeIllustration({ width = 320, color = colors.textPrimary, accentColor = colors.accent, animated = true }: Props) {
  const height = (width * 240) / 400;

  const wheelProgress = useSharedValue(animated ? 0 : 1);
  const riseProgress = useSharedValue(animated ? 0 : 1);

  useEffect(() => {
    if (!animated) return;
    riseProgress.value = withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) });
    wheelProgress.value = withDelay(150, withTiming(1, { duration: 900, easing: Easing.out(Easing.quad) }));
  }, [animated, riseProgress, wheelProgress]);

  const rootStyle = useAnimatedStyle(() => ({
    opacity: riseProgress.value,
    transform: [{ translateY: (1 - riseProgress.value) * 18 }],
  }));

  const motionStyle = useAnimatedStyle(() => ({
    opacity: wheelProgress.value,
    transform: [{ translateX: (1 - wheelProgress.value) * -24 }],
  }));

  return (
    <Animated.View style={rootStyle}>
      <Svg width={width} height={height} viewBox="0 0 400 240" fill="none">
        {/* ground shadow */}
        <Ellipse cx={200} cy={210} rx={150} ry={10} fill="rgba(0,0,0,0.35)" />

        {/* motion lines */}
        <Animated.View style={motionStyle}>
          <Line x1={10} y1={150} x2={40} y2={150} stroke={color} strokeWidth={3} strokeLinecap="round" opacity={0.35} />
          <Line x1={2} y1={168} x2={44} y2={168} stroke={color} strokeWidth={3} strokeLinecap="round" opacity={0.5} />
          <Line x1={14} y1={186} x2={40} y2={186} stroke={color} strokeWidth={3} strokeLinecap="round" opacity={0.35} />
        </Animated.View>

        {/* rear wheel */}
        <Circle cx={96} cy={168} r={56} stroke={color} strokeWidth={6} />
        <Circle cx={96} cy={168} r={36} stroke={color} strokeWidth={2} opacity={0.5} />
        <Circle cx={96} cy={168} r={4} fill={color} />

        {/* front wheel */}
        <Circle cx={304} cy={168} r={56} stroke={color} strokeWidth={6} />
        <Circle cx={304} cy={168} r={36} stroke={color} strokeWidth={2} opacity={0.5} />
        <Circle cx={304} cy={168} r={4} fill={color} />

        {/* frame bag (gravel character) */}
        <Path d="M172,118 L224,106 L208,150 Z" fill={accentColor} opacity={0.35} />

        {/* main frame triangle: BB -> seat tube top -> head tube top -> (close) BB */}
        <Path d="M182,168 L150,60 L280,72 Z" stroke={color} strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" fill="none" />

        {/* rear triangle: seat stay + chain stay */}
        <Path d="M150,60 L96,168 L182,168" stroke={color} strokeWidth={5} strokeLinejoin="round" strokeLinecap="round" fill="none" />

        {/* head tube */}
        <Line x1={280} y1={72} x2={292} y2={96} stroke={color} strokeWidth={7} strokeLinecap="round" />

        {/* fork, raked toward the front axle */}
        <Path d="M292,96 Q300,135 304,168" stroke={color} strokeWidth={6} strokeLinecap="round" fill="none" />

        {/* stem */}
        <Line x1={280} y1={72} x2={298} y2={58} stroke={color} strokeWidth={5} strokeLinecap="round" />

        {/* drop handlebar: flat hood lead-in + a hooked drop */}
        <Path d="M298,58 L314,52" stroke={color} strokeWidth={5} strokeLinecap="round" fill="none" />
        <Path d="M314,52 A17,17 0 1,1 306,84" stroke={color} strokeWidth={5} strokeLinecap="round" fill="none" />

        {/* saddle */}
        <Line x1={130} y1={57} x2={169} y2={53} stroke={color} strokeWidth={8} strokeLinecap="round" />

        {/* chainring + crank + pedal */}
        <Circle cx={182} cy={168} r={22} stroke={color} strokeWidth={3} opacity={0.6} />
        <Line x1={182} y1={168} x2={206} y2={196} stroke={color} strokeWidth={5} strokeLinecap="round" />
        <Circle cx={206} cy={196} r={6} fill={color} />
      </Svg>
    </Animated.View>
  );
}
