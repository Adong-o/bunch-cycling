import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, fonts, radius, spacing } from '@/theme';
import type { Badge, UserBadge } from '@/lib/database.types';

interface Props {
  earned: Array<UserBadge & { badge: Badge }>;
  totalCount: number;
  onPress: () => void;
}

/**
 * The rider's trophy case, promoted onto the profile itself instead of
 * living only behind the "Badges" link — a horizontal strip of each earned
 * badge's own emoji (listMyBadges already orders most-recently-awarded
 * first, so this reads as a little timeline). An empty strip still shows
 * the section with an inviting nudge rather than disappearing — a brand-new
 * rider should see badges exist before they've earned one.
 */
export function BadgeStrip({ earned, totalCount, onPress }: Props) {
  return (
    <View style={styles.root}>
      <Pressable onPress={onPress} style={styles.headerRow} hitSlop={6}>
        <Text style={styles.title}>Badges</Text>
        <View style={styles.headerRight}>
          <Text style={styles.count}>
            {earned.length} of {totalCount}
          </Text>
          <Ionicons name="chevron-forward" size={14} color={colors.textTertiary} />
        </View>
      </Pressable>

      {earned.length === 0 ? (
        <Pressable onPress={onPress} style={styles.emptyRow}>
          <Text style={styles.emptyEmoji}>🏅</Text>
          <Text style={styles.emptyText}>Your first ride earns your first badge</Text>
        </Pressable>
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.strip}>
          {earned.map((ub) => (
            <View key={ub.id} style={styles.chip}>
              <View style={styles.chipIcon}>
                <Text style={styles.chipEmoji}>{ub.badge.icon}</Text>
              </View>
              <Text style={styles.chipLabel} numberOfLines={1}>
                {ub.badge.name}
              </Text>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { marginTop: spacing.lg },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  title: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  count: { fontFamily: fonts.medium, fontSize: 12, color: colors.textTertiary, marginRight: 2 },
  strip: { paddingHorizontal: spacing.md, gap: spacing.sm },
  chip: { width: 68, alignItems: 'center', gap: 4 },
  chipIcon: {
    width: 56,
    height: 56,
    borderRadius: radius.pill,
    backgroundColor: colors.goldMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chipEmoji: { fontSize: 26 },
  chipLabel: { fontFamily: fonts.medium, fontSize: 11, color: colors.textSecondary, textAlign: 'center' },
  emptyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginHorizontal: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  emptyEmoji: { fontSize: 28 },
  emptyText: { flex: 1, fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary },
});
