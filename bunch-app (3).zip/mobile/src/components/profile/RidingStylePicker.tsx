import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radius } from '@/theme';
import type { RidingStyle } from '@/lib/database.types';

export const RIDING_STYLE_OPTIONS: Array<{ value: RidingStyle; label: string }> = [
  { value: 'road', label: 'Road' },
  { value: 'gravel', label: 'Gravel' },
  { value: 'mountain', label: 'Mountain' },
  { value: 'commute', label: 'Commute' },
  { value: 'ebike', label: 'E-bike' },
  { value: 'indoor', label: 'Indoor' },
];

export function ridingStyleLabel(style: RidingStyle): string {
  return RIDING_STYLE_OPTIONS.find((o) => o.value === style)?.label ?? style;
}

interface Props {
  value: RidingStyle[];
  onChange: (next: RidingStyle[]) => void;
  disabled?: boolean;
}

/** Multi-select chips for profiles.riding_styles (shown on the profile header). */
export function RidingStylePicker({ value, onChange, disabled }: Props) {
  function toggle(style: RidingStyle) {
    onChange(value.includes(style) ? value.filter((s) => s !== style) : [...value, style]);
  }
  return (
    <View style={styles.wrap}>
      {RIDING_STYLE_OPTIONS.map((opt) => {
        const active = value.includes(opt.value);
        return (
          <Pressable
            key={opt.value}
            onPress={() => toggle(opt.value)}
            disabled={disabled}
            style={[styles.chip, active && styles.chipActive]}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
          >
            <Text style={[styles.label, active && styles.labelActive]}>{opt.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingVertical: 9,
    paddingHorizontal: 16,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  chipActive: { borderColor: colors.accent, backgroundColor: colors.accentMuted },
  label: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  labelActive: { color: colors.accent },
});
