import React from 'react';
import { Pressable, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, shadow } from '@/theme';

type IconName = keyof typeof Ionicons.glyphMap;

interface ButtonProps {
  icon: IconName;
  label: string;
  onPress: () => void;
  active?: boolean;
  style?: StyleProp<ViewStyle>;
}

/** Round white floating button used for map actions (locate, fit, layers…). 46 px — comfortably above the 44 px touch minimum. */
export function MapRoundButton({ icon, label, onPress, active = false, style }: ButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={4}
      style={({ pressed }) => [styles.round, active && styles.roundActive, pressed && { opacity: 0.85 }, style]}
    >
      <Ionicons name={icon} size={22} color={active ? colors.accent : colors.textPrimary} />
    </Pressable>
  );
}

interface ZoomProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
  style?: StyleProp<ViewStyle>;
}

/** One pill with + above − (the standard map zoom control). */
export function MapZoomPill({ onZoomIn, onZoomOut, style }: ZoomProps) {
  return (
    <View style={[styles.zoomPill, style]}>
      <Pressable onPress={onZoomIn} style={styles.zoomHalf} accessibilityRole="button" accessibilityLabel="Zoom in" hitSlop={4}>
        <Ionicons name="add" size={26} color={colors.textPrimary} />
      </Pressable>
      <View style={styles.zoomDivider} />
      <Pressable onPress={onZoomOut} style={styles.zoomHalf} accessibilityRole="button" accessibilityLabel="Zoom out" hitSlop={4}>
        <Ionicons name="remove" size={26} color={colors.textPrimary} />
      </Pressable>
    </View>
  );
}

const SIZE = 46;

const styles = StyleSheet.create({
  round: { width: SIZE, height: SIZE, borderRadius: SIZE / 2, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', ...shadow.card },
  roundActive: { backgroundColor: colors.accentMuted },
  zoomPill: { width: SIZE, borderRadius: SIZE / 2, backgroundColor: colors.surface, ...shadow.card },
  zoomHalf: { height: SIZE, alignItems: 'center', justifyContent: 'center' },
  zoomDivider: { height: StyleSheet.hairlineWidth, marginHorizontal: 10, backgroundColor: colors.borderStrong },
});
