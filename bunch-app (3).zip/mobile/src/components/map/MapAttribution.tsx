import React from 'react';
import { StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { colors, fonts } from '@/theme';

interface Props {
  /**
   * `compact` is for thumbnails and other small maps: the full credit line would
   * wrap into 3–4 lines and cover the map, so it shrinks to "© OSM". Everything
   * larger than ~200 px wide should use the default.
   */
  compact?: boolean;
  style?: StyleProp<ViewStyle>;
}

/**
 * The attribution OpenStreetMap / OpenMapTiles / OpenFreeMap require, drawn as
 * our own chip (the native one is switched off on every map). One component so
 * every map credits the data the same way and the text can't drift.
 */
export function MapAttribution({ compact = false, style }: Props) {
  return (
    <View style={[styles.chip, compact && styles.chipCompact, style]} pointerEvents="none">
      <Text style={[styles.text, compact && styles.textCompact]} numberOfLines={1}>
        {compact ? '© OSM' : 'OpenFreeMap · © OpenMapTiles · Data from OpenStreetMap'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  chip: {
    position: 'absolute',
    left: 8,
    bottom: 8,
    maxWidth: '92%',
    backgroundColor: colors.mapAttributionBg,
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  chipCompact: { left: 6, bottom: 6, paddingHorizontal: 4, paddingVertical: 1, borderRadius: 4 },
  text: { fontFamily: fonts.regular, fontSize: 9, color: colors.textSecondary },
  textCompact: { fontSize: 8 },
});
