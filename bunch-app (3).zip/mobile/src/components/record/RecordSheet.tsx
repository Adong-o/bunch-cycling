import React, { useState } from 'react';
import { type LayoutChangeEvent, type NativeScrollEvent, type NativeSyntheticEvent, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { PulseDot } from '@/components/ui/PulseDot';
import { distanceUnitLabel, formatDistance, formatDuration, formatElevation, formatSpeed } from '@/lib/units';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import type { UnitSystem } from '@/lib/database.types';

const MENU_HEIGHT = 112;
const PAUSED_ORANGE = '#F28B30';
const PAUSED_TEXT = '#B9620F';

export type RecordSheetMode = 'idle' | 'recording' | 'paused';
export type GpsStatus = 'searching' | 'locked' | 'weak';

interface Props {
  mode: RecordSheetMode;
  units: UnitSystem;
  distanceM: number;
  currentSpeedMps: number | null;
  currentElevationM: number | null;
  avgSpeedMps: number;
  ascentM: number;
  descentM: number;
  movingS: number;
  maxSpeedMps: number;
  gpsStatus: GpsStatus;
  starting: boolean;
  voiceMuted: boolean;
  autoRecenter: boolean;
  /** True when "Allow all the time" is granted, so a ride keeps recording with the screen off. */
  backgroundReady: boolean;
  onToggleVoice: () => void;
  onToggleAutoRecenter: () => void;
  onSetupBackground: () => void;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onFinish: () => void;
  /** Total rendered height of the sheet, so the map controls can sit just above it. */
  onHeightChange?: (height: number) => void;
}

/** One live number: big tabular value, small unit, caption underneath. */
function Metric({ label, value, unit, hero = false, flex = 1 }: { label: string; value: string; unit?: string; hero?: boolean; flex?: number }) {
  return (
    <View style={[styles.metric, { flex }]}>
      <View style={styles.metricValueRow}>
        <Text style={[styles.metricValue, hero ? styles.metricValueHero : styles.metricValueSub]} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>
          {value}
        </Text>
        {unit ? <Text style={[styles.metricUnit, hero && styles.metricUnitHero]}>{unit}</Text> : null}
      </View>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function MenuRow({ icon, label, value, onValueChange }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: boolean; onValueChange: () => void }) {
  return (
    <View style={styles.menuRow}>
      <View style={styles.menuIcon}>
        <Ionicons name={icon} size={18} color={colors.accent} />
      </View>
      <Text style={styles.menuLabel}>{label}</Text>
      <Switch value={value} onValueChange={onValueChange} trackColor={{ false: colors.borderStrong, true: colors.accent }} thumbColor={colors.surface} />
    </View>
  );
}

function split(text: string): [string, string] {
  const i = text.indexOf(' ');
  return i === -1 ? [text, ''] : [text.slice(0, i), text.slice(i + 1)];
}

function GpsChip({ status, compact = false }: { status: GpsStatus; compact?: boolean }) {
  const text = status === 'locked' ? (compact ? 'GPS' : 'GPS locked') : status === 'weak' ? (compact ? 'Weak GPS' : 'Weak GPS') : compact ? 'GPS…' : 'Finding GPS…';
  return (
    <View style={[styles.gpsChip, status === 'locked' && styles.gpsChipLocked, status === 'weak' && styles.gpsChipWeak]}>
      <View style={[styles.gpsDot, status === 'locked' && styles.gpsDotLocked, status === 'weak' && styles.gpsDotWeak]} />
      <Text style={[styles.gpsText, status === 'locked' && { color: colors.success }, status === 'weak' && { color: colors.gold }]}>{text}</Text>
    </View>
  );
}

/**
 * Bottom panel of the Record tab — one white sheet, no dark control band.
 *
 *  - Ready: title + GPS state + the biggest button on screen (Start ride).
 *  - Riding: a "Recording" chip, time and distance as the hero numbers, speed /
 *    average / elevation under them (swipe for ascent, descent, max speed), and
 *    a full-width Pause. Paused swaps that for Resume + Finish, so a ride can
 *    never be ended by a stray tap while it is running.
 *
 * Controls are 58 px tall — the bit a rider hits with a glove on. Pull the sheet
 * up (or tap the sliders button) for quick settings. The vertical pan is scoped
 * to this panel, with a horizontal fail-offset so the stats pager keeps its swipe.
 */
export function RecordSheet(props: Props) {
  const { mode, units, gpsStatus, starting, voiceMuted, autoRecenter, backgroundReady } = props;
  const [page, setPage] = useState(0);
  const [pageWidth, setPageWidth] = useState(0);

  const dragY = useSharedValue(0); // 0 = collapsed, -MENU_HEIGHT = menu open
  const startY = useSharedValue(0);

  const pan = Gesture.Pan()
    .activeOffsetY([-12, 12])
    .failOffsetX([-20, 20])
    .onStart(() => {
      startY.value = dragY.value;
    })
    .onUpdate((e) => {
      dragY.value = Math.min(0, Math.max(-MENU_HEIGHT, startY.value + e.translationY));
    })
    .onEnd((e) => {
      const open = e.velocityY < -400 || (e.velocityY <= 400 && dragY.value < -MENU_HEIGHT / 2);
      dragY.value = withSpring(open ? -MENU_HEIGHT : 0, { damping: 20, stiffness: 200 });
    });

  const menuStyle = useAnimatedStyle(() => ({
    height: -dragY.value,
    opacity: Math.min(1, Math.max(0, -dragY.value / (MENU_HEIGHT * 0.6))),
  }));

  function toggleMenu() {
    dragY.value = withSpring(dragY.value < -MENU_HEIGHT / 2 ? 0 : -MENU_HEIGHT, { damping: 20, stiffness: 200 });
  }

  function onPageScrollEnd(e: NativeSyntheticEvent<NativeScrollEvent>) {
    if (pageWidth > 0) setPage(Math.round(e.nativeEvent.contentOffset.x / pageWidth));
  }

  const [speedValue, speedUnit] = split(formatSpeed(props.currentSpeedMps != null && props.currentSpeedMps >= 0 ? props.currentSpeedMps : 0, units));
  const [avgValue, avgUnit] = split(formatSpeed(props.avgSpeedMps, units));
  const [maxValue, maxUnit] = split(formatSpeed(props.maxSpeedMps, units));
  const distanceValue = formatDistance(props.distanceM, units, { compact: true }).replace(/[a-z]+$/i, '');
  const [eleValue, eleUnit] = props.currentElevationM != null ? split(formatElevation(props.currentElevationM, units)) : ['—', ''];
  const [ascValue, ascUnit] = split(formatElevation(props.ascentM, units));
  const [descValue, descUnit] = split(formatElevation(props.descentM, units));

  function onLayout(e: LayoutChangeEvent) {
    props.onHeightChange?.(e.nativeEvent.layout.height);
  }

  const paused = mode === 'paused';

  return (
    <GestureDetector gesture={pan}>
      <Animated.View style={styles.sheet} onLayout={onLayout}>
        <View style={styles.handle} />

        {mode === 'idle' ? (
          <View style={styles.ready}>
            <View style={styles.headerRow}>
              <Text style={styles.readyTitle}>Ready to ride</Text>
              <View style={styles.headerRight}>
                <GpsChip status={gpsStatus} />
                <Pressable onPress={toggleMenu} style={styles.optionsButton} accessibilityLabel="Ride settings" hitSlop={6}>
                  <Ionicons name="options-outline" size={18} color={colors.textPrimary} />
                </Pressable>
              </View>
            </View>
            {backgroundReady ? (
              <View style={styles.hintRow}>
                <Ionicons name="shield-checkmark-outline" size={16} color={colors.success} />
                <Text style={styles.hintText}>Keeps recording with your screen off.</Text>
              </View>
            ) : (
              <Pressable onPress={props.onSetupBackground} style={styles.hintRow} hitSlop={6}>
                <Ionicons name="alert-circle-outline" size={16} color={colors.gold} />
                <Text style={styles.hintText}>Rides stop when you lock your phone.</Text>
                <Text style={styles.hintLink}>Fix this</Text>
              </Pressable>
            )}
          </View>
        ) : (
          <>
            <View style={styles.headerRow}>
              <View style={[styles.statusChip, paused ? styles.statusChipPaused : styles.statusChipLive]}>
                {paused ? <View style={styles.pausedDot} /> : <PulseDot size={9} />}
                <Text style={[styles.statusText, paused && { color: PAUSED_TEXT }]}>{paused ? 'Paused' : 'Recording'}</Text>
              </View>
              <View style={styles.headerRight}>
                <GpsChip status={gpsStatus} compact />
                <Pressable onPress={toggleMenu} style={styles.optionsButton} accessibilityLabel="Ride settings" hitSlop={6}>
                  <Ionicons name="options-outline" size={18} color={colors.textPrimary} />
                </Pressable>
              </View>
            </View>

            <View onLayout={(e) => setPageWidth(e.nativeEvent.layout.width)}>
              <ScrollView horizontal pagingEnabled showsHorizontalScrollIndicator={false} onMomentumScrollEnd={onPageScrollEnd} scrollEventThrottle={16}>
                <View style={[styles.page, { width: pageWidth || undefined }]}>
                  <View style={styles.heroRow}>
                    <Metric hero flex={1.15} label="Time in motion" value={formatDuration(props.movingS)} />
                    <Metric hero label="Distance" value={distanceValue} unit={distanceUnitLabel(units)} />
                  </View>
                  <View style={styles.subRow}>
                    <Metric label="Speed" value={speedValue} unit={speedUnit} />
                    <Metric label="Average" value={avgValue} unit={avgUnit} />
                    <Metric label="Elevation" value={eleValue} unit={eleUnit} />
                  </View>
                </View>
                <View style={[styles.page, { width: pageWidth || undefined }]}>
                  <View style={styles.heroRow}>
                    <Metric hero label="Ascent" value={ascValue} unit={ascUnit} />
                    <Metric hero label="Descent" value={descValue} unit={descUnit} />
                  </View>
                  <View style={styles.subRow}>
                    <Metric label="Max speed" value={maxValue} unit={maxUnit} />
                    <Metric label="Elevation" value={eleValue} unit={eleUnit} />
                    <View style={{ flex: 1 }} />
                  </View>
                </View>
              </ScrollView>
            </View>
            <View style={styles.dots}>
              {[0, 1].map((i) => (
                <View key={i} style={[styles.dot, page === i && styles.dotActive]} />
              ))}
            </View>
          </>
        )}

        <Animated.View style={[styles.menu, menuStyle]} pointerEvents="box-none">
          <MenuRow icon="volume-high-outline" label="Voice assistant" value={!voiceMuted} onValueChange={props.onToggleVoice} />
          <MenuRow icon="locate-outline" label="Auto-recenter map" value={autoRecenter} onValueChange={props.onToggleAutoRecenter} />
        </Animated.View>

        <View style={styles.controls}>
          {mode === 'idle' ? (
            <Pressable
              disabled={starting}
              onPress={props.onStart}
              accessibilityRole="button"
              accessibilityLabel="Start ride"
              style={({ pressed }) => [styles.button, styles.startButton, (pressed || starting) && { opacity: 0.85 }]}
            >
              <Ionicons name="play" size={22} color={colors.textOnAccent} />
              <Text style={styles.buttonText}>{starting ? 'Starting…' : 'Start ride'}</Text>
            </Pressable>
          ) : mode === 'recording' ? (
            <Pressable
              onPress={props.onPause}
              accessibilityRole="button"
              accessibilityLabel="Pause ride"
              style={({ pressed }) => [styles.button, styles.pauseButton, pressed && { opacity: 0.85 }]}
            >
              <Ionicons name="pause" size={22} color="#FFFFFF" />
              <Text style={styles.buttonText}>Pause</Text>
            </Pressable>
          ) : (
            <View style={styles.pausedButtons}>
              <Pressable
                onPress={props.onResume}
                accessibilityRole="button"
                accessibilityLabel="Resume ride"
                style={({ pressed }) => [styles.button, styles.resumeButton, pressed && { opacity: 0.85 }]}
              >
                <Ionicons name="play" size={22} color="#FFFFFF" />
                <Text style={styles.buttonText}>Resume</Text>
              </Pressable>
              <Pressable
                onPress={props.onFinish}
                accessibilityRole="button"
                accessibilityLabel="Finish ride"
                style={({ pressed }) => [styles.button, styles.finishButton, pressed && { backgroundColor: colors.surfaceHigh }]}
              >
                <Ionicons name="flag" size={18} color={colors.ink} />
                <Text style={[styles.buttonText, { color: colors.ink }]}>Finish</Text>
              </Pressable>
            </View>
          )}
        </View>
      </Animated.View>
    </GestureDetector>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.surface,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xs,
    overflow: 'hidden',
    ...shadow.floating,
  },
  handle: { alignSelf: 'center', width: 38, height: 4, borderRadius: 2, backgroundColor: colors.borderStrong, marginBottom: spacing.sm },

  ready: { paddingBottom: spacing.sm, gap: 6 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 36 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  readyTitle: { fontFamily: fonts.extraBold, fontSize: 26, color: colors.textPrimary, letterSpacing: -0.5 },
  optionsButton: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.surfaceHigh, alignItems: 'center', justifyContent: 'center' },

  gpsChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.pill, backgroundColor: colors.surfaceHigh },
  gpsChipLocked: { backgroundColor: colors.successMuted },
  gpsChipWeak: { backgroundColor: colors.goldMuted },
  gpsDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: colors.textTertiary },
  gpsDotLocked: { backgroundColor: colors.success },
  gpsDotWeak: { backgroundColor: colors.gold },
  gpsText: { fontFamily: fonts.bold, fontSize: 12, color: colors.textSecondary },
  hintRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  hintText: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary, flexShrink: 1 },
  hintLink: { fontFamily: fonts.bold, fontSize: 13, color: colors.accent },

  statusChip: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 12, paddingVertical: 7, borderRadius: radius.pill },
  statusChipLive: { backgroundColor: 'rgba(242, 84, 45, 0.11)' },
  statusChipPaused: { backgroundColor: 'rgba(242, 139, 48, 0.16)' },
  statusText: { fontFamily: fonts.bold, fontSize: 13, color: '#C8431F', letterSpacing: 0.1 },
  pausedDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: PAUSED_ORANGE },

  page: { paddingTop: spacing.xs },
  heroRow: { flexDirection: 'row', alignItems: 'flex-end', paddingBottom: spacing.xs },
  subRow: { flexDirection: 'row', alignItems: 'flex-end', paddingTop: spacing.xs, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  metric: { paddingRight: spacing.xs, paddingVertical: 4 },
  metricValueRow: { flexDirection: 'row', alignItems: 'baseline', gap: 4 },
  metricValue: { fontFamily: fonts.monoBold, color: colors.textPrimary, flexShrink: 1, fontVariant: ['tabular-nums'] },
  metricValueHero: { fontSize: 38, letterSpacing: -1.4 },
  metricValueSub: { fontSize: 23, letterSpacing: -0.6 },
  metricUnit: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary },
  metricUnitHero: { fontSize: 14 },
  metricLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary, marginTop: 1 },

  dots: { flexDirection: 'row', justifyContent: 'center', gap: 6, paddingTop: spacing.xs },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.borderStrong },
  dotActive: { backgroundColor: colors.accent, width: 18 },

  menu: { overflow: 'hidden' },
  menuRow: { flexDirection: 'row', alignItems: 'center', height: 52, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.borderStrong, gap: spacing.sm },
  menuIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, fontFamily: fonts.semiBold, fontSize: 15, color: colors.textPrimary },

  controls: { paddingTop: spacing.sm, paddingBottom: spacing.md },
  pausedButtons: { flexDirection: 'row', gap: spacing.sm },
  button: { height: 58, borderRadius: radius.pill, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  buttonText: { fontFamily: fonts.bold, fontSize: 17, color: '#FFFFFF' },
  startButton: { backgroundColor: colors.accent, ...shadow.card },
  pauseButton: { backgroundColor: colors.ink },
  resumeButton: { flex: 1.25, backgroundColor: colors.accent },
  finishButton: { flex: 1, backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.ink },
});
