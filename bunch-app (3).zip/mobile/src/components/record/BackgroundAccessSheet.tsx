import React, { useState } from 'react';
import { ActivityIndicator, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { IS_ANDROID, openAppSettings, requestBackgroundAccess } from '@/lib/recordingPermissions';
import { colors, fonts, radius, shadow, spacing } from '@/theme';

interface Props {
  visible: boolean;
  /** Called once the rider has chosen how to proceed. `background` is whether "all the time" is now granted. */
  onContinue: (result: { background: boolean }) => void;
  onCancel: () => void;
}

/**
 * Shown the first time a rider starts a ride without "Allow all the time"
 * location. Explains in one breath why it matters (rides otherwise stop the
 * moment the screen locks), then either gets the permission or lets them
 * record while the app stays open. On Android 11+ the permission can only be
 * granted in system settings, so the primary button sends them there.
 */
export function BackgroundAccessSheet({ visible, onContinue, onCancel }: Props) {
  const [busy, setBusy] = useState(false);
  const [stillOff, setStillOff] = useState(false);

  async function onAllow() {
    setBusy(true);
    const granted = await requestBackgroundAccess();
    setBusy(false);
    if (granted) {
      setStillOff(false);
      onContinue({ background: true });
    } else {
      setStillOff(true);
    }
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel} statusBarTranslucent>
      <View style={styles.backdrop}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onCancel} accessibilityLabel="Dismiss" />
        <View style={styles.sheet}>
          <View style={styles.handle} />
          <View style={styles.iconWrap}>
            <Ionicons name="phone-portrait-outline" size={30} color={colors.accent} />
          </View>
          <Text style={styles.title}>Keep recording with your screen off</Text>
          <Text style={styles.body}>
            Unless location is set to <Text style={styles.bold}>{IS_ANDROID ? '“Allow all the time”' : '“Always”'}</Text>, your ride stops the moment you lock your
            phone or switch apps — and you lose the miles in between.
          </Text>

          <View style={styles.steps}>
            <Step n={1} text="Tap “Allow all the time” below" />
            <Step n={2} text={IS_ANDROID ? 'In Location, choose “Allow all the time”' : 'Choose “Change to Always Allow”'} />
            {IS_ANDROID ? <Step n={3} text="If your phone has a battery saver, set Bunch to “Unrestricted”" /> : null}
          </View>

          {stillOff ? (
            <View style={styles.notice}>
              <Ionicons name="information-circle" size={18} color={colors.gold} />
              <Text style={styles.noticeText}>It’s still off. Open settings and choose “{IS_ANDROID ? 'Allow all the time' : 'Always'}”, then come back.</Text>
            </View>
          ) : null}

          <Pressable onPress={stillOff ? openAppSettings : onAllow} disabled={busy} style={({ pressed }) => [styles.primary, (pressed || busy) && { opacity: 0.85 }]}>
            {busy ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.primaryText}>{stillOff ? 'Open settings' : 'Allow all the time'}</Text>}
          </Pressable>
          <Pressable onPress={() => onContinue({ background: false })} style={styles.secondary} hitSlop={8}>
            <Text style={styles.secondaryText}>Record only while Bunch is open</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

function Step({ n, text }: { n: number; text: string }) {
  return (
    <View style={styles.step}>
      <View style={styles.stepNum}>
        <Text style={styles.stepNumText}>{n}</Text>
      </View>
      <Text style={styles.stepText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(21,23,27,0.45)' },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xs,
    paddingBottom: spacing.xl,
    gap: spacing.sm,
    ...shadow.floating,
  },
  handle: { alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: colors.borderStrong, marginBottom: spacing.xs },
  iconWrap: { width: 60, height: 60, borderRadius: 20, backgroundColor: colors.accentMuted, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: fonts.extraBold, fontSize: 24, lineHeight: 30, color: colors.textPrimary, letterSpacing: -0.4 },
  body: { fontFamily: fonts.regular, fontSize: 15, lineHeight: 22, color: colors.textSecondary },
  bold: { fontFamily: fonts.bold, color: colors.textPrimary },
  steps: { gap: spacing.xs, marginVertical: spacing.xs },
  step: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  stepNum: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.surfaceHigh, alignItems: 'center', justifyContent: 'center' },
  stepNumText: { fontFamily: fonts.bold, fontSize: 12, color: colors.textPrimary },
  stepText: { flex: 1, fontFamily: fonts.medium, fontSize: 14, color: colors.textPrimary },
  notice: { flexDirection: 'row', gap: 8, alignItems: 'center', backgroundColor: colors.goldMuted, borderRadius: radius.md, padding: spacing.sm },
  noticeText: { flex: 1, fontFamily: fonts.medium, fontSize: 13, color: colors.textPrimary },
  primary: { height: 54, borderRadius: radius.pill, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', marginTop: spacing.xs },
  primaryText: { fontFamily: fonts.bold, fontSize: 16, color: '#FFFFFF' },
  secondary: { alignItems: 'center', paddingVertical: spacing.xs },
  secondaryText: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textSecondary },
});
