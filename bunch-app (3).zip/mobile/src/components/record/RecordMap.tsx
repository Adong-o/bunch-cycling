import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { type StyleProp, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { Camera, LineLayer, MapView, ShapeSource, UserLocation } from '@maplibre/maplibre-react-native';
import type { LiveLocation } from '@/lib/liveLocation';
import { MapAttribution } from '@/components/map/MapAttribution';
import { colors, fonts } from '@/theme';

// Free, no-API-key OpenFreeMap styles. "Light" (positron) is a calmer base
// for riders who want the route line to stand out.
export type RecordMapStyle = 'liberty' | 'positron';
const STYLE_URLS: Record<RecordMapStyle, string> = {
  liberty: 'https://tiles.openfreemap.org/styles/liberty',
  positron: 'https://tiles.openfreemap.org/styles/positron',
};

/**
 * - off:     the rider is free to pan/zoom; the map stays where they put it.
 * - north:   the map follows the rider, north stays up.
 * - heading: the map follows the rider AND turns with them — it rotates as
 *            the phone turns, like a handlebar nav unit.
 */
export type FollowMode = 'off' | 'north' | 'heading';

const MIN_ZOOM = 3;
const MAX_ZOOM = 19.5;
const DEFAULT_ZOOM = 16;
/** Moving faster than this, the direction of travel is a steadier "up" than the compass. */
const COURSE_SPEED_MPS = 2.5;

export interface RecordMapHandle {
  zoomIn: () => void;
  zoomOut: () => void;
  /** Glide back onto the rider (and resume following). */
  recenter: () => void;
  /** Rotate back to north-up. */
  resetNorth: () => void;
}

interface Props {
  location: LiveLocation;
  /** Where to open the map before the first live fix arrives. */
  initialCenter: { lat: number; lng: number } | null;
  followMode: FollowMode;
  onFollowModeChange: (mode: FollowMode) => void;
  routeCoordinates?: Array<[number, number]>;
  /** A planned route being followed — drawn as a soft dashed line under the recorded track. */
  guideCoordinates?: Array<[number, number]>;
  mapStyle: RecordMapStyle;
  /** Pixels at the bottom covered by the sheet — the rider is kept centred in what's still visible. */
  bottomInset: number;
  topInset: number;
  /** Map rotation in degrees, so the compass button can turn with it. */
  onHeadingChange?: (heading: number) => void;
  style?: StyleProp<ViewStyle>;
}

function pickHeading(loc: LiveLocation): number {
  if (loc.courseDeg != null && (loc.speedMps ?? 0) >= COURSE_SPEED_MPS) return loc.courseDeg;
  return loc.headingDeg ?? loc.courseDeg ?? 0;
}

/**
 * Full-screen live map for the Record tab. The camera is driven by *our*
 * live location (and compass) stream rather than the native "follow user"
 * mode, so it glides to every new fix, rotates with the phone in heading
 * mode, and can't silently stop following. Any touch on the map hands
 * control to the rider (follow → off); the recenter button gives it back.
 */
export const RecordMap = forwardRef<RecordMapHandle, Props>(function RecordMap(
  { location, initialCenter, followMode, onFollowModeChange, routeCoordinates, guideCoordinates, mapStyle, bottomInset, topInset, onHeadingChange, style },
  ref
) {
  // Untyped on purpose — the library's TS defs can't be checked against an
  // installed copy in this environment.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cameraRef = useRef<any>(null);
  const zoomRef = useRef(DEFAULT_ZOOM);
  const centeredOnceRef = useRef(false);
  const [mapReady, setMapReady] = useState(false);

  const target = location.coords;
  const desiredHeading = followMode === 'heading' ? pickHeading(location) : 0;
  const headingBucket = Math.round(desiredHeading / 3);

  // The one place the camera moves: every new fix / heading change while following.
  useEffect(() => {
    if (!mapReady || followMode === 'off' || !target) return;
    const first = !centeredOnceRef.current;
    centeredOnceRef.current = true;
    cameraRef.current?.setCamera({
      centerCoordinate: [target.lng, target.lat],
      zoomLevel: zoomRef.current,
      heading: desiredHeading,
      pitch: 0,
      padding: { paddingTop: topInset, paddingBottom: bottomInset, paddingLeft: 0, paddingRight: 0 },
      animationDuration: first ? 0 : 800,
      animationMode: first ? 'moveTo' : 'linearTo',
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapReady, followMode, target?.lat, target?.lng, headingBucket, bottomInset, topInset]);

  function zoomBy(delta: number) {
    const next = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, zoomRef.current + delta));
    zoomRef.current = next;
    cameraRef.current?.setCamera({ zoomLevel: next, animationDuration: 250, animationMode: 'easeTo' });
  }

  useImperativeHandle(ref, () => ({
    zoomIn: () => zoomBy(1),
    zoomOut: () => zoomBy(-1),
    recenter: () => {
      if (!target) return;
      cameraRef.current?.setCamera({
        centerCoordinate: [target.lng, target.lat],
        zoomLevel: Math.max(zoomRef.current, 15),
        heading: followMode === 'heading' ? desiredHeading : 0,
        padding: { paddingTop: topInset, paddingBottom: bottomInset, paddingLeft: 0, paddingRight: 0 },
        animationDuration: 500,
        animationMode: 'easeTo',
      });
    },
    resetNorth: () => cameraRef.current?.setCamera({ heading: 0, animationDuration: 300, animationMode: 'easeTo' }),
  }));

  const routeGeoJSON =
    routeCoordinates && routeCoordinates.length > 1
      ? { type: 'Feature' as const, properties: {}, geometry: { type: 'LineString' as const, coordinates: routeCoordinates } }
      : null;

  const guideGeoJSON =
    guideCoordinates && guideCoordinates.length > 1
      ? { type: 'Feature' as const, properties: {}, geometry: { type: 'LineString' as const, coordinates: guideCoordinates } }
      : null;

  const open = target ?? initialCenter;

  return (
    // onTouchStart: a finger on the map means the rider wants to look around.
    <View style={[styles.root, style]} onTouchStart={() => followMode !== 'off' && onFollowModeChange('off')}>
      <MapView
        style={styles.map}
        mapStyle={STYLE_URLS[mapStyle]}
        logoEnabled={false}
        attributionEnabled={false}
        compassEnabled={false}
        pitchEnabled={false}
        scrollEnabled
        zoomEnabled
        rotateEnabled
        onDidFinishLoadingMap={() => setMapReady(true)}
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        onRegionWillChange={(feature: any) => {
          if (feature?.properties?.isUserInteraction && followMode !== 'off') onFollowModeChange('off');
        }}
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        onRegionDidChange={(feature: any) => {
          const z = feature?.properties?.zoomLevel;
          if (typeof z === 'number') zoomRef.current = z;
          const h = feature?.properties?.heading;
          if (typeof h === 'number') onHeadingChange?.(h);
        }}
      >
        <Camera
          ref={cameraRef}
          defaultSettings={open ? { centerCoordinate: [open.lng, open.lat], zoomLevel: DEFAULT_ZOOM } : undefined}
          minZoomLevel={MIN_ZOOM}
          maxZoomLevel={MAX_ZOOM}
        />
        <UserLocation visible showsUserHeadingIndicator />
        {guideGeoJSON ? (
          <ShapeSource id="recordGuideSource" shape={guideGeoJSON}>
            <LineLayer id="recordGuideCasing" style={{ lineColor: '#FFFFFF', lineWidth: 8, lineCap: 'round', lineJoin: 'round', lineOpacity: 0.85 }} />
            <LineLayer id="recordGuideLine" style={{ lineColor: colors.accent, lineWidth: 4, lineCap: 'round', lineJoin: 'round', lineOpacity: 0.5, lineDasharray: [1.6, 1.6] }} />
          </ShapeSource>
        ) : null}
        {routeGeoJSON ? (
          <ShapeSource id="recordRouteSource" shape={routeGeoJSON}>
            <LineLayer id="recordRouteCasing" style={{ lineColor: '#FFFFFF', lineWidth: 9, lineCap: 'round', lineJoin: 'round', lineOpacity: 0.9 }} />
            <LineLayer id="recordRouteLine" style={{ lineColor: colors.accent, lineWidth: 5.5, lineCap: 'round', lineJoin: 'round' }} />
          </ShapeSource>
        ) : null}
      </MapView>

      {!open ? (
        <View style={styles.finding} pointerEvents="none">
          <Text style={styles.findingText}>Finding your location…</Text>
        </View>
      ) : null}

      <MapAttribution style={{ bottom: bottomInset + 6 }} />
    </View>
  );
});

const styles = StyleSheet.create({
  root: { overflow: 'hidden', backgroundColor: '#E9EAEC' },
  map: { flex: 1 },
  finding: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', backgroundColor: '#E9EAEC' },
  findingText: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textSecondary },
});
