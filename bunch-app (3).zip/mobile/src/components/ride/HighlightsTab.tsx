import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { TextField } from '@/components/ui/TextField';
import { Button } from '@/components/ui/Button';
import { createRideHighlight, deleteRideHighlight, listRideHighlights } from '@/lib/api/highlights';
import { uploadImage } from '@/lib/api/storage';
import { getErrorMessage } from '@/lib/errors';
import { colors, fonts, radius, spacing } from '@/theme';
import type { Ride, RideHighlight } from '@/lib/database.types';

interface Props {
  ride: Ride;
  isOwner: boolean;
}

/** Ride detail ▸ Highlights: named photo spots from the ride. Anyone who can
 * see the ride (RLS) can view them; only the owner adds or deletes. */
export function HighlightsTab({ ride, isOwner }: Props) {
  const [highlights, setHighlights] = useState<RideHighlight[]>([]);
  const [loading, setLoading] = useState(true);
  const [pendingUri, setPendingUri] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      setHighlights(await listRideHighlights(ride.id));
    } catch {
      setHighlights([]);
    } finally {
      setLoading(false);
    }
  }, [ride.id]);

  useEffect(() => {
    load();
  }, [load]);

  async function onAdd() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Photos access needed', 'Allow photo access in Settings to add a highlight.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (result.canceled || !result.assets[0]) return;
    setName('');
    setPendingUri(result.assets[0].uri);
  }

  async function onSave() {
    if (!pendingUri) return;
    setSaving(true);
    try {
      const url = await uploadImage('ride-photos', ride.user_id, pendingUri);
      const created = await createRideHighlight({
        ride_id: ride.id,
        user_id: ride.user_id,
        name: name.trim(),
        photo_url: url,
        lat: ride.start_lat,
        lng: ride.start_lng,
      });
      setHighlights((prev) => [...prev, created]);
      setPendingUri(null);
    } catch (e) {
      Alert.alert('Could not add highlight', getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  function onDelete(h: RideHighlight) {
    Alert.alert('Remove this highlight?', h.name || 'This photo will be removed from the ride.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteRideHighlight(h.id);
            setHighlights((prev) => prev.filter((x) => x.id !== h.id));
          } catch (e) {
            Alert.alert('Could not remove highlight', getErrorMessage(e));
          }
        },
      },
    ]);
  }

  return (
    <View style={styles.wrap}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Highlights</Text>
        {isOwner ? (
          <Pressable onPress={onAdd} style={styles.addButton} hitSlop={8}>
            <Ionicons name="camera-outline" size={16} color={colors.accent} />
            <Text style={styles.addText}>Add</Text>
          </Pressable>
        ) : null}
      </View>

      {loading ? (
        <ActivityIndicator color={colors.accent} style={{ marginVertical: spacing.lg }} />
      ) : highlights.length === 0 ? (
        <View style={styles.empty}>
          <Ionicons name="images-outline" size={28} color={colors.textTertiary} />
          <Text style={styles.emptyText}>
            {isOwner ? 'Add photos of the spots worth remembering from this ride.' : 'No highlights on this ride yet.'}
          </Text>
        </View>
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.carousel}>
          {highlights.map((h) => (
            <View key={h.id} style={styles.item}>
              {h.photo_url ? <Image source={{ uri: h.photo_url }} style={styles.photo} /> : <View style={[styles.photo, styles.photoPlaceholder]} />}
              <View style={styles.itemFooter}>
                <Text style={styles.itemName} numberOfLines={1}>
                  {h.name || 'Highlight'}
                </Text>
                {isOwner ? (
                  <Pressable onPress={() => onDelete(h)} hitSlop={8}>
                    <Ionicons name="trash-outline" size={16} color={colors.textTertiary} />
                  </Pressable>
                ) : null}
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      <Modal visible={pendingUri != null} transparent animationType="slide" onRequestClose={() => setPendingUri(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalBackdrop}>
          <View style={styles.modalSheet}>
            <Text style={styles.title}>New highlight</Text>
            {pendingUri ? <Image source={{ uri: pendingUri }} style={styles.preview} /> : null}
            <TextField value={name} onChangeText={setName} placeholder="Name it (e.g. Waterfall)" maxLength={80} />
            <View style={styles.modalActions}>
              <View style={{ flex: 1 }}>
                <Button title="Cancel" variant="secondary" onPress={() => setPendingUri(null)} disabled={saving} />
              </View>
              <View style={{ flex: 1 }}>
                <Button title="Add highlight" onPress={onSave} loading={saving} />
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary },
  addButton: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: spacing.sm, paddingVertical: 6, borderRadius: radius.pill, backgroundColor: colors.accentMuted },
  addText: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.accent },
  empty: { alignItems: 'center', gap: spacing.xs, paddingVertical: spacing.lg },
  emptyText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary, textAlign: 'center', lineHeight: 19 },
  carousel: { gap: spacing.sm },
  item: { width: 220, gap: 6 },
  photo: { width: 220, height: 160, borderRadius: radius.md, backgroundColor: colors.surfaceHigh },
  photoPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  itemFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.xs },
  itemName: { flex: 1, fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(21, 23, 27, 0.45)' },
  modalSheet: { backgroundColor: colors.bg, borderTopLeftRadius: radius.xl, borderTopRightRadius: radius.xl, padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.xl },
  preview: { width: '100%', height: 200, borderRadius: radius.md, backgroundColor: colors.surfaceHigh },
  modalActions: { flexDirection: 'row', gap: spacing.sm },
});
