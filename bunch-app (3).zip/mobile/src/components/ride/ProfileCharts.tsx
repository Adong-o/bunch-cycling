import React, { useMemo, useState } from 'react';
import { type LayoutChangeEvent, StyleSheet, Text, View } from 'react-native';
import Svg, { Defs, Line, LinearGradient, Path, Stop } from 'react-native-svg';
import { haversineDistanceM } from '@/lib/geo';
import { formatDistance, formatElevation, formatSpeed } from '@/lib/units';
import { colors, fonts, radius, spacing } from '@/theme';
import type { RouteGeoJSON, SpeedSample, UnitSystem } from '@/lib/database.types';

const CHART_HEIGHT = 150;
const PAD_Y = 12;

interface XY {
  x: number;
  y: number;
}

function smooth(points: XY[], window = 5): XY[] {
  if (points.length < 3) return points;
  return points.map((p, i) => {
    const start = Math.max(0, i - Math.floor(window / 2));
    const end = Math.min(points.length, i + Math.ceil(window / 2));
    const slice = points.slice(start, end);
    return { x: p.x, y: slice.reduce((a, s) => a + s.y, 0) / slice.length };
  });
}

/** [distance_m, elevation_m] pairs from route_geojson's altitude values. */
export function buildElevationSeries(geo: RouteGeoJSON | null | undefined): XY[] {
  if (!geo?.coordinates?.length) return [];
  const pts: XY[] = [];
  let cum = 0;
  let prev: [number, number] | null = null;
  for (const [lng, lat, el] of geo.coordinates) {
    if (prev) cum += haversineDistanceM({ lat: prev[1], lng: prev[0] }, { lat, lng });
    prev = [lng, lat];
    if (el != null) pts.push({ x: cum, y: el });
  }
  return smooth(pts);
}

export function elevationExtremes(series: XY[]): { highest: number; lowest: number } | null {
  if (series.length < 2) return null;
  const ys = series.map((p) => p.y);
  return { highest: Math.max(...ys), lowest: Math.min(...ys) };
}

interface LineChartProps {
  series: XY[];
  color: string;
  /** Optional horizontal reference line (e.g. average speed). */
  referenceY?: number;
  /** Format for the x-axis end label. */
  xEndLabel: string;
  yMinLabel: string;
  yMaxLabel: string;
  gradientId: string;
  /** Force the y-axis to start at 0 (speed). */
  zeroBased?: boolean;
}

function LineChart({ series, color, referenceY, xEndLabel, yMinLabel, yMaxLabel, gradientId, zeroBased }: LineChartProps) {
  const [width, setWidth] = useState(0);
  const { linePath, areaPath, refY } = useMemo(() => {
    if (width <= 0 || series.length < 2) return { linePath: '', areaPath: '', refY: null as number | null };
    const maxX = series[series.length - 1].x || 1;
    const ys = series.map((p) => p.y);
    let minY = zeroBased ? 0 : Math.min(...ys);
    let maxY = Math.max(...ys, referenceY ?? -Infinity);
    if (maxY - minY < 1) maxY = minY + 1;
    const usable = CHART_HEIGHT - PAD_Y * 2;
    const toX = (x: number) => (x / maxX) * width;
    const toY = (y: number) => CHART_HEIGHT - PAD_Y - ((y - minY) / (maxY - minY)) * usable;
    let line = '';
    series.forEach((p, i) => {
      line += `${i === 0 ? 'M' : ' L'}${toX(p.x).toFixed(1)},${toY(p.y).toFixed(1)}`;
    });
    return {
      linePath: line,
      areaPath: `${line} L${width},${CHART_HEIGHT} L0,${CHART_HEIGHT} Z`,
      refY: referenceY != null ? toY(referenceY) : null,
    };
  }, [series, width, referenceY, zeroBased]);

  return (
    <View>
      <View style={styles.chartWrap} onLayout={(e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width)}>
        {width > 0 ? (
          <Svg width={width} height={CHART_HEIGHT}>
            <Defs>
              <LinearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <Stop offset="0" stopColor={color} stopOpacity={0.26} />
                <Stop offset="1" stopColor={color} stopOpacity={0.02} />
              </LinearGradient>
            </Defs>
            <Path d={areaPath} fill={`url(#${gradientId})`} />
            {refY != null ? (
              <Line x1={0} y1={refY} x2={width} y2={refY} stroke={colors.textTertiary} strokeWidth={1.5} strokeDasharray="5 4" />
            ) : null}
            <Path d={linePath} stroke={color} strokeWidth={2.25} fill="none" strokeLinejoin="round" strokeLinecap="round" />
          </Svg>
        ) : null}
      </View>
      <View style={styles.axisRow}>
        <Text style={styles.axisLabel}>0</Text>
        <Text style={styles.axisLabel}>{xEndLabel}</Text>
      </View>
      <View style={styles.axisRow}>
        <Text style={styles.axisLabel}>{yMinLabel}</Text>
        <Text style={styles.axisLabel}>{yMaxLabel}</Text>
      </View>
    </View>
  );
}

export function StatGrid({ items }: { items: Array<{ label: string; value: string }> }) {
  return (
    <View style={styles.grid}>
      {items.map((it) => (
        <View key={it.label} style={styles.gridCell}>
          <Text style={styles.gridLabel}>{it.label}</Text>
          <Text style={styles.gridValue}>{it.value}</Text>
        </View>
      ))}
    </View>
  );
}

interface ElevationProps {
  routeGeojson: RouteGeoJSON | null | undefined;
  units: UnitSystem;
  gainM: number;
  lossM: number;
}

export function ElevationChartCard({ routeGeojson, units, gainM, lossM }: ElevationProps) {
  const series = useMemo(() => buildElevationSeries(routeGeojson), [routeGeojson]);
  const ext = elevationExtremes(series);
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Elevation</Text>
      {ext ? (
        <LineChart
          series={series}
          color={colors.accent}
          gradientId="rideElevationFill"
          xEndLabel={formatDistance(series[series.length - 1].x, units)}
          yMinLabel={formatElevation(ext.lowest, units)}
          yMaxLabel={formatElevation(ext.highest, units)}
        />
      ) : (
        <Text style={styles.empty}>This ride's device didn't report altitude, so there's no profile to draw.</Text>
      )}
      <StatGrid
        items={[
          { label: 'Uphill', value: formatElevation(gainM, units) },
          { label: 'Downhill', value: formatElevation(lossM, units) },
          { label: 'Highest', value: ext ? formatElevation(ext.highest, units) : '—' },
          { label: 'Lowest', value: ext ? formatElevation(ext.lowest, units) : '—' },
        ]}
      />
    </View>
  );
}

interface SpeedProps {
  samples: SpeedSample[] | null | undefined;
  units: UnitSystem;
  avgSpeedMps: number;
  maxSpeedMps: number;
  movingLabel: string;
  elapsedLabel: string;
}

export function SpeedChartCard({ samples, units, avgSpeedMps, maxSpeedMps, movingLabel, elapsedLabel }: SpeedProps) {
  const series = useMemo<XY[]>(
    () => smooth((samples ?? []).map(([d, s]) => ({ x: d, y: s })), 3),
    [samples],
  );
  const hasData = series.length >= 2 && series[series.length - 1].x > 0;
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Speed Profile</Text>
      {hasData ? (
        <>
          <LineChart
            series={series}
            color={colors.accent}
            referenceY={avgSpeedMps}
            zeroBased
            gradientId="rideSpeedFill"
            xEndLabel={formatDistance(series[series.length - 1].x, units)}
            yMinLabel={formatSpeed(0, units)}
            yMaxLabel={formatSpeed(Math.max(...series.map((p) => p.y)), units)}
          />
          <View style={styles.legendRow}>
            <View style={[styles.legendSwatch, { backgroundColor: colors.accent }]} />
            <Text style={styles.legendText}>Speed</Text>
            <View style={[styles.legendSwatch, styles.legendDash]} />
            <Text style={styles.legendText}>Average</Text>
          </View>
        </>
      ) : (
        <Text style={styles.empty}>
          No speed profile for this ride. Rides recorded in Bunch 1.3 and later keep their speed over distance; older rides and imports don't.
        </Text>
      )}
      <StatGrid
        items={[
          { label: 'Average Speed', value: formatSpeed(avgSpeedMps, units) },
          { label: 'Max speed', value: formatSpeed(maxSpeedMps, units) },
          { label: 'Moving Time', value: movingLabel },
          { label: 'Elapsed Time', value: elapsedLabel },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  cardTitle: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary },
  chartWrap: { height: CHART_HEIGHT },
  axisRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 },
  axisLabel: { fontFamily: fonts.regular, fontSize: 11, color: colors.textTertiary },
  empty: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary, lineHeight: 19 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', rowGap: spacing.sm, marginTop: spacing.xs },
  gridCell: { width: '50%', gap: 2 },
  gridLabel: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
  gridValue: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary },
  legendRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendSwatch: { width: 16, height: 3, borderRadius: 2 },
  legendDash: { backgroundColor: colors.textTertiary, marginLeft: spacing.sm },
  legendText: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
});
