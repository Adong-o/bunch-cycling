import type { SpeedSample } from '@/lib/database.types';
import type { TrackPoint } from '@/lib/geo';
import { haversineDistanceM } from '@/lib/geo';

const MAX_SAMPLES = 200;

/**
 * Turns a recorded track into a compact [distance_m, speed_mps] profile for
 * the Ride detail ▸ Speed tab. Returns null (not a flat fabricated line) when
 * the device reported speed on too few fixes to draw anything honest — e.g.
 * GPX imports or very short rides. Speeds are averaged inside equal-width
 * distance buckets so the stored array stays <= 200 pairs however long the ride.
 */
export function buildSpeedSamples(track: TrackPoint[]): SpeedSample[] | null {
  if (track.length < 3) return null;
  const raw: Array<{ d: number; s: number }> = [];
  let cumulative = 0;
  let withSpeed = 0;
  for (let i = 0; i < track.length; i++) {
    if (i > 0) cumulative += haversineDistanceM(track[i - 1], track[i]);
    const s = track[i].speedMps;
    if (s != null && s >= 0) {
      withSpeed += 1;
      raw.push({ d: cumulative, s });
    }
  }
  if (withSpeed < 3 || withSpeed / track.length < 0.5 || cumulative <= 0) return null;
  if (raw.length <= MAX_SAMPLES) {
    return raw.map((r) => [Math.round(r.d), Number(r.s.toFixed(2))] as SpeedSample);
  }
  const bucketSize = raw.length / MAX_SAMPLES;
  const out: SpeedSample[] = [];
  for (let b = 0; b < MAX_SAMPLES; b++) {
    const slice = raw.slice(Math.floor(b * bucketSize), Math.floor((b + 1) * bucketSize));
    if (slice.length === 0) continue;
    const d = slice[slice.length - 1].d;
    const s = slice.reduce((sum, r) => sum + r.s, 0) / slice.length;
    out.push([Math.round(d), Number(s.toFixed(2))]);
  }
  return out;
}
