import React, { useRef, useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button } from '@/components/ui/Button';
import { RideShareCard } from './RideShareCard';
import { shareRideImage } from '@/lib/shareRide';
import { getErrorMessage } from '@/lib/errors';
import { colors, spacing } from '@/theme';
import type { Ride, UnitSystem } from '@/lib/database.types';

interface Props {
  visible: boolean;
  ride: Ride;
  ownerName: string;
  ownerAvatarUrl?: string | null;
  units: UnitSystem;
  onClose: () => void;
}

export function RideShareModal({ visible, ride, ownerName, ownerAvatarUrl, units, onClose }: Props) {
  const cardRef = useRef<View>(null);
  const [sharing, setSharing] = useState(false);

  async function onShare() {
    setSharing(true);
    try {
      await shareRideImage(cardRef);
    } catch (e) {
      Alert.alert('Could not share ride', getErrorMessage(e));
    } finally {
      setSharing(false);
    }
  }

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <Pressable onPress={onClose} hitSlop={10} style={styles.closeButton}>
          <Ionicons name="close" size={22} color={colors.textOnAccent} />
        </Pressable>

        <View ref={cardRef} collapsable={false}>
          <RideShareCard ride={ride} ownerName={ownerName} ownerAvatarUrl={ownerAvatarUrl} units={units} />
        </View>

        <Button title="Share" onPress={onShare} loading={sharing} style={styles.shareButton} />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  // Deliberately a dark scrim, not a theme token — a share-preview modal
  // needs to go dark behind the white card regardless of the app's own
  // (light) theme, same as a native iOS/Android share sheet would.
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(21, 23, 27, 0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  closeButton: {
    position: 'absolute',
    top: 56,
    right: spacing.lg,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  shareButton: { alignSelf: 'stretch' },
});
