import React, { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, { Easing, useAnimatedStyle, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';
import { colors, spacing } from '@/theme';

const TOTAL_STEPS = 8;

interface Props {
  /** 1-based — which onboarding screen this is. */
  step: number;
}

/**
 * A slim 8-segment bar at the top of each onboarding screen: Intro,
 * RiderType, ProfileSetup, TargetSetup, PermissionsSetup, ImportData,
 * UpgradeOffer, Done (Intro doubles as step 1 — its own internal slide dots
 * handle progress within that screen). Every mount "draws" the filled
 * segments in left to right, which doubles as the screen's own entrance cue.
 */
export function OnboardingProgress({ step }: Props) {
  return (
    <View style={styles.row}>
      {Array.from({ length: TOTAL_STEPS }, (_, i) => (
        <Segment key={i} filled={i < step} delay={i * 70} />
      ))}
    </View>
  );
}

function Segment({ filled, delay }: { filled: boolean; delay: number }) {
  const width = useSharedValue(0);

  useEffect(() => {
    width.value = filled ? withDelay(delay, withTiming(100, { duration: 420, easing: Easing.out(Easing.cubic) })) : withTiming(0, { duration: 200 });
    // Deliberately excluding `delay`/`width` from deps — this should only
    // re-run when `filled` changes, not re-trigger the stagger on every
    // parent re-render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filled]);

  const fillStyle = useAnimatedStyle(() => ({ width: `${width.value}%` }));

  return (
    <View style={styles.track}>
      <Animated.View style={[styles.fill, fillStyle]} />
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: 6, paddingHorizontal: spacing.lg, paddingTop: spacing.sm },
  track: { flex: 1, height: 4, borderRadius: 2, backgroundColor: colors.border, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 2, backgroundColor: colors.accent },
});
