import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { colors, fonts } from '@/theme';

type WaypointState = 'upcoming' | 'active' | 'done';

interface WaypointProps {
  /** upcoming = not reached yet (hollow dot), active = the open question (solid ink),
   * done = already answered (solid accent) — the same grammar as the segmented bar
   * above every onboarding screen, just read top-to-bottom instead of left-to-right. */
  state: WaypointState;
  /** Suppresses the connecting rule below the dot — pass on the final item in a list. */
  isLast?: boolean;
  children: React.ReactNode;
}

/**
 * Onboarding's one structural motif, replacing the bordered-card-per-question
 * pattern the previous two passes kept reaching for: a thin vertical rule with a
 * waypoint dot per question, the way a route cue sheet marks distance rather than
 * boxing every turn in its own frame. Built on plain flexbox (no SVG path math,
 * no onLayout measuring) — `rail` and `content` are flex siblings, so the rule
 * always stretches to match whatever `content` renders, including a multi-line
 * option list or a progressive description reveal.
 */
export function Waypoint({ state, isLast, children }: WaypointProps) {
  return (
    <View style={styles.row}>
      <View style={styles.rail}>
        <View style={[styles.dot, dotStateStyles[state]]} />
        {!isLast ? <View style={styles.line} /> : null}
      </View>
      <View style={styles.content}>{children}</View>
    </View>
  );
}

interface OptionRowProps {
  label: string;
  /** Shown only once this option is selected — progressive disclosure instead of
   * permanently printing every option's description, which is most of what made
   * the old cards feel heavy. */
  description?: string;
  selected: boolean;
  onPress: () => void;
}

/** A single pick-one row for inside a Waypoint: weight and color carry the
 * selected state (plus a small accent mark, so it never rests on color alone)
 * instead of a bordered box with an icon circle. */
export function OptionRow({ label, description, selected, onPress }: OptionRowProps) {
  return (
    <Pressable onPress={onPress} style={styles.optionRow} hitSlop={6}>
      <View style={styles.optionLabelRow}>
        <Text style={[styles.optionLabel, selected && styles.optionLabelSelected]}>{label}</Text>
        {selected ? <View style={styles.selectedDot} /> : null}
      </View>
      {selected && description ? (
        <Animated.Text entering={FadeIn.duration(180)} style={styles.optionDescription}>
          {description}
        </Animated.Text>
      ) : null}
    </Pressable>
  );
}

const DOT_SIZE = 9;

const styles = StyleSheet.create({
  row: { flexDirection: 'row' },
  rail: { width: 24, alignItems: 'center' },
  dot: { width: DOT_SIZE, height: DOT_SIZE, borderRadius: DOT_SIZE / 2, marginTop: 7 },
  line: { width: 2, flex: 1, marginTop: 4, marginBottom: 4, borderRadius: 1, backgroundColor: colors.border },
  content: { flex: 1, paddingLeft: 10, paddingBottom: 26 },

  optionRow: { paddingVertical: 11 },
  optionLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  optionLabel: { fontFamily: fonts.medium, fontSize: 16, color: colors.textSecondary },
  optionLabelSelected: { fontFamily: fonts.semiBold, color: colors.textPrimary },
  selectedDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.accent },
  optionDescription: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 18, color: colors.textSecondary, marginTop: 3 },
});

const dotStateStyles = StyleSheet.create({
  upcoming: { backgroundColor: colors.bg, borderWidth: 2, borderColor: colors.borderStrong },
  active: { backgroundColor: colors.textPrimary },
  done: { backgroundColor: colors.accent },
});
