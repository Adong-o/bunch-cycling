import React, { useMemo, useState } from 'react';
import { type LayoutChangeEvent, StyleSheet, Text, View } from 'react-native';
import Svg, { Defs, LinearGradient, Path, Stop } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { haversineDistanceM } from '@/lib/geo';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing } from '@/theme';
import type { RouteGeoJSON, UnitSystem } from '@/lib/database.types';

interface Props {
  routeGeojson: RouteGeoJSON | null | undefined;
  units: UnitSystem;
  elevationGainM: number;
  elevationLossM: number;
}

interface ProfilePoint {
  distanceM: number;
  elevationM: number;
}

const CHART_HEIGHT = 120;
const PADDING_Y = 10;
const SMOOTH_WINDOW = 5;

/** Walks the route's full coordinate list to get a true cumulative-distance
 * x-axis (GPS points aren't perfectly evenly spaced), recording an
 * elevation sample at that distance wherever the device reported altitude.
 * Distance accumulates across every point, elevation or not, so a gap in
 * altitude readings never compresses the x-axis around it. */
function buildProfile(coordinates: RouteGeoJSON['coordinates'] | undefined): ProfilePoint[] {
  if (!coordinates || coordinates.length === 0) return [];
  const points: ProfilePoint[] = [];
  let cumulative = 0;
  let prev: [number, number] | null = null;
  for (const c of coordinates) {
    const [lng, lat, elevationM] = c;
    if (prev) cumulative += haversineDistanceM({ lat: prev[1], lng: prev[0] }, { lat, lng });
    prev = [lng, lat];
    if (elevationM != null) points.push({ distanceM: cumulative, elevationM });
  }
  return points;
}

/** Light moving-average smoothing for the drawn line only — mirrors the
 * noise floor in geo.ts's elevationGainLoss(), but this never feeds back
 * into the gain/loss numbers themselves (those come from the ride's own
 * stored, already-smoothed totals, passed in as props) — just makes the
 * line legible instead of jagged with GPS/barometer jitter. */
function smoothElevations(points: ProfilePoint[], window = SMOOTH_WINDOW): ProfilePoint[] {
  if (points.length < 3) return points;
  return points.map((p, i) => {
    const start = Math.max(0, i - Math.floor(window / 2));
    const end = Math.min(points.length, i + Math.ceil(window / 2));
    const slice = points.slice(start, end);
    const avg = slice.reduce((sum, s) => sum + s.elevationM, 0) / slice.length;
    return { distanceM: p.distanceM, elevationM: avg };
  });
}

/** Strava/Komoot-style elevation profile, built straight from
 * route_geojson's per-point [lng, lat, elevationM] — the same data
 * pointsToGeoJSON()/locationTracking.ts already captures from
 * loc.coords.altitude, so this needs no schema change and no extra API
 * call. If a ride's device never reported altitude (it happens — indoor
 * trainers, some imports), this shows an honest empty state rather than a
 * fabricated flat line. */
export function ElevationProfile({ routeGeojson, units, elevationGainM, elevationLossM }: Props) {
  const [width, setWidth] = useState(0);

  const profile = useMemo(() => smoothElevations(buildProfile(routeGeojson?.coordinates)), [routeGeojson]);

  function onLayout(e: LayoutChangeEvent) {
    setWidth(e.nativeEvent.layout.width);
  }

  if (profile.length < 2) {
    return (
      <View style={styles.card}>
        <Text style={styles.sectionLabel}>Elevation</Text>
        <Text style={styles.emptyText}>This ride's device didn't report altitude, so there's no profile to draw.</Text>
      </View>
    );
  }

  const elevations = profile.map((p) => p.elevationM);
  const minEl = Math.min(...elevations);
  const maxEl = Math.max(...elevations);
  const elRange = Math.max(1, maxEl - minEl);
  const totalDistance = profile[profile.length - 1].distanceM;
  const usableHeight = CHART_HEIGHT - PADDING_Y * 2;

  let linePath = '';
  let areaPath = '';
  if (width > 0 && totalDistance > 0) {
    const toX = (d: number) => (d / totalDistance) * width;
    const toY = (el: number) => CHART_HEIGHT - PADDING_Y - ((el - minEl) / elRange) * usableHeight;
    profile.forEach((p, i) => {
      const x = toX(p.distanceM);
      const y = toY(p.elevationM);
      linePath += i === 0 ? `M${x},${y}` : ` L${x},${y}`;
    });
    areaPath = `${linePath} L${width},${CHART_HEIGHT} L0,${CHART_HEIGHT} Z`;
  }

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <Text style={styles.sectionLabel}>Elevation</Text>
        <View style={styles.statsInline}>
          <View style={styles.statInline}>
            <Ionicons name="trending-up-outline" size={13} color={colors.success} />
            <Text style={styles.statInlineValue}>{formatElevation(elevationGainM, units)}</Text>
          </View>
          <View style={styles.statInline}>
            <Ionicons name="trending-down-outline" size={13} color={colors.danger} />
            <Text style={styles.statInlineValue}>{formatElevation(elevationLossM, units)}</Text>
          </View>
        </View>
      </View>

      <View style={styles.chartWrap} onLayout={onLayout}>
        {width > 0 ? (
          <Svg width={width} height={CHART_HEIGHT}>
            <Defs>
              <LinearGradient id="elevationFill" x1="0" y1="0" x2="0" y2="1">
                <Stop offset="0" stopColor={colors.accent} stopOpacity={0.28} />
                <Stop offset="1" stopColor={colors.accent} stopOpacity={0.02} />
              </LinearGradient>
            </Defs>
            <Path d={areaPath} fill="url(#elevationFill)" />
            <Path d={linePath} stroke={colors.accent} strokeWidth={2} fill="none" strokeLinejoin="round" strokeLinecap="round" />
          </Svg>
        ) : null}
      </View>

      <View style={styles.axisRow}>
        <Text style={styles.axisLabel}>0</Text>
        <Text style={styles.axisLabel}>{formatDistance(totalDistance, units)}</Text>
      </View>
      <View style={styles.minMaxRow}>
        <Text style={styles.minMaxLabel}>Lowest {formatElevation(minEl, units)}</Text>
        <Text style={styles.minMaxLabel}>Highest {formatElevation(maxEl, units)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.xs,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary, letterSpacing: 0.3 },
  statsInline: { flexDirection: 'row', gap: spacing.sm },
  statInline: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  statInlineValue: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textPrimary },
  chartWrap: { height: CHART_HEIGHT, marginTop: spacing.xs },
  axisRow: { flexDirection: 'row', justifyContent: 'space-between' },
  axisLabel: { fontFamily: fonts.regular, fontSize: 11, color: colors.textTertiary },
  minMaxRow: { flexDirection: 'row', justifyContent: 'space-between' },
  minMaxLabel: { fontFamily: fonts.medium, fontSize: 11, color: colors.textSecondary },
  emptyText: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary, lineHeight: 18 },
});
