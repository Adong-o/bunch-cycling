import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/ui/ScreenContainer';
import { colors, fonts, spacing, type as typeTokens } from '@/theme';

export interface LegalSection {
  heading: string;
  /** One or more paragraphs; prefix a line with "• " to render it as a bullet. */
  body: string[];
}

interface Props {
  navigation: { goBack: () => void };
  title: string;
  lastUpdated: string;
  intro: string;
  sections: LegalSection[];
}

/** Shared scrollable layout for Privacy Policy / Terms of Service — content lives in the screens that use it. */
export function LegalDocument({ navigation, title, lastUpdated, intro, sections }: Props) {
  return (
    <ScreenContainer padded={false}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.textPrimary} />
        </Pressable>
        <Text style={styles.headerTitle}>{title}</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.lastUpdated}>Last updated {lastUpdated}</Text>
        <Text style={styles.intro}>{intro}</Text>

        {sections.map((section) => (
          <View key={section.heading} style={styles.section}>
            <Text style={styles.heading}>{section.heading}</Text>
            {section.body.map((line, i) =>
              line.startsWith('• ') ? (
                <View key={i} style={styles.bulletRow}>
                  <Text style={styles.bulletDot}>•</Text>
                  <Text style={styles.bulletText}>{line.slice(2)}</Text>
                </View>
              ) : (
                <Text key={i} style={styles.paragraph}>
                  {line}
                </Text>
              )
            )}
          </View>
        ))}

        <Text style={styles.footerNote}>
          This document is a template drafted for Bunch and hasn't been reviewed by a lawyer. Replace the bracketed
          placeholders with your real legal entity, jurisdiction and contact details, and have it reviewed before
          you rely on it for a public launch.
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.xs },
  headerTitle: { ...typeTokens.h3, color: colors.textPrimary },
  scroll: { paddingHorizontal: spacing.md, paddingBottom: spacing.xxl },
  lastUpdated: { fontFamily: fonts.medium, fontSize: 12, color: colors.textTertiary, marginTop: spacing.xs },
  intro: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 21, color: colors.textSecondary, marginTop: spacing.sm },
  section: { marginTop: spacing.lg, gap: 6 },
  heading: { fontFamily: fonts.semiBold, fontSize: 16, color: colors.textPrimary, marginBottom: 2 },
  paragraph: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 21, color: colors.textSecondary },
  bulletRow: { flexDirection: 'row', gap: 8, paddingLeft: 2 },
  bulletDot: { fontFamily: fonts.regular, fontSize: 14, lineHeight: 21, color: colors.textTertiary },
  bulletText: { flex: 1, fontFamily: fonts.regular, fontSize: 14, lineHeight: 21, color: colors.textSecondary },
  footerNote: {
    fontFamily: fonts.regular,
    fontSize: 12,
    lineHeight: 18,
    color: colors.textTertiary,
    marginTop: spacing.xl,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
