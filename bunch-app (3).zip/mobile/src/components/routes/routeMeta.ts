import type { RouteRow } from '@/lib/database.types';

export type Difficulty = 'easy' | 'moderate' | 'hard';

/** Client-side difficulty from length and climbing — no stored field to drift out of date. */
export function routeDifficulty(route: Pick<RouteRow, 'distance_m' | 'elevation_gain_m'>): Difficulty {
  const score = route.distance_m / 1000 / 25 + route.elevation_gain_m / 500;
  if (score < 1.2) return 'easy';
  if (score < 3) return 'moderate';
  return 'hard';
}

export const DIFFICULTY_LABEL: Record<Difficulty, string> = { easy: 'Easy', moderate: 'Moderate', hard: 'Hard' };

export type DistanceBucket = 'any' | 'short' | 'medium' | 'long';

export const DISTANCE_BUCKETS: Array<{ key: DistanceBucket; label: string; min: number; max: number }> = [
  { key: 'short', label: 'Under 25 km', min: 0, max: 25000 },
  { key: 'medium', label: '25–60 km', min: 25000, max: 60000 },
  { key: 'long', label: '60 km +', min: 60000, max: Infinity },
];
