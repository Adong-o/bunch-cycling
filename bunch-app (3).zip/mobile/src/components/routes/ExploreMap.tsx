import React, { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Camera, CircleLayer, LineLayer, MapView, ShapeSource, UserLocation } from '@maplibre/maplibre-react-native';
import { MapAttribution } from '@/components/map/MapAttribution';
import { colors } from '@/theme';

const STYLE_URL = 'https://tiles.openfreemap.org/styles/liberty';
const OTHERS_COLOR = '#3E4658';

export interface ExploreRoute {
  id: string;
  coordinates: Array<[number, number]>;
  /** The signed-in rider's own route (drawn in the brand colour; others' are slate). */
  mine: boolean;
}

export interface ExploreMapHandle {
  flyTo: (lng: number, lat: number, zoom?: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  /** Fit the camera to every route on the map (or just the selected one). */
  fitRoutes: () => void;
}

interface Props {
  routes: ExploreRoute[];
  selectedId: string | null;
  /** A route line / start dot was tapped (id), or empty map was tapped (null). */
  onSelect: (id: string | null) => void;
  /** Pixels at the top / bottom covered by the search bar and the sheet — fitted routes clear them. */
  topPadding: number;
  bottomPadding: number;
  /** Distance from the bottom edge for the required OSM attribution (kept just above the sheet). */
  attributionBottom: number;
}

type Bounds = [number, number, number, number];

function boundsOf(lists: Array<Array<[number, number]>>): Bounds | null {
  let minLng = Infinity;
  let minLat = Infinity;
  let maxLng = -Infinity;
  let maxLat = -Infinity;
  for (const list of lists) {
    for (const [lng, lat] of list) {
      if (lng < minLng) minLng = lng;
      if (lng > maxLng) maxLng = lng;
      if (lat < minLat) minLat = lat;
      if (lat > maxLat) maxLat = lat;
    }
  }
  return minLng === Infinity ? null : [minLng, minLat, maxLng, maxLat];
}

/**
 * Full-screen map for the Routes tab. Every route the rider can see is drawn
 * (theirs in the brand colour, other riders' in slate) with a start dot; tapping
 * a line or dot selects it and the camera fits it, tapping empty map clears the
 * selection. Pinch / drag / double-tap zoom are the native ones, and the screen
 * adds + / − and "fit all" buttons through the handle.
 */
export const ExploreMap = forwardRef<ExploreMapHandle, Props>(function ExploreMap(
  { routes, selectedId, onSelect, topPadding, bottomPadding, attributionBottom },
  ref
) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cameraRef = useRef<any>(null);
  const zoomRef = useRef(11);
  const paddingRef = useRef({ top: topPadding, bottom: bottomPadding });
  paddingRef.current = { top: topPadding, bottom: bottomPadding };
  const pressedFeature = useRef(false);
  const readyRef = useRef(false);
  /** A flyTo asked for before the style finished loading is applied as soon as it has. */
  const pendingFly = useRef<{ lng: number; lat: number; zoom: number } | null>(null);
  const [ready, setReady] = useState(false);

  const selected = useMemo(() => routes.find((r) => r.id === selectedId) ?? null, [routes, selectedId]);
  const selectedRef = useRef(selected);
  selectedRef.current = selected;
  const others = useMemo(() => routes.filter((r) => r.id !== selectedId), [routes, selectedId]);
  const routesKey = useMemo(() => routes.map((r) => r.id).join('|'), [routes]);

  function fit(bounds: Bounds | null) {
    if (!bounds) return;
    const [minLng, minLat, maxLng, maxLat] = bounds;
    if (minLng === maxLng && minLat === maxLat) {
      cameraRef.current?.setCamera({ centerCoordinate: [minLng, minLat], zoomLevel: 13, animationDuration: 500 });
      return;
    }
    const { top, bottom } = paddingRef.current;
    cameraRef.current?.fitBounds([maxLng, maxLat], [minLng, minLat], [top, 36, bottom, 36], 600);
  }

  useImperativeHandle(ref, () => ({
    flyTo: (lng, lat, zoom = 13) => {
      if (!readyRef.current) {
        pendingFly.current = { lng, lat, zoom };
        return;
      }
      cameraRef.current?.setCamera({ centerCoordinate: [lng, lat], zoomLevel: zoom, animationDuration: 600 });
    },
    zoomIn: () => cameraRef.current?.setCamera({ zoomLevel: Math.min(19, zoomRef.current + 1), animationDuration: 250 }),
    zoomOut: () => cameraRef.current?.setCamera({ zoomLevel: Math.max(2, zoomRef.current - 1), animationDuration: 250 }),
    fitRoutes: () => fit(selected ? boundsOf([selected.coordinates]) : boundsOf(routes.map((r) => r.coordinates))),
  }));

  // Fit every visible route when the map first loads and whenever the set of visible
  // routes changes (search / filters) — but never while the rider is looking at one
  // selected route, and never because the sheet moved (the camera must not jump while
  // a rider drags the sheet around). A flyTo requested before the map was ready wins
  // over the initial fit: the screen only asks for it when there are no routes to show.
  useEffect(() => {
    if (!ready) return;
    const pending = pendingFly.current;
    if (pending && routes.length === 0) {
      pendingFly.current = null;
      cameraRef.current?.setCamera({ centerCoordinate: [pending.lng, pending.lat], zoomLevel: pending.zoom, animationDuration: 0 });
      return;
    }
    pendingFly.current = null;
    if (!selectedRef.current) fit(boundsOf(routes.map((r) => r.coordinates)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, routesKey]);

  // Selecting a route frames it; clearing the selection leaves the camera where the rider put it.
  useEffect(() => {
    if (ready && selected) fit(boundsOf([selected.coordinates]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, selectedId]);

  const othersCollection = useMemo(
    () => ({
      type: 'FeatureCollection' as const,
      features: others.map((r) => ({
        type: 'Feature' as const,
        id: r.id,
        properties: { id: r.id, mine: r.mine ? 1 : 0 },
        geometry: { type: 'LineString' as const, coordinates: r.coordinates },
      })),
    }),
    [others]
  );
  const startsCollection = useMemo(
    () => ({
      type: 'FeatureCollection' as const,
      features: others.map((r) => ({
        type: 'Feature' as const,
        id: r.id,
        properties: { id: r.id, mine: r.mine ? 1 : 0 },
        geometry: { type: 'Point' as const, coordinates: r.coordinates[0] },
      })),
    }),
    [others]
  );
  const selectedLine = useMemo(
    () => (selected ? { type: 'Feature' as const, properties: {}, geometry: { type: 'LineString' as const, coordinates: selected.coordinates } } : null),
    [selected]
  );
  const selectedEnds = useMemo(
    () =>
      selected
        ? {
            type: 'FeatureCollection' as const,
            features: [
              { type: 'Feature' as const, properties: { end: 0 }, geometry: { type: 'Point' as const, coordinates: selected.coordinates[0] } },
              { type: 'Feature' as const, properties: { end: 1 }, geometry: { type: 'Point' as const, coordinates: selected.coordinates[selected.coordinates.length - 1] } },
            ],
          }
        : null,
    [selected]
  );

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function onFeaturePress(e: any) {
    const id = e?.features?.[0]?.properties?.id;
    if (typeof id !== 'string') return;
    pressedFeature.current = true;
    setTimeout(() => (pressedFeature.current = false), 120);
    onSelect(id);
  }

  function onMapPress() {
    // A tap on a route fires both the source's press and the map's; only a tap that hit no route clears the selection.
    setTimeout(() => {
      if (!pressedFeature.current) onSelect(null);
    }, 40);
  }

  return (
    <View style={StyleSheet.absoluteFill}>
      <MapView
        style={StyleSheet.absoluteFill}
        mapStyle={STYLE_URL}
        logoEnabled={false}
        attributionEnabled={false}
        compassEnabled={false}
        pitchEnabled={false}
        onPress={onMapPress}
        onDidFinishLoadingMap={() => {
          readyRef.current = true;
          setReady(true);
        }}
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        onRegionDidChange={(feature: any) => {
          const z = feature?.properties?.zoomLevel;
          if (typeof z === 'number') zoomRef.current = z;
        }}
      >
        <Camera ref={cameraRef} animationMode="flyTo" animationDuration={600} />
        <UserLocation visible />

        {others.length > 0 ? (
          <ShapeSource id="exploreRoutes" shape={othersCollection} onPress={onFeaturePress} hitbox={{ width: 28, height: 28 }}>
            <LineLayer id="exploreRoutesCasing" style={{ lineColor: '#FFFFFF', lineWidth: 6.5, lineCap: 'round', lineJoin: 'round', lineOpacity: 0.9 }} />
            <LineLayer
              id="exploreRoutesLine"
              style={{
                lineColor: ['case', ['==', ['get', 'mine'], 1], colors.accent, OTHERS_COLOR],
                lineWidth: 3.5,
                lineCap: 'round',
                lineJoin: 'round',
                lineOpacity: 0.78,
              }}
            />
          </ShapeSource>
        ) : null}
        {others.length > 0 ? (
          <ShapeSource id="exploreStarts" shape={startsCollection} onPress={onFeaturePress} hitbox={{ width: 36, height: 36 }}>
            <CircleLayer
              id="exploreStartDots"
              style={{
                circleRadius: 5.5,
                circleColor: ['case', ['==', ['get', 'mine'], 1], colors.accent, OTHERS_COLOR],
                circleStrokeColor: '#FFFFFF',
                circleStrokeWidth: 2,
              }}
            />
          </ShapeSource>
        ) : null}

        {selectedLine ? (
          <ShapeSource id="exploreSelected" shape={selectedLine}>
            <LineLayer id="exploreSelectedCasing" style={{ lineColor: '#FFFFFF', lineWidth: 10, lineCap: 'round', lineJoin: 'round' }} />
            <LineLayer id="exploreSelectedLine" style={{ lineColor: colors.accent, lineWidth: 5.5, lineCap: 'round', lineJoin: 'round' }} />
          </ShapeSource>
        ) : null}
        {selectedEnds ? (
          <ShapeSource id="exploreSelectedEnds" shape={selectedEnds}>
            <CircleLayer
              id="exploreSelectedEndDots"
              style={{
                circleRadius: 7.5,
                circleColor: ['case', ['==', ['get', 'end'], 1], colors.danger, colors.success],
                circleStrokeColor: '#FFFFFF',
                circleStrokeWidth: 3,
              }}
            />
          </ShapeSource>
        ) : null}
      </MapView>
      <MapAttribution style={{ bottom: attributionBottom }} />
    </View>
  );
});
