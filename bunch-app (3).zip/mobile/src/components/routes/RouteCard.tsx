import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { RideMap } from '@/components/RideMap';
import { boundingBox, geoJSONToCoordinates } from '@/lib/geo';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import { DIFFICULTY_LABEL, routeDifficulty, type Difficulty } from './routeMeta';
import type { RouteRow, UnitSystem } from '@/lib/database.types';

const DIFFICULTY_COLOR: Record<Difficulty, { fg: string; bg: string }> = {
  easy: { fg: colors.success, bg: colors.successMuted },
  moderate: { fg: colors.gold, bg: colors.goldMuted },
  hard: { fg: colors.danger, bg: colors.dangerMuted },
};

interface Props {
  route: RouteRow;
  units: UnitSystem;
  riders: number;
  selected: boolean;
  isMine: boolean;
  onPress: () => void;
}

export function RouteCard({ route, units, riders, selected, isMine, onPress }: Props) {
  const coords = geoJSONToCoordinates(route.route_geojson);
  const bounds = boundingBox(route.route_geojson);
  const diff = routeDifficulty(route);
  const tone = DIFFICULTY_COLOR[diff];

  return (
    <Pressable onPress={onPress} style={[styles.card, selected && styles.cardSelected]}>
      <View style={styles.body}>
        <View style={styles.chipRow}>
          <View style={[styles.chip, { backgroundColor: tone.bg }]}>
            <Text style={[styles.chipText, { color: tone.fg }]}>{DIFFICULTY_LABEL[diff]}</Text>
          </View>
          <View style={styles.chip}>
            <Text style={styles.chipText}>{route.surface_type}</Text>
          </View>
          {isMine ? (
            <View style={[styles.chip, { backgroundColor: colors.accentMuted }]}>
              <Text style={[styles.chipText, { color: colors.accent }]}>Yours</Text>
            </View>
          ) : null}
        </View>
        <Text style={styles.name} numberOfLines={2}>
          {route.name}
        </Text>
        <View style={styles.statsRow}>
          <Text style={styles.stat}>{formatDistance(route.distance_m, units)}</Text>
          <Text style={styles.dot}>·</Text>
          <Ionicons name="trending-up" size={13} color={colors.textSecondary} />
          <Text style={styles.stat}>{formatElevation(route.elevation_gain_m, units)}</Text>
        </View>
        <View style={styles.statsRow}>
          <Ionicons name="people-outline" size={13} color={colors.textTertiary} />
          <Text style={styles.riders}>{riders === 0 ? 'No rides yet' : `${riders} ${riders === 1 ? 'rider' : 'riders'}`}</Text>
        </View>
      </View>
      {coords.length > 1 ? (
        <RideMap routeCoordinates={coords} bounds={bounds} interactive={false} style={styles.thumb} />
      ) : (
        <View style={[styles.thumb, styles.thumbEmpty]} />
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.sm,
    gap: spacing.sm,
    ...shadow.card,
  },
  cardSelected: { borderColor: colors.accent, borderWidth: 2 },
  body: { flex: 1, gap: 6, justifyContent: 'center' },
  chipRow: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  chip: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill, backgroundColor: colors.surfaceHigh },
  chipText: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.textSecondary, textTransform: 'capitalize' },
  name: { fontFamily: fonts.bold, fontSize: 15, color: colors.textPrimary },
  statsRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  stat: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary },
  dot: { color: colors.textTertiary },
  riders: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary },
  thumb: { width: 104, height: 104, borderRadius: radius.md },
  thumbEmpty: { backgroundColor: colors.surfaceHigh },
});
