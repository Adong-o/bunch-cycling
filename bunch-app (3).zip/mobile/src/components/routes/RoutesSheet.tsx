import React, { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { runOnJS, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { colors, radius, shadow } from '@/theme';

export type SheetSnap = 'collapsed' | 'half' | 'full';

interface Props {
  /** Height of the area the sheet lives in. */
  containerHeight: number;
  snap: SheetSnap;
  onSnapChange: (snap: SheetSnap) => void;
  header: React.ReactNode;
  children: React.ReactNode;
}

export const COLLAPSED_VISIBLE = 132;

/** Draggable bottom sheet with three snap points. The pan gesture lives on
 * the handle + header only, so the list inside scrolls normally. */
export function RoutesSheet({ containerHeight, snap, onSnapChange, header, children }: Props) {
  const fullHeight = Math.max(320, containerHeight - 24);
  const offsets = {
    full: 0,
    half: fullHeight - Math.round(containerHeight * 0.46),
    collapsed: fullHeight - COLLAPSED_VISIBLE,
  };

  const translateY = useSharedValue(offsets[snap]);
  const startY = useSharedValue(0);

  useEffect(() => {
    translateY.value = withSpring(offsets[snap], { damping: 22, stiffness: 220 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snap, containerHeight]);

  const pan = Gesture.Pan()
    .onStart(() => {
      startY.value = translateY.value;
    })
    .onUpdate((e) => {
      translateY.value = Math.min(offsets.collapsed, Math.max(0, startY.value + e.translationY));
    })
    .onEnd((e) => {
      const projected = translateY.value + e.velocityY * 0.12;
      const candidates: Array<[SheetSnap, number]> = [
        ['full', offsets.full],
        ['half', offsets.half],
        ['collapsed', offsets.collapsed],
      ];
      let best = candidates[0];
      for (const c of candidates) if (Math.abs(c[1] - projected) < Math.abs(best[1] - projected)) best = c;
      translateY.value = withSpring(best[1], { damping: 22, stiffness: 220 });
      runOnJS(onSnapChange)(best[0]);
    });

  const style = useAnimatedStyle(() => ({ transform: [{ translateY: translateY.value }] }));

  return (
    <Animated.View style={[styles.sheet, { height: fullHeight }, style]}>
      <GestureDetector gesture={pan}>
        <View collapsable={false}>
          <View style={styles.handleWrap}>
            <View style={styles.handle} />
          </View>
          {header}
        </View>
      </GestureDetector>
      <View style={styles.content}>{children}</View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.bg,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    ...shadow.floating,
  },
  handleWrap: { alignItems: 'center', paddingTop: 10, paddingBottom: 6 },
  handle: { width: 40, height: 5, borderRadius: 3, backgroundColor: colors.borderStrong },
  content: { flex: 1 },
});
