import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDistance, formatElevation } from '@/lib/units';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import { DIFFICULTY_LABEL, routeDifficulty, type Difficulty } from './routeMeta';
import type { RouteRow, UnitSystem } from '@/lib/database.types';

/** Height of the card, so the screen can lift the map controls and attribution clear of it. */
export const ROUTE_PREVIEW_HEIGHT = 104;

const DIFFICULTY_COLOR: Record<Difficulty, { fg: string; bg: string }> = {
  easy: { fg: colors.success, bg: colors.successMuted },
  moderate: { fg: colors.gold, bg: colors.goldMuted },
  hard: { fg: colors.danger, bg: colors.dangerMuted },
};

interface Props {
  route: RouteRow;
  units: UnitSystem;
  riders: number;
  isMine: boolean;
  onOpen: () => void;
  onDismiss: () => void;
}

/** Floating card shown over the Routes map when a route line is tapped: the essentials plus a one-tap way into the full route. */
export function RoutePreviewCard({ route, units, riders, isMine, onOpen, onDismiss }: Props) {
  const diff = routeDifficulty(route);
  const tone = DIFFICULTY_COLOR[diff];
  return (
    <Pressable
      onPress={onOpen}
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.96 }]}
      accessibilityRole="button"
      accessibilityLabel={`${route.name}. Open route details`}
    >
      <View style={styles.body}>
        <View style={styles.chipRow}>
          <View style={[styles.chip, { backgroundColor: tone.bg }]}>
            <Text style={[styles.chipText, { color: tone.fg }]}>{DIFFICULTY_LABEL[diff]}</Text>
          </View>
          <View style={styles.chip}>
            <Text style={styles.chipText}>{route.surface_type}</Text>
          </View>
          {isMine ? (
            <View style={[styles.chip, { backgroundColor: colors.accentMuted }]}>
              <Text style={[styles.chipText, { color: colors.accent }]}>Yours</Text>
            </View>
          ) : null}
        </View>
        <Text style={styles.name} numberOfLines={1}>
          {route.name}
        </Text>
        <View style={styles.statsRow}>
          <Text style={styles.stat}>{formatDistance(route.distance_m, units)}</Text>
          <Text style={styles.dot}>·</Text>
          <Ionicons name="trending-up" size={14} color={colors.textSecondary} />
          <Text style={styles.stat}>{formatElevation(route.elevation_gain_m, units)}</Text>
          <Text style={styles.dot}>·</Text>
          <Text style={styles.riders}>{riders === 0 ? 'No rides yet' : `${riders} ${riders === 1 ? 'rider' : 'riders'}`}</Text>
        </View>
      </View>

      <View style={styles.side}>
        <Pressable onPress={onDismiss} hitSlop={12} accessibilityRole="button" accessibilityLabel="Close route preview" style={styles.close}>
          <Ionicons name="close" size={18} color={colors.textTertiary} />
        </Pressable>
        <View style={styles.go} pointerEvents="none">
          <Ionicons name="arrow-forward" size={20} color={colors.textOnAccent} />
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    height: ROUTE_PREVIEW_HEIGHT,
    flexDirection: 'row',
    alignItems: 'stretch',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    paddingLeft: spacing.md,
    paddingRight: spacing.sm,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
    ...shadow.floating,
  },
  body: { flex: 1, justifyContent: 'center', gap: 6 },
  chipRow: { flexDirection: 'row', gap: 6 },
  chip: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill, backgroundColor: colors.surfaceHigh },
  chipText: { fontFamily: fonts.semiBold, fontSize: 11, color: colors.textSecondary, textTransform: 'capitalize' },
  name: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary },
  statsRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  stat: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textSecondary },
  dot: { color: colors.textTertiary },
  riders: { fontFamily: fonts.regular, fontSize: 13, color: colors.textTertiary },
  side: { alignItems: 'flex-end', justifyContent: 'space-between' },
  close: { width: 24, height: 24, alignItems: 'center', justifyContent: 'center' },
  go: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center' },
});
