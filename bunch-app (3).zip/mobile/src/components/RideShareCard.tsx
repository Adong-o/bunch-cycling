import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import Svg, { Polyline } from 'react-native-svg';
import { StatBlock } from '@/components/ui/StatBlock';
import { formatDistance, formatDuration, formatElevation } from '@/lib/units';
import { colors, fonts, radius, spacing, type as typeTokens } from '@/theme';
import type { Ride, UnitSystem } from '@/lib/database.types';

interface Props {
  ride: Ride;
  ownerName: string;
  ownerAvatarUrl?: string | null;
  units: UnitSystem;
}

const CARD_WIDTH = 340;
const ROUTE_VIEW_W = 300;
const ROUTE_VIEW_H = 150;
const ROUTE_PADDING = 10;

/** Flattens a route into an SVG polyline "x,y x,y …" string, normalized into a fixed viewBox, preserving aspect ratio. North stays up. */
function buildRoutePoints(coordinates: Array<[number, number, number?]>): string | null {
  if (coordinates.length < 2) return null;

  let minLng = Infinity;
  let maxLng = -Infinity;
  let minLat = Infinity;
  let maxLat = -Infinity;
  for (const [lng, lat] of coordinates) {
    if (lng < minLng) minLng = lng;
    if (lng > maxLng) maxLng = lng;
    if (lat < minLat) minLat = lat;
    if (lat > maxLat) maxLat = lat;
  }

  const lngSpan = Math.max(maxLng - minLng, 0.0001);
  const latSpan = Math.max(maxLat - minLat, 0.0001);
  const scale = Math.min((ROUTE_VIEW_W - ROUTE_PADDING * 2) / lngSpan, (ROUTE_VIEW_H - ROUTE_PADDING * 2) / latSpan);

  // Center the (possibly non-square) route within the viewBox.
  const drawnW = lngSpan * scale;
  const drawnH = latSpan * scale;
  const offsetX = ROUTE_PADDING + (ROUTE_VIEW_W - ROUTE_PADDING * 2 - drawnW) / 2;
  const offsetY = ROUTE_PADDING + (ROUTE_VIEW_H - ROUTE_PADDING * 2 - drawnH) / 2;

  return coordinates
    .map(([lng, lat]) => {
      const x = offsetX + (lng - minLng) * scale;
      const y = ROUTE_VIEW_H - offsetY - (lat - minLat) * scale; // flip Y so north is up
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
}

/** Purely presentational — captured as a PNG by RideShareModal, never shown live on its own. */
export function RideShareCard({ ride, ownerName, units }: Props) {
  const routePoints = ride.route_geojson?.coordinates ? buildRoutePoints(ride.route_geojson.coordinates) : null;
  const dateLabel = new Date(ride.started_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <View style={styles.card}>
      <Image source={require('../../assets/wordmark_dark.png')} style={styles.wordmark} resizeMode="contain" />

      <Text style={styles.title} numberOfLines={2}>
        {ride.title}
      </Text>

      {routePoints ? (
        <View style={styles.routeWrap}>
          <Svg width={ROUTE_VIEW_W} height={ROUTE_VIEW_H} viewBox={`0 0 ${ROUTE_VIEW_W} ${ROUTE_VIEW_H}`}>
            <Polyline points={routePoints} fill="none" stroke={colors.accent} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
          </Svg>
        </View>
      ) : null}

      <View style={styles.statsRow}>
        <StatBlock label="DISTANCE" value={formatDistance(ride.distance_m, units)} align="center" style={styles.stat} />
        <StatBlock label="TIME" value={formatDuration(ride.moving_time_s, 'long')} align="center" style={styles.stat} />
        <StatBlock label="ELEVATION" value={formatElevation(ride.elevation_gain_m, units)} align="center" style={styles.stat} />
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          {ownerName} · {dateLabel}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.md,
  },
  wordmark: { width: 102, height: 24 },
  title: { ...typeTokens.h2, color: colors.textPrimary },
  routeWrap: { alignItems: 'center', backgroundColor: colors.surfaceHigh, borderRadius: radius.lg, paddingVertical: spacing.xs },
  statsRow: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm },
  stat: { flex: 1 },
  footer: { alignItems: 'center' },
  footerText: { fontFamily: fonts.medium, fontSize: 12, color: colors.textSecondary },
});
