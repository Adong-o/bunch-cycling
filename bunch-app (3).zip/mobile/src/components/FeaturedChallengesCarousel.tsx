import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Dimensions, FlatList, NativeScrollEvent, NativeSyntheticEvent, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ChallengeCoverArt, isChallengeCoverKey } from './ChallengeCoverArt';
import { useAuthStore } from '@/state/authStore';
import { listFeaturedChallenges, joinChallenge, myParticipation, formatChallengeValue, challengeTypeLabel } from '@/lib/api/challenges';
import { colors, fonts, radius, spacing } from '@/theme';
import type { Challenge } from '@/lib/database.types';

const SCREEN_WIDTH = Dimensions.get('window').width;
const H_PADDING = spacing.md;
const GAP = spacing.sm;
const CARD_WIDTH = SCREEN_WIDTH - H_PADDING * 2;
const SNAP_INTERVAL = CARD_WIDTH + GAP;
const AUTO_ADVANCE_MS = 3000;

interface Props {
  onOpenChallenge: (challengeId: string) => void;
}

/**
 * Admin-featured public challenges, shown above the ride feed: auto-advances
 * every 3s (and whenever someone manually swipes, the timer just restarts
 * from wherever they land — it never fights the gesture), each card shows
 * the challenge's cover art, description and goal, and "Join" works right
 * from the card without leaving the feed.
 */
export function FeaturedChallengesCarousel({ onOpenChallenge }: Props) {
  const profile = useAuthStore((s) => s.profile);
  const units = profile?.units ?? 'metric';

  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [joined, setJoined] = useState<Record<string, boolean>>({});
  const [joining, setJoining] = useState<Record<string, boolean>>({});
  const [index, setIndex] = useState(0);
  const listRef = useRef<FlatList<Challenge>>(null);
  const indexRef = useRef(0);

  useEffect(() => {
    listFeaturedChallenges()
      .then(setChallenges)
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!profile || challenges.length === 0) return;
    Promise.all(challenges.map((c) => myParticipation(c.id, profile.id)))
      .then((results) => {
        const next: Record<string, boolean> = {};
        results.forEach((p, i) => {
          if (p) next[challenges[i].id] = true;
        });
        setJoined(next);
      })
      .catch(() => {});
  }, [profile, challenges]);

  useEffect(() => {
    if (challenges.length < 2) return;
    const timer = setInterval(() => {
      const next = (indexRef.current + 1) % challenges.length;
      listRef.current?.scrollToOffset({ offset: next * SNAP_INTERVAL, animated: true });
      indexRef.current = next;
      setIndex(next);
    }, AUTO_ADVANCE_MS);
    return () => clearInterval(timer);
    // Restart the timer fresh any time the current index changes, whether
    // that came from the timer itself or a manual swipe.
  }, [challenges.length, index]);

  const onMomentumEnd = useCallback((e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const i = Math.round(e.nativeEvent.contentOffset.x / SNAP_INTERVAL);
    indexRef.current = i;
    setIndex(i);
  }, []);

  async function onQuickJoin(challenge: Challenge) {
    if (!profile || joined[challenge.id] || joining[challenge.id]) return;
    setJoining((p) => ({ ...p, [challenge.id]: true }));
    try {
      await joinChallenge(challenge.id, profile.id);
      setJoined((p) => ({ ...p, [challenge.id]: true }));
    } catch {
      // Swallow — they can still join from the full detail screen.
    } finally {
      setJoining((p) => ({ ...p, [challenge.id]: false }));
    }
  }

  if (challenges.length === 0) return null;

  return (
    <View style={styles.root}>
      <View style={styles.headerRow}>
        <Ionicons name="star" size={13} color={colors.gold} />
        <Text style={styles.headerLabel}>FEATURED CHALLENGES</Text>
      </View>

      <FlatList
        ref={listRef}
        data={challenges}
        keyExtractor={(c) => c.id}
        horizontal
        showsHorizontalScrollIndicator={false}
        snapToInterval={SNAP_INTERVAL}
        decelerationRate="fast"
        onMomentumScrollEnd={onMomentumEnd}
        contentContainerStyle={{ paddingHorizontal: H_PADDING }}
        renderItem={({ item }) => (
          <Pressable onPress={() => onOpenChallenge(item.id)} style={styles.card}>
            <ChallengeCoverArt
              coverKey={isChallengeCoverKey(item.cover_image_url) ? item.cover_image_url : 'sunrise-climb'}
              style={StyleSheet.absoluteFillObject}
            />
            <View style={styles.scrim} />
            <View style={styles.cardBody}>
              <View style={styles.cardTop}>
                <Text style={styles.cardTitle} numberOfLines={1}>
                  {item.title}
                </Text>
                {item.description ? (
                  <Text style={styles.cardDescription} numberOfLines={2}>
                    {item.description}
                  </Text>
                ) : null}
              </View>
              <View style={styles.cardFooter}>
                <Text style={styles.cardGoal}>
                  {challengeTypeLabel(item.type)} · {formatChallengeValue(item.type, item.goal_value, units)}
                </Text>
                <Pressable
                  onPress={() => onQuickJoin(item)}
                  disabled={joined[item.id] || joining[item.id]}
                  style={[styles.joinButton, joined[item.id] && styles.joinButtonDone]}
                  hitSlop={6}
                >
                  <Text style={styles.joinButtonLabel}>{joined[item.id] ? 'Joined ✓' : joining[item.id] ? 'Joining…' : 'Join'}</Text>
                </Pressable>
              </View>
            </View>
          </Pressable>
        )}
      />

      {challenges.length > 1 ? (
        <View style={styles.dotsRow}>
          {challenges.map((c, i) => (
            <View key={c.id} style={[styles.dot, i === index && styles.dotActive]} />
          ))}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  // Placed as FeedScreen's FlatList ListHeaderComponent, which already has
  // paddingHorizontal: spacing.md from its own contentContainerStyle — this
  // negative margin cancels that out so CARD_WIDTH's SCREEN_WIDTH math (and
  // the edge-peek effect of the next card) is correct again. Coupled to
  // FeedScreen's own H_PADDING by design, not a general-purpose default.
  root: { marginBottom: spacing.md, marginHorizontal: -H_PADDING },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: H_PADDING, marginBottom: spacing.xs },
  headerLabel: { fontFamily: fonts.semiBold, fontSize: 12, color: colors.textSecondary, letterSpacing: 0.5 },
  card: {
    width: CARD_WIDTH,
    marginRight: GAP,
    height: 168,
    borderRadius: radius.lg,
    overflow: 'hidden',
    justifyContent: 'flex-end',
    backgroundColor: colors.surfaceHigh,
  },
  scrim: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(10,10,16,0.32)' },
  cardBody: { padding: spacing.md, gap: spacing.sm },
  cardTop: { gap: 3 },
  cardTitle: { fontFamily: fonts.bold, fontSize: 18, color: '#FFFFFF' },
  cardDescription: { fontFamily: fonts.regular, fontSize: 12.5, lineHeight: 17, color: 'rgba(255,255,255,0.88)' },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardGoal: { fontFamily: fonts.semiBold, fontSize: 12.5, color: '#FFFFFF', flexShrink: 1 },
  joinButton: { backgroundColor: colors.accent, borderRadius: radius.pill, paddingHorizontal: 16, paddingVertical: 8 },
  joinButtonDone: { backgroundColor: 'rgba(255,255,255,0.22)' },
  joinButtonLabel: { fontFamily: fonts.semiBold, fontSize: 12.5, color: '#FFFFFF' },
  dotsRow: { flexDirection: 'row', justifyContent: 'center', gap: 5, marginTop: spacing.sm },
  dot: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.border },
  dotActive: { width: 14, backgroundColor: colors.accent },
});
