import React from 'react';
import Svg, { Circle, Path } from 'react-native-svg';

// A small set of hand-drawn icons for the places the app most wants to feel
// considered rather than assembled from a stock set: the three onboarding
// hero slides, and four of the five tab bar glyphs. Every path below is
// original geometry on a 24x24 grid — not a recolor or trace of an existing
// icon font. Kept deliberately small and dependency-free (just react-native-svg,
// already used by RideShareCard) rather than a whole custom icon framework.

const STROKE_WIDTH = 1.8;

interface HeroIconProps {
  size?: number;
  color?: string;
}

export interface TabIconProps extends HeroIconProps {
  focused?: boolean;
}

/** Onboarding slide 1 — "your phone already has everything": a gauge dial with a needle and two end ticks. */
export function SpeedometerIcon({ size = 40, color = '#111' }: HeroIconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M4.95 15.57 A7.5 7.5 0 1 1 19.05 15.57"
        stroke={color}
        strokeWidth={STROKE_WIDTH}
        strokeLinecap="round"
      />
      <Path d="M4.95 15.57 L6.36 15.05" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinecap="round" />
      <Path d="M19.05 15.57 L17.64 15.05" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinecap="round" />
      <Path d="M12 13 L15.15 8.49" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinecap="round" />
      <Circle cx={12} cy={13} r={1.3} fill={color} />
    </Svg>
  );
}

/** Onboarding slide 2 — "small targets, kept daily": a solid, slightly-leaning flame, not a symmetric teardrop. */
export function StreakIcon({ size = 40, color = '#111' }: HeroIconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M12 3 C13.5 6 17 9 17 13.5 C17 17.6 14.3 21 11.5 21 C8.2 21 6 18.3 6 15 C6 12.5 7.5 11 8.5 9.5 C8.3 11.5 9 12.5 10 12.5 C9.5 9.5 10.5 5.5 12 3 Z"
        fill={color}
      />
    </Svg>
  );
}

/** Onboarding slide 3 — "challenges you can actually win": a six-sided badge with a ribbon and a check, not a trophy. */
export function ChallengeIcon({ size = 40, color = '#111' }: HeroIconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M12 3 L5.94 6.5 L5.94 13.5 L12 17 L18.06 13.5 L18.06 6.5 Z"
        stroke={color}
        strokeWidth={STROKE_WIDTH}
        strokeLinejoin="round"
      />
      <Path d="M9.5 15.5 L8 22 L11 19.5 Z" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinejoin="round" />
      <Path d="M14.5 15.5 L16 22 L13 19.5 Z" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinejoin="round" />
      <Path d="M9 10.3 L11 12.3 L15.5 7.3" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

/** Tab bar — Feed: a house with an eave that overhangs the walls, rather than a plain pentagon. */
export function HomeTabIcon({ size = 24, color = '#111', focused }: TabIconProps) {
  const house = 'M12 4 L20 11.5 L17.5 11 L17.5 20 L6.5 20 L6.5 11 L4 11.5 Z';
  if (focused) {
    return (
      <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
        <Path d={house} fill={color} />
      </Svg>
    );
  }
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d={house} stroke={color} strokeWidth={STROKE_WIDTH} strokeLinejoin="round" strokeLinecap="round" />
      <Path d="M10.5 20 L10.5 15.5 L13.5 15.5 L13.5 20" stroke={color} strokeWidth={STROKE_WIDTH} strokeLinejoin="round" />
    </Svg>
  );
}

/** Tab bar — Record: a ring with a dot (the universal "record" glyph); bolder when its tab is active. */
export function RecordTabIcon({ size = 24, color = '#111', focused }: TabIconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={12} r={8.4} stroke={color} strokeWidth={focused ? 2.3 : STROKE_WIDTH} />
      <Circle cx={12} cy={12} r={focused ? 4.7 : 3.9} fill={color} />
    </Svg>
  );
}

/** Tab bar — Challenges: a shield with a four-point sparkle, not a trophy. */
export function ChallengesTabIcon({ size = 24, color = '#111', focused }: TabIconProps) {
  const shield = 'M6 4 L18 4 L18 11 C18 16 15.5 19.5 12 21 C8.5 19.5 6 16 6 11 Z';
  if (focused) {
    return (
      <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
        <Path d={shield} fill={color} />
      </Svg>
    );
  }
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d={shield} stroke={color} strokeWidth={STROKE_WIDTH} strokeLinejoin="round" />
      <Path
        d="M12 7.5 C12.3 9.5 12.5 10.7 14.5 11 C12.5 11.3 12.3 12.5 12 14.5 C11.7 12.5 11.5 11.3 9.5 11 C11.5 10.7 11.7 9.5 12 7.5 Z"
        stroke={color}
        strokeWidth={STROKE_WIDTH}
        strokeLinejoin="round"
      />
    </Svg>
  );
}

/** Tab bar — Routes: a winding route line between two waypoints, not a flat pin-on-a-map. */
export function RoutesTabIcon({ size = 24, color = '#111', focused }: TabIconProps) {
  const path = 'M5 19 C5 13 11 15 11 11 C11 7 17 9 17 5';
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path d={path} stroke={color} strokeWidth={focused ? STROKE_WIDTH * 1.4 : STROKE_WIDTH} strokeLinecap="round" />
      {focused ? (
        <>
          <Circle cx={5} cy={19} r={2.1} fill={color} />
          <Circle cx={17} cy={5} r={2.1} fill={color} />
        </>
      ) : (
        <>
          <Circle cx={5} cy={19} r={1.9} stroke={color} strokeWidth={STROKE_WIDTH} />
          <Circle cx={17} cy={5} r={1.9} stroke={color} strokeWidth={STROKE_WIDTH} />
        </>
      )}
    </Svg>
  );
}

/** Tab bar — Profile: a ring with the person's shoulders left open at the edge, instead of a tightly-cropped bust. */
export function ProfileTabIcon({ size = 24, color = '#111', focused }: TabIconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Circle cx={12} cy={12} r={8.3} stroke={color} strokeWidth={STROKE_WIDTH} />
      {focused ? (
        <>
          <Circle cx={12} cy={9.3} r={2.6} fill={color} />
          <Path d="M6.8 18.3 C6.8 14.6 9.1 12.6 12 12.6 C14.9 12.6 17.2 14.6 17.2 18.3 Z" fill={color} />
        </>
      ) : (
        <>
          <Circle cx={12} cy={9.3} r={2.6} stroke={color} strokeWidth={STROKE_WIDTH} />
          <Path
            d="M6.8 17.5 C7.6 14.3 9.6 12.8 12 12.8 C14.4 12.8 16.4 14.3 17.2 17.5"
            stroke={color}
            strokeWidth={STROKE_WIDTH}
            strokeLinecap="round"
          />
        </>
      )}
    </Svg>
  );
}
