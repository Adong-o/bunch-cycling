import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { format } from 'date-fns';
import { ChallengeCoverArt, isChallengeCoverKey } from '@/components/ChallengeCoverArt';
import { challengeTypeLabel, formatChallengeValue } from '@/lib/api/challenges';
import { colors, fonts, radius, shadow, spacing } from '@/theme';
import type { Challenge, UnitSystem } from '@/lib/database.types';

interface Props {
  challenge: Challenge;
  units: UnitSystem;
  onPress: () => void;
  /** Shown on the Popular tab; omit to hide the button. */
  joined?: boolean;
  joining?: boolean;
  onJoin?: () => void;
}

/** Cover-art challenge card used by the Home Challenges and Popular tabs. */
export function ChallengeRow({ challenge, units, onPress, joined, joining, onJoin }: Props) {
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.cover}>
        <ChallengeCoverArt
          coverKey={isChallengeCoverKey(challenge.cover_image_url) ? challenge.cover_image_url : 'sunrise-climb'}
          style={StyleSheet.absoluteFillObject}
        />
        {challenge.is_official ? (
          <View style={styles.badge}>
            <Text style={styles.badgeLabel}>OFFICIAL</Text>
          </View>
        ) : null}
      </View>
      <View style={styles.body}>
        <View style={styles.textCol}>
          <Text style={styles.title} numberOfLines={1}>
            {challenge.title}
          </Text>
          <Text style={styles.meta} numberOfLines={1}>
            {challengeTypeLabel(challenge.type)} · {formatChallengeValue(challenge.type, challenge.goal_value, units)}
          </Text>
          <Text style={styles.meta} numberOfLines={1}>
            Ends {format(new Date(`${challenge.end_date}T00:00:00`), 'd MMM yyyy')}
          </Text>
        </View>
        {onJoin ? (
          <Pressable onPress={onJoin} disabled={joined || joining} style={[styles.joinButton, joined && styles.joinDone]} hitSlop={6}>
            <Text style={[styles.joinLabel, joined && styles.joinLabelDone]}>{joined ? 'Joined' : joining ? 'Joining…' : 'Join'}</Text>
          </Pressable>
        ) : null}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, overflow: 'hidden', ...shadow.card },
  cover: { height: 110, backgroundColor: colors.surfaceHigh },
  badge: { position: 'absolute', top: spacing.xs, left: spacing.xs, backgroundColor: colors.ink, borderRadius: radius.pill, paddingHorizontal: 8, paddingVertical: 3 },
  badgeLabel: { fontFamily: fonts.bold, fontSize: 10, letterSpacing: 0.6, color: colors.textOnAccent },
  body: { flexDirection: 'row', alignItems: 'center', padding: spacing.md, gap: spacing.sm },
  textCol: { flex: 1 },
  title: { fontFamily: fonts.bold, fontSize: 16, color: colors.textPrimary },
  meta: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSecondary, marginTop: 2 },
  joinButton: { backgroundColor: colors.accent, borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 9 },
  joinDone: { backgroundColor: colors.accentMuted },
  joinLabel: { fontFamily: fonts.semiBold, fontSize: 13, color: colors.textOnAccent },
  joinLabelDone: { color: colors.accent },
});
