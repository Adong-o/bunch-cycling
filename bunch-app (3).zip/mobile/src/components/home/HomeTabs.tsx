import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, fonts, spacing } from '@/theme';

export type HomeTabKey = 'explore' | 'challenges' | 'popular';

const TABS: Array<{ key: HomeTabKey; label: string }> = [
  { key: 'explore', label: 'Explore' },
  { key: 'challenges', label: 'Challenges' },
  { key: 'popular', label: 'Popular' },
];

/** Underline tab strip under the Home title (Explore / Challenges / Popular). */
export function HomeTabs({ value, onChange }: { value: HomeTabKey; onChange: (key: HomeTabKey) => void }) {
  return (
    <View style={styles.row}>
      {TABS.map((t) => {
        const active = t.key === value;
        return (
          <Pressable key={t.key} onPress={() => onChange(t.key)} style={styles.tab} accessibilityRole="tab" accessibilityState={{ selected: active }}>
            <Text style={[styles.label, active && styles.labelActive]}>{t.label}</Text>
            <View style={[styles.underline, active && styles.underlineActive]} />
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', paddingHorizontal: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, gap: spacing.lg },
  tab: { paddingTop: spacing.xs, alignItems: 'center' },
  label: { fontFamily: fonts.semiBold, fontSize: 15, color: colors.textTertiary, paddingBottom: spacing.xs },
  labelActive: { color: colors.textPrimary },
  underline: { height: 3, alignSelf: 'stretch', borderRadius: 2, backgroundColor: 'transparent' },
  underlineActive: { backgroundColor: colors.accent },
});
