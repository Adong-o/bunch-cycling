import React, { useMemo } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { RideMap } from '@/components/RideMap';
import { Avatar } from '@/components/ui/Avatar';
import { StatBlock } from '@/components/ui/StatBlock';
import { formatRideTimestamp } from '@/lib/dateFormat';
import { boundingBox, geoJSONToCoordinates } from '@/lib/geo';
import { formatDistance, formatDuration, formatElevation, formatSpeed } from '@/lib/units';
import { colors, fonts, spacing } from '@/theme';
import type { Ride, Profile, UnitSystem } from '@/lib/database.types';

interface Props {
  ride: Ride;
  owner?: Profile | null;
  companions?: Profile[];
  units: UnitSystem;
  kudosCount?: number;
  kudosByMe?: boolean;
  onPress: () => void;
  onPressOwner?: () => void;
  onToggleKudos?: () => void;
  onPressComments?: () => void;
  onShare?: () => void;
}

// "Jane took a ride" vs. "went for a ride" vs. an indoor/imported ride —
// mirrors how the activity actually happened (ride.is_indoor / ride.source)
// rather than always saying the same generic thing.
function activityVerb(ride: Ride): string {
  if (ride.is_indoor) return 'rode indoors';
  if (ride.source === 'import') return 'added a ride';
  if (ride.source === 'manual') return 'logged a ride';
  return 'went for a bike ride';
}

function companionsSuffix(companions: Profile[]): string {
  if (companions.length === 0) return '';
  const names = companions.map((c) => c.display_name || c.username);
  if (names.length <= 2) return ` with ${names.join(' and ')}`;
  return ` with ${names[0]}, ${names[1]} +${names.length - 2} more`;
}

/**
 * Feed card layout, top to bottom, matches how riders actually read an
 * activity (Strava/Komoot convention): who + what they did (with who, if
 * tagged) -> when + where -> what they called it -> the numbers, in the
 * order a rider checks them (time, distance, speed, elevation) -> a photo,
 * if they took one. Tapping anywhere opens the full ride.
 */
export function RideCard({ ride, owner, companions = [], units, kudosCount = 0, kudosByMe = false, onPress, onPressOwner, onToggleKudos, onPressComments, onShare }: Props) {
  const coverPhoto = ride.photo_urls?.[0];
  const routeCoords = useMemo(() => geoJSONToCoordinates(ride.route_geojson), [ride.route_geojson]);
  const bounds = useMemo(() => boundingBox(ride.route_geojson), [ride.route_geojson]);

  return (
    <Card padded={false} style={styles.card}>
      <Pressable onPress={onPress}>
        <View style={styles.header}>
          <Pressable onPress={onPressOwner} disabled={!onPressOwner} hitSlop={6}>
            <Avatar uri={owner?.avatar_url} name={owner?.display_name ?? '?'} size={38} />
          </Pressable>
          <View style={styles.headerText}>
            <Text style={styles.activityLine} numberOfLines={2}>
              <Text onPress={onPressOwner} style={styles.ownerName}>
                {owner?.display_name ?? 'A rider'}
              </Text>
              <Text style={styles.verbText}>
                {' '}
                {activityVerb(ride)}
                {companionsSuffix(companions)}
              </Text>
            </Text>
            <Text style={styles.timestamp} numberOfLines={1}>
              {formatRideTimestamp(ride.started_at)}
              {ride.start_location_name ? ` · ${ride.start_location_name}` : ''}
            </Text>
          </View>
        </View>

        <Text style={styles.title}>{ride.title}</Text>

        <View style={styles.statsRow}>
          <StatBlock label="Time" value={formatDuration(ride.moving_time_s)} />
          <StatBlock label="Distance" value={formatDistance(ride.distance_m, units)} />
          <StatBlock label="Speed" value={formatSpeed(ride.avg_speed_mps, units)} />
          <StatBlock label="Elevation" value={formatElevation(ride.elevation_gain_m, units)} />
        </View>

        {routeCoords.length > 1 ? (
          <View style={styles.mapWrap} pointerEvents="none">
            <RideMap routeCoordinates={routeCoords} bounds={bounds} interactive={false} style={StyleSheet.absoluteFill} />
          </View>
        ) : coverPhoto ? (
          <Image source={{ uri: coverPhoto }} style={styles.photo} />
        ) : null}
      </Pressable>

      <View style={styles.footer}>
        <Pressable onPress={onToggleKudos} disabled={!onToggleKudos} style={styles.footerAction} hitSlop={8}>
          <Ionicons name={kudosByMe ? 'heart' : 'heart-outline'} size={18} color={kudosByMe ? colors.danger : colors.textSecondary} />
          <Text style={[styles.footerActionLabel, kudosByMe && { color: colors.danger }]}>{kudosCount > 0 ? kudosCount : 'Kudos'}</Text>
        </Pressable>
        <Pressable onPress={onPressComments ?? onPress} style={styles.footerAction} hitSlop={8}>
          <Ionicons name="chatbubble-outline" size={17} color={colors.textSecondary} />
          <Text style={styles.footerActionLabel}>Comment</Text>
        </Pressable>
        {onShare ? (
          <Pressable onPress={onShare} style={[styles.footerAction, styles.footerRight]} hitSlop={8} accessibilityLabel="Share ride">
            <Ionicons name="share-outline" size={19} color={colors.textSecondary} />
          </Pressable>
        ) : null}
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: { overflow: 'hidden' },
  header: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.xs, padding: spacing.md, paddingBottom: spacing.xs },
  headerText: { flex: 1 },
  activityLine: { lineHeight: 19 },
  ownerName: { fontFamily: fonts.semiBold, fontSize: 14, color: colors.textPrimary },
  verbText: { fontFamily: fonts.regular, fontSize: 14, color: colors.textSecondary },
  timestamp: { fontFamily: fonts.regular, fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  title: { fontFamily: fonts.bold, fontSize: 17, color: colors.textPrimary, paddingHorizontal: spacing.md, marginTop: 2 },
  mapWrap: { height: 170, marginTop: spacing.sm, backgroundColor: colors.surfaceHigh },
  footerRight: { marginLeft: 'auto' },
  photo: { width: '100%', height: 160, marginTop: spacing.sm, backgroundColor: colors.surfaceHigh },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    marginTop: spacing.sm,
    paddingBottom: 2,
  },
  footer: {
    flexDirection: 'row',
    gap: spacing.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  footerAction: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  footerActionLabel: { fontFamily: fonts.medium, fontSize: 13, color: colors.textSecondary },
});
