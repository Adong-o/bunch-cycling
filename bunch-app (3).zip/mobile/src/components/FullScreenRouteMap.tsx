import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Camera, CircleLayer, LineLayer, MapView, ShapeSource } from '@maplibre/maplibre-react-native';
import { MapAttribution } from '@/components/map/MapAttribution';
import { colors, fonts, shadow, spacing } from '@/theme';

const STYLES = {
  liberty: 'https://tiles.openfreemap.org/styles/liberty',
  positron: 'https://tiles.openfreemap.org/styles/positron',
} as const;

interface Props {
  visible: boolean;
  onClose: () => void;
  title?: string;
  routeCoordinates: Array<[number, number]>;
  /** [minLng, minLat, maxLng, maxLat] */
  bounds: [number, number, number, number] | null;
}

/**
 * A full-screen, fully explorable map of a route: pinch, drag, rotate, plus
 * zoom buttons, a "fit the whole route" button and a map-style toggle. Maps
 * embedded in scrolling screens can't be zoomed reliably (the scroll view
 * steals the gesture), so those show a preview and open this on tap.
 */
export function FullScreenRouteMap({ visible, onClose, title, routeCoordinates, bounds }: Props) {
  const insets = useSafeAreaInsets();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cameraRef = useRef<any>(null);
  const zoomRef = useRef(12);
  const [ready, setReady] = useState(false);
  const [style, setStyle] = useState<keyof typeof STYLES>('liberty');

  function fit(duration = 600) {
    if (!bounds) return;
    const [minLng, minLat, maxLng, maxLat] = bounds;
    if (minLng === maxLng && minLat === maxLat) {
      cameraRef.current?.setCamera({ centerCoordinate: [minLng, minLat], zoomLevel: 15, animationDuration: duration });
      return;
    }
    cameraRef.current?.fitBounds([maxLng, maxLat], [minLng, minLat], [insets.top + 80, 56, insets.bottom + 56, 56], duration);
  }

  useEffect(() => {
    if (visible && ready) fit(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, ready]);

  useEffect(() => {
    if (!visible) setReady(false);
  }, [visible]);

  function zoomBy(delta: number) {
    const next = Math.min(19.5, Math.max(2, zoomRef.current + delta));
    zoomRef.current = next;
    cameraRef.current?.setCamera({ zoomLevel: next, animationDuration: 250, animationMode: 'easeTo' });
  }

  const line = useMemo(
    () => (routeCoordinates.length > 1 ? { type: 'Feature' as const, properties: {}, geometry: { type: 'LineString' as const, coordinates: routeCoordinates } } : null),
    [routeCoordinates]
  );
  const ends = useMemo(() => {
    if (routeCoordinates.length < 2) return null;
    return {
      type: 'FeatureCollection' as const,
      features: [
        { type: 'Feature' as const, properties: { kind: 'start' }, geometry: { type: 'Point' as const, coordinates: routeCoordinates[0] } },
        { type: 'Feature' as const, properties: { kind: 'end' }, geometry: { type: 'Point' as const, coordinates: routeCoordinates[routeCoordinates.length - 1] } },
      ],
    };
  }, [routeCoordinates]);

  const center = bounds ? ([(bounds[0] + bounds[2]) / 2, (bounds[1] + bounds[3]) / 2] as [number, number]) : undefined;

  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <View style={styles.root}>
        <MapView
          style={StyleSheet.absoluteFill}
          mapStyle={STYLES[style]}
          logoEnabled={false}
          attributionEnabled={false}
          compassEnabled
          scrollEnabled
          zoomEnabled
          rotateEnabled
          pitchEnabled={false}
          onDidFinishLoadingMap={() => setReady(true)}
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          onRegionDidChange={(f: any) => {
            const z = f?.properties?.zoomLevel;
            if (typeof z === 'number') zoomRef.current = z;
          }}
        >
          <Camera ref={cameraRef} defaultSettings={center ? { centerCoordinate: center, zoomLevel: 12 } : undefined} />
          {line ? (
            <ShapeSource id="fsRouteSource" shape={line}>
              <LineLayer id="fsRouteCasing" style={{ lineColor: '#FFFFFF', lineWidth: 9, lineCap: 'round', lineJoin: 'round', lineOpacity: 0.95 }} />
              <LineLayer id="fsRouteLine" style={{ lineColor: colors.accent, lineWidth: 5.5, lineCap: 'round', lineJoin: 'round' }} />
            </ShapeSource>
          ) : null}
          {ends ? (
            <ShapeSource id="fsEndsSource" shape={ends}>
              <CircleLayer
                id="fsEnds"
                style={{
                  circleRadius: 8,
                  circleColor: ['match', ['get', 'kind'], 'start', colors.success, colors.danger],
                  circleStrokeColor: '#FFFFFF',
                  circleStrokeWidth: 3,
                }}
              />
            </ShapeSource>
          ) : null}
        </MapView>

        <View style={[styles.top, { paddingTop: insets.top + spacing.xs }]} pointerEvents="box-none">
          <Pressable onPress={onClose} style={styles.round} accessibilityLabel="Close map" hitSlop={6}>
            <Ionicons name="close" size={24} color={colors.textPrimary} />
          </Pressable>
          {title ? (
            <View style={styles.titlePill}>
              <Text style={styles.titleText} numberOfLines={1}>
                {title}
              </Text>
            </View>
          ) : (
            <View style={{ flex: 1 }} />
          )}
          <Pressable onPress={() => setStyle((s) => (s === 'liberty' ? 'positron' : 'liberty'))} style={styles.round} accessibilityLabel="Change map style" hitSlop={6}>
            <Ionicons name={style === 'liberty' ? 'layers-outline' : 'layers'} size={22} color={colors.textPrimary} />
          </Pressable>
        </View>

        <View style={[styles.controls, { bottom: insets.bottom + spacing.lg }]}>
          <Pressable onPress={() => fit()} style={styles.round} accessibilityLabel="Fit the whole route" hitSlop={6}>
            <Ionicons name="scan-outline" size={22} color={colors.textPrimary} />
          </Pressable>
          <View style={styles.zoomPill}>
            <Pressable onPress={() => zoomBy(1)} style={styles.zoomHalf} accessibilityLabel="Zoom in" hitSlop={4}>
              <Ionicons name="add" size={26} color={colors.textPrimary} />
            </Pressable>
            <View style={styles.zoomDivider} />
            <Pressable onPress={() => zoomBy(-1)} style={styles.zoomHalf} accessibilityLabel="Zoom out" hitSlop={4}>
              <Ionicons name="remove" size={26} color={colors.textPrimary} />
            </Pressable>
          </View>
        </View>

        <MapAttribution style={{ bottom: insets.bottom + 6 }} />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#E9EAEC' },
  top: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', gap: spacing.xs, paddingHorizontal: spacing.md },
  round: { width: 46, height: 46, borderRadius: 23, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', ...shadow.card },
  titlePill: { flex: 1, height: 46, borderRadius: 23, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.md, ...shadow.card },
  titleText: { fontFamily: fonts.bold, fontSize: 15, color: colors.textPrimary },
  controls: { position: 'absolute', right: spacing.md, gap: 10, alignItems: 'center' },
  zoomPill: { width: 46, borderRadius: 23, backgroundColor: colors.surface, ...shadow.card },
  zoomHalf: { height: 46, alignItems: 'center', justifyContent: 'center' },
  zoomDivider: { height: StyleSheet.hairlineWidth, marginHorizontal: 10, backgroundColor: colors.borderStrong },
});
