import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
// Named imports on purpose — the package's default-export namespace
// (`import MapLibreGL from ...` then `MapLibreGL.MapView`) still works in
// v10 but is documented as deprecated there.
import { Ionicons } from '@expo/vector-icons';
import { Camera, CircleLayer, LineLayer, MapView, ShapeSource, UserLocation } from '@maplibre/maplibre-react-native';
import { FullScreenRouteMap } from '@/components/FullScreenRouteMap';
import { MapAttribution } from '@/components/map/MapAttribution';
import { colors, radius } from '@/theme';

// Free, no-API-key vector tiles. Required attribution is rendered below as
// our own overlay (attributionEnabled={false} on the map) so it's correct
// and visible regardless of how a given library version renders the style's
// own attribution metadata.
const STYLE_URL = 'https://tiles.openfreemap.org/styles/liberty';

interface Props {
  /** [lng, lat] pairs — the recorded or saved route to draw as a line. */
  routeCoordinates?: Array<[number, number]>;
  /** Camera follows the device's live position (recording / pre-ride states). */
  followUser?: boolean;
  /** [minLng, minLat, maxLng, maxLat] to fit the camera to when not following the user (e.g. a finished ride). */
  bounds?: [number, number, number, number] | null;
  interactive?: boolean;
  /**
   * Shows a small preview map that opens a full-screen, fully explorable map
   * on tap. Use this (instead of `interactive`) for any map that sits inside
   * a scrolling screen — a scroll view steals pinch/drag gestures from an
   * embedded map, which is why those maps could never be zoomed.
   */
  expandable?: boolean;
  /** Title shown on the full-screen map. */
  expandTitle?: string;
  /** Show the rider's own live position dot (only meaningful on live maps). */
  showUser?: boolean;
  /** Mark where the route starts (green) and finishes (red) — for a route you are about to ride, not for list thumbnails. */
  showEndpoints?: boolean;
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
}

export function RideMap({ routeCoordinates, followUser = false, bounds, interactive = true, expandable = false, expandTitle, showUser = false, showEndpoints = false, style, children }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [width, setWidth] = useState(0);
  // An expandable map is a preview: gestures belong to the full-screen view.
  const live = interactive && !expandable;
  // Untyped on purpose: this library's own TS defs can't be verified against
  // an installed copy in this environment (no npm registry access here — see
  // the README), so a hand-rolled type here would just be a second guess.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const cameraRef = useRef<any>(null);
  // Was: a plain mount-time useEffect calling cameraRef.current?.fitBounds(...).
  // On a fresh mount the native map view frequently isn't ready yet — the
  // optional-chained call silently no-ops against a null ref — so the camera
  // was left at MapLibre's own built-in default (zoom level 0, centered on
  // [0, 0]), which renders as a wide view of the Gulf of Guinea off the West
  // African coast ("the map of Africa"). Gating the imperative fit on the
  // map's own onDidFinishLoadingMap event (rather than on mount) makes sure
  // the native camera command only fires once it can actually take it.
  const [mapReady, setMapReady] = useState(false);

  useEffect(() => {
    if (followUser || !bounds || !mapReady) return;
    const [minLng, minLat, maxLng, maxLat] = bounds;
    // Single-point "route" (e.g. a very short ride) — just center on it.
    if (minLng === maxLng && minLat === maxLat) {
      cameraRef.current?.setCamera({ centerCoordinate: [minLng, minLat], zoomLevel: 14, animationDuration: 400 });
      return;
    }
    cameraRef.current?.fitBounds([maxLng, maxLat], [minLng, minLat], 56, 500);
  }, [followUser, bounds, mapReady]);

  // Belt-and-braces default for the sliver of time before onDidFinishLoadingMap
  // fires: center on the route's own midpoint (never [0, 0]) at a reasonable
  // zoom, computed straight from the same bounds, so there's no frame where
  // an unrelated default camera is visible even briefly.
  const fallbackCenter = !followUser && bounds ? ([(bounds[0] + bounds[2]) / 2, (bounds[1] + bounds[3]) / 2] as [number, number]) : undefined;

  const routeGeoJSON =
    routeCoordinates && routeCoordinates.length > 1
      ? {
          type: 'Feature' as const,
          properties: {},
          geometry: { type: 'LineString' as const, coordinates: routeCoordinates },
        }
      : null;

  const endpoints =
    showEndpoints && routeCoordinates && routeCoordinates.length > 1
      ? {
          type: 'FeatureCollection' as const,
          features: [
            { type: 'Feature' as const, properties: { kind: 'start' }, geometry: { type: 'Point' as const, coordinates: routeCoordinates[0] } },
            { type: 'Feature' as const, properties: { kind: 'end' }, geometry: { type: 'Point' as const, coordinates: routeCoordinates[routeCoordinates.length - 1] } },
          ],
        }
      : null;

  return (
    <View style={[styles.root, style]} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
      <MapView
        style={styles.map}
        mapStyle={STYLE_URL}
        logoEnabled={false}
        attributionEnabled={false}
        compassEnabled={live}
        scrollEnabled={live}
        zoomEnabled={live}
        rotateEnabled={live}
        pitchEnabled={false}
        onDidFinishLoadingMap={() => setMapReady(true)}
      >
        <Camera
          ref={cameraRef}
          defaultSettings={fallbackCenter ? { centerCoordinate: fallbackCenter, zoomLevel: 11 } : undefined}
          followUserLocation={followUser}
          followUserMode="normal"
          followZoomLevel={16.5}
          animationMode="flyTo"
          animationDuration={600}
        />
        {showUser || followUser ? <UserLocation visible showsUserHeadingIndicator /> : null}
        {routeGeoJSON ? (
          <ShapeSource id="rideRouteSource" shape={routeGeoJSON}>
            <LineLayer
              id="rideRouteLine"
              style={{ lineColor: colors.accent, lineWidth: 4, lineCap: 'round', lineJoin: 'round' }}
            />
          </ShapeSource>
        ) : null}
        {endpoints ? (
          <ShapeSource id="rideRouteEnds" shape={endpoints}>
            <CircleLayer
              id="rideRouteEndDots"
              style={{
                circleRadius: 6.5,
                circleColor: ['match', ['get', 'kind'], 'start', colors.success, colors.danger],
                circleStrokeColor: '#FFFFFF',
                circleStrokeWidth: 2.5,
              }}
            />
          </ShapeSource>
        ) : null}
        {children}
      </MapView>

      <MapAttribution compact={width > 0 && width < 220} />

      {expandable ? (
        <>
          {/* Whole preview is one big tap target; the badge just says what it does. */}
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setExpanded(true)} accessibilityRole="button" accessibilityLabel="Open full-screen map" />
          <View style={styles.expandBadge} pointerEvents="none">
            <Ionicons name="expand" size={16} color={colors.textPrimary} />
          </View>
          <FullScreenRouteMap visible={expanded} onClose={() => setExpanded(false)} title={expandTitle} routeCoordinates={routeCoordinates ?? []} bounds={bounds ?? null} />
        </>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { overflow: 'hidden', borderRadius: radius.lg, backgroundColor: colors.surface },
  map: { flex: 1 },
  expandBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
