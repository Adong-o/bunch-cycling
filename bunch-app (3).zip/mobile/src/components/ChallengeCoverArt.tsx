import React from 'react';
import { StyleSheet, View, ViewStyle, StyleProp } from 'react-native';
import Svg, { Circle, Defs, LinearGradient, Path, Polygon, Stop } from 'react-native-svg';

// A small set of original, code-drawn challenge covers — the "stock photos"
// a challenge creator picks from. Deliberately illustrated rather than real
// hotlinked photos: no external host to go down or rate-limit, nothing to
// attribute, and it stays visually consistent with the rest of the app's
// hand-drawn marks (GravelBikeIllustration, the tab icons, the app icon
// itself). `cover_image_url` stores the key below, not a URL — still a plain
// text column, just repurposed; ChallengeDetailScreen and ChallengeRow treat
// an unrecognized value as a legacy real URL and fall back to <Image>.

export interface ChallengeCoverOption {
  key: string;
  label: string;
}

export const CHALLENGE_COVERS: ChallengeCoverOption[] = [
  { key: 'sunrise-climb', label: 'Sunrise Climb' },
  { key: 'night-ride', label: 'Night Ride' },
  { key: 'gravel-grind', label: 'Gravel Grind' },
  { key: 'coastal-loop', label: 'Coastal Loop' },
  { key: 'city-sprint', label: 'City Sprint' },
  { key: 'forest-trail', label: 'Forest Trail' },
];

const COVER_KEYS = new Set(CHALLENGE_COVERS.map((c) => c.key));
export function isChallengeCoverKey(value: string | null | undefined): value is string {
  return !!value && COVER_KEYS.has(value);
}

interface Props {
  coverKey: string;
  style?: StyleProp<ViewStyle>;
}

export function ChallengeCoverArt({ coverKey, style }: Props) {
  return (
    <View style={[styles.root, style]}>
      <Svg width="100%" height="100%" viewBox="0 0 400 240" preserveAspectRatio="xMidYMid slice">
        {renderCover(coverKey)}
      </Svg>
    </View>
  );
}

function renderCover(key: string) {
  switch (key) {
    case 'sunrise-climb':
      return (
        <>
          <Defs>
            <LinearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#FFB199" />
              <Stop offset="1" stopColor="#E8533F" />
            </LinearGradient>
          </Defs>
          <Polygon points="0,240 400,240 400,0 0,0" fill="url(#g)" />
          <Circle cx={300} cy={70} r={34} fill="#FFE9B0" opacity={0.9} />
          <Polygon points="0,240 120,110 190,180 260,90 400,240" fill="#B23A2C" opacity={0.85} />
          <Polygon points="0,240 90,160 170,220 230,150 400,240" fill="#8E2A20" />
        </>
      );
    case 'night-ride':
      return (
        <>
          <Defs>
            <LinearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#262A52" />
              <Stop offset="1" stopColor="#13152C" />
            </LinearGradient>
          </Defs>
          <Polygon points="0,240 400,240 400,0 0,0" fill="url(#g)" />
          {[[40, 40], [90, 80], [140, 35], [230, 60], [300, 30], [350, 70], [190, 100], [60, 120]].map(([x, y], i) => (
            <Circle key={i} cx={x} cy={y} r={i % 2 === 0 ? 2.2 : 1.4} fill="#FAFAF8" opacity={0.8} />
          ))}
          <Circle cx={330} cy={60} r={22} fill="#F4EFD8" opacity={0.95} />
          <Circle cx={100} cy={176} r={34} fill="none" stroke="#4D47FC" strokeWidth={6} opacity={0.9} />
          <Circle cx={220} cy={190} r={40} fill="none" stroke="#4D47FC" strokeWidth={6} opacity={0.9} />
          <Path d="M100 176 L150 110 L220 190" stroke="#FAFAF8" strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />
        </>
      );
    case 'gravel-grind':
      return (
        <>
          <Defs>
            <LinearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#D8B892" />
              <Stop offset="1" stopColor="#9C7349" />
            </LinearGradient>
          </Defs>
          <Polygon points="0,240 400,240 400,0 0,0" fill="url(#g)" />
          <Path d="M-20 170 C 80 150, 140 190, 240 160 S 400 150, 440 170" stroke="#7A5634" strokeWidth={10} fill="none" opacity={0.5} strokeLinecap="round" />
          <Path d="M-20 205 C 90 190, 160 225, 260 200 S 420 195, 450 210" stroke="#6B4A2A" strokeWidth={14} fill="none" opacity={0.6} strokeLinecap="round" />
          {Array.from({ length: 14 }).map((_, i) => (
            <Circle key={i} cx={20 + i * 29} cy={60 + ((i * 37) % 70)} r={2.4} fill="#6B4A2A" opacity={0.5} />
          ))}
        </>
      );
    case 'coastal-loop':
      return (
        <>
          <Defs>
            <LinearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#8FD3E8" />
              <Stop offset="1" stopColor="#1C7FA8" />
            </LinearGradient>
          </Defs>
          <Polygon points="0,240 400,240 400,0 0,0" fill="url(#g)" />
          <Circle cx={60} cy={56} r={26} fill="#FFF7DE" opacity={0.9} />
          <Path d="M-20 150 C 60 130, 120 170, 200 150 S 340 130, 420 150" stroke="#F4FBFD" strokeWidth={6} fill="none" opacity={0.55} strokeLinecap="round" />
          <Path d="M-20 185 C 70 165, 140 205, 220 185 S 350 165, 430 190" stroke="#0E5E7E" strokeWidth={10} fill="none" opacity={0.6} strokeLinecap="round" />
          <Path d="M-20 220 C 80 200, 160 235, 260 215 S 380 205, 430 225" stroke="#0E5E7E" strokeWidth={16} fill="none" opacity={0.8} strokeLinecap="round" />
        </>
      );
    case 'city-sprint':
      return (
        <>
          <Defs>
            <LinearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#8D7BE0" />
              <Stop offset="1" stopColor="#4B3B96" />
            </LinearGradient>
          </Defs>
          <Polygon points="0,240 400,240 400,0 0,0" fill="url(#g)" />
          {[
            [0, 120, 46],
            [50, 90, 36],
            [92, 140, 58],
            [156, 70, 30],
            [192, 110, 50],
            [248, 95, 40],
            [294, 150, 64],
            [364, 80, 36],
          ].map(([x, y, w], i) => (
            <Polygon key={i} points={`${x},240 ${x},${y} ${x + w},${y} ${x + w},240`} fill="#2C2065" opacity={0.75} />
          ))}
          <Circle cx={330} cy={50} r={16} fill="#FFE9B0" opacity={0.9} />
        </>
      );
    case 'forest-trail':
      return (
        <>
          <Defs>
            <LinearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#9BCB8C" />
              <Stop offset="1" stopColor="#2F6B3F" />
            </LinearGradient>
          </Defs>
          <Polygon points="0,240 400,240 400,0 0,0" fill="url(#g)" />
          {[[40, 70], [120, 50], [220, 65], [310, 45], [370, 75]].map(([x, h], i) => (
            <React.Fragment key={i}>
              <Polygon points={`${x},${240 - h - 70} ${x - 38},${240 - 40} ${x + 38},${240 - 40}`} fill="#1F4A2B" opacity={0.85} />
              <Polygon points={`${x},${240 - h - 40} ${x - 30},${240 - 10} ${x + 30},${240 - 10}`} fill="#255A34" opacity={0.9} />
            </React.Fragment>
          ))}
        </>
      );
    default:
      return <Polygon points="0,240 400,240 400,0 0,0" fill="#2A2D3A" />;
  }
}

const styles = StyleSheet.create({
  root: { overflow: 'hidden' },
});
