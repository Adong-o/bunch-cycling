// jest-expo wraps the standard React Native Jest preset with Expo's own
// module mocks (fonts, asset resolution, etc.) and already knows which
// node_modules packages need Babel transformation — don't hand-roll
// transformIgnorePatterns on top of it.
module.exports = {
  preset: 'jest-expo',
  // tsconfig.json's `paths` maps "@/*" -> "src/*", but that's resolved by
  // TypeScript/Metro, not Babel (there's no babel-plugin-module-resolver in
  // babel.config.js) — so Jest needs its own mapping or any "@/..." import
  // in a tested file fails to resolve.
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
};
