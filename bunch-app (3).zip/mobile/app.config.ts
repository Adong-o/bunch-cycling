import type { ExpoConfig, ConfigContext } from 'expo/config';

// The splash/launcher moment stays on the brand-dark mark deliberately — a
// bold dark splash that opens into the (now light) app is a normal pattern,
// not a leftover. The in-app theme itself lives in src/theme/colors.ts.
// INK is the exact background of the supplied Bunch app icon (#0E0E12) so the
// adaptive icon, the splash and the store icon are one continuous colour.
const INK = '#0E0E12';

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: 'Bunch',
  slug: 'bunch-cycling',
  scheme: 'bunch',
  version: '1.4.0',
  orientation: 'portrait',
  userInterfaceStyle: 'light',
  backgroundColor: INK,
  icon: './assets/icon_square.png',
  splash: {
    image: './assets/splash_mark.png',
    resizeMode: 'contain',
    backgroundColor: INK,
  },
  assetBundlePatterns: ['**/*'],
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.bunchcycling.app',
    infoPlist: {
      NSLocationWhenInUseUsageDescription:
        'Bunch uses your location to record your ride route, distance, speed and elevation on the map.',
      NSLocationAlwaysAndWhenInUseUsageDescription:
        'Bunch keeps recording your ride on the map and in your stats if you switch apps or lock your phone mid-ride.',
      NSBluetoothAlwaysUsageDescription:
        'Bunch uses Bluetooth to pair with heart rate, speed/cadence and power sensors and read live data from them.',
      UIBackgroundModes: ['location'],
    },
  },
  android: {
    package: 'com.bunchcycling.app',
    adaptiveIcon: {
      // Mark sits inside the 66dp safe zone (it is drawn at the same
      // proportions as the iOS icon), so round / squircle / teardrop masks
      // never clip it. The monochrome layer drives Android 13+ themed icons.
      foregroundImage: './assets/adaptive_icon_foreground.png',
      monochromeImage: './assets/adaptive_icon_monochrome.png',
      backgroundColor: INK,
    },
    permissions: [
      'ACCESS_COARSE_LOCATION',
      'ACCESS_FINE_LOCATION',
      'ACCESS_BACKGROUND_LOCATION',
      'FOREGROUND_SERVICE',
      'FOREGROUND_SERVICE_LOCATION',
      'POST_NOTIFICATIONS',
      'BLUETOOTH_SCAN',
      'BLUETOOTH_CONNECT',
    ],
  },
  plugins: [
    [
      'expo-location',
      {
        locationAlwaysAndWhenInUsePermission:
          'Bunch keeps recording your ride on the map and in your stats if you switch apps or lock your phone mid-ride.',
        locationWhenInUsePermission:
          'Bunch uses your location to record your ride route, distance, speed and elevation on the map.',
        isAndroidBackgroundLocationEnabled: true,
        isAndroidForegroundServiceEnabled: true,
      },
    ],
    [
      'expo-image-picker',
      {
        photosPermission: 'Bunch needs access to your photos so you can add one to your profile or a ride.',
        cameraPermission: 'Bunch needs access to your camera so you can snap a photo for your profile or a ride.',
      },
    ],
    [
      'expo-splash-screen',
      {
        image: './assets/splash_mark.png',
        resizeMode: 'contain',
        backgroundColor: INK,
      },
    ],
    [
      'expo-notifications',
      {
        // Pure white-on-transparent stencil glyph — the shape Android
        // requires for a status-bar icon (a full-color icon renders as a
        // plain white blob there). Drives the live ride-timer notification
        // in src/lib/rideNotification.ts.
        icon: './assets/notification_icon.png',
        color: '#4D47FC',
      },
    ],
    '@maplibre/maplibre-react-native',
  ],
  extra: {
    eas: {
      projectId: 'REPLACE_WITH_YOUR_EAS_PROJECT_ID',
    },
  },
});
