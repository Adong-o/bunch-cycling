import 'react-native-gesture-handler';
// Side-effect import: registers the background location TaskManager task at
// JS-bundle-load time, including the headless start the OS performs to
// deliver a batch of background location updates while no screen exists. The
// task writes every fix straight to disk through the recording engine.
import '@/lib/recording/task';
import React, { useCallback, useEffect, useState } from 'react';
import { AppState } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import {
  useFonts as useManropeFonts,
  Manrope_400Regular,
  Manrope_500Medium,
  Manrope_600SemiBold,
  Manrope_700Bold,
  Manrope_800ExtraBold,
} from '@expo-google-fonts/manrope';
import { JetBrainsMono_500Medium, JetBrainsMono_700Bold } from '@expo-google-fonts/jetbrains-mono';
import { RootNavigator } from '@/navigation/RootNavigator';
import { useAuthStore } from '@/state/authStore';
import { startSyncManager } from '@/lib/syncManager';
import { recordingEngine } from '@/lib/recording/engine';
import { colors } from '@/theme';

SplashScreen.preventAutoHideAsync().catch(() => {
  /* no-op: fine if this is called more than once during fast refresh */
});

export default function App() {
  const [fontsLoaded] = useManropeFonts({
    Manrope_400Regular,
    Manrope_500Medium,
    Manrope_600SemiBold,
    Manrope_700Bold,
    Manrope_800ExtraBold,
    JetBrainsMono_500Medium,
    JetBrainsMono_700Bold,
  });

  const initAuth = useAuthStore((s) => s.init);
  const initializing = useAuthStore((s) => s.initializing);
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth();
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Drains any rides that got queued locally because they finished with no
  // connection (see rideOutbox.ts / syncManager.ts) — starts once, for the
  // app's whole lifetime, independent of which screen is open.
  useEffect(() => startSyncManager(), []);

  // A ride in progress must survive anything: rebuild it from disk on every
  // launch, and every time the app returns to the foreground make sure the OS
  // is still delivering GPS (a battery manager may have stopped it quietly).
  useEffect(() => {
    void recordingEngine.hydrate().then(() => recordingEngine.checkHealth()).catch(() => {});
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') void recordingEngine.checkHealth().catch(() => {});
    });
    return () => sub.remove();
  }, []);

  useEffect(() => {
    if (fontsLoaded && !initializing) {
      setAppReady(true);
    }
  }, [fontsLoaded, initializing]);

  const onLayoutRootView = useCallback(() => {
    if (appReady) {
      SplashScreen.hideAsync().catch(() => {});
    }
  }, [appReady]);

  if (!appReady) {
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: colors.bg }} onLayout={onLayoutRootView}>
      <SafeAreaProvider>
        <StatusBar style="dark" />
        <RootNavigator />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
