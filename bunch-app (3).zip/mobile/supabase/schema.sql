-- =============================================================================
-- Bunch — Supabase schema
-- =============================================================================
-- Run this in your Supabase project's SQL Editor (Database → SQL Editor →
-- New query → paste this whole file → Run). It is safe to run on a
-- brand-new project, AND safe to run again on top of itself — every object
-- below is created idempotently, so re-pasting this file (after a partial
-- failure, or just because you're not sure if you already ran it) never
-- errors with "X already exists". It converges to exactly what's in this
-- file every time, rather than silently keeping a stale policy/trigger from
-- whatever version you ran last.
--
-- After it finishes, read the comment block at the very bottom of this file
-- ("MAKE YOURSELF AN ADMIN") — that one manual step is required once, and
-- can't be scripted because it needs the user id of the account you sign up
-- with in the app.
--
-- Design notes (also covered in /README.md):
--   • All distances are stored in METERS, all durations in SECONDS, all
--     speeds in METERS/SECOND. The app converts to km/mi, h:mm:ss, etc. at
--     display time based on the rider's `profiles.units` preference.
--   • Every table has Row Level Security turned on. There is no reliance on
--     the service_role key anywhere — the admin web app authenticates as a
--     normal Supabase user whose `profiles.is_admin` is true, and RLS alone
--     decides what that account can see and change.
--   • Free-tier limits (2 bikes, 3 routes, 5 starred segments, "join 2
--     challenges before you can create one") are enforced in the database,
--     not just in the app UI, via BEFORE INSERT triggers — so they hold even
--     if a request bypasses the app.
--   • Routes/segments/rides store their geometry as a GeoJSON LineString in a
--     plain `jsonb` column rather than a PostGIS `geometry` column. This is
--     a deliberate simplification: it needs no extension beyond the
--     always-available pgcrypto, so there's nothing version- or
--     availability-dependent to go wrong when you paste this into a fresh
--     project, and at this app's scale (bounding-box pre-filters, haversine
--     math client-side) it doesn't need PostGIS's indexing to stay fast.
--   • Idempotency pattern used throughout: CREATE TABLE / CREATE INDEX use
--     IF NOT EXISTS (native Postgres support); CREATE POLICY / CREATE
--     TRIGGER have no such clause in Postgres, so each is preceded by a
--     matching DROP ... IF EXISTS — which also means a re-run always
--     converges to this file's current definition rather than keeping a
--     stale one; CREATE TYPE has no IF NOT EXISTS either and DROP TYPE would
--     be destructive to any column already using it, so those are wrapped in
--     a DO block that swallows "already exists" instead; VIEW and FUNCTION
--     already have native OR REPLACE.
-- =============================================================================


-- The whole file runs as one transaction: if anything below fails, nothing
-- is left half-created, and you can fix it and simply run the file again.
begin;

-- -----------------------------------------------------------------------------
-- 0. EXTENSIONS
-- -----------------------------------------------------------------------------
-- gen_random_uuid() is built into Postgres 13+ so nothing here strictly
-- depends on pgcrypto, but every Supabase project already has it enabled in
-- the `extensions` schema — this just makes sure, and installs it there
-- (not into `public`) to match Supabase's own convention.
create extension if not exists pgcrypto with schema extensions;


-- -----------------------------------------------------------------------------
-- 1. ENUM TYPES
-- -----------------------------------------------------------------------------
-- CREATE TYPE has no IF NOT EXISTS in any Postgres version, and DROP TYPE
-- first would be destructive (it cascades to every column using it) — so
-- each one is wrapped to swallow exactly the "already exists" error and
-- nothing else.
do $$ begin
  create type public.unit_system as enum ('metric', 'imperial');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.target_period as enum ('daily', 'weekly');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.bike_type as enum ('road', 'gravel', 'mountain', 'commuter', 'ebike', 'other');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.surface_type as enum ('paved', 'gravel', 'mixed', 'dirt');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.ride_visibility as enum ('public', 'followers', 'private');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.ride_source as enum ('gps', 'manual', 'import');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.challenge_type as enum ('distance', 'elevation', 'duration', 'ride_count');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.device_type as enum ('heart_rate', 'speed_cadence', 'power', 'combo', 'other');
exception when duplicate_object then null;
end $$;

-- v1.3: the brand of a GPS watch/computer logged in the recording_devices
-- registry below (distinct from device_type above, which is a BLE sensor
-- kind, not a brand).
do $$ begin
  create type public.recording_device_brand as enum ('garmin', 'coros', 'suunto', 'polar', 'apple_watch', 'amazfit', 'wahoo', 'other');
exception when duplicate_object then null;
end $$;


-- -----------------------------------------------------------------------------
-- 2. TABLES
-- -----------------------------------------------------------------------------

-- Public-facing profile. Anything another rider should be able to see lives
-- here. Readable by every signed-in user; writable only by its owner (and by
-- admins, for the premium/admin flags — see the trigger + policy below).
create table if not exists public.profiles (
  id                  uuid primary key references auth.users(id) on delete cascade,
  username            text not null unique,
  display_name        text not null default '',
  avatar_url          text,
  bio                 text not null default '',
  units               public.unit_system not null default 'metric',
  weight_kg           numeric(5,2),
  target_period       public.target_period not null default 'weekly',
  target_distance_m   numeric not null default 50000,
  timezone            text not null default 'UTC',
  onboarding_completed boolean not null default false,
  is_admin            boolean not null default false,
  is_premium          boolean not null default false,
  premium_since       timestamptz,
  current_streak      integer not null default 0,
  longest_streak      integer not null default 0,
  last_streak_date    date,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  constraint username_format check (username ~ '^[a-z0-9_]{3,20}$'),
  constraint weight_positive check (weight_kg is null or weight_kg > 0)
);
comment on table public.profiles is 'Public rider profile. One row per auth.users row, created automatically on sign-up.';

-- v1.2: two light, descriptive onboarding fields — "what kind of rider are
-- you, what are you here for" — surfaced once at sign-up to tailor copy and
-- defaults, not used for anything access-gating. ADD COLUMN IF NOT EXISTS
-- (not the inline table definition above) so this reaches an already-created
-- `profiles` table from an earlier schema.sql run, not just a fresh one.
alter table public.profiles add column if not exists riding_experience text;
alter table public.profiles add column if not exists primary_goal text;

do $$ begin
  alter table public.profiles add constraint riding_experience_valid
    check (riding_experience is null or riding_experience in ('new', 'casual', 'regular', 'competitive'));
exception when duplicate_object then null;
end $$;

do $$ begin
  alter table public.profiles add constraint primary_goal_valid
    check (primary_goal is null or primary_goal in ('fitness', 'commuting', 'racing', 'social', 'exploring'));
exception when duplicate_object then null;
end $$;

-- Private half of a profile (right now just email). Split out of `profiles`
-- so the broad "any signed-in user can read profiles" policy below never
-- exposes anyone's email address.
create table if not exists public.profiles_private (
  id    uuid primary key references public.profiles(id) on delete cascade,
  email text
);
comment on table public.profiles_private is 'Sensitive profile fields. Only the owner and admins can read this.';

create table if not exists public.bikes (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references public.profiles(id) on delete cascade,
  name              text not null,
  type              public.bike_type not null default 'gravel',
  is_default        boolean not null default false,
  is_retired        boolean not null default false,
  total_distance_m  numeric not null default 0,
  total_rides       integer not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
comment on table public.bikes is 'A rider''s garage. Free plan: 2 bikes. Premium: unlimited. Enforced in enforce_bike_cap(). type = ''ebike'' gets its own category on segment leaderboards — see segment_leaderboard below.';

create table if not exists public.routes (
  id                   uuid primary key default gen_random_uuid(),
  user_id              uuid not null references public.profiles(id) on delete cascade,
  name                 text not null,
  description          text not null default '',
  distance_m           numeric not null default 0,
  elevation_gain_m     numeric not null default 0,
  route_geojson        jsonb not null,
  surface_type         public.surface_type not null default 'mixed',
  is_public            boolean not null default false,
  created_from_ride_id uuid,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
comment on table public.routes is 'Saved/planned routes — either built from scratch (created_from_ride_id null) or saved from a completed ride. Free plan: 3 routes. Premium: unlimited. Enforced in enforce_route_cap().';

create table if not exists public.rides (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references public.profiles(id) on delete cascade,
  bike_id           uuid references public.bikes(id) on delete set null,
  route_id          uuid references public.routes(id) on delete set null,
  title             text not null default '',
  description       text not null default '',
  visibility        public.ride_visibility not null default 'public',
  source            public.ride_source not null default 'gps',
  is_indoor         boolean not null default false,
  started_at        timestamptz not null,
  ended_at          timestamptz not null,
  moving_time_s     integer not null default 0,
  elapsed_time_s    integer not null default 0,
  distance_m        numeric not null default 0,
  elevation_gain_m  numeric not null default 0,
  elevation_loss_m  numeric not null default 0,
  avg_speed_mps     numeric not null default 0,
  max_speed_mps     numeric not null default 0,
  avg_heart_rate    integer,
  max_heart_rate    integer,
  calories          integer,
  start_lat         double precision,
  start_lng         double precision,
  end_lat           double precision,
  end_lng           double precision,
  route_geojson     jsonb,
  photo_urls        text[] not null default '{}',
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint ride_times_ok check (ended_at >= started_at),
  constraint ride_numbers_ok check (
    moving_time_s >= 0 and elapsed_time_s >= 0 and distance_m >= 0 and
    elevation_gain_m >= 0 and elevation_loss_m >= 0
  )
);
comment on table public.rides is 'A completed ride. route_geojson is a GeoJSON LineString of [lng,lat,elevation_m] points. source = ''import'' is a ride brought in from a GPX/TCX file rather than recorded live.';

-- Resolve the routes <-> rides circular reference now that both tables exist.
do $$ begin
  alter table public.routes
    add constraint routes_created_from_ride_fk
    foreign key (created_from_ride_id) references public.rides(id) on delete set null;
exception when duplicate_object then null;
end $$;

create table if not exists public.segments (
  id                uuid primary key default gen_random_uuid(),
  created_by        uuid not null references public.profiles(id) on delete cascade,
  name              text not null,
  distance_m        numeric not null,
  elevation_gain_m  numeric not null default 0,
  avg_grade_pct     numeric,
  surface_type      public.surface_type not null default 'mixed',
  start_lat         double precision not null,
  start_lng         double precision not null,
  end_lat           double precision not null,
  end_lng           double precision not null,
  route_geojson     jsonb not null,
  created_at        timestamptz not null default now()
);
comment on table public.segments is 'Community-created leaderboard segments, carved out of a ride.';

create table if not exists public.segment_stars (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  segment_id  uuid not null references public.segments(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique (user_id, segment_id)
);
comment on table public.segment_stars is 'Segments a rider is tracking for live effort detection. Free plan: 5. Premium: unlimited.';

create table if not exists public.segment_efforts (
  id            uuid primary key default gen_random_uuid(),
  segment_id    uuid not null references public.segments(id) on delete cascade,
  ride_id       uuid not null references public.rides(id) on delete cascade,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  elapsed_s     integer not null,
  avg_speed_mps numeric,
  started_at    timestamptz not null,
  created_at    timestamptz not null default now(),
  constraint effort_time_positive check (elapsed_s > 0)
);
comment on table public.segment_efforts is 'One rider''s attempt at a segment, matched client-side after a ride is saved.';

create table if not exists public.challenges (
  id                uuid primary key default gen_random_uuid(),
  created_by        uuid not null references public.profiles(id) on delete cascade,
  is_official       boolean not null default false,
  title             text not null,
  description       text not null default '',
  cover_image_url   text,
  type              public.challenge_type not null,
  goal_value        numeric not null,
  start_date        date not null,
  end_date          date not null,
  is_public         boolean not null default true,
  invite_code       text not null unique,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint challenge_dates_ok check (end_date >= start_date),
  constraint challenge_goal_positive check (goal_value > 0)
);
comment on table public.challenges is 'is_official = made by Bunch/admin. Everyone else must have joined 2 challenges first — enforced in enforce_challenge_create_gate().';

create table if not exists public.challenge_participants (
  id                uuid primary key default gen_random_uuid(),
  challenge_id      uuid not null references public.challenges(id) on delete cascade,
  user_id           uuid not null references public.profiles(id) on delete cascade,
  current_progress  numeric not null default 0,
  joined_at         timestamptz not null default now(),
  completed_at      timestamptz,
  unique (challenge_id, user_id)
);
comment on table public.challenge_participants is 'current_progress is recomputed from scratch after every ride — see recompute_challenge_progress().';

create table if not exists public.badges (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique,
  name            text not null,
  description     text not null,
  icon            text not null,
  criteria_type   text not null,
  criteria_value  numeric not null,
  created_at      timestamptz not null default now(),
  constraint badges_criteria_type_valid check (
    criteria_type in (
      'total_rides', 'total_distance_m', 'total_elevation_m',
      'longest_streak', 'challenges_completed',
      'single_ride_distance_m', 'single_ride_elevation_m'
    )
  )
);
comment on table public.badges is 'The badge catalog. Seeded below. Awarded automatically by check_and_award_badges().';

create table if not exists public.user_badges (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  badge_id      uuid not null references public.badges(id) on delete cascade,
  ride_id       uuid references public.rides(id) on delete set null,
  challenge_id  uuid references public.challenges(id) on delete set null,
  awarded_at    timestamptz not null default now(),
  unique (user_id, badge_id)
);
comment on table public.user_badges is 'Rows only ever get inserted by the SECURITY DEFINER check_and_award_badges() function — not directly by clients. See RLS policies below.';

create table if not exists public.follows (
  id            uuid primary key default gen_random_uuid(),
  follower_id   uuid not null references public.profiles(id) on delete cascade,
  following_id  uuid not null references public.profiles(id) on delete cascade,
  created_at    timestamptz not null default now(),
  unique (follower_id, following_id),
  constraint no_self_follow check (follower_id <> following_id)
);

create table if not exists public.kudos (
  id          uuid primary key default gen_random_uuid(),
  ride_id     uuid not null references public.rides(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique (ride_id, user_id)
);

create table if not exists public.ride_comments (
  id          uuid primary key default gen_random_uuid(),
  ride_id     uuid not null references public.rides(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  body        text not null,
  created_at  timestamptz not null default now(),
  constraint comment_not_empty check (char_length(trim(body)) > 0)
);

create table if not exists public.ride_tags (
  id          uuid primary key default gen_random_uuid(),
  ride_id     uuid not null references public.rides(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  tagged_by   uuid not null references public.profiles(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique (ride_id, user_id)
);
comment on table public.ride_tags is 'Riders tagged as having ridden along on a ride ("Rode with"). tagged_by is who added the tag (almost always the ride owner); user_id is who got tagged, and can always remove their own tag — see RLS below. Visible wherever the underlying ride is visible, same idiom as kudos/ride_comments. Tagging also extends that ride''s own visibility to the tagged rider — see the "Rides visible per visibility setting" policy.';

create table if not exists public.devices (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null references public.profiles(id) on delete cascade,
  name                text not null,
  type                public.device_type not null default 'other',
  ble_identifier      text,
  last_connected_at   timestamptz,
  created_at          timestamptz not null default now()
);
comment on table public.devices is 'Bluetooth LE sensors (heart rate / speed-cadence / power) a rider has paired. ble_identifier is the platform BLE peripheral id from the last live pairing (see mobile/src/lib/ble.ts) so a known sensor can be reconnected without rescanning.';

create table if not exists public.recording_devices (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  brand       public.recording_device_brand not null default 'other',
  name        text not null,
  created_at  timestamptz not null default now()
);
comment on table public.recording_devices is 'A GPS watch/computer a rider also records with (Garmin, Coros, Suunto, Polar, Apple Watch, Amazfit, Wahoo, or other) — a saved registry only, not a live sync integration; no OAuth credentials exist for these providers yet. Lets a ride be tagged with which device recorded it (rides.recording_device_id) so a rider who sometimes rides with a watch instead of the phone never has to feel they are losing that history to use Bunch. Free plan: 1 device. Premium: unlimited. Enforced in enforce_recording_device_cap(). Deliberately a separate table from `devices` above, which is live-paired BLE sensors, not a records-only registry.';

-- Now that recording_devices exists, let a ride record which device (if any)
-- captured it, and give every ride a human-readable start location —
-- reverse-geocoded once at save time (see mobile/src/lib/geocode.ts), not
-- looked up again on every render. ADD COLUMN IF NOT EXISTS so this reaches
-- an already-created `rides` table from an earlier schema.sql run, not just
-- a fresh one.
alter table public.rides add column if not exists recording_device_id uuid references public.recording_devices(id) on delete set null;
alter table public.rides add column if not exists start_location_name text;


-- -----------------------------------------------------------------------------
-- 3. INDEXES
-- -----------------------------------------------------------------------------
create index if not exists idx_bikes_user                      on public.bikes(user_id);
create index if not exists idx_routes_user                     on public.routes(user_id);
create index if not exists idx_rides_user_started              on public.rides(user_id, started_at desc);
create index if not exists idx_rides_visibility                on public.rides(visibility);
create index if not exists idx_segments_created_by             on public.segments(created_by);
create index if not exists idx_segment_stars_user              on public.segment_stars(user_id);
create index if not exists idx_segment_efforts_segment_elapsed on public.segment_efforts(segment_id, elapsed_s);
create index if not exists idx_segment_efforts_user            on public.segment_efforts(user_id);
create index if not exists idx_segment_efforts_ride            on public.segment_efforts(ride_id);
create index if not exists idx_challenges_invite_code          on public.challenges(invite_code);
create index if not exists idx_challenge_participants_challenge on public.challenge_participants(challenge_id);
create index if not exists idx_challenge_participants_user     on public.challenge_participants(user_id);
create index if not exists idx_user_badges_user                on public.user_badges(user_id);
create index if not exists idx_follows_follower                on public.follows(follower_id);
create index if not exists idx_follows_following               on public.follows(following_id);
create index if not exists idx_kudos_ride                      on public.kudos(ride_id);
create index if not exists idx_ride_comments_ride              on public.ride_comments(ride_id);
create index if not exists idx_devices_user                    on public.devices(user_id);
create index if not exists idx_ride_tags_ride                  on public.ride_tags(ride_id);
create index if not exists idx_ride_tags_user                  on public.ride_tags(user_id);
create index if not exists idx_recording_devices_user          on public.recording_devices(user_id);
create index if not exists idx_rides_recording_device          on public.rides(recording_device_id);


-- -----------------------------------------------------------------------------
-- 4. FUNCTIONS
-- -----------------------------------------------------------------------------

-- Is this uid an admin? SECURITY DEFINER so it can read `profiles` without
-- tripping the profiles RLS policy that itself calls is_admin() — avoids
-- infinite recursion.
create or replace function public.is_admin(uid uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select coalesce((select is_admin from public.profiles where id = uid), false);
$$;

-- The next two helpers exist ONLY to stop RLS recursion: `challenges` and
-- `challenge_participants` each need to check something about the OTHER
-- table (and challenge_participants even needs to check itself, for "is the
-- viewer a fellow participant"). Doing that with a plain EXISTS subquery
-- against a table that has its own RLS re-triggers that table's policy,
-- which in this case loops right back — Postgres detects it and raises
-- "infinite recursion detected in policy". SECURITY DEFINER sidesteps this
-- exactly like is_admin() does above: the function runs as the table owner,
-- who isn't subject to RLS, so the lookup inside it never re-enters any
-- policy at all.
create or replace function public.is_challenge_participant(p_challenge_id uuid, p_user_id uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.challenge_participants
    where challenge_id = p_challenge_id and user_id = p_user_id
  );
$$;

create or replace function public.can_view_challenge(p_challenge_id uuid, p_user_id uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.challenges c
    where c.id = p_challenge_id
      and (c.is_public = true or c.created_by = p_user_id or public.is_admin(p_user_id))
  );
$$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Creates the profiles + profiles_private row the moment someone signs up.
-- Picks a unique username from the left-hand side of their email, falling
-- back to riderXXXXXX if that's taken or unusable.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  base_username text;
  final_username text;
  suffix int := 0;
begin
  base_username := lower(regexp_replace(split_part(coalesce(new.email, ''), '@', 1), '[^a-z0-9_]', '', 'g'));
  if base_username is null or length(base_username) < 3 then
    base_username := 'rider' || substr(replace(new.id::text, '-', ''), 1, 6);
  end if;
  base_username := substr(base_username, 1, 20);

  final_username := base_username;
  while exists (select 1 from public.profiles where username = final_username) loop
    suffix := suffix + 1;
    final_username := substr(base_username, 1, 20 - length(suffix::text)) || suffix::text;
  end loop;

  insert into public.profiles (id, username, display_name)
  values (new.id, final_username, initcap(split_part(coalesce(new.email, 'Rider'), '@', 1)));

  insert into public.profiles_private (id, email)
  values (new.id, new.email);

  return new;
end;
$$;

-- Blocks a non-admin from granting themselves admin/premium through a normal
-- profile update. Admins (checked via is_admin(), i.e. the ACTOR's own row,
-- not the row being edited) may change these fields on any profile — this is
-- how the admin web app's "upgrade user" button works, with no service key.
--
-- auth.uid() is NULL when there is no end-user JWT at all — i.e. a query run
-- directly as the Postgres owner (the SQL Editor, or a migration) or with
-- the service_role key. Both are already-trusted, privileged contexts (an
-- anonymous API request can never reach this table — there is no policy
-- granting it to the `anon` role), so they're let through unguarded. This is
-- what makes the one-time "MAKE YOURSELF AN ADMIN" bootstrap at the bottom
-- of this file actually work: run from the SQL Editor, auth.uid() is NULL.
create or replace function public.prevent_privilege_escalation()
returns trigger
language plpgsql
as $$
begin
  if auth.uid() is not null and not public.is_admin(auth.uid()) then
    new.is_admin := old.is_admin;
    new.is_premium := old.is_premium;
    new.premium_since := old.premium_since;
  end if;
  return new;
end;
$$;

create or replace function public.enforce_bike_cap()
returns trigger
language plpgsql
as $$
declare
  existing_count integer;
  premium boolean;
begin
  select is_premium into premium from public.profiles where id = new.user_id;
  select count(*) into existing_count from public.bikes where user_id = new.user_id;
  if not coalesce(premium, false) and existing_count >= 2 then
    raise exception 'Free plan is limited to 2 bikes. Upgrade to Bunch Premium to add more.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

create or replace function public.enforce_route_cap()
returns trigger
language plpgsql
as $$
declare
  existing_count integer;
  premium boolean;
begin
  select is_premium into premium from public.profiles where id = new.user_id;
  select count(*) into existing_count from public.routes where user_id = new.user_id;
  if not coalesce(premium, false) and existing_count >= 3 then
    raise exception 'Free plan is limited to 3 saved routes. Upgrade to Bunch Premium to save more.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

create or replace function public.enforce_recording_device_cap()
returns trigger
language plpgsql
as $$
declare
  existing_count integer;
  premium boolean;
begin
  select is_premium into premium from public.profiles where id = new.user_id;
  select count(*) into existing_count from public.recording_devices where user_id = new.user_id;
  if not coalesce(premium, false) and existing_count >= 1 then
    raise exception 'Free plan is limited to 1 recording device. Upgrade to Bunch Premium to add more.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

-- A ride's own rider doesn't need tagging on their own ride — they're
-- already on it by definition, and the client's "Rode with" list should
-- never have to defensively filter the owner back out.
create or replace function public.enforce_ride_tag_not_owner()
returns trigger
language plpgsql
as $$
declare
  owner_id uuid;
begin
  select user_id into owner_id from public.rides where id = new.ride_id;
  if owner_id = new.user_id then
    raise exception 'The ride''s own rider doesn''t need to be tagged on it.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

create or replace function public.enforce_segment_star_cap()
returns trigger
language plpgsql
as $$
declare
  existing_count integer;
  premium boolean;
begin
  select is_premium into premium from public.profiles where id = new.user_id;
  select count(*) into existing_count from public.segment_stars where user_id = new.user_id;
  if not coalesce(premium, false) and existing_count >= 5 then
    raise exception 'Free plan is limited to 5 starred segments. Upgrade to Bunch Premium to star more.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

-- Only admins may create an "official" challenge. Everyone else needs to
-- have joined at least 2 challenges first.
create or replace function public.enforce_challenge_create_gate()
returns trigger
language plpgsql
as $$
declare
  joined_count integer;
begin
  if new.is_official and not public.is_admin(new.created_by) then
    raise exception 'Only Bunch admins can create official challenges.' using errcode = 'P0001';
  end if;

  if public.is_admin(new.created_by) then
    return new;
  end if;

  select count(*) into joined_count from public.challenge_participants where user_id = new.created_by;
  if joined_count < 2 then
    raise exception 'Join at least 2 challenges before you can create your own.' using errcode = 'P0001';
  end if;

  return new;
end;
$$;

create or replace function public.generate_invite_code()
returns trigger
language plpgsql
as $$
declare
  candidate text;
  tries int := 0;
begin
  if new.invite_code is not null and length(trim(new.invite_code)) > 0 then
    return new;
  end if;

  loop
    candidate := upper(substr(md5(random()::text || clock_timestamp()::text), 1, 7));
    exit when not exists (select 1 from public.challenges where invite_code = candidate);
    tries := tries + 1;
    if tries > 20 then
      raise exception 'Could not generate a unique invite code — please try again.';
    end if;
  end loop;

  new.invite_code := candidate;
  return new;
end;
$$;

-- Keeps bikes.total_distance_m / total_rides in sync whenever a ride is
-- logged, edited (incl. re-assigned to a different bike) or deleted.
create or replace function public.update_bike_totals()
returns trigger
language plpgsql
as $$
declare
  target_bike uuid;
begin
  target_bike := case when tg_op = 'DELETE' then old.bike_id else new.bike_id end;

  if target_bike is not null then
    update public.bikes b
    set total_distance_m = coalesce((select sum(distance_m) from public.rides where bike_id = target_bike), 0),
        total_rides       = coalesce((select count(*) from public.rides where bike_id = target_bike), 0)
    where b.id = target_bike;
  end if;

  if tg_op = 'UPDATE' and old.bike_id is distinct from new.bike_id and old.bike_id is not null then
    update public.bikes b
    set total_distance_m = coalesce((select sum(distance_m) from public.rides where bike_id = old.bike_id), 0),
        total_rides       = coalesce((select count(*) from public.rides where bike_id = old.bike_id), 0)
    where b.id = old.bike_id;
  end if;

  return coalesce(new, old);
end;
$$;

-- Awards every badge the rider now qualifies for. Cumulative criteria are
-- read fresh from the database each time; single-ride criteria are checked
-- against the ride that was just saved (p_ride_distance_m / p_ride_elevation_m
-- are null when this is called from a context with no specific ride, e.g.
-- after a challenge completes).
--
-- SECURITY DEFINER on purpose: this is the ONLY way a row is ever allowed
-- into user_badges (see the RLS policy on that table) — regular users cannot
-- insert their own badges, which is how we keep the trophy case honest.
create or replace function public.check_and_award_badges(
  p_user_id uuid,
  p_ride_distance_m numeric default null,
  p_ride_elevation_m numeric default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  total_distance numeric;
  total_rides_count integer;
  total_elevation numeric;
  streak integer;
  challenges_completed integer;
  b record;
begin
  select coalesce(sum(distance_m), 0), count(*), coalesce(sum(elevation_gain_m), 0)
    into total_distance, total_rides_count, total_elevation
    from public.rides where user_id = p_user_id;

  select coalesce(longest_streak, 0) into streak from public.profiles where id = p_user_id;

  select count(*) into challenges_completed
    from public.challenge_participants where user_id = p_user_id and completed_at is not null;

  for b in select * from public.badges loop
    if (
      (b.criteria_type = 'total_rides' and total_rides_count >= b.criteria_value) or
      (b.criteria_type = 'total_distance_m' and total_distance >= b.criteria_value) or
      (b.criteria_type = 'total_elevation_m' and total_elevation >= b.criteria_value) or
      (b.criteria_type = 'longest_streak' and streak >= b.criteria_value) or
      (b.criteria_type = 'challenges_completed' and challenges_completed >= b.criteria_value) or
      (b.criteria_type = 'single_ride_distance_m' and p_ride_distance_m is not null and p_ride_distance_m >= b.criteria_value) or
      (b.criteria_type = 'single_ride_elevation_m' and p_ride_elevation_m is not null and p_ride_elevation_m >= b.criteria_value)
    ) then
      insert into public.user_badges (user_id, badge_id)
      values (p_user_id, b.id)
      on conflict (user_id, badge_id) do nothing;
    end if;
  end loop;
end;
$$;

-- Recomputes current_progress for every challenge a rider is in, FROM
-- SCRATCH, by summing their rides inside the challenge's date window. Doing
-- a full recompute (instead of +/- incrementing) means an edited or deleted
-- ride can never leave progress out of sync.
create or replace function public.recompute_challenge_progress(p_user_id uuid)
returns void
language plpgsql
as $$
declare
  cp record;
  new_progress numeric;
begin
  for cp in
    select cpar.id, cpar.completed_at, c.type, c.goal_value, c.start_date, c.end_date
    from public.challenge_participants cpar
    join public.challenges c on c.id = cpar.challenge_id
    where cpar.user_id = p_user_id
  loop
    if cp.type = 'distance' then
      select coalesce(sum(distance_m), 0) into new_progress from public.rides
        where user_id = p_user_id and started_at::date between cp.start_date and cp.end_date;
    elsif cp.type = 'elevation' then
      select coalesce(sum(elevation_gain_m), 0) into new_progress from public.rides
        where user_id = p_user_id and started_at::date between cp.start_date and cp.end_date;
    elsif cp.type = 'duration' then
      select coalesce(sum(moving_time_s), 0) into new_progress from public.rides
        where user_id = p_user_id and started_at::date between cp.start_date and cp.end_date;
    else
      select coalesce(count(*), 0) into new_progress from public.rides
        where user_id = p_user_id and started_at::date between cp.start_date and cp.end_date;
    end if;

    update public.challenge_participants
    set current_progress = new_progress,
        completed_at = case
          when cp.completed_at is not null then cp.completed_at
          when new_progress >= cp.goal_value then now()
          else null
        end
    where id = cp.id;

    if cp.completed_at is null and new_progress >= cp.goal_value then
      perform public.check_and_award_badges(p_user_id);
    end if;
  end loop;
end;
$$;

-- Backfills progress the moment someone joins a challenge, so a rider who
-- already has qualifying rides before joining doesn't see 0 until their
-- next ride.
create or replace function public.challenge_participants_after_insert()
returns trigger
language plpgsql
as $$
begin
  perform public.recompute_challenge_progress(new.user_id);
  return new;
end;
$$;

-- Single AFTER trigger function on `rides` that fans out to both the
-- challenge-progress recompute and the badge check, for insert/update/delete.
-- Fires the same way regardless of `source` — an imported GPX/TCX ride
-- counts toward streaks, challenges and badges exactly like a GPS-recorded
-- one, since both just insert a normal row into this table.
create or replace function public.rides_after_change()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'DELETE' then
    perform public.recompute_challenge_progress(old.user_id);
    perform public.check_and_award_badges(old.user_id);
    return old;
  else
    perform public.recompute_challenge_progress(new.user_id);
    perform public.check_and_award_badges(new.user_id, new.distance_m, new.elevation_gain_m);
    return new;
  end if;
end;
$$;


-- -----------------------------------------------------------------------------
-- 5. TRIGGERS
-- -----------------------------------------------------------------------------
-- CREATE TRIGGER has no IF NOT EXISTS in any current Postgres version, so
-- each is preceded by a DROP TRIGGER IF EXISTS — harmless (triggers have no
-- dependents the way a type or a column does) and it means a re-run always
-- ends up with this file's current trigger definition.

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

drop trigger if exists profiles_guard_privilege on public.profiles;
create trigger profiles_guard_privilege
  before update on public.profiles
  for each row execute function public.prevent_privilege_escalation();

drop trigger if exists bikes_set_updated_at on public.bikes;
create trigger bikes_set_updated_at
  before update on public.bikes
  for each row execute function public.set_updated_at();

drop trigger if exists bikes_enforce_cap on public.bikes;
create trigger bikes_enforce_cap
  before insert on public.bikes
  for each row execute function public.enforce_bike_cap();

drop trigger if exists routes_set_updated_at on public.routes;
create trigger routes_set_updated_at
  before update on public.routes
  for each row execute function public.set_updated_at();

drop trigger if exists routes_enforce_cap on public.routes;
create trigger routes_enforce_cap
  before insert on public.routes
  for each row execute function public.enforce_route_cap();

drop trigger if exists segment_stars_enforce_cap on public.segment_stars;
create trigger segment_stars_enforce_cap
  before insert on public.segment_stars
  for each row execute function public.enforce_segment_star_cap();

drop trigger if exists recording_devices_enforce_cap on public.recording_devices;
create trigger recording_devices_enforce_cap
  before insert on public.recording_devices
  for each row execute function public.enforce_recording_device_cap();

drop trigger if exists ride_tags_enforce_not_owner on public.ride_tags;
create trigger ride_tags_enforce_not_owner
  before insert on public.ride_tags
  for each row execute function public.enforce_ride_tag_not_owner();

drop trigger if exists challenges_set_updated_at on public.challenges;
create trigger challenges_set_updated_at
  before update on public.challenges
  for each row execute function public.set_updated_at();

drop trigger if exists challenges_enforce_create_gate on public.challenges;
create trigger challenges_enforce_create_gate
  before insert on public.challenges
  for each row execute function public.enforce_challenge_create_gate();

drop trigger if exists challenges_generate_invite_code on public.challenges;
create trigger challenges_generate_invite_code
  before insert on public.challenges
  for each row execute function public.generate_invite_code();

drop trigger if exists rides_set_updated_at on public.rides;
create trigger rides_set_updated_at
  before update on public.rides
  for each row execute function public.set_updated_at();

drop trigger if exists rides_update_bike_totals on public.rides;
create trigger rides_update_bike_totals
  after insert or update or delete on public.rides
  for each row execute function public.update_bike_totals();

drop trigger if exists rides_after_change_trigger on public.rides;
create trigger rides_after_change_trigger
  after insert or update or delete on public.rides
  for each row execute function public.rides_after_change();

drop trigger if exists challenge_participants_recompute_on_join on public.challenge_participants;
create trigger challenge_participants_recompute_on_join
  after insert on public.challenge_participants
  for each row execute function public.challenge_participants_after_insert();


-- -----------------------------------------------------------------------------
-- 6. VIEWS
-- -----------------------------------------------------------------------------
-- security_invoker means these views run with the CALLER's RLS, not the
-- view owner's — required so a view can't be used to bypass row security.
-- CREATE OR REPLACE is natively idempotent, so no extra guard needed here —
-- just make sure a re-run's definition has the same column list (it does).

create or replace view public.home_feed
with (security_invoker = true) as
select r.*
from public.rides r
where r.user_id = auth.uid()
   or (
     r.visibility in ('public', 'followers')
     and exists (
       select 1 from public.follows f
       where f.follower_id = auth.uid() and f.following_id = r.user_id
     )
   )
   or exists (
     select 1 from public.ride_tags t
     where t.ride_id = r.id and t.user_id = auth.uid()
   );
comment on view public.home_feed is 'Your own rides + rides from people you follow + rides you''re tagged on ("Rode with"), regardless of that ride''s own visibility — same rule as the "Rides visible per visibility setting" RLS policy. Query this instead of `rides` for the home feed.';

create or replace view public.challenge_leaderboard
with (security_invoker = true) as
select
  cp.challenge_id,
  cp.user_id,
  p.username,
  p.display_name,
  p.avatar_url,
  cp.current_progress,
  cp.completed_at,
  cp.joined_at,
  rank() over (
    partition by cp.challenge_id
    order by cp.current_progress desc, cp.completed_at asc nulls last
  ) as rank
from public.challenge_participants cp
join public.profiles p on p.id = cp.user_id;

-- v1.2: e-bike rides now compete in their own category instead of being
-- silently mixed in with acoustic ones — a motor-assisted climb time isn't
-- comparable to an unassisted one, and burying that was a real fairness gap.
-- is_ebike is derived from the BIKE USED ON THAT RIDE (segment_efforts ->
-- rides -> bikes), defaulting to false (acoustic) whenever a ride has no
-- bike selected, so nothing becomes unranked just because a rider skipped
-- picking a bike. rank() is partitioned by (segment_id, is_ebike), so each
-- category gets its own independent #1 — the UI (SegmentDetailScreen) splits
-- the two leaderboards into tabs rather than interleaving them.
create or replace view public.segment_leaderboard
with (security_invoker = true) as
select
  se.segment_id,
  se.user_id,
  p.username,
  p.display_name,
  p.avatar_url,
  coalesce(b.type = 'ebike', false) as is_ebike,
  min(se.elapsed_s) as best_elapsed_s,
  rank() over (
    partition by se.segment_id, coalesce(b.type = 'ebike', false)
    order by min(se.elapsed_s) asc
  ) as rank
from public.segment_efforts se
join public.profiles p on p.id = se.user_id
left join public.rides r on r.id = se.ride_id
left join public.bikes b on b.id = r.bike_id
group by se.segment_id, se.user_id, p.username, p.display_name, p.avatar_url, coalesce(b.type = 'ebike', false);


-- -----------------------------------------------------------------------------
-- 7. GRANTS
-- -----------------------------------------------------------------------------
-- Base table privileges. RLS policies (next section) decide which ROWS are
-- actually visible/writable — this just allows the `authenticated` role to
-- attempt the statement at all. GRANT is naturally idempotent (re-granting
-- an already-held privilege is a no-op), so nothing extra needed here.
grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant select on public.home_feed, public.challenge_leaderboard, public.segment_leaderboard to authenticated;


-- -----------------------------------------------------------------------------
-- 8. ROW LEVEL SECURITY
-- -----------------------------------------------------------------------------
-- ENABLE ROW LEVEL SECURITY is idempotent (re-enabling is a no-op). CREATE
-- POLICY is not, and has no IF NOT EXISTS, so every policy below is preceded
-- by a matching DROP POLICY IF EXISTS.

alter table public.profiles enable row level security;
drop policy if exists "Profiles are readable by any signed-in user" on public.profiles;
create policy "Profiles are readable by any signed-in user"
  on public.profiles for select to authenticated using (true);
drop policy if exists "Users insert their own profile" on public.profiles;
create policy "Users insert their own profile"
  on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users and admins can update a profile" on public.profiles;
create policy "Users and admins can update a profile"
  on public.profiles for update to authenticated
  using (auth.uid() = id or public.is_admin(auth.uid()))
  with check (auth.uid() = id or public.is_admin(auth.uid()));

alter table public.profiles_private enable row level security;
drop policy if exists "Only the owner or an admin can read private profile data" on public.profiles_private;
create policy "Only the owner or an admin can read private profile data"
  on public.profiles_private for select to authenticated
  using (auth.uid() = id or public.is_admin(auth.uid()));

alter table public.bikes enable row level security;
drop policy if exists "Bikes are readable by any signed-in user" on public.bikes;
create policy "Bikes are readable by any signed-in user"
  on public.bikes for select to authenticated using (true);
drop policy if exists "Users manage their own bikes (insert)" on public.bikes;
create policy "Users manage their own bikes (insert)"
  on public.bikes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users manage their own bikes (update)" on public.bikes;
create policy "Users manage their own bikes (update)"
  on public.bikes for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage their own bikes (delete)" on public.bikes;
create policy "Users manage their own bikes (delete)"
  on public.bikes for delete to authenticated using (auth.uid() = user_id);

alter table public.routes enable row level security;
drop policy if exists "Routes visible to owner, admins, or if public" on public.routes;
create policy "Routes visible to owner, admins, or if public"
  on public.routes for select to authenticated
  using (auth.uid() = user_id or is_public = true or public.is_admin(auth.uid()));
drop policy if exists "Users manage their own routes (insert)" on public.routes;
create policy "Users manage their own routes (insert)"
  on public.routes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users manage their own routes (update)" on public.routes;
create policy "Users manage their own routes (update)"
  on public.routes for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage their own routes (delete)" on public.routes;
create policy "Users manage their own routes (delete)"
  on public.routes for delete to authenticated using (auth.uid() = user_id);

alter table public.rides enable row level security;
drop policy if exists "Rides visible per visibility setting" on public.rides;
create policy "Rides visible per visibility setting"
  on public.rides for select to authenticated
  using (
    auth.uid() = user_id
    or visibility = 'public'
    or public.is_admin(auth.uid())
    or (
      visibility = 'followers'
      and exists (select 1 from public.follows f where f.follower_id = auth.uid() and f.following_id = rides.user_id)
    )
    -- Being tagged as "rode with" shares the ride with you regardless of its
    -- visibility — see the ride_tags table comment and the Privacy Policy.
    or exists (select 1 from public.ride_tags t where t.ride_id = rides.id and t.user_id = auth.uid())
  );
drop policy if exists "Users manage their own rides (insert)" on public.rides;
create policy "Users manage their own rides (insert)"
  on public.rides for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users manage their own rides (update)" on public.rides;
create policy "Users manage their own rides (update)"
  on public.rides for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage their own rides (delete)" on public.rides;
create policy "Users manage their own rides (delete)"
  on public.rides for delete to authenticated using (auth.uid() = user_id);

alter table public.segments enable row level security;
drop policy if exists "Segments are readable by any signed-in user" on public.segments;
create policy "Segments are readable by any signed-in user"
  on public.segments for select to authenticated using (true);
drop policy if exists "Users create segments" on public.segments;
create policy "Users create segments"
  on public.segments for insert to authenticated with check (auth.uid() = created_by);
drop policy if exists "Creators and admins manage segments (update)" on public.segments;
create policy "Creators and admins manage segments (update)"
  on public.segments for update to authenticated
  using (auth.uid() = created_by or public.is_admin(auth.uid()))
  with check (auth.uid() = created_by or public.is_admin(auth.uid()));
drop policy if exists "Creators and admins manage segments (delete)" on public.segments;
create policy "Creators and admins manage segments (delete)"
  on public.segments for delete to authenticated
  using (auth.uid() = created_by or public.is_admin(auth.uid()));

alter table public.segment_stars enable row level security;
drop policy if exists "Users see their own starred segments" on public.segment_stars;
create policy "Users see their own starred segments"
  on public.segment_stars for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users star segments" on public.segment_stars;
create policy "Users star segments"
  on public.segment_stars for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users unstar segments" on public.segment_stars;
create policy "Users unstar segments"
  on public.segment_stars for delete to authenticated using (auth.uid() = user_id);

alter table public.segment_efforts enable row level security;
drop policy if exists "Segment efforts are readable by any signed-in user" on public.segment_efforts;
create policy "Segment efforts are readable by any signed-in user"
  on public.segment_efforts for select to authenticated using (true);
drop policy if exists "Users log their own segment efforts" on public.segment_efforts;
create policy "Users log their own segment efforts"
  on public.segment_efforts for insert to authenticated
  with check (
    auth.uid() = user_id
    and exists (select 1 from public.rides r where r.id = ride_id and r.user_id = auth.uid())
  );
drop policy if exists "Users delete their own segment efforts" on public.segment_efforts;
create policy "Users delete their own segment efforts"
  on public.segment_efforts for delete to authenticated using (auth.uid() = user_id);

alter table public.challenges enable row level security;
drop policy if exists "Challenges visible if public, owned, participating, or admin" on public.challenges;
create policy "Challenges visible if public, owned, participating, or admin"
  on public.challenges for select to authenticated
  using (
    is_public = true
    or auth.uid() = created_by
    or public.is_admin(auth.uid())
    or public.is_challenge_participant(id, auth.uid())
  );
drop policy if exists "Users create challenges (gate enforced by trigger)" on public.challenges;
create policy "Users create challenges (gate enforced by trigger)"
  on public.challenges for insert to authenticated with check (auth.uid() = created_by);
drop policy if exists "Creators and admins manage challenges (update)" on public.challenges;
create policy "Creators and admins manage challenges (update)"
  on public.challenges for update to authenticated
  using (auth.uid() = created_by or public.is_admin(auth.uid()))
  with check ((auth.uid() = created_by and is_official = false) or public.is_admin(auth.uid()));
drop policy if exists "Creators and admins manage challenges (delete)" on public.challenges;
create policy "Creators and admins manage challenges (delete)"
  on public.challenges for delete to authenticated
  using (auth.uid() = created_by or public.is_admin(auth.uid()));

alter table public.challenge_participants enable row level security;
drop policy if exists "Challenge participants visible to fellow participants" on public.challenge_participants;
create policy "Challenge participants visible to fellow participants"
  on public.challenge_participants for select to authenticated
  using (
    user_id = auth.uid()
    or public.can_view_challenge(challenge_id, auth.uid())
    or public.is_challenge_participant(challenge_id, auth.uid())
  );
drop policy if exists "Users join challenges" on public.challenge_participants;
create policy "Users join challenges"
  on public.challenge_participants for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users and the system update their own participation row" on public.challenge_participants;
create policy "Users and the system update their own participation row"
  on public.challenge_participants for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users leave challenges" on public.challenge_participants;
create policy "Users leave challenges"
  on public.challenge_participants for delete to authenticated using (auth.uid() = user_id);

alter table public.badges enable row level security;
drop policy if exists "Badges are readable by any signed-in user" on public.badges;
create policy "Badges are readable by any signed-in user"
  on public.badges for select to authenticated using (true);
drop policy if exists "Only admins manage the badge catalog (insert)" on public.badges;
create policy "Only admins manage the badge catalog (insert)"
  on public.badges for insert to authenticated with check (public.is_admin(auth.uid()));
drop policy if exists "Only admins manage the badge catalog (update)" on public.badges;
create policy "Only admins manage the badge catalog (update)"
  on public.badges for update to authenticated using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));
drop policy if exists "Only admins manage the badge catalog (delete)" on public.badges;
create policy "Only admins manage the badge catalog (delete)"
  on public.badges for delete to authenticated using (public.is_admin(auth.uid()));

alter table public.user_badges enable row level security;
drop policy if exists "Trophy cases are readable by any signed-in user" on public.user_badges;
create policy "Trophy cases are readable by any signed-in user"
  on public.user_badges for select to authenticated using (true);
drop policy if exists "Only admins can directly award a badge" on public.user_badges;
create policy "Only admins can directly award a badge"
  on public.user_badges for insert to authenticated with check (public.is_admin(auth.uid()));
drop policy if exists "Only admins can revoke a badge" on public.user_badges;
create policy "Only admins can revoke a badge"
  on public.user_badges for delete to authenticated using (public.is_admin(auth.uid()));

alter table public.follows enable row level security;
drop policy if exists "Follow graph is readable by any signed-in user" on public.follows;
create policy "Follow graph is readable by any signed-in user"
  on public.follows for select to authenticated using (true);
drop policy if exists "Users follow people" on public.follows;
create policy "Users follow people"
  on public.follows for insert to authenticated with check (auth.uid() = follower_id);
drop policy if exists "Users unfollow people" on public.follows;
create policy "Users unfollow people"
  on public.follows for delete to authenticated using (auth.uid() = follower_id);

alter table public.kudos enable row level security;
drop policy if exists "Kudos visible if the underlying ride is visible" on public.kudos;
create policy "Kudos visible if the underlying ride is visible"
  on public.kudos for select to authenticated
  using (exists (select 1 from public.rides r where r.id = kudos.ride_id));
drop policy if exists "Users give kudos" on public.kudos;
create policy "Users give kudos"
  on public.kudos for insert to authenticated
  with check (auth.uid() = user_id and exists (select 1 from public.rides r where r.id = ride_id));
drop policy if exists "Users remove their own kudos" on public.kudos;
create policy "Users remove their own kudos"
  on public.kudos for delete to authenticated using (auth.uid() = user_id);

alter table public.ride_comments enable row level security;
drop policy if exists "Comments visible if the underlying ride is visible" on public.ride_comments;
create policy "Comments visible if the underlying ride is visible"
  on public.ride_comments for select to authenticated
  using (exists (select 1 from public.rides r where r.id = ride_comments.ride_id));
drop policy if exists "Users comment on rides they can see" on public.ride_comments;
create policy "Users comment on rides they can see"
  on public.ride_comments for insert to authenticated
  with check (auth.uid() = user_id and exists (select 1 from public.rides r where r.id = ride_id));
drop policy if exists "Users edit their own comments" on public.ride_comments;
create policy "Users edit their own comments"
  on public.ride_comments for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users and admins delete comments" on public.ride_comments;
create policy "Users and admins delete comments"
  on public.ride_comments for delete to authenticated using (auth.uid() = user_id or public.is_admin(auth.uid()));

alter table public.ride_tags enable row level security;
drop policy if exists "Ride tags visible if the underlying ride is visible" on public.ride_tags;
create policy "Ride tags visible if the underlying ride is visible"
  on public.ride_tags for select to authenticated
  using (exists (select 1 from public.rides r where r.id = ride_tags.ride_id));
drop policy if exists "Ride owners tag riders who rode with them" on public.ride_tags;
create policy "Ride owners tag riders who rode with them"
  on public.ride_tags for insert to authenticated
  with check (
    auth.uid() = tagged_by
    and exists (select 1 from public.rides r where r.id = ride_id and r.user_id = auth.uid())
  );
drop policy if exists "Tagged riders or the ride owner can remove a tag" on public.ride_tags;
create policy "Tagged riders or the ride owner can remove a tag"
  on public.ride_tags for delete to authenticated
  using (
    auth.uid() = user_id
    or exists (select 1 from public.rides r where r.id = ride_id and r.user_id = auth.uid())
    or public.is_admin(auth.uid())
  );

alter table public.devices enable row level security;
drop policy if exists "Users manage their own devices (select)" on public.devices;
create policy "Users manage their own devices (select)"
  on public.devices for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users manage their own devices (insert)" on public.devices;
create policy "Users manage their own devices (insert)"
  on public.devices for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users manage their own devices (update)" on public.devices;
create policy "Users manage their own devices (update)"
  on public.devices for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage their own devices (delete)" on public.devices;
create policy "Users manage their own devices (delete)"
  on public.devices for delete to authenticated using (auth.uid() = user_id);

alter table public.recording_devices enable row level security;
drop policy if exists "Users manage their own recording devices (select)" on public.recording_devices;
create policy "Users manage their own recording devices (select)"
  on public.recording_devices for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users manage their own recording devices (insert)" on public.recording_devices;
create policy "Users manage their own recording devices (insert)"
  on public.recording_devices for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users manage their own recording devices (update)" on public.recording_devices;
create policy "Users manage their own recording devices (update)"
  on public.recording_devices for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage their own recording devices (delete)" on public.recording_devices;
create policy "Users manage their own recording devices (delete)"
  on public.recording_devices for delete to authenticated using (auth.uid() = user_id);


-- -----------------------------------------------------------------------------
-- 9. STORAGE (avatars, ride photos, challenge cover images)
-- -----------------------------------------------------------------------------
-- All three buckets are PUBLIC (readable by anyone with the URL, no auth
-- required) so photos show up in shared links and the feed without a signed
-- URL round-trip. Writes are restricted by the policies below: a file must
-- live under a path starting with the uploader's own user id, e.g.
-- `avatars/<user_id>/photo.jpg`.

insert into storage.buckets (id, name, public)
values
  ('avatars', 'avatars', true),
  ('ride-photos', 'ride-photos', true),
  ('challenge-covers', 'challenge-covers', true)
on conflict (id) do nothing;

drop policy if exists "Public read: avatars" on storage.objects;
create policy "Public read: avatars"
  on storage.objects for select to public using (bucket_id = 'avatars');
drop policy if exists "Owners upload their own avatar" on storage.objects;
create policy "Owners upload their own avatar"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and split_part(name, '/', 1) = auth.uid()::text);
drop policy if exists "Owners update their own avatar" on storage.objects;
create policy "Owners update their own avatar"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and split_part(name, '/', 1) = auth.uid()::text);
drop policy if exists "Owners delete their own avatar" on storage.objects;
create policy "Owners delete their own avatar"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and split_part(name, '/', 1) = auth.uid()::text);

drop policy if exists "Public read: ride photos" on storage.objects;
create policy "Public read: ride photos"
  on storage.objects for select to public using (bucket_id = 'ride-photos');
drop policy if exists "Owners upload their own ride photos" on storage.objects;
create policy "Owners upload their own ride photos"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'ride-photos' and split_part(name, '/', 1) = auth.uid()::text);
drop policy if exists "Owners update their own ride photos" on storage.objects;
create policy "Owners update their own ride photos"
  on storage.objects for update to authenticated
  using (bucket_id = 'ride-photos' and split_part(name, '/', 1) = auth.uid()::text);
drop policy if exists "Owners delete their own ride photos" on storage.objects;
create policy "Owners delete their own ride photos"
  on storage.objects for delete to authenticated
  using (bucket_id = 'ride-photos' and split_part(name, '/', 1) = auth.uid()::text);

drop policy if exists "Public read: challenge covers" on storage.objects;
create policy "Public read: challenge covers"
  on storage.objects for select to public using (bucket_id = 'challenge-covers');
drop policy if exists "Admins manage challenge covers (insert)" on storage.objects;
create policy "Admins manage challenge covers (insert)"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'challenge-covers' and public.is_admin(auth.uid()));
drop policy if exists "Admins manage challenge covers (update)" on storage.objects;
create policy "Admins manage challenge covers (update)"
  on storage.objects for update to authenticated
  using (bucket_id = 'challenge-covers' and public.is_admin(auth.uid()));
drop policy if exists "Admins manage challenge covers (delete)" on storage.objects;
create policy "Admins manage challenge covers (delete)"
  on storage.objects for delete to authenticated
  using (bucket_id = 'challenge-covers' and public.is_admin(auth.uid()));


-- -----------------------------------------------------------------------------
-- 10. SEED DATA — badge catalog
-- -----------------------------------------------------------------------------
insert into public.badges (slug, name, description, icon, criteria_type, criteria_value) values
  ('first-ride',        'First Pedal',         'Logged your first ride with Bunch.',                     '🚲', 'total_rides',            1),
  ('rides-10',          'Regular',              'Logged 10 rides.',                                       '🔁', 'total_rides',            10),
  ('rides-50',          'Dedicated',            'Logged 50 rides.',                                       '🏆', 'total_rides',            50),
  ('rides-100',         'Road Warrior',         'Logged 100 rides.',                                      '⚔️', 'total_rides',            100),
  ('half-century-ride', 'Half-Century Hero',    'Rode 50 km in a single ride.',                           '🥈', 'single_ride_distance_m', 50000),
  ('century-ride',      'Century Club',         'Rode 100 km in a single ride.',                          '🥇', 'single_ride_distance_m', 100000),
  ('distance-500',      '500 Club',             'Reached 500 km total distance.',                         '📍', 'total_distance_m',       500000),
  ('distance-1000',     'Kilometre Crusher',    'Reached 1,000 km total distance.',                       '🚀', 'total_distance_m',       1000000),
  ('distance-5000',     'Lifer',                'Reached 5,000 km total distance.',                       '🌍', 'total_distance_m',       5000000),
  ('climber-1000',      'Climber',              'Climbed 1,000 m total elevation.',                       '⛰️', 'total_elevation_m',      1000),
  ('climber-10000',     'High Alpine',          'Climbed 10,000 m total elevation.',                      '🏔️', 'total_elevation_m',      10000),
  ('big-climb',         'Mountain Goat',        'Climbed 1,000 m of elevation in a single ride.',         '🐐', 'single_ride_elevation_m', 1000),
  ('streak-7',          'Week Streak',          'Hit your target 7 days in a row.',                       '🔥', 'longest_streak',        7),
  ('streak-30',         'Iron Streak',          'Hit your target 30 days in a row.',                      '🔥', 'longest_streak',        30),
  ('streak-100',        'Unstoppable',          'Hit your target 100 days in a row.',                     '💎', 'longest_streak',        100),
  ('challenger-1',      'Challenge Finisher',   'Completed your first challenge.',                        '🎯', 'challenges_completed',  1),
  ('challenger-5',      'Challenge Veteran',    'Completed 5 challenges.',                                '🎖️', 'challenges_completed',  5)
on conflict (slug) do nothing;

commit;

-- =============================================================================
-- 11. ADMIN DASHBOARD STATS (added for the admin web app)
-- =============================================================================
-- A single SECURITY DEFINER RPC instead of a security_invoker view: the
-- dashboard needs SUMs (total distance/elevation ridden platform-wide), and
-- PostgREST/Supabase-js can't express an aggregate-only select portably
-- across project versions the way the existing `select=count` head-queries
-- (used for the plain row counts below) can. The function checks is_admin()
-- itself and raises if the caller isn't one, so it stays safe to expose via
-- RPC to the `authenticated` role without any extra grant. CREATE OR REPLACE
-- is natively idempotent — safe to re-run on its own any time.
create or replace function public.admin_dashboard_stats()
returns table (
  total_users bigint,
  premium_users bigint,
  admin_users bigint,
  total_rides bigint,
  total_distance_m numeric,
  total_elevation_m numeric,
  active_challenges bigint,
  total_badges bigint
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin(auth.uid()) then
    raise exception 'admin_dashboard_stats() is admin-only';
  end if;

  return query
  select
    (select count(*) from public.profiles),
    (select count(*) from public.profiles where is_premium = true),
    (select count(*) from public.profiles where is_admin = true),
    (select count(*) from public.rides),
    (select coalesce(sum(distance_m), 0) from public.rides),
    (select coalesce(sum(elevation_gain_m), 0) from public.rides),
    (select count(*) from public.challenges where end_date >= current_date),
    (select count(*) from public.badges);
end;
$$;
comment on function public.admin_dashboard_stats() is 'Platform-wide counts + sums for the admin web app dashboard. Admin-only — raises for anyone else.';

-- =============================================================================
-- MAKE YOURSELF AN ADMIN  (do this once, manually, after you sign up)
-- =============================================================================
-- 1. Build/run the mobile app and sign up for a normal account (or sign up
--    from the admin web app — it uses the same sign-up flow).
-- 2. Back here in the SQL Editor, run:
--
--      select id, username from public.profiles;
--
--    to find your new account's id, then run (swap in your real id):
--
--      update public.profiles set is_admin = true where id = 'paste-your-uuid-here';
--
-- 3. Sign in to the admin web app with that same account. You can now create
--    official challenges (with a cover image) and upgrade other users to
--    premium from there, manage the badge catalog, moderate ride comments —
--    and you can promote further admins the same way (repeat step 2), or
--    from the admin web app once you're in, since is_admin(auth.uid()) now
--    lets your account update anyone's `profiles` row.
-- =============================================================================
