-- =============================================================================
-- Bunch — schema_v3.sql  (run AFTER schema.sql and schema_v2.sql)
-- =============================================================================
-- Append-only and idempotent, same as v2: every statement is `if not exists`,
-- `create or replace`, or guarded by `drop ... if exists`, so running the file
-- twice (or partway, after a failure) is safe.
--
-- What this adds, and the screen that actually uses each piece (nothing here
-- is speculative — if the UI doesn't read it, it isn't in this file):
--
--   1. ride_highlights     — named photo spots pinned to a ride's route
--                            (Ride detail ▸ Highlights tab, Record ▸ "Create
--                            Highlight" while riding)
--   2. rides.speed_samples — downsampled [distance_m, speed_mps] pairs so the
--                            Ride detail ▸ Speed tab can draw a real speed
--                            profile. Elevation already comes from
--                            route_geojson's altitude values.
--   3. profiles.riding_styles — the style chips on the profile header
--                            (Road / Gravel / Mountain / ...), edited in
--                            Settings ▸ Favorite riding styles
--   4. route_ride_counts   — how many riders have ridden each public route
--                            (the participant count on Routes ▸ explore cards)
--   5. Events tab          — NO new table: the Home "Events" tab is the
--                            existing public `challenges`.

-- =============================================================================
-- 1. Ride highlights
-- =============================================================================
create table if not exists public.ride_highlights (
  id          uuid primary key default gen_random_uuid(),
  ride_id     uuid not null references public.rides(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  name        text not null default '',
  photo_url   text,
  lat         double precision,
  lng         double precision,
  created_at  timestamptz not null default now(),
  constraint highlight_name_len check (char_length(name) <= 80)
);
create index if not exists ride_highlights_ride_idx on public.ride_highlights (ride_id, created_at);
create index if not exists ride_highlights_user_idx on public.ride_highlights (user_id);

alter table public.ride_highlights enable row level security;

-- Visible whenever the ride itself is visible to the viewer: the sub-select
-- runs under the viewer's own RLS on public.rides, so a private ride's
-- highlights stay private with no extra rule to keep in sync.
drop policy if exists "Highlights visible with their ride" on public.ride_highlights;
create policy "Highlights visible with their ride"
  on public.ride_highlights for select to authenticated
  using (exists (select 1 from public.rides r where r.id = ride_highlights.ride_id));

drop policy if exists "Owners add highlights to their rides" on public.ride_highlights;
create policy "Owners add highlights to their rides"
  on public.ride_highlights for insert to authenticated
  with check (
    auth.uid() = user_id
    and exists (select 1 from public.rides r where r.id = ride_id and r.user_id = auth.uid())
  );

drop policy if exists "Owners edit their highlights" on public.ride_highlights;
create policy "Owners edit their highlights"
  on public.ride_highlights for update to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Owners delete their highlights" on public.ride_highlights;
create policy "Owners delete their highlights"
  on public.ride_highlights for delete to authenticated
  using (auth.uid() = user_id or public.is_admin(auth.uid()));

-- Photos reuse the existing public `ride-photos` bucket and its
-- owner-folder upload policy (schema.sql §9) — no new bucket.

-- =============================================================================
-- 2. Speed profile samples on rides
-- =============================================================================
-- jsonb array of [distance_m, speed_mps] pairs, capped client-side at ~200
-- points. Null on rides recorded before v1.3 or imported from GPX without
-- timestamps; the Speed tab then shows an honest "no speed data" state.
alter table public.rides add column if not exists speed_samples jsonb;

-- =============================================================================
-- 3. Riding styles on profiles
-- =============================================================================
alter table public.profiles add column if not exists riding_styles text[] not null default '{}';

do $$ begin
  alter table public.profiles add constraint riding_styles_valid
    check (riding_styles <@ array['road','gravel','mountain','commute','ebike','indoor']::text[]);
exception when duplicate_object then null; end $$;

-- =============================================================================
-- 4. Ride counts per public route
-- =============================================================================
-- security_invoker so the counts respect each viewer's RLS on rides: you only
-- ever count rides you're allowed to see, never leaking a private ride.
create or replace view public.route_ride_counts
with (security_invoker = true) as
  select r.route_id, count(*)::int as ride_count, count(distinct r.user_id)::int as rider_count
  from public.rides r
  where r.route_id is not null
  group by r.route_id;

comment on view public.route_ride_counts is 'Per-route number of rides and distinct riders the current viewer can see. Used for the participant count on Routes explore cards.';
grant select on public.route_ride_counts to authenticated;
