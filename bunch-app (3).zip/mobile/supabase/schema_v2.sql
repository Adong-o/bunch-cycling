-- =============================================================================
-- Bunch — schema v2 (the 1.2.1 update)
-- =============================================================================
-- Run this ONCE in the Supabase SQL Editor, AFTER schema.sql has already been
-- run on this project. It does not replace schema.sql or stand on its own —
-- it's a migration that patches a few tables/policies and adds a few new ones
-- on top of what's already there. Safe to re-run (every statement below is
-- either `create or replace`, `drop ... if exists` + `create`, or
-- `add column if not exists`), so if something fails partway through you can
-- fix it and just run the whole file again.
--
-- A quick note on naming: this is called "schema v2" because that's genuinely
-- the clearest way to think about it from the outside — "everything new since
-- 1.2.0, in one file, that runs alongside the original." Technically it's a
-- migration file rather than a second, parallel copy of the schema (there's
-- only ever one real `rides` table, one real `challenges` table, etc. — this
-- file alters the ones schema.sql already created), but that distinction
-- doesn't change how you use it: paste schema.sql once for a fresh project,
-- then paste this once on top, same as any other update.
--
-- =============================================================================
-- 1. FIX: "infinite recursion detected in policy for relation rides"
-- =============================================================================
-- Root cause: `rides`' own SELECT policy and `ride_tags`' SELECT policy each
-- queried the OTHER table directly. Postgres expands a table's RLS policy
-- textually wherever that table is touched — so reading `rides` pulled in
-- ride_tags' policy, which pulled rides' policy back in, which pulled
-- ride_tags' policy in again, forever, until Postgres detected the cycle and
-- raised exactly the error you saw.
--
-- This wasn't only breaking challenge-joining and ride-saving (saving a ride
-- fails because most clients do `insert(...).select()`, which evaluates the
-- SELECT policy on the row it just inserted; joining a challenge fails
-- because recompute_challenge_progress() reads from `rides` right after).
-- The same cycle was also reachable — just not yet reported, because you
-- likely hadn't exercised these yet — from: giving kudos, commenting on a
-- ride, tagging/untagging a "rode with" rider, and logging a segment effort,
-- since all of those also do a plain `exists (select 1 from rides ...)`
-- somewhere in their own policies.
--
-- The fix follows the exact pattern already used for the analogous
-- challenges/challenge_participants cycle (see is_challenge_participant() /
-- can_view_challenge() in schema.sql): one SECURITY DEFINER helper function
-- that answers "can this user see this ride" by querying rides and ride_tags
-- directly. A SECURITY DEFINER function runs as its owner, who isn't subject
-- to RLS, so its internal queries never re-enter any policy — no cycle.
--
-- Both rides' and ride_tags' SELECT policies now call this one function
-- instead of querying each other, which breaks the cycle at its root. Every
-- other place listed above just does a plain select against `rides` or
-- `ride_tags`, so fixing these two policies fixes all of them too — nothing
-- else needs to change.

create or replace function public.can_view_ride(p_ride_id uuid, p_user_id uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.rides r
    where r.id = p_ride_id
      and (
        r.user_id = p_user_id
        or r.visibility = 'public'
        or public.is_admin(p_user_id)
        or (
          r.visibility = 'followers'
          and exists (
            select 1 from public.follows f
            where f.follower_id = p_user_id and f.following_id = r.user_id
          )
        )
        -- Being tagged as "rode with" shares the ride with you regardless of
        -- its visibility — same rule as before, just evaluated in here now.
        or exists (
          select 1 from public.ride_tags t
          where t.ride_id = r.id and t.user_id = p_user_id
        )
      )
  );
$$;
comment on function public.can_view_ride(uuid, uuid) is 'SECURITY DEFINER helper that answers "can p_user_id see p_ride_id" — exists only to stop the rides/ride_tags RLS recursion, same idiom as can_view_challenge(). Called from both rides'' and ride_tags'' SELECT policies instead of each table querying the other directly.';

drop policy if exists "Rides visible per visibility setting" on public.rides;
create policy "Rides visible per visibility setting"
  on public.rides for select to authenticated
  using (public.can_view_ride(id, auth.uid()));

drop policy if exists "Ride tags visible if the underlying ride is visible" on public.ride_tags;
create policy "Ride tags visible if the underlying ride is visible"
  on public.ride_tags for select to authenticated
  using (public.can_view_ride(ride_id, auth.uid()));

-- =============================================================================
-- 2. Featured challenges (auto-advancing carousel on the Feed)
-- =============================================================================
-- Admins can mark a PUBLIC challenge as featured; it then shows as a card in
-- the Feed's featured carousel. No RLS changes needed — the existing
-- "Creators and admins manage challenges (update)" policy already lets any
-- admin update any challenge, which covers flipping this column.
-- featured_implies_public stops a private challenge from ever being featured
-- (and shown to people who couldn't join it anyway) even by mistake.

alter table public.challenges add column if not exists is_featured boolean not null default false;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'featured_implies_public'
  ) then
    alter table public.challenges
      add constraint featured_implies_public check (not is_featured or is_public);
  end if;
end $$;

create index if not exists idx_challenges_featured on public.challenges(is_featured) where is_featured = true;

-- =============================================================================
-- 3. Public waitlist (website email capture)
-- =============================================================================
-- Visitors on the marketing site (anonymous, no account) submit their email
-- to join the waitlist from the landing page. Only admins can read the list
-- back, to follow up later — same is_admin() helper as everywhere else.

create table if not exists public.waitlist (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  name text,
  created_at timestamptz not null default now()
);

create unique index if not exists idx_waitlist_email on public.waitlist (lower(email));

alter table public.waitlist enable row level security;

drop policy if exists "Anyone can join the waitlist" on public.waitlist;
create policy "Anyone can join the waitlist"
  on public.waitlist for insert to anon, authenticated
  with check (true);

drop policy if exists "Admins can view the waitlist" on public.waitlist;
create policy "Admins can view the waitlist"
  on public.waitlist for select to authenticated
  using (public.is_admin(auth.uid()));

-- =============================================================================
-- 4. More badges — lower-tier "early win" milestones
-- =============================================================================
-- check_and_award_badges() (schema.sql) already loops over every row in
-- public.badges and checks it against the rider's current totals, so a new
-- tier of a criteria_type it already understands needs no function or
-- constraint change — just a seed row. These four fill the biggest early-ride
-- gaps in the original 16-badge catalog (seeded in schema.sql, section 10):
-- total_rides jumped straight from 1 to 10, total_distance_m from nothing to
-- 500 km, total_elevation_m from nothing to 1,000 m, and longest_streak from
-- nothing to 7 days — all too far out for a brand-new free-tier rider to
-- reach quickly. A rider who earns nothing for their first couple of weeks
-- is a rider who may churn before Premium ever comes up; these give an
-- earlier, easier first (and second) badge.

insert into public.badges (slug, name, description, icon, criteria_type, criteria_value) values
  ('rides-25',      'On a Roll',    'Logged 25 rides.',                  '🚴', 'total_rides',       25),
  ('distance-100',  'First 100',    'Reached 100 km total distance.',    '🏁', 'total_distance_m',  100000),
  ('elevation-100', 'First Climb',  'Climbed 100 m total elevation.',    '🚵', 'total_elevation_m', 100),
  ('streak-3',      'First Streak', 'Hit your target 3 days in a row.',  '✨', 'longest_streak',    3)
on conflict (slug) do nothing;

-- =============================================================================
-- 5. Real per-badge icons on the Badges screen (mobile client note)
-- =============================================================================
-- No schema change here — just a pointer for anyone reading this file end to
-- end. public.badges.icon has always held a distinct emoji per badge
-- (🚲🔁🏆⚔️🥈🥇📍🚀🌍⛰️🏔️🐐🔥💎🎯🎖️, plus the four above), but
-- mobile/src/screens/profile/BadgesScreen.tsx was rendering every badge —
-- earned or not — with the same generic ribbon/lock icon and never actually
-- reading this column. Fixed client-side as part of this same update
-- (BadgesScreen.tsx now renders badge.icon directly, dimmed when locked);
-- no migration needed for that half of the fix.

