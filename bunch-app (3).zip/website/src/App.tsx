import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/state/AuthContext';
import { Layout } from '@/components/Layout';
import { LoadingView } from '@/components/LoadingView';
import { AccessGate } from '@/components/AccessGate';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { UsersPage } from '@/pages/UsersPage';
import { ChallengesPage } from '@/pages/ChallengesPage';
import { BadgesPage } from '@/pages/BadgesPage';
import { ModerationPage } from '@/pages/ModerationPage';
import { WaitlistPage } from '@/pages/WaitlistPage';
import { HomePage } from '@/pages/HomePage';
import { PrivacyPage } from '@/pages/PrivacyPage';
import { TermsPage } from '@/pages/TermsPage';

// Two halves under one roof: the public marketing site at the root (what
// Bunch is, what it costs, the legal pages) and the admin console nested
// entirely under /admin. AuthProvider wraps both, but it never blocks a
// render — HomePage/PrivacyPage/TermsPage don't call useAuth() at all, so a
// visitor never waits on a Supabase session check to see the marketing site.
export default function App() {
  return (
    <AuthProvider>
      <Routes>
        {/* Public marketing site */}
        <Route path="/" element={<HomePage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/terms" element={<TermsPage />} />

        {/* Admin console — same Supabase project, same anon key, gated by
            each account's own profiles.is_admin via RLS. See lib/supabase.ts. */}
        <Route path="/admin/login" element={<LoginGateway />} />
        <Route path="/admin" element={<ProtectedShell />}>
          <Route index element={<DashboardPage />} />
          <Route path="users" element={<UsersPage />} />
          <Route path="challenges" element={<ChallengesPage />} />
          <Route path="badges" element={<BadgesPage />} />
          <Route path="moderation" element={<ModerationPage />} />
          <Route path="waitlist" element={<WaitlistPage />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  );
}

/** Gatekeeper for every /admin/* route except /admin/login: resolves auth,
 * bounces signed-out visitors to /admin/login, and stops a signed-in-but-
 * non-admin account at AccessGate instead of rendering any admin screen or
 * data fetch. */
function ProtectedShell() {
  const { loading, session, isAdmin } = useAuth();
  if (loading) return <LoadingView label="Loading Bunch Admin…" />;
  if (!session) return <Navigate to="/admin/login" replace />;
  if (!isAdmin) return <AccessGate />;
  return <Layout />;
}

function LoginGateway() {
  const { loading, session, isAdmin } = useAuth();
  if (loading) return <LoadingView label="Loading Bunch Admin…" />;
  if (session && isAdmin) return <Navigate to="/admin" replace />;
  if (session && !isAdmin) return <AccessGate />;
  return <LoginPage />;
}
