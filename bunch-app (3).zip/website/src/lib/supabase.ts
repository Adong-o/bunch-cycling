import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY. Check website/.env (see .env.example).');
}

// Same project, same anon key as the mobile app — there is no service_role
// key anywhere in this app. Every admin action (granting Premium, creating
// an official challenge, editing the badge catalog, promoting an admin)
// works purely because RLS policies in mobile/supabase/schema.sql check
// is_admin(auth.uid()) against the signed-in user's own profile row. See
// prevent_privilege_escalation() and the policy comments in schema.sql.
// The public marketing pages (Home, Privacy, Terms) never touch this
// client at all — only the /admin/* routes do.
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
});
