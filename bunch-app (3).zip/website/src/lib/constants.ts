// Single source of truth for the real, enforced numbers shown on the
// marketing site — sourced from mobile/src/screens/profile/PremiumScreen.tsx
// and mobile/src/lib/api/{bikes,routes,segments}.ts. Nothing on the site
// invents a figure that isn't already true in the app.
export const PREMIUM_MONTHLY_PRICE = '$4.99';
// 12 x $4.99 = $59.88; 8% off = $55.09.
export const PREMIUM_YEARLY_PRICE = '$55.09';
export const PREMIUM_YEARLY_DISCOUNT = '8%';
export const FREE_BIKE_LIMIT = '2';
export const FREE_ROUTE_LIMIT = '3';
export const FREE_SEGMENT_LIMIT = '5';
export const FREE_DEVICE_LIMIT = '1';

// Real, monitored support/contact address for Bunch.
export const SUPPORT_EMAIL = 'adongoabc@proton.me';
