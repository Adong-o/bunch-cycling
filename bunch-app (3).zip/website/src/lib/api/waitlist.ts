import { supabase } from '@/lib/supabase';
import type { Waitlist } from '@/lib/database.types';

/** Postgres unique-violation — thrown when an email already exists, since
 * idx_waitlist_email (schema_v2.sql) is a unique index on lower(email). */
const DUPLICATE_EMAIL_CODE = '23505';

/** Called from the public marketing site — no auth required. Insert-only,
 * per the "Anyone can join the waitlist" RLS policy in schema_v2.sql: a
 * visitor can add a row but can never read the list back (that needs
 * is_admin(), see listWaitlist below). A repeat signup with the same email
 * hits the unique index and becomes a friendly message instead of a raw
 * database error, so the caller doesn't need its own special-case logic. */
export async function joinWaitlist(email: string, name?: string): Promise<void> {
  const { error } = await supabase.from('waitlist').insert({
    email: email.trim().toLowerCase(),
    name: name?.trim() || null,
  });
  if (error) {
    if (error.code === DUPLICATE_EMAIL_CODE) {
      throw new Error("You're already on the list — we'll be in touch.");
    }
    throw error;
  }
}

/** Admin-only, per the "Admins can view the waitlist" RLS policy — most
 * recent signups first, so the admin page can see who just joined. */
export async function listWaitlist(): Promise<Waitlist[]> {
  const { data, error } = await supabase.from('waitlist').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}
