import { supabase } from '@/lib/supabase';
import type { Profile } from '@/lib/database.types';

const PAGE_SIZE = 40;

export async function listUsers({ query, offset = 0 }: { query?: string; offset?: number }): Promise<{ rows: Profile[]; hasMore: boolean }> {
  let q = supabase.from('profiles').select('*').order('created_at', { ascending: false }).range(offset, offset + PAGE_SIZE - 1);
  if (query?.trim()) {
    const term = query.trim().toLowerCase();
    q = q.or(`username.ilike.%${term}%,display_name.ilike.%${term}%`);
  }
  const { data, error } = await q;
  if (error) throw error;
  return { rows: data ?? [], hasMore: (data?.length ?? 0) === PAGE_SIZE };
}

/** Relies entirely on the profiles RLS policy + prevent_privilege_escalation()
 * trigger in schema.sql — the caller's own `is_admin` row makes this work,
 * no service_role key involved. A non-admin's write would just have the
 * privileged fields silently stripped by that trigger. */
export async function setPremium(userId: string, isPremium: boolean): Promise<Profile> {
  const patch: { is_premium: boolean; premium_since?: string } = { is_premium: isPremium };
  if (isPremium) patch.premium_since = new Date().toISOString();
  const { data, error } = await supabase.from('profiles').update(patch).eq('id', userId).select('*').single();
  if (error) throw error;
  return data;
}

export async function setAdmin(userId: string, isAdmin: boolean): Promise<Profile> {
  const { data, error } = await supabase.from('profiles').update({ is_admin: isAdmin }).eq('id', userId).select('*').single();
  if (error) throw error;
  return data;
}
