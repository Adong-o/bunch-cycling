import { supabase } from '@/lib/supabase';
import type { RideComment } from '@/lib/database.types';

export type CommentWithContext = RideComment & {
  author: { username: string; display_name: string; avatar_url: string | null } | null;
  ride: { title: string } | null;
};

type RawRow = RideComment & {
  profiles: { username: string; display_name: string; avatar_url: string | null } | null;
  rides: { title: string } | null;
};

export async function listRecentComments(limit = 60): Promise<CommentWithContext[]> {
  const { data, error } = await supabase
    .from('ride_comments')
    .select('*, profiles(username, display_name, avatar_url), rides(title)')
    .order('created_at', { ascending: false })
    .limit(limit)
    .returns<RawRow[]>();
  if (error) throw error;
  return (data ?? []).map(({ profiles, rides, ...rest }) => ({ ...rest, author: profiles, ride: rides }));
}

/** Admin bypass is built into the ride_comments RLS delete policy directly
 * (`auth.uid() = user_id or public.is_admin(auth.uid())`) — same no-service-key
 * pattern as everything else in this app. */
export async function deleteComment(id: string): Promise<void> {
  const { error } = await supabase.from('ride_comments').delete().eq('id', id);
  if (error) throw error;
}
