import { supabase } from '@/lib/supabase';
import type { Challenge, ChallengeType, TablesInsert, TablesUpdate } from '@/lib/database.types';

export type ChallengeWithCount = Challenge & { participant_count: number };

type RawRow = Challenge & { challenge_participants: { count: number }[] };

export async function listChallenges(): Promise<ChallengeWithCount[]> {
  // is_admin(auth.uid()) in the challenges RLS select policy means an admin
  // sees every challenge here, not just public/official ones — needed so
  // this page can also moderate user-created challenges.
  const { data, error } = await supabase
    .from('challenges')
    .select('*, challenge_participants(count)')
    .order('created_at', { ascending: false })
    .returns<RawRow[]>();
  if (error) throw error;
  return (data ?? []).map(({ challenge_participants, ...rest }) => ({
    ...rest,
    participant_count: challenge_participants?.[0]?.count ?? 0,
  }));
}

export async function createChallenge(input: TablesInsert<'challenges'>): Promise<Challenge> {
  // invite_code is deliberately omitted — generate_invite_code() fills it
  // server-side on insert (see schema.sql); passing one ourselves would
  // just get overwritten by that trigger's own uniqueness check.
  const { data, error } = await supabase.from('challenges').insert(input).select('*').single();
  if (error) throw error;
  return data;
}

export async function updateChallenge(id: string, patch: TablesUpdate<'challenges'>): Promise<Challenge> {
  const { data, error } = await supabase.from('challenges').update(patch).eq('id', id).select('*').single();
  if (error) throw error;
  return data;
}

/** Featuring only ever applies to public challenges — the DB has a check
 * constraint (featured_implies_public, schema_v2.sql) enforcing this too,
 * so a bad call here fails loudly rather than silently featuring something
 * riders couldn't actually join. */
export async function setChallengeFeatured(id: string, featured: boolean): Promise<Challenge> {
  const { data, error } = await supabase.from('challenges').update({ is_featured: featured }).eq('id', id).select('*').single();
  if (error) throw error;
  return data;
}

export async function deleteChallenge(id: string): Promise<void> {
  const { error } = await supabase.from('challenges').delete().eq('id', id);
  if (error) throw error;
}

/** Only admins can write to the challenge-covers bucket (see schema.sql
 * storage policies) — this call fails with a storage RLS error for anyone
 * else, same mechanism as every other admin action in this app. */
export async function uploadChallengeCover(file: File, uploaderId: string): Promise<string> {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const path = `${uploaderId}/${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from('challenge-covers').upload(path, file, {
    contentType: file.type || 'image/jpeg',
    upsert: false,
  });
  if (error) throw error;
  const { data } = supabase.storage.from('challenge-covers').getPublicUrl(path);
  return data.publicUrl;
}

/** Mirrors mobile/src/lib/api/challenges.ts's per-type goal unit semantics,
 * reverse-engineered from recompute_challenge_progress() in schema.sql:
 * distance/elevation in meters, duration in seconds, ride_count as a count.
 * The admin form always works in metric (km/m) — there's no per-admin unit
 * preference the way riders have one. */
export function goalValueToBaseUnits(type: ChallengeType, displayValue: number): number {
  if (type === 'distance') return Math.round(displayValue * 1000); // km -> m
  if (type === 'duration') return Math.round(displayValue * 3600); // hours -> s
  return Math.round(displayValue); // elevation already meters, ride_count already a count
}

export function baseUnitsToGoalValue(type: ChallengeType, baseValue: number): number {
  if (type === 'distance') return Math.round((baseValue / 1000) * 10) / 10;
  if (type === 'duration') return Math.round((baseValue / 3600) * 10) / 10;
  return baseValue;
}

export function goalUnitLabel(type: ChallengeType): string {
  if (type === 'distance') return 'km';
  if (type === 'elevation') return 'm';
  if (type === 'duration') return 'hours';
  return 'rides';
}
