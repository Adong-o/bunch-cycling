import { supabase } from '@/lib/supabase';
import type { Badge, BadgeCriteriaType, TablesInsert, TablesUpdate } from '@/lib/database.types';

export async function listBadges(): Promise<Badge[]> {
  const { data, error } = await supabase.from('badges').select('*').order('criteria_value', { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function createBadge(input: TablesInsert<'badges'>): Promise<Badge> {
  const { data, error } = await supabase.from('badges').insert(input).select('*').single();
  if (error) throw error;
  return data;
}

export async function updateBadge(id: string, patch: TablesUpdate<'badges'>): Promise<Badge> {
  const { data, error } = await supabase.from('badges').update(patch).eq('id', id).select('*').single();
  if (error) throw error;
  return data;
}

export async function deleteBadge(id: string): Promise<void> {
  const { error } = await supabase.from('badges').delete().eq('id', id);
  if (error) throw error;
}

export const CRITERIA_TYPES: Array<{ value: BadgeCriteriaType; label: string }> = [
  { value: 'total_rides', label: 'Total rides' },
  { value: 'total_distance_m', label: 'Total distance' },
  { value: 'total_elevation_m', label: 'Total elevation' },
  { value: 'longest_streak', label: 'Longest streak' },
  { value: 'challenges_completed', label: 'Challenges completed' },
  { value: 'single_ride_distance_m', label: 'Single-ride distance' },
  { value: 'single_ride_elevation_m', label: 'Single-ride elevation' },
];

/** check_and_award_badges() in schema.sql compares criteria_value directly
 * against the rider's running totals, which are stored in meters/seconds —
 * so distance-shaped criteria need a km-to-m conversion for admin-friendly
 * input, same as challenge goals. Elevation and counts need no conversion. */
export function isDistanceCriteria(t: BadgeCriteriaType): boolean {
  return t === 'total_distance_m' || t === 'single_ride_distance_m';
}

export function criteriaUnitLabel(t: BadgeCriteriaType): string {
  if (isDistanceCriteria(t)) return 'km';
  if (t === 'total_elevation_m' || t === 'single_ride_elevation_m') return 'm';
  if (t === 'longest_streak') return 'days';
  if (t === 'challenges_completed') return 'challenges';
  return 'rides';
}

export function criteriaValueToBase(t: BadgeCriteriaType, displayValue: number): number {
  return isDistanceCriteria(t) ? Math.round(displayValue * 1000) : Math.round(displayValue);
}

export function baseToCriteriaValue(t: BadgeCriteriaType, baseValue: number): number {
  return isDistanceCriteria(t) ? Math.round((baseValue / 1000) * 10) / 10 : baseValue;
}
