import { format, formatDistanceToNow } from 'date-fns';

export function formatDistanceM(m: number): string {
  const km = m / 1000;
  return km >= 100 ? `${Math.round(km)} km` : `${km.toFixed(1)} km`;
}

export function formatElevationM(m: number): string {
  return `${Math.round(m)} m`;
}

export function formatDuration(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

export function formatDate(iso: string): string {
  return format(new Date(iso), 'd MMM yyyy');
}

export function formatDateTime(iso: string): string {
  return format(new Date(iso), 'd MMM yyyy, HH:mm');
}

export function formatRelative(iso: string): string {
  return formatDistanceToNow(new Date(iso), { addSuffix: true });
}

/** Challenge progress/goal values are stored in base units per type — mirrors
 * the exact semantics of recompute_challenge_progress() in schema.sql:
 * distance/elevation in meters, duration in seconds, ride_count as a plain count. */
export function formatChallengeValue(type: 'distance' | 'elevation' | 'duration' | 'ride_count', value: number): string {
  if (type === 'distance') return formatDistanceM(value);
  if (type === 'elevation') return formatElevationM(value);
  if (type === 'duration') return formatDuration(value);
  return `${Math.round(value)} ride${value === 1 ? '' : 's'}`;
}

export function challengeTypeLabel(type: 'distance' | 'elevation' | 'duration' | 'ride_count'): string {
  if (type === 'distance') return 'Distance';
  if (type === 'elevation') return 'Elevation';
  if (type === 'duration') return 'Time';
  return 'Ride count';
}
