import React, { useEffect, useMemo, useState } from 'react';
import { listWaitlist } from '@/lib/api/waitlist';
import { Button } from '@/components/Button';
import { LoadingView, EmptyState } from '@/components/LoadingView';
import { IconSearch, IconMail, IconCheck, IconCopy } from '@/components/icons';
import { formatDate } from '@/lib/format';
import { getErrorMessage } from '@/lib/errors';
import type { Waitlist } from '@/lib/database.types';

export function WaitlistPage() {
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState<Waitlist[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await listWaitlist();
      setRows(data);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  // The whole point of this page is "see everyone, reach out later" — the
  // list isn't expected to grow into the thousands the way riders might, so
  // a single fetch + client-side filter keeps this simple rather than
  // reimplementing UsersPage's debounced server search for no real benefit.
  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return rows;
    return rows.filter((r) => r.email.toLowerCase().includes(term) || (r.name ?? '').toLowerCase().includes(term));
  }, [rows, query]);

  async function copyAllEmails() {
    try {
      await navigator.clipboard.writeText(filtered.map((r) => r.email).join('\n'));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      setError(getErrorMessage(e));
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-text-primary">Waitlist</h1>
          <p className="text-sm text-text-tertiary mt-0.5">
            Everyone who requested early access from the site{loading ? '' : ` — ${rows.length} so far`}.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative w-full sm:w-64">
            <IconSearch size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name or email"
              className="w-full bg-surface border border-border rounded-md pl-9 pr-3 py-2.5 text-sm text-text-primary placeholder:text-text-tertiary outline-none focus:border-accent transition-colors"
            />
          </div>
          <Button
            variant="secondary"
            icon={copied ? <IconCheck size={15} /> : <IconCopy size={15} />}
            onClick={copyAllEmails}
            disabled={filtered.length === 0}
          >
            {copied ? 'Copied' : 'Copy all emails'}
          </Button>
        </div>
      </div>

      {error ? <p className="text-sm text-danger bg-danger-muted border border-danger/30 rounded-md px-3 py-2">{error}</p> : null}

      {loading ? (
        <LoadingView />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<IconMail size={22} />}
          title={query ? 'No matches' : 'No one has joined yet'}
          description={query ? 'Try a different search.' : 'New signups from the "Get early access" form will show up here.'}
        />
      ) : (
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="hidden md:grid grid-cols-[1fr_1fr_140px] gap-4 px-4 py-2.5 border-b border-border text-xs font-semibold text-text-tertiary uppercase tracking-wide">
            <span>Email</span>
            <span>Name</span>
            <span>Joined</span>
          </div>
          {filtered.map((w, i) => (
            <div
              key={w.id}
              className="flex flex-col md:grid md:grid-cols-[1fr_1fr_140px] gap-1 md:gap-4 px-4 py-3.5 border-b border-border last:border-b-0 md:items-center hover:bg-surface-high/50 transition-colors animate-[rowIn_0.25s_ease-out_both]"
              style={{ animationDelay: `${Math.min(i, 12) * 25}ms` }}
            >
              <span className="text-sm font-semibold text-text-primary truncate">{w.email}</span>
              <span className="text-sm text-text-secondary truncate">{w.name || '—'}</span>
              <span className="text-xs text-text-secondary md:text-sm">{formatDate(w.created_at)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
