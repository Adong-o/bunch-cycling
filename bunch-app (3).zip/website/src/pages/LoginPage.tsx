import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/state/AuthContext';
import { Button } from '@/components/Button';
import { TextField } from '@/components/TextField';
import { BrandLogo } from '@/components/BrandMark';
import { getErrorMessage } from '@/lib/errors';

export function LoginPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'in' | 'up'>('in');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmNotice, setConfirmNotice] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === 'in') {
        await signIn(email.trim(), password);
      } else {
        const { needsEmailConfirm } = await signUp(email.trim(), password);
        if (needsEmailConfirm) {
          setConfirmNotice(true);
        }
      }
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-bg">
      <div className="w-full max-w-sm animate-[modalIn_0.3s_cubic-bezier(0.16,1,0.3,1)]">
        <div className="flex flex-col items-center mb-8">
          <div className="mb-5">
            <BrandLogo height={40} />
          </div>
          <h1 className="text-xl font-extrabold text-text-primary tracking-tight">Bunch Admin</h1>
          <p className="text-sm text-text-tertiary mt-1">Sign in with your admin account</p>
        </div>

        {confirmNotice ? (
          <div className="bg-surface border border-border rounded-lg p-5 text-center">
            <p className="text-sm text-text-primary font-semibold mb-1">Check your email</p>
            <p className="text-sm text-text-secondary">We sent a confirmation link to {email}. Confirm it, then sign in below.</p>
            <Button variant="secondary" className="mt-4" onClick={() => { setConfirmNotice(false); setMode('in'); }}>
              Back to sign in
            </Button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="bg-surface border border-border rounded-lg p-5 flex flex-col gap-4">
            <TextField
              label="Email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
            />
            <TextField
              label="Password"
              type="password"
              autoComplete={mode === 'in' ? 'current-password' : 'new-password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              minLength={6}
              required
            />
            {error ? <p className="text-sm text-danger">{error}</p> : null}
            <Button type="submit" loading={busy} className="mt-1">
              {mode === 'in' ? 'Sign in' : 'Create account'}
            </Button>
            <p className="text-center text-xs text-text-tertiary">
              {mode === 'in' ? (
                <>
                  Bootstrapping your first admin?{' '}
                  <button type="button" onClick={() => setMode('up')} className="text-accent font-semibold hover:underline">
                    Create an account
                  </button>
                </>
              ) : (
                <>
      Already have one?{' '}
                  <button type="button" onClick={() => setMode('in')} className="text-accent font-semibold hover:underline">
                    Sign in
                  </button>
                </>
              )}
            </p>
          </form>
        )}

        {mode === 'up' && !confirmNotice ? (
          <p className="text-xs text-text-tertiary text-center mt-4 leading-relaxed">
            This creates a normal Bunch account. It won't have admin access until someone flips{' '}
            <code className="font-mono-num text-text-secondary">is_admin</code> on it in Supabase — see the SQL snippet shown after you sign in.
          </p>
        ) : null}

        <Link to="/" className="block text-center text-xs text-text-tertiary hover:text-text-secondary mt-6 transition-colors">
          ← Back to bunchcycling.app
        </Link>
      </div>
    </div>
  );
}
