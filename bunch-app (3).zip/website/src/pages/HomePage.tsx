import React from 'react';
import { MarketingLayout } from '@/components/marketing/MarketingLayout';
import { HeroVisual } from '@/components/marketing/HeroVisual';
import { WaitlistForm } from '@/components/marketing/WaitlistForm';
import { IconRoute, IconMountain, IconFlag, IconUsers, IconBluetooth, IconBike } from '@/components/icons';
import { buildSpeed } from '@/components/marketing/profile';
import {
  PREMIUM_MONTHLY_PRICE,
  PREMIUM_YEARLY_PRICE,
  PREMIUM_YEARLY_DISCOUNT,
  FREE_BIKE_LIMIT,
  FREE_ROUTE_LIMIT,
  FREE_SEGMENT_LIMIT,
  FREE_DEVICE_LIMIT,
} from '@/lib/constants';

const MINI_SPEED = buildSpeed(300, 64, 4, 1, 120);

export function HomePage() {
  return (
    <MarketingLayout>
      <Hero />
      <Statement />
      <Features />
      <HowItWorks />
      <Pricing />
      <Faq />
      <FinalCta />
    </MarketingLayout>
  );
}

function Hero() {
  return (
    <section className="max-w-site mx-auto px-5 md:px-8 pt-14 md:pt-20 pb-16 md:pb-24">
      <div className="max-w-[700px] mx-auto text-center" style={{ animation: 'riseIn 0.6s cubic-bezier(0.16,1,0.3,1) both' }}>
        <span className="inline-flex items-center gap-2 text-xs font-semibold text-text-secondary bg-surface-high border border-border rounded-full px-3 py-1.5 mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-accent" aria-hidden="true" />
          Early access — not yet available on the App Store or Google Play
        </span>

        <h1 className="text-4xl md:text-[3.4rem] leading-[1.08] font-extrabold text-text-primary tracking-tight text-balance">
          The ride tracker built only for cyclists.
        </h1>

        <p className="mt-5 text-lg text-text-secondary leading-relaxed max-w-[520px] mx-auto">
          Precise GPS recording, real elevation breakdowns, fair segment leaderboards, and a crew that rides with
          you — one app, built for cycling alone.
        </p>

        <div id="early-access" className="mt-8 max-w-[560px] mx-auto scroll-mt-24">
          <WaitlistForm variant="full" />
        </div>

        <a
          href="#features"
          className="mt-5 inline-block text-sm font-semibold text-text-secondary hover:text-text-primary transition-colors"
        >
          See what's included
        </a>
      </div>

      <div className="mt-14 md:mt-16">
        <HeroVisual />
      </div>
    </section>
  );
}

function Statement() {
  return (
    <section className="border-y border-border bg-surface-high/60">
      <div className="max-w-site mx-auto px-5 md:px-8 py-16 md:py-20">
        <p className="text-2xl md:text-4xl font-extrabold text-text-primary tracking-tight leading-snug max-w-[820px]">
          Ride tracking built for cyclists, not retrofitted from one app that tries to do everything.
        </p>
      </div>
    </section>
  );
}

const FEATURES = [
  {
    icon: IconRoute,
    title: 'Built for real GPS tracking',
    body: "Every ride records with precise GPS, live pace and distance, and a route that colors in as you go. Lose signal and Bunch keeps recording offline — it syncs the moment you're back.",
  },
  {
    icon: IconMountain,
    title: 'Every climb, broken down',
    body: 'See the full elevation profile for a ride, not just a single gain number — where it climbed, how steep, and where you finally get to stop pedaling.',
  },
  {
    icon: IconFlag,
    title: 'Segments, run fairly',
    body: 'Chase your best time on local climbs and sprints, with e-bike efforts kept on their own leaderboard instead of mixed in with yours.',
  },
  {
    icon: IconUsers,
    title: 'Ride with your crew',
    body: 'Tag the riders you rode with and they show up right on the activity, trade kudos, and follow the people whose rides you actually want to see.',
  },
  {
    icon: IconBluetooth,
    title: "However you record, it's yours",
    body: 'Pair a heart rate, speed, cadence or power sensor over Bluetooth, or log the Garmin, Coros, Wahoo or Apple Watch you rode with — your data stays attached to the ride either way.',
  },
  {
    icon: IconBike,
    title: 'Your garage, your streaks',
    body: "Track mileage per bike, keep a riding streak alive, and earn badges for things you actually did, not for logging in.",
  },
];

function Features() {
  const [primary, ...rest] = FEATURES;
  return (
    <section id="features" className="max-w-site mx-auto px-5 md:px-8 py-20 md:py-28 scroll-mt-20">
      <div className="max-w-[560px] mb-12 md:mb-16">
        <h2 className="text-3xl md:text-4xl font-extrabold text-text-primary tracking-tight">
          Everything a ride needs. Nothing it doesn't.
        </h2>
        <p className="mt-4 text-base text-text-secondary leading-relaxed">
          Six things Bunch does properly, because cycling was the only sport it was ever built for.
        </p>
      </div>

      <div className="grid lg:grid-cols-[minmax(0,420px)_1fr] gap-5 lg:gap-6 items-stretch">
        {/* The one feature that's also the hero's whole pitch gets a stage
            of its own instead of sitting in an identical box with the rest. */}
        <div className="rounded-xl border border-border bg-surface p-8 flex flex-col">
          <div className="w-11 h-11 rounded-md bg-accent-muted flex items-center justify-center text-accent mb-5">
            <primary.icon size={22} />
          </div>
          <h3 className="text-xl font-bold text-text-primary mb-2.5">{primary.title}</h3>
          <p className="text-sm text-text-secondary leading-relaxed">{primary.body}</p>
          <div className="mt-6 pt-6 border-t border-border">
            {/* a mini speed profile: spiky stop-and-go with sprints, the way
                a real recorded ride looks, filled down to its baseline */}
            <svg viewBox="0 0 300 64" preserveAspectRatio="none" className="w-full h-16" fill="none" aria-hidden="true">
              <defs>
                <linearGradient id="miniSpeedArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4D47FC" stopOpacity="0.28" />
                  <stop offset="100%" stopColor="#4D47FC" stopOpacity="0" />
                </linearGradient>
              </defs>
              <line x1="0" x2="300" y1="63" y2="63" stroke="#D8D8D3" strokeWidth="1" vectorEffect="non-scaling-stroke" />
              <path d={MINI_SPEED.area} fill="url(#miniSpeedArea)" />
              <path d={MINI_SPEED.line} stroke="#4D47FC" strokeWidth="1.5" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
            </svg>
            <div className="mt-2 flex justify-between font-mono-num text-[10px] text-text-tertiary">
              <span>0:00</span>
              <span>Max 43.9 km/h</span>
              <span>1:11</span>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-surface divide-y divide-border overflow-hidden">
          {rest.map((f) => (
            <div key={f.title} className="flex items-start gap-4 p-6">
              <div className="w-10 h-10 rounded-md bg-surface-high flex items-center justify-center text-text-secondary shrink-0">
                <f.icon size={18} />
              </div>
              <div className="min-w-0">
                <h3 className="text-base font-bold text-text-primary mb-1.5">{f.title}</h3>
                <p className="text-sm text-text-secondary leading-relaxed">{f.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const STEPS = [
  {
    title: 'Create your free account',
    body: "Sign up with email or Google, answer a couple of quick questions, and you're set up to ride in under a minute.",
  },
  {
    title: 'Record the way you ride',
    body: 'Track with your phone alone, pair your sensors over Bluetooth, or log the GPS watch you used — Bunch keeps recording even if you lose signal.',
  },
  {
    title: 'Build your streak, with your crew',
    body: 'Tag who you rode with, chase segments, join challenges, and watch your streak grow ride after ride.',
  },
];

function HowItWorks() {
  return (
    <section className="bg-surface-high/60 border-y border-border">
      <div className="max-w-site mx-auto px-5 md:px-8 py-20 md:py-28">
        <h2 className="text-3xl md:text-4xl font-extrabold text-text-primary tracking-tight mb-12 md:mb-16 max-w-[520px]">
          Three steps and you're rolling.
        </h2>
        <div className="relative grid md:grid-cols-3 gap-10">
          <div className="hidden md:block absolute top-[18px] left-[calc(100%/6)] right-[calc(100%/6)] h-px bg-border-strong" aria-hidden="true" />
          {STEPS.map((s, i) => (
            <div key={s.title} className="relative">
              <div className="relative z-10 w-9 h-9 rounded-full bg-ink text-cream flex items-center justify-center text-sm font-bold mb-4">
                {i + 1}
              </div>
              <h3 className="text-base font-bold text-text-primary mb-2">{s.title}</h3>
              <p className="text-sm text-text-secondary leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Kept in lockstep with mobile/src/screens/profile/PremiumScreen.tsx's
// FEATURES table — same five rows, same numbers, sourced from the same
// constants.ts so the site can never quote a different plan than the app.
const PRICING_ROWS = [
  { label: 'Bikes in your garage', free: FREE_BIKE_LIMIT, premium: 'Unlimited' },
  { label: 'Saved routes', free: FREE_ROUTE_LIMIT, premium: 'Unlimited' },
  { label: 'Starred segments', free: FREE_SEGMENT_LIMIT, premium: 'Unlimited' },
  { label: 'Recording devices', free: FREE_DEVICE_LIMIT, premium: 'Unlimited' },
  { label: 'Profile badge', free: '—', premium: 'Gold badge' },
];

function Pricing() {
  return (
    <section id="premium" className="max-w-site mx-auto px-5 md:px-8 py-20 md:py-28 scroll-mt-20">
      <div className="max-w-[560px] mb-12 md:mb-16">
        <h2 className="text-3xl md:text-4xl font-extrabold text-text-primary tracking-tight">Simple pricing.</h2>
        <p className="mt-4 text-base text-text-secondary leading-relaxed">
          Free covers the basics for as long as you ride. Premium removes the limits.
        </p>
      </div>

      <div className="grid lg:grid-cols-[1fr_380px] gap-8 items-start">
        <div className="rounded-xl border border-border bg-surface overflow-hidden">
          <div className="flex items-center px-6 py-4 border-b border-border bg-surface-high/60">
            <div className="flex-[1.4]" />
            <span className="flex-1 text-center text-xs font-semibold text-text-tertiary tracking-wide">Free</span>
            <span className="flex-1 text-center text-xs font-semibold text-gold tracking-wide">Premium</span>
          </div>
          {PRICING_ROWS.map((row, i) => (
            <div
              key={row.label}
              className={`flex items-center px-6 py-4 ${i !== PRICING_ROWS.length - 1 ? 'border-b border-border' : ''}`}
            >
              <span className="flex-[1.4] text-sm font-medium text-text-primary">{row.label}</span>
              <span className="flex-1 text-center text-sm text-text-secondary">{row.free}</span>
              <span className="flex-1 text-center text-sm font-semibold text-gold">{row.premium}</span>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-accent/30 bg-accent-muted p-7">
          <p className="text-sm font-semibold text-accent mb-1">Bunch Premium</p>
          <div className="flex items-end gap-1.5 mb-1">
            <span className="text-4xl font-extrabold text-text-primary">{PREMIUM_MONTHLY_PRICE}</span>
            <span className="text-sm font-medium text-text-secondary mb-1">/ month</span>
          </div>
          <p className="text-sm text-text-secondary mb-6">
            or {PREMIUM_YEARLY_PRICE} billed yearly — about {PREMIUM_YEARLY_DISCOUNT} off
          </p>
          <WaitlistForm variant="compact" />
          <p className="mt-4 text-xs text-text-tertiary leading-relaxed">
            In early access, Premium is granted directly by the Bunch team rather than billed automatically —
            in-app billing arrives at launch.
          </p>
        </div>
      </div>
    </section>
  );
}

const FAQS = [
  {
    q: 'Is Bunch available to download yet?',
    a: "Not yet — we're in early access while we finish building. Request early access and we'll let you know the moment Bunch is live on the App Store and Google Play.",
  },
  {
    q: 'How much does Bunch cost?',
    a: `Free covers the basics: ${FREE_BIKE_LIMIT} bikes, ${FREE_ROUTE_LIMIT} saved routes, ${FREE_SEGMENT_LIMIT} starred segments, and ${FREE_DEVICE_LIMIT} recording device. Premium is ${PREMIUM_MONTHLY_PRICE}/month, or ${PREMIUM_YEARLY_PRICE}/year if you pay annually, and removes every limit.`,
  },
  {
    q: 'Does it track rides without a phone signal?',
    a: "Yes. Recording only needs GPS, not a data connection, so your ride keeps recording through dead zones and syncs the moment you're back online.",
  },
  {
    q: 'I already ride with a Garmin, Wahoo, or Coros. What happens to that?',
    a: "Add it to your profile as a recording device and tag it on any ride you import — so it's clear what recorded what, without forcing you to switch computers or lose your history.",
  },
  {
    q: 'Can I get my data out?',
    a: "Every ride can be exported as a GPX file whenever you want it. It's your ride, recorded by you.",
  },
];

function Faq() {
  return (
    <section id="faq" className="bg-surface-high/60 border-y border-border">
      <div className="max-w-site mx-auto px-5 md:px-8 py-20 md:py-28 scroll-mt-20">
        <h2 className="text-3xl md:text-4xl font-extrabold text-text-primary tracking-tight mb-12 md:mb-16 max-w-[520px]">
          Questions, answered.
        </h2>
        <div className="max-w-[720px] flex flex-col gap-3">
          {FAQS.map((item) => (
            <details key={item.q} className="group rounded-lg border border-border bg-surface px-5 py-4">
              <summary className="flex items-center justify-between gap-4 cursor-pointer text-sm font-semibold text-text-primary list-none [&::-webkit-details-marker]:hidden">
                {item.q}
                <span className="shrink-0 text-text-tertiary transition-transform duration-200 group-open:rotate-45 text-lg leading-none">
                  +
                </span>
              </summary>
              <p className="mt-3 text-sm text-text-secondary leading-relaxed">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="max-w-site mx-auto px-5 md:px-8 pb-20 md:pb-28">
      <div className="rounded-xl bg-ink px-8 py-14 md:py-20 text-center flex flex-col items-center">
        <h2 className="text-3xl md:text-4xl font-extrabold text-cream tracking-tight max-w-[480px]">
          Ready when you are.
        </h2>
        <p className="mt-4 text-base text-white/60 max-w-[440px]">
          Request early access and be first to know when Bunch is ready to ride.
        </p>
        <div className="mt-8 w-full max-w-[560px]">
          <WaitlistForm variant="full" onDark />
        </div>
      </div>
    </section>
  );
}
