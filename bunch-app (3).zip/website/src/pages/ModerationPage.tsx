import React, { useEffect, useState } from 'react';
import { listRecentComments, deleteComment, type CommentWithContext } from '@/lib/api/comments';
import { Avatar } from '@/components/Avatar';
import { Button } from '@/components/Button';
import { LoadingView, EmptyState } from '@/components/LoadingView';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { IconMessage, IconTrash } from '@/components/icons';
import { formatRelative } from '@/lib/format';
import { getErrorMessage } from '@/lib/errors';

export function ModerationPage() {
  const [comments, setComments] = useState<CommentWithContext[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<CommentWithContext | null>(null);

  async function load() {
    try {
      setComments(await listRecentComments());
    } catch (e) {
      setError(getErrorMessage(e));
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function onConfirmDelete() {
    if (!deleteTarget) return;
    await deleteComment(deleteTarget.id);
    setComments((cs) => cs?.filter((c) => c.id !== deleteTarget.id) ?? cs);
  }

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold text-text-primary">Moderation</h1>
        <p className="text-sm text-text-tertiary mt-0.5">The most recent comments across every ride. Remove anything that breaks the rules.</p>
      </div>

      {error ? <p className="text-sm text-danger bg-danger-muted border border-danger/30 rounded-md px-3 py-2">{error}</p> : null}

      {!comments ? (
        <LoadingView />
      ) : comments.length === 0 ? (
        <EmptyState icon={<IconMessage size={22} />} title="No comments yet" description="Rider comments will show up here as they're posted." />
      ) : (
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          {comments.map((c, i) => (
            <div
              key={c.id}
              className="flex items-start gap-3 px-4 py-3.5 border-b border-border last:border-b-0 hover:bg-surface-high/50 transition-colors animate-[rowIn_0.2s_ease-out_both]"
              style={{ animationDelay: `${Math.min(i, 14) * 20}ms` }}
            >
              <Avatar url={c.author?.avatar_url} name={c.author?.display_name || c.author?.username || '?'} size={34} />
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline gap-2 flex-wrap">
                  <span className="text-sm font-semibold text-text-primary">{c.author?.display_name || c.author?.username || 'Unknown rider'}</span>
                  <span className="text-xs text-text-tertiary">on "{c.ride?.title || 'a ride'}"</span>
                  <span className="text-xs text-text-tertiary">· {formatRelative(c.created_at)}</span>
                </div>
                <p className="text-sm text-text-secondary mt-1 leading-relaxed break-words">{c.body}</p>
              </div>
              <button
                onClick={() => setDeleteTarget(c)}
                className="text-text-tertiary hover:text-danger transition-colors p-1.5 shrink-0"
                aria-label="Delete comment"
                title="Delete comment"
              >
                <IconTrash size={16} />
              </button>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={onConfirmDelete}
        danger
        title="Delete this comment?"
        description="This removes it immediately for everyone. This can't be undone."
        confirmLabel="Delete comment"
      />
    </div>
  );
}
