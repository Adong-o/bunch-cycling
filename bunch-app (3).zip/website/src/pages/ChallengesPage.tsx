import React, { useEffect, useState } from 'react';
import { listChallenges, deleteChallenge, setChallengeFeatured, goalUnitLabel, baseUnitsToGoalValue, type ChallengeWithCount } from '@/lib/api/challenges';
import { Button } from '@/components/Button';
import { Pill } from '@/components/Pill';
import { LoadingView, EmptyState } from '@/components/LoadingView';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { ChallengeFormModal } from '@/components/ChallengeFormModal';
import { IconPlus, IconTrophy, IconEdit, IconTrash, IconUsers, IconStar } from '@/components/icons';
import { formatDate } from '@/lib/format';
import { getErrorMessage } from '@/lib/errors';
import type { Challenge } from '@/lib/database.types';

type Filter = 'all' | 'official' | 'user';

export function ChallengesPage() {
  const [challenges, setChallenges] = useState<ChallengeWithCount[] | null>(null);
  const [filter, setFilter] = useState<Filter>('all');
  const [error, setError] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Challenge | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Challenge | null>(null);

  async function load() {
    try {
      setChallenges(await listChallenges());
    } catch (e) {
      setError(getErrorMessage(e));
    }
  }

  useEffect(() => {
    load();
  }, []);

  function openCreate() {
    setEditing(null);
    setFormOpen(true);
  }
  function openEdit(c: Challenge) {
    setEditing(c);
    setFormOpen(true);
  }

  function onSaved(saved: Challenge) {
    setChallenges((cs) => {
      if (!cs) return cs;
      const exists = cs.some((c) => c.id === saved.id);
      const withCount = { ...saved, participant_count: cs.find((c) => c.id === saved.id)?.participant_count ?? 0 };
      return exists ? cs.map((c) => (c.id === saved.id ? withCount : c)) : [withCount, ...cs];
    });
  }

  async function onConfirmDelete() {
    if (!deleteTarget) return;
    await deleteChallenge(deleteTarget.id);
    setChallenges((cs) => cs?.filter((c) => c.id !== deleteTarget.id) ?? cs);
  }

  async function onToggleFeatured(c: ChallengeWithCount) {
    if (!c.is_public) return; // can't feature a private challenge — see the DB check constraint
    const next = !c.is_featured;
    setChallenges((cs) => cs?.map((x) => (x.id === c.id ? { ...x, is_featured: next } : x)) ?? cs);
    try {
      await setChallengeFeatured(c.id, next);
    } catch (e) {
      setChallenges((cs) => cs?.map((x) => (x.id === c.id ? { ...x, is_featured: c.is_featured } : x)) ?? cs);
      setError(getErrorMessage(e));
    }
  }

  const visible = (challenges ?? []).filter((c) => (filter === 'all' ? true : filter === 'official' ? c.is_official : !c.is_official));

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-text-primary">Challenges</h1>
          <p className="text-sm text-text-tertiary mt-0.5">Launch official challenges, or moderate what riders create.</p>
        </div>
        <Button icon={<IconPlus size={16} />} onClick={openCreate}>
          New challenge
        </Button>
      </div>

      <div className="flex gap-2">
        {(['all', 'official', 'user'] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
              filter === f ? 'bg-accent-muted text-accent border-accent/30' : 'bg-surface text-text-secondary border-border hover:text-text-primary'
            }`}
          >
            {f === 'all' ? 'All' : f === 'official' ? 'Official' : 'User-created'}
          </button>
        ))}
      </div>

      {error ? <p className="text-sm text-danger bg-danger-muted border border-danger/30 rounded-md px-3 py-2">{error}</p> : null}

      {!challenges ? (
        <LoadingView />
      ) : visible.length === 0 ? (
        <EmptyState icon={<IconTrophy size={22} />} title="No challenges here" description="Nothing matches this filter yet." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {visible.map((c, i) => (
            <div
              key={c.id}
              className="bg-surface border border-border rounded-lg overflow-hidden flex flex-col animate-[rowIn_0.25s_ease-out_both]"
              style={{ animationDelay: `${Math.min(i, 12) * 30}ms` }}
            >
              <div className="h-28 bg-surface-high flex items-center justify-center overflow-hidden relative">
                {c.cover_image_url ? (
                  <img src={c.cover_image_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <IconTrophy size={26} className="text-text-tertiary" />
                )}
                <button
                  type="button"
                  onClick={() => onToggleFeatured(c)}
                  disabled={!c.is_public}
                  title={!c.is_public ? 'Only public challenges can be featured' : c.is_featured ? 'Unfeature' : 'Feature on the app feed'}
                  className={`absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                    c.is_featured ? 'bg-gold text-ink' : 'bg-black/40 text-white hover:bg-black/55'
                  } ${!c.is_public ? 'opacity-40 cursor-not-allowed' : ''}`}
                >
                  <IconStar size={14} filled={c.is_featured} />
                </button>
              </div>
              <div className="p-4 flex flex-col gap-2.5 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-sm font-bold text-text-primary leading-snug">{c.title}</h3>
                  {c.is_official ? <Pill tone="gold">Official</Pill> : <Pill tone="neutral">Rider-made</Pill>}
                </div>
                <p className="text-xs text-text-secondary">
                  {baseUnitsToGoalValue(c.type, c.goal_value)} {goalUnitLabel(c.type)} · {formatDate(c.start_date)} – {formatDate(c.end_date)}
                </p>
                <div className="flex items-center gap-3 text-xs text-text-tertiary mt-auto pt-1">
                  <span className="flex items-center gap-1">
                    <IconUsers size={13} /> {c.participant_count}
                  </span>
                  <Pill tone={c.is_public ? 'accent' : 'neutral'}>{c.is_public ? 'Public' : 'Private'}</Pill>
                  {c.is_featured ? <Pill tone="gold">Featured</Pill> : null}
                </div>
                <div className="flex gap-2 mt-1">
                  <Button variant="secondary" size="sm" icon={<IconEdit size={13} />} onClick={() => openEdit(c)} className="flex-1">
                    Edit
                  </Button>
                  <Button variant="danger" size="sm" icon={<IconTrash size={13} />} onClick={() => setDeleteTarget(c)}>
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <ChallengeFormModal open={formOpen} challenge={editing} onClose={() => setFormOpen(false)} onSaved={onSaved} />

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={onConfirmDelete}
        danger
        title="Delete this challenge?"
        description={`"${deleteTarget?.title}" and everyone's progress on it will be permanently deleted. This can't be undone.`}
        confirmLabel="Delete challenge"
      />
    </div>
  );
}
