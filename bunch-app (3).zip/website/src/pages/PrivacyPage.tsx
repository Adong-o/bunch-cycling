import React from 'react';
import { MarketingLayout } from '@/components/marketing/MarketingLayout';
import { LegalContent, type LegalSection } from '@/components/marketing/LegalContent';
import { SUPPORT_EMAIL } from '@/lib/constants';

// Mirrors mobile/src/screens/legal/PrivacyPolicyScreen.tsx section for
// section, so the policy a rider reads in the app is the same one a visitor
// reads here — SUPPORT_EMAIL is the real, monitored address. [Legal entity
// name] and [address] stay bracketed because we don't have real values for
// them yet; see the root README's "before you launch" list.
const SECTIONS: LegalSection[] = [
  {
    heading: '1. The short version',
    body: [
      "Bunch records your rides using your phone's GPS and lets you share them with other riders if you choose to. We collect only what the app needs to work — your account details, your ride data, and anything you add to your profile — and we don't sell your data to advertisers or data brokers.",
      'You control who sees each ride through its visibility setting (private, followers, or public), and you can export or delete your rides and your account at any time.',
    ],
  },
  {
    heading: '2. Information we collect',
    body: [
      'Account information: the email address and password you sign up with, and the username and display name you choose.',
      'Profile information you add: avatar photo, bio, weight (optional, used only to estimate calories), unit preference, and activity goals.',
      'Ride data: GPS location points recorded while you record a ride, along with the distance, speed, elevation, duration and route that app calculates from them, plus any title, description or photos you attach to a ride, and anyone you tag as having ridden with you.',
      'Content you create: comments, kudos, routes and segments you save, challenges you create or join, and devices you add to your profile.',
      'Usage information: basic technical data such as app version and device type, used for crash diagnostics and improving the app.',
    ],
  },
  {
    heading: '3. Location data specifically',
    body: [
      "Bunch only records your location while you actively start a ride recording, and it stops when you end or discard it — it does not track your location in the background at any other time.",
      "If you grant background location permission, recording continues while your screen is locked or you switch apps, solely so an in-progress ride isn't cut short. You can deny or revoke this at any time in Settings without losing the ability to record rides in the foreground.",
      "Your recorded GPS tracks are stored so you can view your ride history and route map, and so segment and leaderboard features can work. They are shared with other riders only to the extent your ride's visibility setting allows.",
    ],
  },
  {
    heading: '4. How we use your information',
    body: [
      '• To provide the core features of the app: recording and displaying rides, maps, stats, streaks, badges, segments, and challenges.',
      '• To operate the social features you opt into: your public or followers-visible rides, kudos and comments from other riders, and the riding companions you tag on a ride.',
      '• To maintain your account, including authentication and password resets.',
      '• To process your Bunch Premium subscription, where applicable.',
      '• To keep the service secure and prevent abuse.',
      '• To communicate with you about your account or changes to the service.',
    ],
  },
  {
    heading: '5. Who we share it with',
    body: [
      'We do not sell your personal information. We share it only in these cases:',
      '• With other riders, according to the visibility you choose for each ride, your profile, and your follower relationships — including riders you tag on a ride, who can see that ride regardless of its visibility setting.',
      '• With service providers who host our infrastructure and database (currently Supabase) strictly to operate the app on our behalf, under their own data-protection obligations.',
      '• If required by law, or to protect the rights, safety, or property of Bunch, our riders, or the public.',
      "• If Bunch is involved in a merger, acquisition, or sale of assets, in which case we'll let you know before your information is transferred.",
    ],
  },
  {
    heading: '6. Data retention and deletion',
    body: [
      'We keep your account and ride data for as long as your account is active. You can delete an individual ride, route, or segment at any time from within the app, which removes it immediately — including removing yourself from a ride someone else tagged you on.',
      `To delete your account entirely, contact us at ${SUPPORT_EMAIL} and we will delete your account and associated personal data, except where we're required to retain limited records for legal or accounting purposes.`,
    ],
  },
  {
    heading: '7. Your choices and rights',
    body: [
      '• Access and export: you can view all of your ride data in the app, and export an individual ride as a GPX file at any time.',
      '• Correction: you can edit your profile and ride details whenever you like.',
      '• Tagging: if another rider tags you on a ride, you can remove the tag yourself at any time without needing their permission.',
      '• Deletion: you can delete individual content yourself, or request full account deletion as described above.',
      '• Depending on where you live, you may have additional rights under laws like the GDPR or CCPA, including the right to request a copy of your data or object to certain processing. Contact us to exercise these rights.',
    ],
  },
  {
    heading: "8. Children's privacy",
    body: [
      "Bunch is not directed at children, and we don't knowingly collect information from anyone under 13 (or the minimum age required in your country). If you believe a child has created an account, contact us and we'll remove it.",
    ],
  },
  {
    heading: '9. Security',
    body: [
      "We use industry-standard safeguards — including encryption in transit and row-level access controls on our database — to protect your information. No method of transmission or storage is perfectly secure, so we can't guarantee absolute security.",
    ],
  },
  {
    heading: '10. Changes to this policy',
    body: [
      `We may update this policy from time to time. If we make a material change, we'll notify you in the app or by email before it takes effect. The "last updated" date above always reflects the current version.`,
    ],
  },
  {
    heading: '11. Contact us',
    body: [`Questions about this policy or your data? Reach us at ${SUPPORT_EMAIL}. [Legal entity name], [address], is the data controller responsible for your information.`],
  },
];

const INTRO =
  'This policy explains what information Bunch ("we," "us") collects when you use our cycling tracking app, how we use it, and the choices you have. By using Bunch, you agree to the practices described here.';

export function PrivacyPage() {
  return (
    <MarketingLayout>
      <LegalContent title="Privacy Policy" lastUpdated="October 17, 2026" intro={INTRO} sections={SECTIONS} />
    </MarketingLayout>
  );
}
