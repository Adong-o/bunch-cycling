import React, { useEffect, useState } from 'react';
import { listBadges, deleteBadge, criteriaUnitLabel, baseToCriteriaValue, CRITERIA_TYPES } from '@/lib/api/badges';
import { Button } from '@/components/Button';
import { LoadingView, EmptyState } from '@/components/LoadingView';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { BadgeFormModal } from '@/components/BadgeFormModal';
import { IconPlus, IconBadge, IconEdit, IconTrash } from '@/components/icons';
import { getErrorMessage } from '@/lib/errors';
import type { Badge } from '@/lib/database.types';

export function BadgesPage() {
  const [badges, setBadges] = useState<Badge[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Badge | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Badge | null>(null);

  async function load() {
    try {
      setBadges(await listBadges());
    } catch (e) {
      setError(getErrorMessage(e));
    }
  }

  useEffect(() => {
    load();
  }, []);

  function onSaved(saved: Badge) {
    setBadges((bs) => {
      if (!bs) return bs;
      const exists = bs.some((b) => b.id === saved.id);
      const next = exists ? bs.map((b) => (b.id === saved.id ? saved : b)) : [...bs, saved];
      return next.sort((a, b) => a.criteria_value - b.criteria_value);
    });
  }

  async function onConfirmDelete() {
    if (!deleteTarget) return;
    await deleteBadge(deleteTarget.id);
    setBadges((bs) => bs?.filter((b) => b.id !== deleteTarget.id) ?? bs);
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-text-primary">Badges</h1>
          <p className="text-sm text-text-tertiary mt-0.5">The achievement catalog — awarded automatically as riders hit each target.</p>
        </div>
        <Button
          icon={<IconPlus size={16} />}
          onClick={() => {
            setEditing(null);
            setFormOpen(true);
          }}
        >
          New badge
        </Button>
      </div>

      {error ? <p className="text-sm text-danger bg-danger-muted border border-danger/30 rounded-md px-3 py-2">{error}</p> : null}

      {!badges ? (
        <LoadingView />
      ) : badges.length === 0 ? (
        <EmptyState icon={<IconBadge size={22} />} title="No badges yet" description="Create the first one riders can earn." />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((b, i) => (
            <div
              key={b.id}
              className="bg-surface border border-border rounded-lg p-4 flex gap-3 animate-[rowIn_0.25s_ease-out_both]"
              style={{ animationDelay: `${Math.min(i, 16) * 25}ms` }}
            >
              <div className="w-11 h-11 rounded-md bg-gold-muted flex items-center justify-center text-xl shrink-0">{b.icon}</div>
              <div className="min-w-0 flex-1 flex flex-col">
                <h3 className="text-sm font-bold text-text-primary">{b.name}</h3>
                <p className="text-xs text-text-secondary mt-0.5 leading-relaxed">{b.description}</p>
                <p className="text-xs text-text-tertiary mt-1.5 font-mono-num">
                  {baseToCriteriaValue(b.criteria_type, b.criteria_value)} {criteriaUnitLabel(b.criteria_type)} ·{' '}
                  {CRITERIA_TYPES.find((t) => t.value === b.criteria_type)?.label}
                </p>
                <div className="flex gap-2 mt-auto pt-2.5">
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={<IconEdit size={13} />}
                    onClick={() => {
                      setEditing(b);
                      setFormOpen(true);
                    }}
                    className="flex-1"
                  >
                    Edit
                  </Button>
                  <Button variant="danger" size="sm" icon={<IconTrash size={13} />} onClick={() => setDeleteTarget(b)}>
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <BadgeFormModal open={formOpen} badge={editing} onClose={() => setFormOpen(false)} onSaved={onSaved} />

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={onConfirmDelete}
        danger
        title="Delete this badge?"
        description={`"${deleteTarget?.name}" will be removed from the catalog, and taken away from every rider who already earned it. This can't be undone.`}
        confirmLabel="Delete badge"
      />
    </div>
  );
}
