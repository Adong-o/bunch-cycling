import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/state/AuthContext';
import { LoadingView } from '@/components/LoadingView';
import { StatCard } from '@/components/StatCard';
import { getErrorMessage } from '@/lib/errors';
import { IconUsers, IconGlobe, IconShield, IconBike, IconTrophy, IconBadge } from '@/components/icons';

type Stats = {
  total_users: number;
  premium_users: number;
  admin_users: number;
  total_rides: number;
  total_distance_m: number;
  total_elevation_m: number;
  active_challenges: number;
  total_badges: number;
};

export function DashboardPage() {
  const { profile } = useAuth();
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .rpc('admin_dashboard_stats')
      .then(({ data, error }) => {
        if (error) throw error;
        setStats(data?.[0] ?? null);
      })
      .catch((e) => setError(getErrorMessage(e)));
  }, []);

  if (error) {
    return (
      <div className="bg-danger-muted border border-danger/30 rounded-lg p-4 text-sm text-danger">
        Couldn't load dashboard stats: {error}
        {/decode|function|schema cache/i.test(error) ? (
          <p className="mt-2 text-danger/80">
            This needs the <code className="font-mono-num">admin_dashboard_stats()</code> function from{' '}
            <code className="font-mono-num">supabase/schema.sql</code> — run that block once in the Supabase SQL editor if you set up the
            database before this was added.
          </p>
        ) : null}
      </div>
    );
  }

  if (!stats) return <LoadingView />;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold text-text-primary">Welcome back{profile?.display_name ? `, ${profile.display_name.split(' ')[0]}` : ''}</h1>
        <p className="text-sm text-text-tertiary mt-0.5">Here's how Bunch is doing right now.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Riders" value={stats.total_users.toLocaleString()} icon={<IconUsers size={20} />} tone="accent" />
        <StatCard label="Premium riders" value={stats.premium_users.toLocaleString()} icon={<IconShield size={20} />} tone="gold" />
        <StatCard label="Rides logged" value={stats.total_rides.toLocaleString()} icon={<IconBike size={20} />} />
        <StatCard label="Active challenges" value={stats.active_challenges.toLocaleString()} icon={<IconTrophy size={20} />} />
        <StatCard label="Distance ridden" value={`${Math.round(stats.total_distance_m / 1000).toLocaleString()} km`} icon={<IconGlobe size={20} />} />
        <StatCard label="Elevation climbed" value={`${Math.round(stats.total_elevation_m).toLocaleString()} m`} icon={<IconGlobe size={20} />} />
        <StatCard label="Badge catalog" value={stats.total_badges.toLocaleString()} icon={<IconBadge size={20} />} />
        <StatCard label="Admins" value={stats.admin_users.toLocaleString()} icon={<IconShield size={20} />} />
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mt-2">
        <QuickLink to="/users" title="Manage users" description="Search riders, grant Premium, promote admins." />
        <QuickLink to="/challenges" title="Create a challenge" description="Launch an official Bunch challenge with a cover image." />
        <QuickLink to="/badges" title="Edit badge catalog" description="Add, tune, or retire achievement badges." />
      </div>
    </div>
  );
}

function QuickLink({ to, title, description }: { to: string; title: string; description: string }) {
  return (
    <Link
      to={to}
      className="bg-surface border border-border rounded-lg p-4 hover:border-border-strong hover:bg-surface-high transition-colors"
    >
      <p className="text-sm font-semibold text-text-primary">{title}</p>
      <p className="text-xs text-text-tertiary mt-1 leading-relaxed">{description}</p>
    </Link>
  );
}
