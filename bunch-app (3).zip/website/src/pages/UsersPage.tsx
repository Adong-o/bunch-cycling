import React, { useEffect, useState } from 'react';
import { listUsers, setPremium, setAdmin } from '@/lib/api/users';
import { useAuth } from '@/state/AuthContext';
import { Avatar } from '@/components/Avatar';
import { Pill } from '@/components/Pill';
import { Toggle } from '@/components/Toggle';
import { Button } from '@/components/Button';
import { LoadingView, EmptyState } from '@/components/LoadingView';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { IconSearch, IconUsers, IconShield } from '@/components/icons';
import { formatDate } from '@/lib/format';
import { getErrorMessage } from '@/lib/errors';
import type { Profile } from '@/lib/database.types';

type AdminAction = { user: Profile; grant: boolean };

export function UsersPage() {
  const { profile: me, refreshProfile } = useAuth();
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [adminAction, setAdminAction] = useState<AdminAction | null>(null);
  const [revokePremiumTarget, setRevokePremiumTarget] = useState<Profile | null>(null);

  async function load(q: string) {
    setLoading(true);
    setError(null);
    try {
      const { rows, hasMore } = await listUsers({ query: q });
      setRows(rows);
      setHasMore(hasMore);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  async function loadMore() {
    setLoadingMore(true);
    try {
      const { rows: more, hasMore: hm } = await listUsers({ query, offset: rows.length });
      setRows((r) => [...r, ...more]);
      setHasMore(hm);
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setLoadingMore(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(() => load(query), 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  async function applyPremium(u: Profile, next: boolean) {
    setBusyId(u.id);
    try {
      const updated = await setPremium(u.id, next);
      setRows((rs) => rs.map((r) => (r.id === u.id ? updated : r)));
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  function onTogglePremium(u: Profile, next: boolean) {
    // Mirrors the mobile AdminScreen: granting is instant, revoking confirms
    // first since it immediately cuts off the rider's paid features.
    if (!next) {
      setRevokePremiumTarget(u);
      return;
    }
    applyPremium(u, true);
  }

  async function onConfirmAdmin() {
    if (!adminAction) return;
    const { user, grant } = adminAction;
    setBusyId(user.id);
    try {
      const updated = await setAdmin(user.id, grant);
      setRows((rs) => rs.map((r) => (r.id === user.id ? updated : r)));
      if (user.id === me?.id) await refreshProfile();
    } catch (e) {
      setError(getErrorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-text-primary">Users</h1>
          <p className="text-sm text-text-tertiary mt-0.5">Search riders, grant Premium, promote admins.</p>
        </div>
        <div className="relative w-full sm:w-72">
          <IconSearch size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name or username"
            className="w-full bg-surface border border-border rounded-md pl-9 pr-3 py-2.5 text-sm text-text-primary placeholder:text-text-tertiary outline-none focus:border-accent transition-colors"
          />
        </div>
      </div>

      {error ? <p className="text-sm text-danger bg-danger-muted border border-danger/30 rounded-md px-3 py-2">{error}</p> : null}

      {loading ? (
        <LoadingView />
      ) : rows.length === 0 ? (
        <EmptyState icon={<IconUsers size={22} />} title="No riders found" description={query ? 'Try a different search.' : 'No one has signed up yet.'} />
      ) : (
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="hidden md:grid grid-cols-[1fr_120px_120px_110px] gap-4 px-4 py-2.5 border-b border-border text-xs font-semibold text-text-tertiary uppercase tracking-wide">
            <span>Rider</span>
            <span>Joined</span>
            <span>Premium</span>
            <span>Admin</span>
          </div>
          {rows.map((u, i) => (
            <div
              key={u.id}
              className="flex flex-col md:grid md:grid-cols-[1fr_120px_120px_110px] gap-2 md:gap-4 px-4 py-3.5 border-b border-border last:border-b-0 md:items-center hover:bg-surface-high/50 transition-colors animate-[rowIn_0.25s_ease-out_both]"
              style={{ animationDelay: `${Math.min(i, 12) * 25}ms` }}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Avatar url={u.avatar_url} name={u.display_name || u.username} size={36} />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-text-primary truncate">{u.display_name || u.username}</p>
                  <p className="text-xs text-text-tertiary truncate">@{u.username}</p>
                </div>
              </div>
              <span className="text-xs text-text-secondary md:text-sm">{formatDate(u.created_at)}</span>
              <div className="flex items-center gap-2">
                <Toggle checked={u.is_premium} disabled={busyId === u.id} onChange={(next) => onTogglePremium(u, next)} label="Premium" />
                {u.is_premium ? <Pill tone="gold">Premium</Pill> : null}
              </div>
              <div className="flex items-center gap-2">
                <Toggle
                  checked={u.is_admin}
                  disabled={busyId === u.id}
                  onChange={(next) => setAdminAction({ user: u, grant: next })}
                  label="Admin"
                />
                {u.is_admin ? (
                  <Pill tone="accent" icon={<IconShield size={11} />}>
                    Admin
                  </Pill>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      )}

      {hasMore && !loading ? (
        <Button variant="secondary" onClick={loadMore} loading={loadingMore} className="self-center">
          Load more
        </Button>
      ) : null}

      <ConfirmDialog
        open={!!adminAction}
        onClose={() => setAdminAction(null)}
        onConfirm={onConfirmAdmin}
        danger={!adminAction?.grant}
        title={adminAction?.grant ? 'Grant admin access?' : adminAction?.user.id === me?.id ? 'Remove your own admin access?' : 'Remove admin access?'}
        description={
          adminAction?.grant
            ? `${adminAction.user.display_name || adminAction.user.username} will be able to manage every user, challenge and badge in Bunch — including promoting other admins.`
            : adminAction?.user.id === me?.id
              ? "You'll be signed out of admin tools immediately and will need someone else — or direct database access — to restore it."
              : `${adminAction?.user.display_name || adminAction?.user.username} will lose all admin access immediately.`
        }
        confirmLabel={adminAction?.grant ? 'Grant admin' : 'Remove access'}
      />

      <ConfirmDialog
        open={!!revokePremiumTarget}
        onClose={() => setRevokePremiumTarget(null)}
        onConfirm={async () => {
          if (revokePremiumTarget) await applyPremium(revokePremiumTarget, false);
        }}
        danger
        title="Revoke Premium?"
        description={`${revokePremiumTarget?.display_name || revokePremiumTarget?.username} will immediately lose access to paid features. Their "member since" date is kept in case they resubscribe.`}
        confirmLabel="Revoke Premium"
      />
    </div>
  );
}
