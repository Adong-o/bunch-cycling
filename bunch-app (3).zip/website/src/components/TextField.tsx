import React, { forwardRef } from 'react';

interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const TextField = forwardRef<HTMLInputElement, Props>(function TextField(
  { label, error, hint, id, className = '', ...rest },
  ref
) {
  const inputId = id ?? rest.name;
  return (
    <div className="flex flex-col gap-1.5">
      {label ? (
        <label htmlFor={inputId} className="text-xs font-semibold text-text-secondary tracking-wide">
          {label}
        </label>
      ) : null}
      <input
        ref={ref}
        id={inputId}
        className={`bg-surface border rounded-md px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-tertiary outline-none transition-colors ${
          error ? 'border-danger' : 'border-border focus:border-accent'
        } ${className}`}
        {...rest}
      />
      {hint && !error ? <p className="text-xs text-text-tertiary">{hint}</p> : null}
      {error ? <p className="text-xs text-danger">{error}</p> : null}
    </div>
  );
});

export function TextArea({
  label,
  error,
  hint,
  id,
  className = '',
  ...rest
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string; error?: string; hint?: string }) {
  const inputId = id ?? rest.name;
  return (
    <div className="flex flex-col gap-1.5">
      {label ? (
        <label htmlFor={inputId} className="text-xs font-semibold text-text-secondary tracking-wide">
          {label}
        </label>
      ) : null}
      <textarea
        id={inputId}
        className={`bg-surface border rounded-md px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-tertiary outline-none transition-colors resize-none ${
          error ? 'border-danger' : 'border-border focus:border-accent'
        } ${className}`}
        {...rest}
      />
      {hint && !error ? <p className="text-xs text-text-tertiary">{hint}</p> : null}
      {error ? <p className="text-xs text-danger">{error}</p> : null}
    </div>
  );
}

export function Select({
  label,
  error,
  hint,
  id,
  className = '',
  children,
  ...rest
}: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string; error?: string; hint?: string }) {
  const inputId = id ?? rest.name;
  return (
    <div className="flex flex-col gap-1.5">
      {label ? (
        <label htmlFor={inputId} className="text-xs font-semibold text-text-secondary tracking-wide">
          {label}
        </label>
      ) : null}
      <select
        id={inputId}
        className={`bg-surface border rounded-md px-3.5 py-2.5 text-sm text-text-primary outline-none transition-colors ${
          error ? 'border-danger' : 'border-border focus:border-accent'
        } ${className}`}
        {...rest}
      >
        {children}
      </select>
      {hint && !error ? <p className="text-xs text-text-tertiary">{hint}</p> : null}
      {error ? <p className="text-xs text-danger">{error}</p> : null}
    </div>
  );
}
