import React from 'react';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';
type Size = 'sm' | 'md';

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
}

const base =
  'inline-flex items-center justify-center gap-2 font-semibold rounded-md transition-colors duration-150 disabled:opacity-50 disabled:pointer-events-none select-none whitespace-nowrap';

const variants: Record<Variant, string> = {
  primary: 'bg-accent text-text-on-accent hover:bg-accent-pressed',
  secondary: 'bg-surface-high text-text-primary border border-border-strong hover:bg-surface-highest',
  danger: 'bg-danger-muted text-danger border border-danger/30 hover:bg-danger/20',
  ghost: 'bg-transparent text-text-secondary hover:text-text-primary hover:bg-surface',
};

const sizes: Record<Size, string> = {
  sm: 'text-xs px-3 py-1.5',
  md: 'text-sm px-4 py-2.5',
};

export function Button({ variant = 'primary', size = 'md', loading, icon, disabled, children, className = '', ...rest }: Props) {
  return (
    <button
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? <Spinner /> : icon}
      {children}
    </button>
  );
}

export function Spinner({ className = '' }: { className?: string }) {
  return (
    <svg className={`animate-spin h-4 w-4 ${className}`} viewBox="0 0 24 24" fill="none">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3.5" />
      <path className="opacity-90" fill="currentColor" d="M22 12a10 10 0 0 0-10-10v3.5A6.5 6.5 0 0 1 18.5 12H22z" />
    </svg>
  );
}
