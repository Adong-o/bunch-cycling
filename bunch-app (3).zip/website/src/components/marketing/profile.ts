/**
 * Deterministic, real-looking ride profiles for the marketing visuals.
 * Built from layered sines plus a seeded hash "road texture", so the same
 * seed always draws the same line (no flicker between renders) and the
 * result reads like recorded elevation/speed data rather than a smooth
 * decorative curve.
 */
function hash(n: number): number {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

export interface Profile {
  /** Stroked line, e.g. "M0,10 L1,12 ..." */
  line: string;
  /** Closed filled area under the line down to the baseline. */
  area: string;
  /** Last point, in the same coordinate space. */
  end: { x: number; y: number };
}

/** Elevation: long climbs and descents with a little roughness. */
export function buildElevation(width: number, height: number, padTop: number, padBottom: number, n = 180): Profile {
  const pts: Array<[number, number]> = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    let e =
      0.42 +
      0.22 * Math.sin(t * 3.4 + 0.6) +
      0.1 * Math.sin(t * 8.1 + 1.3) +
      0.04 * Math.sin(t * 21 + 0.2) +
      (hash(i) - 0.5) * 0.035;
    // A real climb near the start, a plateau, then the long descent home.
    e += 0.18 * Math.exp(-Math.pow((t - 0.28) / 0.1, 2));
    e = Math.min(0.95, Math.max(0.06, e));
    const x = t * width;
    const y = padTop + (1 - e) * (height - padTop - padBottom);
    pts.push([x, y]);
  }
  return toProfile(pts, height - padBottom);
}

/** Speed: spiky, stop-and-go, with sprints. */
export function buildSpeed(width: number, height: number, padTop: number, padBottom: number, n = 220): Profile {
  const pts: Array<[number, number]> = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    let v = 0.3 + 0.12 * Math.sin(t * 9 + 0.4) + 0.06 * Math.sin(t * 27) + (hash(i + 500) - 0.5) * 0.16;
    if (hash(Math.floor(i / 9) + 900) > 0.86) v += 0.28 * hash(i + 77); // sprints
    if (hash(Math.floor(i / 11) + 1300) > 0.9) v *= 0.25; // stops
    v = Math.min(0.97, Math.max(0.03, v));
    pts.push([t * width, padTop + (1 - v) * (height - padTop - padBottom)]);
  }
  return toProfile(pts, height - padBottom);
}

function toProfile(pts: Array<[number, number]>, baseline: number): Profile {
  const f = (v: number) => v.toFixed(1);
  const line = pts.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${f(x)},${f(y)}`).join(' ');
  const first = pts[0];
  const last = pts[pts.length - 1];
  const area = `${line} L${f(last[0])},${f(baseline)} L${f(first[0])},${f(baseline)} Z`;
  return { line, area, end: { x: last[0], y: last[1] } };
}
