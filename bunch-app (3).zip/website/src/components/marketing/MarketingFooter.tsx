import React from 'react';
import { Link } from 'react-router-dom';
import { BrandLogo } from '@/components/BrandMark';
import { SUPPORT_EMAIL } from '@/lib/constants';

export function MarketingFooter() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-border mt-24">
      <div className="max-w-site mx-auto px-5 md:px-8 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
        <div className="col-span-2 md:col-span-1">
          <Link to="/" className="inline-flex items-center mb-3" aria-label="Bunch — home">
            <BrandLogo height={26} />
          </Link>
          <p className="text-sm text-text-tertiary leading-relaxed max-w-[200px]">Ride tracking built for cyclists, not retrofitted from one.</p>
        </div>

        <FooterColumn
          title="Product"
          links={[
            { to: '/#features', label: 'Features' },
            { to: '/#premium', label: 'Premium' },
            { to: '/#faq', label: 'FAQ' },
          ]}
        />
        <FooterColumn
          title="Legal"
          links={[
            { to: '/privacy', label: 'Privacy Policy' },
            { to: '/terms', label: 'Terms of Service' },
          ]}
        />
        <FooterColumn
          title="Contact"
          links={[{ to: `mailto:${SUPPORT_EMAIL}`, label: SUPPORT_EMAIL, external: true }]}
        />
      </div>

      <div className="border-t border-border">
        <div className="max-w-site mx-auto px-5 md:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-text-tertiary">
          <p>&copy; {year} Bunch. Early access — not yet available on the App Store or Google Play.</p>
          <Link to="/admin/login" className="hover:text-text-secondary transition-colors">
            Admin
          </Link>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: { to: string; label: string; external?: boolean }[] }) {
  return (
    <div>
      <p className="text-xs font-semibold text-text-tertiary uppercase tracking-wider mb-3">{title}</p>
      <div className="flex flex-col gap-2.5">
        {links.map((link) =>
          link.external ? (
            <a key={link.to} href={link.to} className="text-sm text-text-secondary hover:text-text-primary transition-colors break-all">
              {link.label}
            </a>
          ) : (
            <Link key={link.to} to={link.to} className="text-sm text-text-secondary hover:text-text-primary transition-colors">
              {link.label}
            </Link>
          )
        )}
      </div>
    </div>
  );
}
