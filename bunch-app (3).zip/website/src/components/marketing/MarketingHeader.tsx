import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BrandLogo } from '@/components/BrandMark';
import { IconMenu, IconX } from '@/components/icons';

const NAV = [
  { href: '/#features', label: 'Features' },
  { href: '/#premium', label: 'Premium' },
  { href: '/#faq', label: 'FAQ' },
];

// Mirrors Button's primary/md classes exactly (components/Button.tsx) — this
// has to be a real Link, not a <button>, so React Router's navigation and
// MarketingLayout's hash-scroll work from any page (Privacy, Terms, the
// waitlist admin view), not just while already on Home.
const ctaClass =
  'inline-flex items-center justify-center gap-2 rounded-md bg-accent px-4 py-2.5 text-sm font-semibold text-text-on-accent whitespace-nowrap transition-colors duration-150 hover:bg-accent-pressed';

/**
 * A plain nav + one CTA — the header used to carry a full compact
 * WaitlistForm (email field and all) crammed into a 64px sticky row next to
 * the logo and links. A form competing for space in a wayfinding bar is why
 * it read as cluttered; this links to the real form in the hero instead of
 * trying to be one. See HomePage.tsx's Hero() for the #early-access target
 * and its scroll-mt-24 (clears this sticky header on arrival).
 */
export function MarketingHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-bg/85 backdrop-blur border-b border-border">
      <div className="max-w-site mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center shrink-0" aria-label="Bunch — home">
          <BrandLogo height={30} />
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className="px-3.5 py-2 rounded-md text-sm font-semibold text-text-secondary hover:text-text-primary hover:bg-surface-high transition-colors"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <Link to="/#early-access" className={`hidden lg:inline-flex shrink-0 ${ctaClass}`}>
          Get early access
        </Link>

        <button
          onClick={() => setOpen((v) => !v)}
          className="lg:hidden text-text-secondary p-1.5"
          aria-label={open ? 'Close menu' : 'Open menu'}
        >
          {open ? <IconX size={22} /> : <IconMenu size={22} />}
        </button>
      </div>

      {open ? (
        <div className="lg:hidden border-t border-border bg-bg px-5 py-4 flex flex-col gap-1 animate-[rowIn_0.18s_ease-out]">
          {NAV.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              onClick={() => setOpen(false)}
              className="px-2 py-2.5 rounded-md text-sm font-semibold text-text-secondary hover:bg-surface-high hover:text-text-primary transition-colors"
            >
              {item.label}
            </Link>
          ))}
          <Link to="/#early-access" onClick={() => setOpen(false)} className={`mt-2 w-full ${ctaClass}`}>
            Get early access
          </Link>
        </div>
      ) : null}
    </header>
  );
}
