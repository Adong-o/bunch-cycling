import React from 'react';
import { Link } from 'react-router-dom';

export interface LegalSection {
  heading: string;
  body: string[];
}

interface Props {
  title: string;
  lastUpdated: string;
  intro: string;
  sections: LegalSection[];
}

/** Shared renderer for Privacy/Terms — mirrors the structure of
 * mobile/src/components/legal/LegalDocument.tsx so the web and app copy stay
 * easy to diff against each other, restyled for the site instead of a phone
 * screen. A body line beginning with "• " is grouped into a real <ul> rather
 * than left as a literal bullet character in a paragraph. */
export function LegalContent({ title, lastUpdated, intro, sections }: Props) {
  return (
    <div className="max-w-[720px] mx-auto px-5 md:px-8 py-16 md:py-24">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-semibold text-text-secondary hover:text-text-primary transition-colors mb-10">
        <span aria-hidden>←</span> Bunch
      </Link>

      <h1 className="text-3xl md:text-4xl font-extrabold text-text-primary tracking-tight">{title}</h1>
      <p className="text-sm text-text-tertiary mt-3 mb-8">Last updated {lastUpdated}</p>
      <p className="text-base text-text-secondary leading-relaxed mb-12">{intro}</p>

      <div className="flex flex-col gap-10">
        {sections.map((section) => (
          <section key={section.heading}>
            <h2 className="text-lg font-bold text-text-primary mb-3">{section.heading}</h2>
            <div className="flex flex-col gap-3">
              {groupBody(section.body).map((block, i) =>
                block.type === 'ul' ? (
                  <ul key={i} className="list-disc pl-5 space-y-2 text-text-secondary leading-relaxed">
                    {block.items.map((item, j) => (
                      <li key={j}>{item}</li>
                    ))}
                  </ul>
                ) : (
                  <p key={i} className="text-text-secondary leading-relaxed">
                    {block.items[0]}
                  </p>
                )
              )}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

function groupBody(body: string[]): { type: 'p' | 'ul'; items: string[] }[] {
  const blocks: { type: 'p' | 'ul'; items: string[] }[] = [];
  for (const line of body) {
    const isBullet = line.startsWith('• ');
    const text = isBullet ? line.slice(2) : line;
    const last = blocks[blocks.length - 1];
    if (isBullet && last?.type === 'ul') {
      last.items.push(text);
    } else {
      blocks.push({ type: isBullet ? 'ul' : 'p', items: [text] });
    }
  }
  return blocks;
}
