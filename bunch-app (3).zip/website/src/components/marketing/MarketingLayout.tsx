import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { MarketingHeader } from './MarketingHeader';
import { MarketingFooter } from './MarketingFooter';

/** Shell for every public page (Home, Privacy, Terms). Also handles
 * cross-page anchor links — react-router doesn't scroll to a #hash on
 * navigation by itself, so a footer/header link like `/#premium` clicked
 * from /privacy needs a manual scroll-into-view once Home has mounted. */
export function MarketingLayout({ children }: { children: React.ReactNode }) {
  const { hash } = useLocation();

  useEffect(() => {
    if (!hash) return;
    const id = hash.slice(1);
    const el = document.getElementById(id);
    if (el) requestAnimationFrame(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  }, [hash]);

  return (
    <div className="min-h-screen flex flex-col">
      <MarketingHeader />
      <main className="flex-1">{children}</main>
      <MarketingFooter />
    </div>
  );
}
