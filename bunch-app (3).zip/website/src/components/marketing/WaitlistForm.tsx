import React, { useState } from 'react';
import { TextField } from '@/components/TextField';
import { Button } from '@/components/Button';
import { IconCheck } from '@/components/icons';
import { joinWaitlist } from '@/lib/api/waitlist';
import { getErrorMessage } from '@/lib/errors';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface Props {
  /** 'compact' is a single email field + button for tight spaces (the
   * header). 'full' adds an optional name field and stacks into a short
   * two-step layout, for the hero, pricing card and final CTA. */
  variant?: 'compact' | 'full';
  /** True when the form sits on the dark `bg-ink` panels (the final CTA) —
   * only changes the success message's text color, since TextField/Button
   * are reused as-is on both. */
  onDark?: boolean;
  className?: string;
}

/** The one real "Get early access" capture, used everywhere that CTA
 * appears on the site — inserts into the public `waitlist` table (see
 * schema_v2.sql §3) so the team can follow up later instead of relying on
 * a visitor's own email client. One component so loading/success/error
 * behavior can only ever work one way, wherever it's placed. */
export function WaitlistForm({ variant = 'full', onDark = false, className = '' }: Props) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');
  const [error, setError] = useState<string | undefined>(undefined);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = email.trim();
    if (!EMAIL_RE.test(trimmed)) {
      setError('Enter a valid email address.');
      return;
    }
    setError(undefined);
    setStatus('loading');
    try {
      await joinWaitlist(trimmed, variant === 'full' ? name : undefined);
      setStatus('success');
    } catch (err) {
      setError(getErrorMessage(err));
      setStatus('idle');
    }
  }

  if (status === 'success') {
    return (
      <div
        className={`flex items-center gap-2.5 text-sm font-semibold ${onDark ? 'text-cream' : 'text-text-primary'} ${className}`}
        style={{ animation: 'riseInSmall 0.4s cubic-bezier(0.16,1,0.3,1) both' }}
        role="status"
      >
        <span className="w-6 h-6 rounded-full bg-success flex items-center justify-center text-white shrink-0">
          <IconCheck size={13} />
        </span>
        You're on the list — we'll email you the moment Bunch is ready.
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <form onSubmit={onSubmit} noValidate className={`flex flex-wrap items-start gap-2 ${className}`}>
        <div className="flex-1 min-w-[150px]">
          <TextField
            type="email"
            inputMode="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            aria-label="Email address"
            error={error}
            disabled={status === 'loading'}
          />
        </div>
        <Button type="submit" loading={status === 'loading'} className="shrink-0">
          Get early access
        </Button>
      </form>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className={`w-full flex flex-col items-center gap-3 ${className}`}>
      <div className="w-full flex flex-col sm:flex-row gap-3">
        <div className="flex-1 min-w-0">
          <TextField
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name (optional)"
            aria-label="Name"
            autoComplete="name"
            disabled={status === 'loading'}
          />
        </div>
        <div className="flex-1 min-w-0">
          <TextField
            type="email"
            inputMode="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            aria-label="Email address"
            error={error}
            disabled={status === 'loading'}
          />
        </div>
      </div>
      <Button type="submit" loading={status === 'loading'}>
        Get early access
      </Button>
    </form>
  );
}
