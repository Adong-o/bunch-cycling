import React from 'react';
import { buildElevation } from './profile';

const W = 1200;
const H = 500;
const PAD_TOP = 96;
const PAD_BOTTOM = 64;

// Built once at module load — deterministic, so it never flickers.
const ELEVATION = buildElevation(W, H, PAD_TOP, PAD_BOTTOM);

const GRID_ROWS = [0, 1, 2, 3].map((i) => PAD_TOP + (i / 3) * (H - PAD_TOP - PAD_BOTTOM));
const GRID_COLS = [0, 1, 2, 3, 4].map((i) => (i / 4) * W);

// Same numbers as a real ride card in the app, so this reads as a recorded
// ride instead of decoration.
const Y_LABELS = [
  { text: '1,810 m', top: `${(GRID_ROWS[0] / H) * 100}%` },
  { text: '1,560 m', top: `${(GRID_ROWS[3] / H) * 100}%` },
];
const X_LABELS = ['Start', '5.9 km', '11.7 km', '17.6 km'];

/**
 * The hero's product visual: an elevation profile drawn the way a recorded
 * ride actually looks — an irregular line with real climbs and descents, a
 * filled area under it, gridlines and distance ticks — on the same dark
 * `bg-ink` panel as the final CTA band. Stat numbers use `font-mono-num`,
 * the convention the mobile app and admin dashboard share for anything
 * numeric. Axis text is HTML, not SVG text, because the SVG stretches to
 * fit the panel and would distort letters.
 */
export function HeroVisual({ className = '' }: { className?: string }) {
  return (
    <div
      className={`relative rounded-xl overflow-hidden bg-ink aspect-[4/3] sm:aspect-[16/9] md:aspect-[2.3/1] ${className}`}
      style={{ animation: 'riseIn 0.7s cubic-bezier(0.16,1,0.3,1) 0.1s both' }}
    >
      <svg className="absolute inset-0 w-full h-full" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="heroArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#4D47FC" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#4D47FC" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="heroLine" x1="0" y1="0" x2={W} y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#6F6AFF" />
            <stop offset="100%" stopColor="#B4B0FF" />
          </linearGradient>
        </defs>

        <g stroke="#FAFAF8" strokeOpacity="0.09" strokeWidth="1">
          {GRID_ROWS.map((y) => (
            <line key={`r${y}`} x1="0" x2={W} y1={y} y2={y} strokeDasharray="4 6" vectorEffect="non-scaling-stroke" />
          ))}
          {GRID_COLS.map((x) => (
            <line key={`c${x}`} x1={x} x2={x} y1={PAD_TOP} y2={H - PAD_BOTTOM} strokeOpacity="0.05" vectorEffect="non-scaling-stroke" />
          ))}
        </g>

        {/* distance ticks along the baseline */}
        <g stroke="#FAFAF8" strokeOpacity="0.25">
          {Array.from({ length: 41 }, (_, i) => (
            <line
              key={i}
              x1={(i / 40) * W}
              x2={(i / 40) * W}
              y1={H - PAD_BOTTOM}
              y2={H - PAD_BOTTOM + (i % 10 === 0 ? 10 : 5)}
              vectorEffect="non-scaling-stroke"
            />
          ))}
        </g>

        <path className="profile-fade" d={ELEVATION.area} fill="url(#heroArea)" style={{ animation: 'fadeInProfile 0.9s ease-out 1.1s both' }} />

        <path
          className="profile-draw"
          d={ELEVATION.line}
          pathLength={1}
          stroke="url(#heroLine)"
          strokeWidth="3"
          strokeLinejoin="round"
          strokeLinecap="round"
          style={{ strokeDasharray: 1, strokeDashoffset: 1, animation: 'drawProfile 1.8s cubic-bezier(0.16,1,0.3,1) 0.4s forwards' }}
        />
      </svg>

      {Y_LABELS.map((l) => (
        <span
          key={l.text}
          className="absolute left-3 font-mono-num text-[10px] text-white/40 leading-none -translate-y-1/2 hidden sm:block"
          style={{ top: l.top }}
        >
          {l.text}
        </span>
      ))}
      <div className="absolute inset-x-3 bottom-3 flex justify-between font-mono-num text-[10px] text-white/40 leading-none">
        {X_LABELS.map((t) => (
          <span key={t}>{t}</span>
        ))}
      </div>

      {/* live recording dot at the line's leading edge */}
      <div
        className="absolute w-3 h-3"
        style={{ left: `${(ELEVATION.end.x / W) * 100}%`, top: `${(ELEVATION.end.y / H) * 100}%`, transform: 'translate(-100%, -50%)' }}
      >
        <span className="absolute inset-0 rounded-full bg-accent" style={{ animation: 'pulseRing 2s ease-out 2.1s infinite' }} />
        <span className="absolute inset-0 rounded-full bg-accent ring-2 ring-ink" />
      </div>

      <div className="absolute inset-x-4 top-4 flex gap-2 sm:gap-3">
        <StatChip label="Distance" value="17.6 km" delay="1.3s" />
        <StatChip label="Elevation gain" value="200 m" delay="1.45s" />
        <StatChip label="Avg speed" value="14.8 km/h" delay="1.6s" className="hidden sm:flex" />
      </div>
    </div>
  );
}

function StatChip({ label, value, delay, className = 'flex' }: { label: string; value: string; delay: string; className?: string }) {
  return (
    <div
      className={`flex-col bg-white/[0.07] backdrop-blur border border-white/10 rounded-md px-3 py-2 ${className}`}
      style={{ animation: `riseInSmall 0.5s cubic-bezier(0.16,1,0.3,1) ${delay} both` }}
    >
      <span className="text-[10px] text-white/50 leading-none whitespace-nowrap">{label}</span>
      <span className="font-mono-num text-sm font-bold text-cream leading-tight whitespace-nowrap mt-1">{value}</span>
    </div>
  );
}
