import React, { useState } from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { useAuth } from '@/state/AuthContext';
import { Avatar } from './Avatar';
import { BrandLogo } from './BrandMark';
import { IconDashboard, IconUsers, IconTrophy, IconBadge, IconMessage, IconMail, IconLogout, IconMenu, IconX, IconGlobe } from './icons';

const NAV = [
  { to: '/admin', label: 'Dashboard', icon: IconDashboard, end: true },
  { to: '/admin/users', label: 'Users', icon: IconUsers },
  { to: '/admin/challenges', label: 'Challenges', icon: IconTrophy },
  { to: '/admin/badges', label: 'Badges', icon: IconBadge },
  { to: '/admin/moderation', label: 'Moderation', icon: IconMessage },
  { to: '/admin/waitlist', label: 'Waitlist', icon: IconMail },
];

export function Layout() {
  const { profile, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen flex">
      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 inset-x-0 h-14 bg-surface border-b border-border flex items-center justify-between px-4 z-30">
        <Wordmark />
        <button onClick={() => setMobileOpen(true)} className="text-text-secondary p-1" aria-label="Open menu">
          <IconMenu size={22} />
        </button>
      </div>

      {/* Mobile sidebar overlay */}
      {mobileOpen ? (
        <div className="md:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-ink/40" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-64 bg-surface border-r border-border p-4 animate-[modalIn_0.18s_cubic-bezier(0.16,1,0.3,1)]">
            <div className="flex items-center justify-between mb-6">
              <Wordmark />
              <button onClick={() => setMobileOpen(false)} className="text-text-secondary p-1" aria-label="Close menu">
                <IconX size={20} />
              </button>
            </div>
            <SidebarNav onNavigate={() => setMobileOpen(false)} />
          </div>
        </div>
      ) : null}

      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:flex-col w-64 shrink-0 border-r border-border bg-surface px-4 py-6 fixed inset-y-0">
        <div className="px-2 mb-8">
          <Wordmark />
        </div>
        <SidebarNav />
        <div className="mt-auto pt-4 border-t border-border flex flex-col gap-3">
          <Link to="/" className="flex items-center gap-2 px-3 py-2 rounded-md text-xs font-semibold text-text-tertiary hover:text-text-secondary hover:bg-surface-high transition-colors">
            <IconGlobe size={15} />
            Back to bunchcycling.app
          </Link>
          <div className="flex items-center gap-2.5 px-2">
            <Avatar url={profile?.avatar_url} name={profile?.display_name || profile?.username || '?'} size={34} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-text-primary truncate">{profile?.display_name || profile?.username}</p>
              <p className="text-xs text-text-tertiary truncate">@{profile?.username}</p>
            </div>
            <button onClick={signOut} className="text-text-tertiary hover:text-danger transition-colors p-1.5" aria-label="Sign out" title="Sign out">
              <IconLogout size={17} />
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 md:ml-64 pt-14 md:pt-0 min-w-0">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-6 md:py-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

function Wordmark() {
  return (
    <div className="flex items-center gap-2.5">
      <BrandLogo height={22} />
      <span className="text-[10px] font-semibold text-text-tertiary tracking-widest uppercase border border-border rounded px-1.5 py-0.5">Admin</span>
    </div>
  );
}

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex flex-col gap-0.5">
      {NAV.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          onClick={onNavigate}
          className={({ isActive }) =>
            `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-semibold transition-colors ${
              isActive ? 'bg-accent-muted text-accent' : 'text-text-secondary hover:bg-surface-high hover:text-text-primary'
            }`
          }
        >
          <item.icon size={18} />
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
