import React, { useState } from 'react';
import { useAuth } from '@/state/AuthContext';
import { Button } from './Button';
import { IconLock } from './icons';

/** Shown when someone is signed in with a real Supabase session but their
 * `profiles.is_admin` is false — e.g. right after bootstrapping the very
 * first admin account per the instructions at the bottom of schema.sql.
 * Gives them the exact SQL to run rather than a dead end. */
export function AccessGate() {
  const { session, profile, signOut, refreshProfile } = useAuth();
  const [checking, setChecking] = useState(false);
  const userId = session?.user.id ?? '';
  const sql = `update public.profiles set is_admin = true where id = '${userId}';`;

  async function onRecheck() {
    setChecking(true);
    try {
      await refreshProfile();
    } finally {
      setChecking(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-bg">
      <div className="w-full max-w-md text-center">
        <div className="w-14 h-14 rounded-xl bg-surface-high flex items-center justify-center mx-auto mb-5 text-text-tertiary">
          <IconLock size={24} />
        </div>
        <h1 className="text-lg font-bold text-text-primary">This account isn't an admin</h1>
        <p className="text-sm text-text-secondary mt-2 leading-relaxed">
          Signed in as <span className="text-text-primary font-semibold">{profile?.username ?? session?.user.email}</span>. Run this once in
          your Supabase project's SQL Editor to grant admin access:
        </p>
        <pre className="mt-4 bg-ink border border-border rounded-md p-3.5 text-left text-xs font-mono-num text-accent overflow-x-auto select-all">
          {sql}
        </pre>
        <div className="flex items-center justify-center gap-2 mt-5">
          <Button variant="secondary" onClick={signOut}>
            Sign out
          </Button>
          <Button onClick={onRecheck} loading={checking}>
            I ran it — recheck
          </Button>
        </div>
      </div>
    </div>
  );
}
