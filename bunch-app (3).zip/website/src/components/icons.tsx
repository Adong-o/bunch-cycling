import React from 'react';

/** Small inline icon set — kept dependency-free (no icon package) since the
 * admin app only needs a couple dozen glyphs. Stroke-based, 1.8–2px weight,
 * matches the line-icon language @expo/vector-icons' Ionicons uses on mobile. */

type Props = { size?: number; className?: string };
const base = (size = 18) => ({ width: size, height: size, viewBox: '0 0 24 24', fill: 'none' as const, stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const });

export const IconDashboard = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></svg>
);
export const IconUsers = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20c0-3.6 2.9-6.5 6.5-6.5s6.5 2.9 6.5 6.5" /><circle cx="17.5" cy="8.5" r="2.8" /><path d="M15.2 13.7c3 .3 5.3 2.9 5.3 6" /></svg>
);
export const IconTrophy = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M7 4h10v5a5 5 0 0 1-10 0V4Z" /><path d="M7 5H4a1 1 0 0 0-1 1v1a4 4 0 0 0 4 4M17 5h3a1 1 0 0 1 1 1v1a4 4 0 0 1-4 4" /><path d="M12 14v3M9 21h6M9.5 17h5l.5 4H9l.5-4Z" /></svg>
);
export const IconBadge = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><circle cx="12" cy="9" r="6" /><path d="m8.5 14-1.7 7 5.2-2.8 5.2 2.8-1.7-7" /></svg>
);
export const IconFlag = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M5 3v18" /><path d="M5 4h11l-2.5 4L16 12H5" /></svg>
);
export const IconLogout = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="M16 17l5-5-5-5" /><path d="M21 12H9" /></svg>
);
export const IconPlus = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M12 5v14M5 12h14" /></svg>
);
export const IconTrash = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M3 6h18" /><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6" /><path d="M10 11v6M14 11v6" /></svg>
);
export const IconEdit = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
);
export const IconSearch = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
);
export const IconCheck = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M20 6 9 17l-5-5" /></svg>
);
export const IconX = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M18 6 6 18M6 6l12 12" /></svg>
);
export const IconUpload = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M12 16V4M7 9l5-5 5 5" /><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" /></svg>
);
export const IconChevronDown = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="m6 9 6 6 6-6" /></svg>
);
export const IconMenu = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M3 6h18M3 12h18M3 18h18" /></svg>
);
export const IconShield = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M12 2 4 5v6c0 5 3.4 8.7 8 10 4.6-1.3 8-5 8-10V5l-8-3Z" /></svg>
);
export const IconBike = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><circle cx="6" cy="17" r="3.5" /><circle cx="18" cy="17" r="3.5" /><path d="M6 17 10 8h4M18 17 13 8M10 8H8" /></svg>
);
export const IconLock = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><rect x="4" y="11" width="16" height="9" rx="2" /><path d="M8 11V7a4 4 0 1 1 8 0v4" /></svg>
);
export const IconGlobe = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18Z" /></svg>
);
export const IconMessage = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5Z" /></svg>
);
export const IconBluetooth = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M6.5 6.5 17.5 17.5 12 23 12 1 17.5 6.5 6.5 17.5" /></svg>
);
export const IconRoute = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><circle cx="6" cy="18" r="3" /><circle cx="18" cy="6" r="3" /><path d="M9 18h7a3 3 0 0 0 3-3v-1a3 3 0 0 0-3-3H8a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3h7" /></svg>
);
export const IconFlame = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M12 22c4.4 0 7-2.7 7-6.5 0-2.5-1.1-4.3-2.6-6.2-.2 1.6-1 2.6-1.9 3.1.3-2.8-.5-5.7-3-8.4-.6 2.5-1.8 4-3.4 5.6C6.5 11.2 5 13 5 15.5 5 19.3 7.6 22 12 22Z" /><path d="M12 22c1.8 0 3-1.2 3-3 0-1.2-.6-2-1.3-2.9-.3.7-.8 1.1-1.3 1.3.1-1.2-.3-2.3-1.4-3.4-1 1.3-1.8 2.3-1.8 3.7 0 2.3 1.5 4.3 2.8 4.3Z" opacity="0.5" /></svg>
);
export const IconShare = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><rect x="3" y="5" width="13" height="14" rx="2.5" /><path d="M21 3v7h-7" /><path d="M21 3 13 11" /></svg>
);
export const IconStar = ({ size, className, filled }: Props & { filled?: boolean }) => (
  <svg {...base(size)} className={className} fill={filled ? 'currentColor' : 'none'}>
    <path d="m12 3 2.8 5.9 6.4.8-4.7 4.5 1.2 6.4L12 17.6l-5.7 3 1.2-6.4-4.7-4.5 6.4-.8L12 3Z" />
  </svg>
);
export const IconMountain = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><path d="M2 20 9 7 13 14 16 9 22 20Z" strokeLinejoin="round" /><path d="M7.3 9.6h3.4" opacity="0.5" /></svg>
);
export const IconMail = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m4 7 8 6 8-6" /></svg>
);
export const IconCopy = ({ size, className }: Props) => (
  <svg {...base(size)} className={className}><rect x="8" y="8" width="13" height="13" rx="2" /><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3" /></svg>
);
