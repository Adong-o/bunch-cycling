import React from 'react';

// The real Bunch artwork — the supplied logo and app icon, traced into flat
// SVGs that live in /public so every page shares one cached copy:
//   /logo.svg         full lockup (mark + "bunch") for light backgrounds
//   /logo-light.svg   full lockup for dark backgrounds
//   /mark.svg         three-person mark for light backgrounds
//   /mark-light.svg   three-person mark for dark backgrounds
//   /favicon.svg      the app icon (rounded dark tile)
// Sizing is by height; the width follows the artwork's own aspect ratio so it
// can never be squashed.
const LOGO_ASPECT = 1113 / 262;
const MARK_ASPECT = 756 / 627;

interface BaseProps {
  /** Pick the variant drawn for dark backgrounds. */
  onDark?: boolean;
  className?: string;
}

/** Mark + "bunch" wordmark. */
export function BrandLogo({ height = 28, onDark = false, className = '' }: BaseProps & { height?: number }) {
  return (
    <img
      src={onDark ? '/logo-light.svg' : '/logo.svg'}
      alt="Bunch"
      height={height}
      width={Math.round(height * LOGO_ASPECT)}
      draggable={false}
      className={`block select-none ${className}`}
      style={{ height, width: 'auto' }}
    />
  );
}

/** The three-person mark on its own (decorative — pair it with visible text). */
export function BrandMark({ size = 24, onDark = false, className = '' }: BaseProps & { size?: number }) {
  return (
    <img
      src={onDark ? '/mark-light.svg' : '/mark.svg'}
      alt=""
      aria-hidden="true"
      height={size}
      width={Math.round(size * MARK_ASPECT)}
      draggable={false}
      className={`block select-none ${className}`}
      style={{ height: size, width: 'auto' }}
    />
  );
}

/** The app icon as a tile (dark rounded square with the mark), for compact spots. */
export function AppIcon({ size = 40, className = '' }: { size?: number; className?: string }) {
  return <img src="/favicon.svg" alt="" aria-hidden="true" width={size} height={size} draggable={false} className={`block shrink-0 select-none ${className}`} />;
}
