import React, { useRef, useState } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { TextField, TextArea, Select } from './TextField';
import { Toggle } from './Toggle';
import { IconUpload, IconTrophy } from './icons';
import { useAuth } from '@/state/AuthContext';
import { createChallenge, updateChallenge, uploadChallengeCover, goalValueToBaseUnits, baseUnitsToGoalValue, goalUnitLabel } from '@/lib/api/challenges';
import { getErrorMessage } from '@/lib/errors';
import type { Challenge, ChallengeType } from '@/lib/database.types';

const TYPES: Array<{ value: ChallengeType; label: string }> = [
  { value: 'distance', label: 'Distance' },
  { value: 'elevation', label: 'Elevation' },
  { value: 'duration', label: 'Time' },
  { value: 'ride_count', label: 'Ride count' },
];

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
function daysFromNowISO(days: number): string {
  return new Date(Date.now() + days * 86400000).toISOString().slice(0, 10);
}

export function ChallengeFormModal({
  open,
  challenge,
  onClose,
  onSaved,
}: {
  open: boolean;
  challenge: Challenge | null;
  onClose: () => void;
  onSaved: (c: Challenge) => void;
}) {
  const { profile } = useAuth();
  const isEdit = !!challenge;
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState(challenge?.title ?? '');
  const [description, setDescription] = useState(challenge?.description ?? '');
  const [type, setType] = useState<ChallengeType>(challenge?.type ?? 'distance');
  const [goalInput, setGoalInput] = useState(() => (challenge ? String(baseUnitsToGoalValue(challenge.type, challenge.goal_value)) : '100'));
  const [startDate, setStartDate] = useState(challenge?.start_date ?? todayISO());
  const [endDate, setEndDate] = useState(challenge?.end_date ?? daysFromNowISO(14));
  const [isPublic, setIsPublic] = useState(challenge?.is_public ?? true);
  const [isOfficial, setIsOfficial] = useState(challenge?.is_official ?? true);
  const [coverUrl, setCoverUrl] = useState<string | null>(challenge?.cover_image_url ?? null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function resetAndClose() {
    setError(null);
    onClose();
  }

  function onTypeChange(t: ChallengeType) {
    setType(t);
    if (!isEdit) setGoalInput(t === 'distance' ? '100' : t === 'elevation' ? '1000' : t === 'duration' ? '10' : '10');
  }

  async function onPickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !profile) return;
    setUploading(true);
    setError(null);
    try {
      const url = await uploadChallengeCover(file, profile.id);
      setCoverUrl(url);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    setError(null);

    if (!title.trim()) return setError('Give the challenge a title.');
    const goalNum = Number(goalInput);
    if (!Number.isFinite(goalNum) || goalNum <= 0) return setError('Enter a valid goal.');
    if (startDate > endDate) return setError('End date must be on or after the start date.');

    setSaving(true);
    try {
      const payload = {
        is_official: isOfficial,
        title: title.trim(),
        description: description.trim(),
        cover_image_url: coverUrl,
        type,
        goal_value: goalValueToBaseUnits(type, goalNum),
        start_date: startDate,
        end_date: endDate,
        is_public: isPublic,
      };
      const result = challenge
        ? await updateChallenge(challenge.id, payload)
        : await createChallenge({ ...payload, created_by: profile.id });
      onSaved(result);
      resetAndClose();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} title={isEdit ? 'Edit challenge' : 'New challenge'} width={560}>
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-xs font-semibold text-text-secondary tracking-wide">Cover image</label>
          <div className="mt-1.5 flex items-center gap-3">
            <div className="w-24 h-16 rounded-md bg-surface-high border border-border overflow-hidden flex items-center justify-center shrink-0">
              {coverUrl ? (
                <img src={coverUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                <IconTrophy size={20} className="text-text-tertiary" />
              )}
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={onPickFile} className="hidden" id="cover-upload" />
            <Button type="button" variant="secondary" size="sm" icon={<IconUpload size={14} />} loading={uploading} onClick={() => fileInputRef.current?.click()}>
              {coverUrl ? 'Replace' : 'Upload'}
            </Button>
          </div>
        </div>

        <TextField label="Title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="October Gravel Grind" required />
        <TextArea label="Description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="What's this challenge about?" />

        <div className="grid grid-cols-2 gap-3">
          <Select label="Goal type" value={type} onChange={(e) => onTypeChange(e.target.value as ChallengeType)}>
            {TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
          <TextField
            label={`Goal (${goalUnitLabel(type)})`}
            type="number"
            min={0}
            step="any"
            value={goalInput}
            onChange={(e) => setGoalInput(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <TextField label="Start date" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
          <TextField label="End date" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
        </div>

        <div className="flex items-center justify-between bg-surface-high rounded-md px-3.5 py-3">
          <div>
            <p className="text-sm font-semibold text-text-primary">Public</p>
            <p className="text-xs text-text-tertiary mt-0.5">Listed in Discover. Off = joinable only with the invite code.</p>
          </div>
          <Toggle checked={isPublic} onChange={setIsPublic} label="Public" />
        </div>
        <div className="flex items-center justify-between bg-surface-high rounded-md px-3.5 py-3">
          <div>
            <p className="text-sm font-semibold text-text-primary">Official</p>
            <p className="text-xs text-text-tertiary mt-0.5">Shown with a gold "Official" badge, from the Bunch team.</p>
          </div>
          <Toggle checked={isOfficial} onChange={setIsOfficial} label="Official" />
        </div>

        {error ? <p className="text-sm text-danger">{error}</p> : null}

        <div className="flex justify-end gap-2 mt-1">
          <Button type="button" variant="ghost" onClick={resetAndClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" loading={saving}>
            {isEdit ? 'Save changes' : 'Create challenge'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
