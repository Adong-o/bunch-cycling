import React from 'react';

type Tone = 'accent' | 'success' | 'danger' | 'gold' | 'neutral';

const tones: Record<Tone, string> = {
  accent: 'bg-accent-muted text-accent',
  success: 'bg-success-muted text-success',
  danger: 'bg-danger-muted text-danger',
  gold: 'bg-gold-muted text-gold',
  neutral: 'bg-surface-high text-text-secondary border border-border-strong',
};

export function Pill({ tone = 'neutral', icon, children }: { tone?: Tone; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${tones[tone]}`}>
      {icon}
      {children}
    </span>
  );
}
