import React from 'react';
import { Spinner } from './Button';

export function LoadingView({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 py-24 text-text-tertiary">
      <Spinner className="h-6 w-6" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-20 px-6 text-center">
      {icon ? <div className="w-14 h-14 rounded-xl bg-surface-high flex items-center justify-center text-text-tertiary mb-1">{icon}</div> : null}
      <h3 className="text-base font-semibold text-text-primary">{title}</h3>
      {description ? <p className="text-sm text-text-secondary max-w-sm">{description}</p> : null}
      {action}
    </div>
  );
}
