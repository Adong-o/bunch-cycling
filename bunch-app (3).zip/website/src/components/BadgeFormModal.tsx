import React, { useState } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { TextField, TextArea, Select } from './TextField';
import { createBadge, updateBadge, CRITERIA_TYPES, criteriaUnitLabel, criteriaValueToBase, baseToCriteriaValue } from '@/lib/api/badges';
import { getErrorMessage } from '@/lib/errors';
import type { Badge, BadgeCriteriaType } from '@/lib/database.types';

function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export function BadgeFormModal({
  open,
  badge,
  onClose,
  onSaved,
}: {
  open: boolean;
  badge: Badge | null;
  onClose: () => void;
  onSaved: (b: Badge) => void;
}) {
  const isEdit = !!badge;
  const [name, setName] = useState(badge?.name ?? '');
  const [slug, setSlug] = useState(badge?.slug ?? '');
  const [slugTouched, setSlugTouched] = useState(isEdit);
  const [description, setDescription] = useState(badge?.description ?? '');
  const [icon, setIcon] = useState(badge?.icon ?? '🏅');
  const [criteriaType, setCriteriaType] = useState<BadgeCriteriaType>(badge?.criteria_type ?? 'total_rides');
  const [valueInput, setValueInput] = useState(() => (badge ? String(baseToCriteriaValue(badge.criteria_type, badge.criteria_value)) : '10'));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function onNameChange(v: string) {
    setName(v);
    if (!slugTouched) setSlug(slugify(v));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!name.trim()) return setError('Give the badge a name.');
    if (!/^[a-z0-9-]{2,40}$/.test(slug)) return setError('Slug must be lowercase letters, numbers and hyphens only.');
    if (!description.trim()) return setError('Add a short description — riders see this on the badge.');
    if (!icon.trim()) return setError('Pick an emoji for the icon.');
    const n = Number(valueInput);
    if (!Number.isFinite(n) || n <= 0) return setError('Enter a valid target.');

    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        slug,
        description: description.trim(),
        icon: icon.trim(),
        criteria_type: criteriaType,
        criteria_value: criteriaValueToBase(criteriaType, n),
      };
      const result = badge ? await updateBadge(badge.id, payload) : await createBadge(payload);
      onSaved(result);
      onClose();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(/unique|duplicate/i.test(msg) ? 'That slug is already taken.' : msg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? 'Edit badge' : 'New badge'} width={480}>
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <div className="flex gap-3">
          <div className="w-20">
            <TextField label="Icon" value={icon} onChange={(e) => setIcon(e.target.value)} className="text-center text-xl" maxLength={4} />
          </div>
          <div className="flex-1">
            <TextField label="Name" value={name} onChange={(e) => onNameChange(e.target.value)} placeholder="Century Club" />
          </div>
        </div>

        <TextField
          label="Slug"
          value={slug}
          onChange={(e) => {
            setSlugTouched(true);
            setSlug(slugify(e.target.value));
          }}
          placeholder="century-club"
          hint="Permanent id — changing it on an existing badge is safe, riders never see it."
        />

        <TextArea
          label="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={2}
          placeholder="Rode 100 km in a single ride."
        />

        <div className="grid grid-cols-2 gap-3">
          <Select label="Criteria" value={criteriaType} onChange={(e) => setCriteriaType(e.target.value as BadgeCriteriaType)}>
            {CRITERIA_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
          <TextField
            label={`Target (${criteriaUnitLabel(criteriaType)})`}
            type="number"
            min={0}
            step="any"
            value={valueInput}
            onChange={(e) => setValueInput(e.target.value)}
          />
        </div>

        {error ? <p className="text-sm text-danger">{error}</p> : null}

        <div className="flex justify-end gap-2 mt-1">
          <Button type="button" variant="ghost" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" loading={saving}>
            {isEdit ? 'Save changes' : 'Create badge'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
