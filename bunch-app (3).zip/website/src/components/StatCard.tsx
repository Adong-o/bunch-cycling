import React from 'react';

export function StatCard({
  label,
  value,
  icon,
  tone = 'default',
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
  tone?: 'default' | 'accent' | 'gold';
}) {
  const iconBg = tone === 'accent' ? 'bg-accent-muted text-accent' : tone === 'gold' ? 'bg-gold-muted text-gold' : 'bg-surface-high text-text-secondary';
  return (
    <div className="bg-surface border border-border rounded-lg p-5 flex items-center gap-4">
      {icon ? <div className={`w-11 h-11 rounded-md flex items-center justify-center shrink-0 ${iconBg}`}>{icon}</div> : null}
      <div className="min-w-0">
        <p className="font-mono-num text-2xl font-bold text-text-primary leading-tight truncate">{value}</p>
        <p className="text-xs text-text-tertiary mt-0.5">{label}</p>
      </div>
    </div>
  );
}
