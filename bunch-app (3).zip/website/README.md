# Bunch Website

Two halves under one Vite app: the public marketing site at `/` (what Bunch is, what it costs, the
legal pages) and the admin console nested entirely under `/admin` (grant Premium, promote admins,
launch official challenges, curate the badge catalog, moderate ride comments). Same Supabase
project as the mobile app, same anon key, no service_role key anywhere — every admin action works
purely because `mobile/supabase/schema.sql`'s RLS policies check `is_admin(auth.uid())` against your own
signed-in profile. A visitor to the marketing site never waits on a Supabase session check — see
the comment at the top of `src/App.tsx`.

## Setup

```bash
cd website
npm install
npm run dev
```

Opens at `http://localhost:5173` — the marketing homepage. The admin console is at
`http://localhost:5173/admin`. `.env` is already filled in with the same Supabase project the
mobile app uses — if you ever point this at a different project, copy `.env.example` to `.env.local`
and fill in your own values.

**One extra SQL block if your database predates this app:** the admin dashboard needs
`admin_dashboard_stats()`, a small function added near the end of `mobile/supabase/schema.sql`
(search for "11. ADMIN DASHBOARD STATS"). If you ran `schema.sql` before this app existed, open the Supabase SQL
editor and run just that block once — it's a plain `create or replace function`, safe to run
on top of your existing data.

### Bootstrapping your first admin

1. Go to `/admin`, click "Create an account" on the sign-in screen, and sign up (same flow as the
   mobile app — a `profiles` row is created automatically).
2. You'll land on an "this account isn't an admin" screen with a ready-to-run SQL snippet — copy it
   into the Supabase SQL editor and run it. That flips `is_admin = true` on your new account.
3. Back in the app, click "I ran it — recheck". You're in, and can promote further admins from the
   Users page from now on — no more manual SQL needed after the first one.

## What's here

**Marketing site** (`src/pages/HomePage.tsx`, `PrivacyPage.tsx`, `TermsPage.tsx`) — a single-page
scroll (hero, features, how it works, pricing, FAQ, final CTA) plus the two legal pages, sharing
`mobile`'s pricing/limit constants (`src/lib/constants.ts`) so the numbers never drift out of sync
between the app and the site.

**Admin console** (everything under `/admin`):
- **Dashboard** — riders, Premium riders, rides logged, distance/elevation totals, active
  challenges, badge catalog size, admin count. All computed server-side by `admin_dashboard_stats()`.
- **Users** — search by name/username, grant or revoke Premium (revoke asks for confirmation),
  promote or demote admins (both directions confirm — demoting yourself locks you out of admin
  tools immediately, the dialog says so).
- **Challenges** — every challenge, official and rider-made. Create an official challenge with a
  cover image (upload goes to the `challenge-covers` storage bucket, which only admins can write
  to), edit or delete any challenge. Dates use plain HTML date inputs — no picker library needed
  on web.
- **Badges** — full CRUD on the achievement catalog (`badges` table): icon (emoji), name,
  description, the stat it tracks, and the target. Deleting a badge removes it from everyone who
  already earned it — the confirm dialog says so.
- **Moderation** — the most recent ride comments platform-wide, with one-click delete.

## Notes on scope

- **No service_role key, anywhere.** Every privileged action is a normal authenticated Supabase
  call that works because the signed-in account's own `profiles.is_admin` is `true`. See the
  policy comments in `mobile/supabase/schema.sql` (`prevent_privilege_escalation()`, and the `is_admin()`
  checks throughout the RLS policies) for the exact mechanism.
- **Challenge goal values and badge targets convert to the same base units the mobile app uses**
  (meters for distance/elevation, seconds for duration, a plain count for everything else) —
  reverse-engineered from `recompute_challenge_progress()` and `check_and_award_badges()` in
  schema.sql. Both forms work in km/hours for admin convenience; there's no per-admin unit
  preference the way riders have one.
- **This sandbox couldn't reach the npm registry** to run an actual `npm install`/build here (a
  proxy policy block, not a code issue) — same constraint noted elsewhere in this project for the
  mobile app. Every file was written carefully and cross-checked by hand (every import matched
  against its export, every Supabase query's embedded-select typing pinned explicitly with
  `.returns<T>()` rather than left to inference), but it has not run through a real `tsc`/`vite
  build` yet. Run `npm run build` after `npm install` — if anything surfaces, it'll be a small,
  easy-to-spot fix, not an architectural problem.
