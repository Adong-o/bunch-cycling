import type { Config } from 'tailwindcss';

// Mirrors mobile/src/theme/colors.ts exactly, so the site and the admin
// console read as the same product as the phone app rather than a generic
// bootstrap panel. v1.2: moved off the old dark v1 palette onto the current
// light one — see mobile/src/theme/colors.ts for the full rationale.
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#15171B',
        blue: '#4D47FC',
        slate: '#6B7280',
        cream: '#FAFAF8',

        bg: '#FAFAF8',
        surface: '#FFFFFF',
        'surface-high': '#F2F2EF',
        'surface-highest': '#E6E6E2',

        border: '#EAEAE6',
        'border-strong': '#D8D8D3',

        'text-primary': '#15171B',
        'text-secondary': '#6B7280',
        'text-tertiary': '#9B9B94',
        'text-on-accent': '#FFFFFF',

        accent: '#4D47FC',
        'accent-pressed': '#3C37CC',
        'accent-muted': 'rgba(77, 71, 252, 0.10)',

        success: '#17875A',
        'success-muted': 'rgba(23, 135, 90, 0.12)',
        danger: '#C8372F',
        'danger-muted': 'rgba(200, 55, 47, 0.10)',
        gold: '#AD7D0A',
        'gold-muted': 'rgba(173, 125, 10, 0.12)',
      },
      fontFamily: {
        sans: ['Manrope', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        sm: '8px',
        md: '14px',
        lg: '20px',
        xl: '28px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(21, 23, 27, 0.04), 0 4px 16px -4px rgba(21, 23, 27, 0.08)',
        floating: '0 16px 40px -12px rgba(21, 23, 27, 0.18)',
      },
      maxWidth: {
        site: '1120px',
      },
    },
  },
  plugins: [],
} satisfies Config;
